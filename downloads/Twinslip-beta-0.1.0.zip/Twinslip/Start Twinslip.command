#!/bin/bash
# Double-click to open Twinslip. The first time, it connects your agent apps.
# Everything stays on this computer.

cd "$(dirname "$0")" || exit 1
pause() { echo; read -n 1 -s -r -p "Press any key to close this window."; echo; }

echo "Twinslip"
echo "============"
echo

# 1. Node, version 22.13 or newer.
if ! command -v node >/dev/null 2>&1; then
  echo "Twinslip needs Node, a free program. Opening nodejs.org now."
  echo "Download the version marked LTS, install it, then double-click this file again."
  open "https://nodejs.org/en/download"
  pause; exit 1
fi
if ! node -e 'const [a,b]=process.versions.node.split(".").map(Number); process.exit(a>22||(a===22&&b>=13)?0:1)'; then
  echo "Your Node is version $(node --version), and Twinslip needs 22.13 or newer."
  echo "Opening nodejs.org: install the LTS version, then double-click this file again."
  open "https://nodejs.org/en/download"
  pause; exit 1
fi

# 2. Connect the agent apps. Every launch, so a moved folder or a new Node fixes itself;
#    it only changes a setting when something is different, and asks nothing.
if ! node bin/twinslip.js setup --yes --quiet; then
  echo
  echo "No agent app was connected. Send a screenshot of this window to Daniel."
  echo
fi
echo
echo "Next: open your agent app and say: Set up Twinslip"
echo

# 3. Open the ledger in your browser. Closing this window closes the page (your agent keeps recording).
echo "Opening your ledger at http://127.0.0.1:4747 ..."
echo "Keep this window open while you look at it. Your agent records purchases either way."
echo
node bin/twinslip.js
pause
