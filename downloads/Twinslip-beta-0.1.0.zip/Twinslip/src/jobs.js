// Cost per job: what a piece of work cost, across every agent and vendor that touched it.
//
// "What did my agents cost last month?" is the first question. The next one is "what did that
// report, that migration, that campaign cost?", and no bank statement or vendor dashboard can
// answer it, because the work spans vendors and agents. Agents name the job when they report
// (record_purchase / record_usage `job`); this sums it. Only counted (confirmed) spending is
// summed; currencies are never added together.

import { cleanJob, LedgerError } from './ledger.js';
import { formatCents } from './money.js';

/**
 * Jobs, most recently active first: { job, totals: [{ currency, cents }], purchases, verified,
 * agents: [name], merchants: [name], first_on, last_on }. Jobs match without regard to case.
 */
export function jobCosts(ledger, { from = null, to = null, limit = 100, job = null } = {}) {
  const where = ["p.status = 'confirmed'", 'p.job IS NOT NULL'];
  const args = [];
  if (job) { where.push('lower(p.job) = lower(?)'); args.push(job); }
  if (from) { where.push('p.occurred_on >= ?'); args.push(from); }
  if (to) { where.push('p.occurred_on < ?'); args.push(to); }
  const rows = ledger.db.prepare(`
    SELECT lower(p.job) AS k, p.job, p.currency, p.amount_cents, p.verified_at, p.occurred_on, p.merchant, p.id, a.name AS agent
    FROM purchases p JOIN agents a ON a.id = p.agent_id
    WHERE ${where.join(' AND ')} ORDER BY p.id`).all(...args);
  const jobs = new Map();
  // Each job's client, by the rule the user (or the first agent to name one) set (src/clients.js).
  const clients = new Map(ledger.db.prepare('SELECT jc.job_key, c.id, c.name FROM job_clients jc JOIN clients c ON c.id = jc.client_id').all()
    .map((c) => [c.job_key, { id: c.id, name: c.name }]));
  for (const r of rows) {
    const j = jobs.get(r.k) ?? jobs.set(r.k, { k: r.k, job: r.job, totals: new Map(), purchases: 0, verified: 0, agents: new Set(), merchants: new Map(), first_on: r.occurred_on, last_on: r.occurred_on }).get(r.k);
    j.job = r.job; // the latest spelling wins
    j.totals.set(r.currency, (j.totals.get(r.currency) ?? 0) + r.amount_cents);
    j.purchases++;
    if (r.verified_at) j.verified++;
    j.agents.add(r.agent);
    j.merchants.set(r.merchant, (j.merchants.get(r.merchant) ?? 0) + Math.abs(r.amount_cents));
    if (r.occurred_on < j.first_on) j.first_on = r.occurred_on;
    if (r.occurred_on > j.last_on) j.last_on = r.occurred_on;
  }
  return [...jobs.values()]
    .map((j) => ({
      job: j.job,
      totals: [...j.totals].map(([currency, cents]) => ({ currency, cents })).sort((a, b) => b.cents - a.cents),
      purchases: j.purchases,
      verified: j.verified,
      agents: [...j.agents],
      merchants: [...j.merchants].sort((a, b) => b[1] - a[1]).map(([m]) => m),
      first_on: j.first_on,
      last_on: j.last_on,
      client: clients.get(j.k)?.name ?? null,
      client_id: clients.get(j.k)?.id ?? null,
    }))
    .sort((a, b) => b.last_on.localeCompare(a.last_on) || a.job.localeCompare(b.job))
    .slice(0, limit);
}

/** One job by name (any case), or null. */
export function jobCost(ledger, name) {
  const job = cleanJob(name);
  if (!job) throw new LedgerError('job is required: the name the purchases were reported under.');
  return jobCosts(ledger, { job, limit: 1 })[0] ?? null;
}

/** A job's cost in one sentence, for agents to tell the user. */
export function jobSentence(j) {
  const total = j.totals.map((t) => formatCents(t.cents, t.currency)).join(' + ');
  const who = j.agents.length === 1 ? j.agents[0] : `${j.agents.slice(0, -1).join(', ')} and ${j.agents.at(-1)}`;
  const vendors = j.merchants.length <= 3 ? j.merchants.join(', ') : `${j.merchants.slice(0, 3).join(', ')} and ${j.merchants.length - 3} more`;
  const checked = j.verified === j.purchases ? 'all of it checked against the bank or a receipt'
    : j.verified ? `${j.verified} of ${j.purchases} purchases checked against the bank or a receipt` : 'none of it checked against the bank yet';
  const span = j.first_on === j.last_on ? `on ${j.first_on}` : `from ${j.first_on} to ${j.last_on}`;
  return `"${j.job}" cost ${total} ${span}: ${j.purchases} purchase${j.purchases === 1 ? '' : 's'} by ${who}, paid to ${vendors}; ${checked}.`;
}
