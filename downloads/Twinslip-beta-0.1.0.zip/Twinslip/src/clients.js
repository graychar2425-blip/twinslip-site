// Clients: who the user bills for agent work (docs/PRODUCT.md §2).
//
// A job can belong to a client. Agents may name the client when they report (`client`, like
// `job`); the user sets or changes a job's client in the Jobs view, and that rule ("job X goes to
// client Y") decides the client of every purchase in the job, later ones included. An agent's
// naming only fills what nobody decided yet: a job with no rule (which then gets one, marked as
// the agent's) or a purchase with no job. A retry never renames anything. Seeing what a client
// hasn't been billed yet is free; statements and billing are Pro (src/billing.js).

import { cleanJob, LedgerError } from './ledger.js';
import { redact } from './redact.js';
import { tx } from './db.js';

export const CLIENT_NAME_MAX = 80;
const MARKUP_MAX_BP = 10_000; // 100%
const MARKUP_ERROR = 'A handling fee must be a percentage from 0 to 100, like 10 or 12.5.';

/** A client name as people and agents type it: whitespace collapsed, secrets scrubbed; '' means none. */
export function cleanClient(raw) {
  if (raw === undefined || raw === null) return null;
  const name = redact(String(raw)).replace(/\s+/g, ' ').trim().slice(0, CLIENT_NAME_MAX).trim();
  return name || null;
}

/** "10", "12.5%", "" → hundredths of a percent (1000, 1250, 0). Anything else is refused. */
export function parseMarkup(raw) {
  if (raw === null || raw === undefined) return 0;
  const s = String(raw).replace(/\s+/g, '').replace(/%$/, '');
  if (s === '') return 0;
  const m = /^(\d{1,3})(?:\.(\d{1,2}))?$/.exec(s);
  const bp = m ? Number(m[1]) * 100 + Number((m[2] ?? '').padEnd(2, '0')) : NaN;
  if (!Number.isInteger(bp) || bp > MARKUP_MAX_BP) throw new LedgerError(MARKUP_ERROR);
  return bp;
}

const COLUMNS = 'id, name, markup_bp';

export function findClient(ledger, name) {
  const clean = cleanClient(name);
  if (!clean) return null;
  return ledger.db.prepare(`SELECT ${COLUMNS} FROM clients WHERE name = ?`).get(clean) ?? null; // the column compares without case
}

export function getClient(ledger, id) {
  const c = ledger.db.prepare(`SELECT ${COLUMNS} FROM clients WHERE id = ?`).get(Number(id));
  if (!c) throw new LedgerError('No such client.', 404);
  return c;
}

export function listClients(ledger) {
  return ledger.db.prepare(`SELECT ${COLUMNS} FROM clients ORDER BY name COLLATE NOCASE`).all();
}

/** The client with this name (any case), created if it's new. The first spelling is kept. */
export function ensureClient(ledger, name) {
  const clean = cleanClient(name);
  if (!clean) throw new LedgerError('A client name must be 1 to 80 characters.');
  const nowIso = ledger.now().toISOString();
  ledger.db.prepare('INSERT OR IGNORE INTO clients (name, markup_bp, created_at, updated_at) VALUES (?, 0, ?, ?)').run(clean, nowIso, nowIso);
  return findClient(ledger, clean);
}

/** The user renames a client or sets its handling fee (hundredths of a percent). */
export function updateClient(ledger, id, { name, markupBp } = {}) {
  const c = getClient(ledger, id);
  const sets = [];
  const args = [];
  if (name !== undefined) {
    const clean = cleanClient(name);
    if (!clean) throw new LedgerError('A client name must be 1 to 80 characters.');
    const clash = findClient(ledger, clean);
    if (clash && clash.id !== c.id) throw new LedgerError(`There's already a client called ${clash.name}.`, 409);
    sets.push('name = ?');
    args.push(clean);
  }
  if (markupBp !== undefined) {
    if (!Number.isInteger(markupBp) || markupBp < 0 || markupBp > MARKUP_MAX_BP) throw new LedgerError(MARKUP_ERROR);
    sets.push('markup_bp = ?');
    args.push(markupBp);
  }
  if (sets.length) {
    ledger.db.prepare(`UPDATE clients SET ${sets.join(', ')}, updated_at = ? WHERE id = ?`).run(...args, ledger.now().toISOString(), c.id);
  }
  return getClient(ledger, c.id);
}

/** The rule for a job (any case): { client_id, client, set_by }, where a null client means "no client"; or null. */
export function jobClient(ledger, job) {
  const name = cleanJob(job);
  if (!name) return null;
  const r = ledger.db.prepare(`SELECT jc.client_id, c.name AS client, jc.set_by FROM job_clients jc
    LEFT JOIN clients c ON c.id = jc.client_id WHERE jc.job_key = lower(?)`).get(name);
  return r ? { client_id: r.client_id ?? null, client: r.client ?? null, set_by: r.set_by } : null;
}

/**
 * The user decides a job's client (or, with no client, that it has none). Every purchase in the
 * job moves with it, and the rule decides the job's later purchases too. Bills already marked keep
 * the client they were billed to (src/billing.js).
 */
export function setJobClient(ledger, job, client) {
  const name = cleanJob(job);
  if (!name) throw new LedgerError('job is required: the name the purchases were reported under.');
  const out = tx(ledger.db, () => {
    const c = cleanClient(client) ? ensureClient(ledger, client) : null;
    const id = c?.id ?? null;
    ledger.db.prepare(`INSERT INTO job_clients (job_key, client_id, set_by, updated_at) VALUES (lower(?), ?, 'user', ?)
      ON CONFLICT(job_key) DO UPDATE SET client_id = excluded.client_id, set_by = 'user', updated_at = excluded.updated_at`)
      .run(name, id, ledger.now().toISOString());
    ledger.db.prepare('UPDATE purchases SET client_id = ? WHERE job IS NOT NULL AND lower(job) = lower(?)').run(id, name);
    ledger.db.prepare('UPDATE usage_streams SET client_id = ? WHERE lower(job) = lower(?)').run(id, name);
    return { job: name, client_id: id, client: c?.name ?? null };
  });
  ledger.track('client_set', { by: 'user' });
  return out;
}

/**
 * An agent named a client in a report. With a job nobody has decided yet, the job gets that client
 * (a rule marked as the agent's) and its purchases with no client follow. A job that already has a
 * rule keeps it: the agent's naming creates nothing. Returns the named client's id, or null.
 */
export function reportedClient(ledger, { job = null, client = null } = {}) {
  if (!cleanClient(client)) return null;
  const jobName = cleanJob(job);
  if (jobName && ledger.db.prepare('SELECT 1 FROM job_clients WHERE job_key = lower(?)').get(jobName)) return null;
  const c = ensureClient(ledger, client);
  if (jobName) {
    ledger.db.prepare("INSERT INTO job_clients (job_key, client_id, set_by, updated_at) VALUES (lower(?), ?, 'agent', ?)")
      .run(jobName, c.id, ledger.now().toISOString());
    ledger.db.prepare('UPDATE purchases SET client_id = ? WHERE client_id IS NULL AND job IS NOT NULL AND lower(job) = lower(?)').run(c.id, jobName);
    ledger.db.prepare('UPDATE usage_streams SET client_id = ? WHERE client_id IS NULL AND lower(job) = lower(?)').run(c.id, jobName);
    ledger.track('client_set', { by: 'agent' });
  }
  return c.id;
}

/**
 * Settle the client of the row a report landed on: the job's rule if it has one, else the client
 * it already had, else the one reported. Only on the reporting agent's own row or one waiting for
 * the user's tap, like the job. Returns the client's name, or null.
 */
export function assignClient(ledger, purchaseId, { reportedId = null, agentId = null } = {}) {
  const p = ledger.db.prepare('SELECT id, job, client_id, agent_id, status FROM purchases WHERE id = ?').get(Number(purchaseId));
  if (!p) return null;
  let target = p.client_id;
  if (agentId === null || p.agent_id === agentId || p.status === 'candidate') {
    const rule = p.job ? ledger.db.prepare('SELECT client_id FROM job_clients WHERE job_key = lower(?)').get(p.job) : undefined;
    target = rule ? rule.client_id : (p.client_id ?? reportedId ?? null);
    if (target !== p.client_id) ledger.db.prepare('UPDATE purchases SET client_id = ? WHERE id = ?').run(target, p.id);
  }
  return target == null ? null : ledger.db.prepare('SELECT name FROM clients WHERE id = ?').get(target)?.name ?? null;
}

/** An agent's report (record_purchase) landed on `purchaseId`: settle its client. Returns the client's name, or null. */
export function settleReportedClient(ledger, purchaseId, { job = null, client = null, agentId = null } = {}) {
  return tx(ledger.db, () => assignClient(ledger, purchaseId, { reportedId: reportedClient(ledger, { job, client }), agentId }));
}
