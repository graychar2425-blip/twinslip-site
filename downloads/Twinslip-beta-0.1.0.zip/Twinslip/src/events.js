// Local event log for beta instrumentation. Stored only in the user's ledger.db; nothing
// here is ever sent anywhere. Props must never carry merchant names, amounts, agent
// names or descriptions — counts, kinds and durations only. The allowlist enforces it.

import { AsyncLocalStorage } from 'node:async_hooks';

/** Set by the local server while it answers a GET: events written then are throttled. */
export const servingGet = new AsyncLocalStorage();

const ALLOWED_PROPS = {
  app_started: [],
  ui_view: [],
  agent_created: [],
  source_connected: ['kind'],
  sync_attempt: ['kind'],
  sync_completed: ['kind', 'inserted', 'candidates', 'auto'],
  sync_failed: ['kind', 'code'],
  csv_imported: ['inserted', 'candidates', 'auto', 'duplicates'],
  link_imported: ['recorded', 'merged', 'duplicates', 'requested'],
  lnget_imported: ['recorded', 'duplicates', 'already_reported'],
  attribution: ['result', 'via', 'latency_h'],
  attribution_undone: [],
  rule_created: ['action', 'retro'],
  rule_deleted: [],
  pulled_in: [],
  manual_added: [],
  receipt_added: [],
  report_viewed: [],
  agent_reported: ['method', 'merged'],
  receipt_recorded: ['merged'],
  mcp_connected: [],
  receipt_sweep_started: [],
  budget_set: [],
  budget_cleared: [],
  budget_checked: [],
  budget_alert: ['level'],
  exported: ['format', 'rows'],
  onboarding_dismissed: [],
  inbox_batch: ['n'],
  captured: ['source', 'status'],
  share_card: ['channel', 'size'],
  pro_activated: ['seats'],
  pro_deactivated: [],
  pro_gate_hit: ['feature'],
  taxpack_built: ['year'],
  mandate_set: [],
  mandate_cleared: [],
  mandate_checked: ['within'],
  mandate_flagged: ['reasons'],
  mandate_flag_resolved: ['how'],
  usage_recorded: ['new_line'],
  job_cost_checked: [],
  client_set: ['by'],
  unbilled_checked: ['pro'],
  statement_previewed: ['pro'],
  statement_built: ['format'],
  billed: ['lines'],
  billing_undone: [],
  relay_kit_created: [],
  relay_kit_revoked: [],
  relay_pulled: ['applied', 'rejected'],
  // The free plan's limits (src/plan.js): counts only, never which agent or account.
  over_free_limit: ['kind'],
  plan_released: ['n', 'pro'],
  free_agent_chosen: [],
  free_account_chosen: [],
  account_added: ['n'],
};

/**
 * Any event written while the server answers a GET (a page load, a download) is kept at most
 * once per name and props every 10 minutes, so reloading can't grow the log without bound.
 * Actions, the CLI and agents are always recorded exactly.
 */
const THROTTLE_MS = 10 * 60 * 1000;
/** Events older than this are deleted when the app starts. */
export const KEEP_EVENTS_DAYS = 400;

export function track(db, name, props = {}, now = new Date()) {
  const allowed = ALLOWED_PROPS[name];
  if (!allowed) throw new Error(`unknown event: ${name}`);
  const clean = {};
  for (const k of allowed) {
    const v = props[k];
    if (typeof v === 'number' && Number.isFinite(v)) clean[k] = v;
    else if (typeof v === 'string' && /^[a-z_.]{1,32}$/.test(v)) clean[k] = v;
  }
  const json = JSON.stringify(clean);
  if (servingGet.getStore() && db.prepare('SELECT 1 FROM events WHERE name = ? AND props = ? AND at > ?')
    .get(name, json, new Date(now.getTime() - THROTTLE_MS).toISOString())) return;
  db.prepare('INSERT INTO events (at, name, props) VALUES (?, ?, ?)').run(now.toISOString(), name, json);
}

/** Drop events older than KEEP_EVENTS_DAYS. Returns how many went. */
export function pruneEvents(db, now = new Date()) {
  const cutoff = new Date(now.getTime() - KEEP_EVENTS_DAYS * 86400e3).toISOString();
  return Number(db.prepare('DELETE FROM events WHERE at < ?').run(cutoff).changes);
}

export const EVENT_NAMES = Object.keys(ALLOWED_PROPS);
