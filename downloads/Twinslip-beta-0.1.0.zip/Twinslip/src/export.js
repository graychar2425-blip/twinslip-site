// Export the agent bucket as import-ready files: a full CSV for spreadsheets and
// accountants, and the CSV layouts YNAB and Lunch Money import. Files only, on purpose:
// syncing into those apps would mean holding the user's API tokens.
//
// Confirmed purchases are exported, and in the plain CSV also what waits in the inbox from an agent
// the free plan doesn't cover, marked in its own column: export is never limited (src/plan.js).
// Personal spending never leaves through here.

import { LedgerError } from './ledger.js';
import { addDays, isIsoDate } from './dates.js';
import { HELD } from './plan.js';

export const EXPORT_FORMATS = ['csv', 'ynab', 'lunchmoney'];

// Provenance only. Whether a purchase is verified is verified_at alone (docs/design/TRUST-PLAN.md).
const SEEN_BY = { agent: 'agent', email: 'receipt found', alert: 'bank alert found', simplefin: 'bank', csv: 'bank', phone: 'iPhone', webhook: 'webhook', manual: 'added by hand', link: 'Stripe Link', lnget: 'paid through lnget' };

/**
 * One CSV field. Text a spreadsheet would run as a formula (= + - @, tab, CR) gets a leading
 * apostrophe: merchant names come from banks and agents, never trust them to be inert.
 */
export function csvField(v) {
  if (v === null || v === undefined) return '';
  if (typeof v === 'number') return String(v);
  let s = String(v);
  if (/^[=+\-@\t\r]/.test(s)) s = `'${s}`;
  return /[",\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

const decimal = (cents) => (cents / 100).toFixed(2);
const row = (fields) => fields.map((f) => (f && f.raw !== undefined ? f.raw : csvField(f))).join(',');
const num = (s) => ({ raw: s }); // already-formatted amounts: never apostrophe-prefixed

/**
 * Returns { filename, csv, rows, skipped } for confirmed purchases with from <= date < to.
 * YNAB and Lunch Money files hold one currency (default USD); `skipped` counts the rest.
 */
export function exportPurchases(ledger, { format = 'csv', from, to, currency = 'USD' } = {}) {
  if (!EXPORT_FORMATS.includes(format)) throw new LedgerError(`format must be one of: ${EXPORT_FORMATS.join(', ')}.`);
  if (!isIsoDate(from)) throw new LedgerError('from must be a date like 2026-10-01.');
  if (!isIsoDate(to)) throw new LedgerError('to must be a date like 2026-11-01.');
  if (from >= to) throw new LedgerError('from must be before to.');
  if (!/^[A-Z]{3}$/.test(currency)) throw new LedgerError('currency must be a 3-letter code like USD.');

  const confirmed = ledger.confirmedPurchases({ from, to }).map((p) => ({ ...p, waiting: false }));
  // Waiting purchases from agents the free plan doesn't cover: in the plain CSV, marked, never left out.
  const held = format !== 'csv' ? [] : ledger.db.prepare(`
    SELECT p.id, p.occurred_on, p.amount_cents, p.currency, p.merchant, p.held_agent_id AS agent_id, a.name AS agent_name,
           s.kind AS source_kind, p.payment_method, p.verified_at, p.job,
           (SELECT group_concat(DISTINCT s2.kind) FROM purchases c JOIN sources s2 ON s2.id = c.source_id WHERE c.merged_into = p.id) AS also_seen_by,
           (SELECT count(*) FROM receipts r WHERE r.purchase_id = p.id) AS receipt_count
    FROM purchases p JOIN agents a ON a.id = p.held_agent_id JOIN sources s ON s.id = p.source_id
    WHERE p.status = 'candidate' AND p.match_reason = ? AND p.occurred_on >= ? AND p.occurred_on < ?`).all(HELD, from, to)
    .map((p) => ({ ...p, waiting: true }));
  const all = [...confirmed, ...held].sort((a, b) => b.occurred_on.localeCompare(a.occurred_on) || b.id - a.id).reverse(); // oldest first, like a statement
  const skipped = {};
  const picked = format === 'csv' ? all : all.filter((p) => {
    if (p.currency === currency) return true;
    skipped[p.currency] = (skipped[p.currency] ?? 0) + 1;
    return false;
  });
  const verified = (p) => Boolean(p.verified_at);
  const memo = (p) => `Agent: ${p.agent_name}${p.job ? ` · Job: ${p.job}` : ''}${verified(p) ? ' · verified' : ''} · Twinslip`;

  let lines;
  if (format === 'csv') {
    // New columns go last, so a spreadsheet that reads the earlier ones by position keeps working.
    lines = [row(['Date', 'Merchant', 'Amount', 'Currency', 'Agent', 'Payment method', 'Verified', 'Seen by', 'Receipts', 'Ledger ID', 'Job', 'Status'])];
    for (const p of picked) {
      const seen = [...new Set([p.source_kind, ...(p.also_seen_by ? p.also_seen_by.split(',') : [])].map((k) => SEEN_BY[k] ?? k))];
      lines.push(row([p.occurred_on, p.merchant, num(decimal(p.amount_cents)), p.currency, p.agent_name, p.payment_method ?? '',
        verified(p) ? 'yes' : 'no', seen.join(', '), p.receipt_count, p.id, p.job ?? '',
        p.waiting ? 'waiting in your inbox: the free plan covers one agent' : 'counted']));
    }
  } else if (format === 'ynab') {
    lines = [row(['Date', 'Payee', 'Memo', 'Outflow', 'Inflow'])];
    for (const p of picked) {
      const out = p.amount_cents >= 0;
      lines.push(row([p.occurred_on, p.merchant, memo(p), num(out ? decimal(p.amount_cents) : ''), num(out ? '' : decimal(-p.amount_cents))]));
    }
  } else {
    lines = [row(['date', 'payee', 'amount', 'notes', 'tags'])];
    for (const p of picked) {
      lines.push(row([p.occurred_on, p.merchant, num(decimal(p.amount_cents)), memo(p), `Twinslip,Agent: ${p.agent_name}`]));
    }
  }
  ledger.track('exported', { format, rows: picked.length });
  const last = addDays(to, -1);
  return {
    filename: `twinslip${format === 'csv' ? '' : `-${format}`}-${from}_to_${last}.csv`,
    csv: `${lines.join('\r\n')}\r\n`,
    rows: picked.length,
    skipped,
  };
}
