// Two local importers that hold no keys of ours (docs/CONTRACTS.md §8; research Move 5):
//
//   twinslip import --from link-cli   runs the user's own link-cli (Stripe Link's command line)
//                                     with two read-only commands, and records the charges on
//                                     the user's Link wallet. A spend request (an agent asking
//                                     for a card) is never a purchase: it only marks the charge
//                                     made with that card, so the charge waits for a tap.
//   twinslip import --from lnget      reads lnget's payment log: lnget serve on 127.0.0.1:2402,
//                                     or else ~/.lnget/events.db, opened read-only.
//
// How each counts (docs/design/TRUST-PLAN.md: ✓ only for what the agent didn't supply):
//   - Stripe Link's record comes from Stripe, through a tool the user signed in to, not from the
//     agent. A Link charge is independent evidence, like a line on the bank's CSV: it checks (✓)
//     an agent's report of the same charge, and the user's rules sort it.
//   - lnget is the Lightning client the agent itself runs, so its log is agent-supplied
//     evidence, like a receipt the agent found: never the ✓. lnget doesn't say which agent paid,
//     so each finished day's payments to one host become one line that waits in the inbox for a
//     tap. Payments an agent already reported with an L402 receipt (same payment hash) are
//     skipped. Amounts stay in sats (currency SAT): Twinslip looks up no price.
//
// Neither installs anything or holds a credential, and both keep only the date, amount, merchant
// and the line's id. Neither has been run against the real tools: both are tested with made-up
// output in the shapes their docs describe, and the field names they read are listed below.

import { spawn } from 'node:child_process';
import { existsSync } from 'node:fs';
import { join } from 'node:path';
import { LedgerError } from './ledger.js';
import { parseAmountToCents } from './money.js';
import { redact } from './redact.js';
import { addDays, toLocalDate } from './dates.js';
import { dateOf, exponentOf, hostOf, sameName } from './rails.js';

export const LINK_CLI = 'link-cli';
/** The only commands Twinslip runs: both read-only, and the second skips Link's bank-aggregation rows. */
export const LINK_COMMANDS = [
  ['spend-request', 'list', '--include-history', '--format', 'json'],
  ['transactions', 'list', '--origin', 'link', '--format', 'json'],
];
export const LNGET_URL = 'http://127.0.0.1:2402/api/events';
export const lngetDbPath = (home) => join(home, '.lnget', 'events.db');

const MAX_OUTPUT = 32 * 1024 * 1024;
const str = (v) => (typeof v === 'string' && v.trim() ? v.trim() : typeof v === 'number' ? String(v) : null);
const clean = (v) => { const s = str(v); return s ? redact(s).replace(/\s+/g, ' ').trim().slice(0, 80) || null : null; };
const plural = (n, word) => `${n.toLocaleString('en-US')} ${word}${n === 1 ? '' : 's'}`;

/** The user's own link-cli, without a shell and with nothing on its stdin; resolves with what it printed. */
export function runLinkCli(args, { timeoutMs = 60_000 } = {}) {
  return new Promise((resolve, reject) => {
    let out = '';
    let err = '';
    let settled = false;
    const done = (fn, v) => { if (!settled) { settled = true; clearTimeout(timer); fn(v); } };
    const child = spawn(LINK_CLI, args, { stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true });
    const timer = setTimeout(() => child.kill(), timeoutMs);
    child.stdout.setEncoding('utf8').on('data', (d) => {
      out += d;
      if (out.length > MAX_OUTPUT) { child.kill(); done(reject, Object.assign(new Error('its output was too large'), { stderr: '' })); }
    });
    child.stderr.setEncoding('utf8').on('data', (d) => { if (err.length < 4096) err += d; });
    child.on('error', (e) => done(reject, e));
    child.on('close', (code, signal) => (code === 0 ? done(resolve, out)
      : done(reject, Object.assign(new Error(signal ? `it was stopped (${signal}) after ${timeoutMs / 1000} seconds` : `it exited with code ${code}`), { code, stderr: err }))));
  });
}

/** A list of objects from a tool's JSON: an array, or the array under a usual key. Null when there's none. */
function listIn(v) {
  const list = Array.isArray(v) ? v : ['data', 'items', 'results', 'events', 'transactions', 'spend_requests'].map((k) => v?.[k]).find(Array.isArray);
  return list ? list.filter((x) => x && typeof x === 'object' && !Array.isArray(x)) : null;
}

/** The list link-cli printed, and whether it said there is more than it listed (`has_more`). */
function linkList(text, what) {
  let v;
  try { v = JSON.parse(String(text)); } catch {
    throw new LedgerError(`link-cli's ${what} wasn't JSON Twinslip can read (it asks for --format json). Check that your link-cli is up to date. Nothing was recorded.`);
  }
  const list = listIn(v);
  if (!list) throw new LedgerError(`link-cli's ${what} had no list Twinslip recognizes. Nothing was recorded.`);
  return { list, more: v?.has_more === true || v?.hasMore === true };
}

/**
 * An amount from Stripe-style JSON: an integer is in the currency's minor units (cents, yen), a
 * decimal string in major units. `type` says a refund or a purchase where it can; otherwise a
 * positive amount is money spent. Returns { cents, currency } in the ledger's units, or null.
 */
function linkAmount(x) {
  const currency = String(x.currency ?? x.amount?.currency ?? 'usd').toUpperCase();
  if (!/^[A-Z]{3}$/.test(currency)) return null;
  const raw = x.amount && typeof x.amount === 'object' ? x.amount.value ?? x.amount.amount : x.amount;
  let cents = null;
  const minor = typeof raw === 'number' ? raw : typeof raw === 'string' && /^-?\d+$/.test(raw.trim()) ? Number(raw) : null;
  if (minor !== null && Number.isSafeInteger(minor)) cents = Math.round(minor * 10 ** (2 - exponentOf(currency)));
  else if (typeof raw === 'string') cents = parseAmountToCents(raw);
  if (!Number.isSafeInteger(cents) || cents === 0) return null;
  const kind = String(x.type ?? x.kind ?? '');
  if (/refund|return|revers/i.test(kind)) cents = -Math.abs(cents); // not "credit": a credit_card_purchase is a purchase
  else if (/purchase|charge|capture|payment|debit|spend/i.test(kind)) cents = Math.abs(cents);
  return { cents, currency };
}

const linkMerchant = (x) => clean(x.merchant_name ?? (typeof x.merchant === 'string' ? x.merchant : x.merchant?.name) ?? x.merchant_data?.name ?? x.description)
  ?? hostOf(x.merchant_url ?? x.merchant?.url);
const linkDate = (x) => dateOf(x.created ?? x.created_at ?? x.date ?? x.transacted_at ?? x.posted_at ?? x.authorized_at);

/**
 * `twinslip import --from link-cli`. `run(args)` runs link-cli (tests pass a fake; the real
 * tool is never run by the tests). Returns the counts describeLinkImport says.
 */
export async function importLinkCli(ledger, { run = runLinkCli, dryRun = false } = {}) {
  const outputs = [];
  for (const args of LINK_COMMANDS) {
    try {
      outputs.push(await run(args));
    } catch (err) {
      if (err?.code === 'ENOENT') {
        throw new LedgerError("link-cli isn't installed on this computer (or isn't on your PATH). Twinslip runs your own copy of Stripe's " +
          'link-cli and never installs it or holds its sign-in: install it and sign in, then run this again.');
      }
      const why = redact(String(err?.stderr || err?.message || err)).replace(/\s+/g, ' ').trim().slice(0, 200);
      throw new LedgerError(`link-cli didn't list your ${args[0] === 'spend-request' ? 'spend requests' : 'transactions'}: ${why}. ` +
        'Check that it works and is signed in (run it yourself), then try again. Nothing was recorded.');
    }
  }
  const { list: requests, more: moreRequests } = linkList(outputs[0], 'spend-request list');
  const { list: txns, more: moreCharges } = linkList(outputs[1], 'transactions list');
  const more = { charges: moreCharges, requests: moreRequests };
  // A spend request is an agent asking for a card; it was approved unless it says otherwise.
  const open = requests.map((x) => ({ merchant: linkMerchant(x), amount: linkAmount(x), date: linkDate(x), status: String(x.status ?? '') }))
    .filter((x) => x.merchant && x.amount && x.date && !/den(y|ied)|reject|cancel|fail|pend/i.test(x.status));
  let skipped = 0;
  let unreadable = 0;
  const rows = [];
  for (const x of txns) {
    if (/pend|declin|fail|cancel|void|revers|expir|reject/i.test(String(x.status ?? ''))) { skipped++; continue; }
    const id = str(x.id ?? x.transaction_id);
    const amount = linkAmount(x);
    const merchant = linkMerchant(x);
    const date = linkDate(x);
    if (!id || !amount || !merchant || !date) { unreadable++; continue; }
    rows.push({ id, merchant, date, ...amount, requested: false });
  }
  // Each spend request's card pays once: the first charge that fits it (merchant, at most the
  // approved amount, from the day before the request to three days after) was the agent's.
  for (const t of rows) {
    if (t.cents <= 0) continue;
    const i = open.findIndex((q) => q.amount.currency === t.currency && t.cents <= q.amount.cents + Math.max(1, Math.round(q.amount.cents / 100))
      && t.date >= addDays(q.date, -1) && t.date <= addDays(q.date, 3) && sameName(q.merchant, t.merchant));
    if (i >= 0) { t.requested = true; open.splice(i, 1); }
  }
  const requested = rows.filter((t) => t.requested).length;
  if (dryRun) return { dryRun: true, read: txns.length, requests: requests.length, toRecord: rows.length, requested, skipped, unreadable, more };
  const sourceId = ledger.ensureSource('link', 'Stripe Link (link-cli)');
  const known = new Set(ledger.db.prepare('SELECT external_id FROM purchases WHERE source_id = ?').all(sourceId).map((x) => x.external_id));
  const r = ledger.ingest(sourceId, rows.map((t) => ({
    externalId: `link:${t.id}`, occurredOn: t.date, amountCents: t.cents, currency: t.currency,
    merchant: t.merchant, description: t.merchant, requestedByAgent: t.requested,
  })));
  const now = ledger.now().toISOString();
  ledger.db.prepare('UPDATE sources SET last_attempt_at = ?, last_success_at = ?, last_error = NULL WHERE id = ?').run(now, now, sourceId);
  ledger.markChecked('link');
  // Only charges that now wait in the inbox because an agent asked for the card (not a retry, and
  // not one already counted for an agent) are said to.
  const waitingRequested = rows.filter((t, i) => t.requested && !known.has(`link:${t.id}`)
    && ['candidate'].includes(ledger.getPurchase(r.ids[i]).status) && ledger.getPurchase(r.ids[i]).match_reason === 'agent_requested').length;
  ledger.track('link_imported', { recorded: r.inserted, merged: r.merged, duplicates: r.duplicates, requested: waitingRequested });
  return { read: txns.length, requests: requests.length, recorded: r.inserted, merged: r.merged, checked: r.checked, waiting: r.candidates,
    duplicates: r.duplicates, requested: waitingRequested, skipped, unreadable, more };
}

export function describeLinkImport(r) {
  if (r.dryRun) {
    return `Dry run: link-cli listed ${plural(r.read, 'charge')} and ${plural(r.requests, 'spend request')}; ${r.toRecord} would be imported` +
      `${r.requested ? ` (${r.requested} made with a card an agent asked for)` : ''}. Nothing was recorded.`;
  }
  const out = [`Stripe Link: read ${plural(r.read, 'charge')} and ${plural(r.requests, 'spend request')} through your link-cli.`];
  out.push(`${r.recorded} new${r.waiting ? `, ${r.waiting} waiting in your inbox for one tap (Mine or Agents?)` : ''}` +
    `${r.requested ? `, ${r.requested} made with a card an agent asked for` : ''}.`);
  if (r.merged) out.push(`${r.merged} matched purchases already recorded${r.checked ? `; ${plural(r.checked, 'agent report')} now checked ✓` : ''}.`);
  if (r.duplicates) out.push(`${r.duplicates} already imported.`);
  if (r.skipped) out.push(`${r.skipped} pending, declined or cancelled, left out (pending ones come in once they post).`);
  if (r.unreadable) out.push(`${r.unreadable} had no amount, merchant or date Twinslip could read, left out.`);
  if (r.more?.charges) out.push(`link-cli said it has more charges than it listed: only the first ${plural(r.read, 'charge')} were read.`);
  if (r.more?.requests) out.push(`It also has more spend requests than it listed, so a charge on a card an agent asked for may not be marked.`);
  return out.join(' ');
}

// ── lnget ───────────────────────────────────────────────────────────────────

async function readLngetDb(path, max) {
  const { DatabaseSync } = await import('node:sqlite');
  let db;
  try { db = new DatabaseSync(path, { readOnly: true }); } catch (err) {
    throw new LedgerError(`Couldn't open lnget's events.db (${redact(String(err.message)).slice(0, 120)}). Nothing was recorded.`);
  }
  try {
    const tables = db.prepare("SELECT name FROM sqlite_master WHERE type = 'table'").all().map((t) => t.name);
    const table = tables.find((t) => t === 'events') ?? tables.find((t) => /event|payment/i.test(t));
    if (!table) throw new LedgerError("lnget's events.db has no table of events Twinslip recognizes. Nothing was recorded.");
    const name = `"${table.replaceAll('"', '""')}"`;
    let rows;
    try { rows = db.prepare(`SELECT * FROM ${name} ORDER BY rowid DESC LIMIT ?`).all(max + 1); } catch { rows = db.prepare(`SELECT * FROM ${name} LIMIT ?`).all(max + 1); }
    return rows;
  } finally {
    db.close();
  }
}

/** A payment's millisatoshis, fees included: *_msat fields, else *_sat fields (a bare `amount` is sats). */
function msatOf(e) {
  const num = (v) => (v === undefined || v === null || v === '' ? null : Number(v));
  const msat = num(e.amount_msat ?? e.amountMsat ?? e.value_msat);
  const sat = num(e.amount_sat ?? e.amount_sats ?? e.amountSat ?? e.amountSats ?? e.cost_sat ?? e.price_sat ?? e.sats ?? e.amount);
  const base = msat ?? (sat === null ? null : sat * 1000);
  if (base === null || !Number.isFinite(base)) return null;
  const feeMsat = num(e.fee_msat ?? e.feeMsat);
  const feeSat = num(e.fee_sat ?? e.fee_sats ?? e.feeSat ?? e.fee);
  const fee = feeMsat ?? (feeSat === null ? 0 : feeSat * 1000);
  return Math.round(base + (Number.isFinite(fee) && fee > 0 ? fee : 0));
}

/**
 * `twinslip import --from lnget`. `fetch` reaches lnget serve on this computer only; `dbPath` is
 * lnget's events.db, read when lnget serve isn't running. Returns the counts describeLngetImport says.
 */
export async function importLnget(ledger, { fetch = globalThis.fetch, dbPath = null, dryRun = false, timeoutMs = 5000, maxEvents = 200_000 } = {}) {
  let events = null;
  let from = null;
  let answered = false;
  try {
    const res = await fetch(LNGET_URL, { signal: AbortSignal.timeout(timeoutMs), headers: { Accept: 'application/json' } });
    if (res.ok) { answered = true; events = listIn(await res.json()); from = 'lnget serve on 127.0.0.1:2402'; }
  } catch { /* lnget serve isn't running: read its file instead */ }
  if (answered && !events) throw new LedgerError("lnget serve answered, but not with a list of events Twinslip recognizes. Nothing was recorded.");
  if (!events) {
    if (!dbPath || !existsSync(dbPath)) {
      throw new LedgerError("Couldn't find lnget's payment log: nothing answered on 127.0.0.1:2402 (lnget serve), and there's no ~/.lnget/events.db. " +
        'Is lnget installed, and has it paid for anything yet? Twinslip never installs it.');
    }
    events = await readLngetDb(dbPath, maxEvents);
    from = dbPath;
  }
  // Past the read limit, the newest events (the file is read newest first) are kept, and it's said.
  const partial = events.length > maxEvents;
  if (partial) events = events.slice(0, maxEvents);
  const today = toLocalDate(ledger.now());
  // Payments an agent already reported with an L402 receipt, by payment hash.
  const reported = new Set(ledger.db.prepare("SELECT reference FROM rail_receipts WHERE rail = 'l402' AND reference IS NOT NULL").all()
    .map((x) => x.reference.toLowerCase()));
  const groups = new Map();
  const n = { payments: 0, alreadyReported: 0, today: 0, skipped: 0, unreadable: 0 };
  for (const e of events) {
    const type = str(e.type ?? e.event ?? e.event_type ?? e.kind);
    if (type && /fail|error|cancel|declin|timeout|expir|pend/i.test(type)) { n.skipped++; continue; }
    if (type && (!/pay|l402|purchase|spend/i.test(type) || /challenge|request|quote/i.test(type))) continue; // not a payment
    if (e.success === false || e.success === 0 || /fail|error|pend|cancel|declin|timeout|expir/i.test(str(e.status ?? e.state) ?? '')) { n.skipped++; continue; }
    const msat = msatOf(e);
    const host = hostOf(e.url ?? e.target ?? e.endpoint ?? e.resource ?? e.uri) ?? clean(e.host ?? e.domain);
    const date = dateOf(e.timestamp ?? e.time ?? e.created_at ?? e.createdAt ?? e.ts ?? e.paid_at);
    if (!msat || msat <= 0 || !host || !date) { n.unreadable++; continue; }
    n.payments++;
    const ph = str(e.payment_hash ?? e.paymentHash ?? e.hash)?.toLowerCase();
    if (ph && reported.has(ph)) { n.alreadyReported++; continue; }
    if (date >= today) { n.today++; continue; } // a day is imported once it's over, so its line never changes
    const key = `${host}|${date}`;
    const g = groups.get(key) ?? { host, date, msat: 0, count: 0 };
    g.msat += msat;
    g.count++;
    groups.set(key, g);
  }
  const lines = [...groups.values()].filter((g) => Math.round(g.msat / 10) > 0);
  if (dryRun) return { dryRun: true, from, ...n, toRecord: lines.length, partial: partial ? maxEvents : 0 };
  const sourceId = ledger.ensureSource('lnget', 'lnget (Lightning)');
  // Sats as currency SAT, in the ledger's hundredths: 1 sat is 100, so a millisatoshi is a tenth.
  const r = ledger.ingest(sourceId, lines.map((g) => ({
    externalId: `lnget:${g.host}:${g.date}`, occurredOn: g.date, amountCents: Math.round(g.msat / 10), currency: 'SAT',
    merchant: g.host, description: `${plural(g.count, 'payment')} through lnget`,
  })));
  const now = ledger.now().toISOString();
  ledger.db.prepare('UPDATE sources SET last_attempt_at = ?, last_success_at = ?, last_error = NULL WHERE id = ?').run(now, now, sourceId);
  ledger.markChecked('lnget');
  ledger.track('lnget_imported', { recorded: r.inserted, duplicates: r.duplicates, already_reported: n.alreadyReported });
  return { from, ...n, recorded: r.inserted, merged: r.merged, waiting: r.candidates, duplicates: r.duplicates, partial: partial ? maxEvents : 0 };
}

export function describeLngetImport(r) {
  if (r.dryRun) return `Dry run: lnget (${r.from}) lists ${plural(r.payments, 'payment')}; ${plural(r.toRecord, 'line')} would be imported. Nothing was recorded.`;
  const out = [`lnget (${r.from}): read ${plural(r.payments, 'payment')}.`];
  if (r.recorded) out.push(`${plural(r.recorded, 'new line')} (one per host per day, in sats) ${r.recorded === 1 ? 'waits' : 'wait'} in your inbox for one tap: Mine or Agents?`);
  if (r.duplicates) out.push(`${plural(r.duplicates, 'day')} already imported.`);
  if (r.alreadyReported) out.push(`${r.alreadyReported} already reported by your agents (same payment hash), so not added again.`);
  if (r.today) out.push(`Today's ${plural(r.today, 'payment')} ${r.today === 1 ? 'waits' : 'wait'} until the day is over: run this again tomorrow.`);
  if (r.skipped) out.push(`${r.skipped} failed or pending, left out.`);
  if (r.unreadable) out.push(`${r.unreadable} had no amount, host or time Twinslip could read, left out.`);
  if (r.partial) out.push(`The log is longer than Twinslip reads at once: only the newest ${plural(r.partial, 'event')} were read.`);
  return out.join(' ');
}
