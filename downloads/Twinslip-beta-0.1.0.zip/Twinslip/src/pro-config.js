// Which checkout store sells Twinslip Pro. Placeholders until Daniel creates the Lemon
// Squeezy (or Paddle) account; while they're null, Pro simply isn't on sale yet and the app
// says so. Fill these in from the Lemon Squeezy dashboard: Store ID and Product ID(s).
export const PRO_CONFIG = {
  provider: 'lemonsqueezy',
  storeId: null, // e.g. 12345
  productIds: [], // e.g. [67890] (the Pro product; annual and monthly variants share it)
  // A seat is one person, on up to this many of their computers (Daniel, 2026-10-06). In the
  // checkout, set each key's activation limit to seats x this number; the app divides it back.
  computersPerSeat: 2,
  api: 'https://api.lemonsqueezy.com/v1/licenses',
  siteUrl: 'https://twinslip.example', // SITE_URL: Daniel picks the domain; never point DNS from here
  buyUrl: 'https://twinslip.example/pro', // the website's Pro page (SITE_URL + /pro)
};
