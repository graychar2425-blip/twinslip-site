import { openDb, tx, setMeta, INDEPENDENT_SQL, INDEPENDENT_KINDS } from './db.js';
import { formatCents } from './money.js';
import { findSubscriptions } from './subscriptions.js';
import { NOT_SPENDING } from './totals.js';
import { track } from './events.js';
import { detectKnownMerchant, displayMerchant, merchantKey } from './merchants.js';
import { addDays, addMonths, isIsoDate, monthKey, toLocalDate } from './dates.js';
import { createHash, randomUUID } from 'node:crypto';
import { redact } from './redact.js';
import { matchRefund } from './refunds.js';
import { flagIfOutside } from './mandates.js';

/**
 * A job: the piece of work a purchase paid for, as the agent names it ("Q3 market report").
 * Whitespace is collapsed and anything that looks like a secret is scrubbed; '' means none.
 */
export function cleanJob(raw) {
  if (raw === undefined || raw === null) return null;
  const job = redact(String(raw)).replace(/\s+/g, ' ').trim().slice(0, 80);
  return job || null;
}

export const PAYMENT_METHODS = ['card', 'prepaid_credits', 'crypto', 'bank_transfer', 'invoice', 'other'];

/** Agent apps setup connects, and the name each one's agent starts with (the user can rename it). */
export const AGENT_KEYS = { 'claude-desktop': 'Claude', 'claude-code': 'Claude Code', cursor: 'Cursor', windsurf: 'Windsurf' };

/** Sources that can independently witness the same charge. */
export function sourceGroup(kind) {
  return kind === 'simplefin' || kind === 'csv' ? 'bank' : kind; // phone, alert, webhook: each its own witness
}

/** What an agent supplies: its own reports, and the receipts and bank alerts it finds in email. Never proof on their own. */
export const AGENT_SUPPLIED = ['agent', 'email', 'alert'];
export const isIndependent = (kind) => INDEPENDENT_KINDS.includes(kind);

/** The most an agent, receipt, alert or capture event may say one purchase cost: 100,000.00. */
export const MAX_REPORTED_CENTS = 10_000_000;
/** Test captures one agent may send in an hour, and how many recent ones are kept. */
export const CAPTURE_CHECKS_PER_HOUR = 60;
export const CAPTURE_CHECKS_KEPT = 100;
/** Writes one agent may add in a rolling hour, across every record tool. */
export const AGENT_HOURLY_LIMIT = 300;
/** Dates an agent, receipt, alert or capture event may give: up to 400 days back, 1 day ahead (time zones). */
export const DATE_WINDOW = { back: 400, ahead: 1 };

/** Refuse a reported date outside DATE_WINDOW, with a reason. */
export function checkReportedDate(date, today, field = 'date') {
  if (!isIsoDate(date)) throw new LedgerError(`${field} must be a real date like 2026-10-05.`);
  if (date > addDays(today, DATE_WINDOW.ahead)) throw new LedgerError(`${field} can't be later than tomorrow.`);
  if (date < addDays(today, -DATE_WINDOW.back)) throw new LedgerError(`${field} must be within the last ${DATE_WINDOW.back} days.`);
}

/** Refuse a reported amount over the cap, with a reason. */
export function checkReportedAmount(cents) {
  if (Math.abs(cents) > MAX_REPORTED_CENTS) {
    throw new LedgerError('Amounts over 100,000.00 are refused. If this is real, ask the user to add it in Twinslip by hand.');
  }
}

/**
 * An identifier (a reference, an email's message id) as stored. Normal ones stay readable.
 * One that looks like a secret is stored only as a hash of the original: distinct secrets stay
 * distinct, a retry still matches, and the secret itself never reaches the database.
 */
export function safeId(raw, max = 120) {
  const s = String(raw);
  return s.length <= max && redact(s) === s ? s : `h:${createHash('sha256').update(s).digest('hex')}`;
}

export function firstToken(key) {
  return String(key).split(' ')[0].replace(/\.(COM|IO|AI|ORG|NET|CO|DEV|APP)$/, '');
}

/** "AMAZON" (from an agent) and "AMAZON MKTPL AMZN.COM" (from a bank) are the same merchant. */
export function sameMerchant(a, b) {
  return a === b || firstToken(a) === firstToken(b);
}

/**
 * Who most likely bought a waiting charge: the top two agents, a confidence, and a reason a
 * person can check. Deterministic and explainable on purpose; no model, no hidden weights.
 *
 *   score = purchases from this merchant + 2 × those at about this amount (a recurring charge)
 *   high:   ≥2 earlier charges at about this amount, all one agent, and the user has never
 *           said "not an agent" for this merchant. Only these may be confirmed in a batch.
 *   medium: the top agent has history here and at least twice the runner-up's score.
 */
export function guessAgents(p, { agents, history, rejected }) {
  const same = history.filter((h) => sameMerchant(h.merchant_key, p.merchant_key));
  const tolerance = Math.max(50, Math.round(Math.abs(p.amount_cents) * 0.02));
  const near = (h) => h.currency === p.currency && Math.abs(h.amount_cents - p.amount_cents) <= tolerance;
  const scored = agents.map((a) => {
    const mine = same.filter((h) => h.agent_id === a.id);
    const atAmount = mine.filter(near).length;
    const last = mine.reduce((m, h) => (h.occurred_on > m ? h.occurred_on : m), '');
    return { agent_id: a.id, agent_name: a.name, times: mine.length, atAmount, score: mine.length + 2 * atAmount, last, recent: a.recent };
  }).sort((x, y) => y.score - x.score || y.last.localeCompare(x.last) || y.recent - x.recent || x.agent_id - y.agent_id);
  const [top, second] = scored;
  const saidNo = rejected.filter((k) => sameMerchant(k, p.merchant_key)).length;
  const runnerUp = second?.score ?? 0;
  let confidence = 'low';
  if (top?.score > 0 && top.score >= 2 * runnerUp) confidence = 'medium';
  if (confidence === 'medium' && top.atAmount >= 2 && runnerUp === 0 && saidNo === 0) confidence = 'high';
  const amount = formatCents(Math.abs(p.amount_cents), p.currency);
  let why = null;
  if (confidence === 'high') why = `${top.atAmount} earlier ${p.merchant} charges of about ${amount} were ${top.agent_name}`;
  else if (confidence === 'medium') why = `${top.agent_name} bought from ${p.merchant} ${top.times} time${top.times === 1 ? '' : 's'} before`;
  if (saidNo && why) why += `, but you said "not an agent" for ${p.merchant} ${saidNo === 1 ? 'once' : `${saidNo} times`}`;
  return {
    guesses: scored.slice(0, 2).map(({ agent_id, agent_name, score }) => ({ agent_id, agent_name, score })),
    confidence,
    why,
  };
}

export class LedgerError extends Error {
  constructor(message, status = 400) {
    super(message);
    this.status = status;
  }
}

const HOUR = 3600 * 1000;
const BUDGET_LEVELS = [50, 80, 100]; // % of a monthly budget worth telling someone about
const MAX_BUDGET_CENTS = 1e10;

export class Ledger {
  constructor({ dataDir = null, db = null, now = () => new Date() } = {}) {
    this.now = now;
    this.dataDir = dataDir;
    this.db = db ?? openDb(dataDir, { now });
  }

  close() {
    try { this.db.close(); } catch { /* already closed */ }
  }

  track(name, props) {
    track(this.db, name, props, this.now());
  }

  // ── Agents ────────────────────────────────────────────────────────────────

  listAgents() {
    return this.db.prepare('SELECT id, name, created_at, monthly_budget_cents, budget_currency FROM agents ORDER BY id').all();
  }

  /** Set (cents) or clear (null) an agent's monthly budget. */
  setAgentBudget(id, cents, currency = 'USD') {
    this.requireAgent(id);
    if (cents !== null && (!Number.isSafeInteger(cents) || cents <= 0 || cents > MAX_BUDGET_CENTS)) {
      throw new LedgerError('A budget must be an amount like "50.00", or empty for no budget.');
    }
    if (!/^[A-Z]{3}$/.test(currency)) throw new LedgerError('currency must be a 3-letter code like USD.');
    this.db.prepare('UPDATE agents SET monthly_budget_cents = ?, budget_currency = ? WHERE id = ?').run(cents, currency, Number(id));
    this.track(cents === null ? 'budget_cleared' : 'budget_set');
    return { id: Number(id), monthly_budget_cents: cents, budget_currency: currency };
  }

  /**
   * Agents with a budget and where they stand this month. `level` is the highest threshold
   * reached: 0, 50, 80 or 100 (at or over budget).
   */
  budgetStatus(month = monthKey(toLocalDate(this.now()))) {
    return this.db.prepare(`
      SELECT a.id AS agent_id, a.name AS agent, a.monthly_budget_cents AS budget_cents, a.budget_currency AS currency,
             COALESCE((SELECT sum(p.amount_cents) FROM purchases p
                       WHERE p.agent_id = a.id AND p.status = 'confirmed' AND p.currency = a.budget_currency
                         AND substr(p.occurred_on, 1, 7) = ?), 0) AS spent_cents
      FROM agents a WHERE a.monthly_budget_cents IS NOT NULL ORDER BY a.id`).all(month)
      .map((r) => {
        const level = BUDGET_LEVELS.findLast((l) => r.spent_cents * 100 >= l * r.budget_cents) ?? 0;
        return { ...r, month, pct: Math.round((r.spent_cents * 100) / r.budget_cents), level };
      });
  }

  createAgent(name) {
    const clean = String(name ?? '').trim();
    if (!clean || clean.length > 60) throw new LedgerError('Agent name must be 1–60 characters.');
    if (this.db.prepare('SELECT 1 FROM agents WHERE name = ? COLLATE NOCASE').get(clean)) {
      throw new LedgerError(`There's already an agent called ${clean}.`, 409);
    }
    const owner = this.#aliasOwner(clean);
    if (owner) throw new LedgerError(`${clean} was the old name of an agent you renamed, and an agent app may still use it. Pick another name.`, 409);
    const { lastInsertRowid } = this.db
      .prepare('INSERT INTO agents (name, created_at) VALUES (?, ?)')
      .run(clean, this.now().toISOString());
    this.track('agent_created');
    return { id: Number(lastInsertRowid), name: clean };
  }

  renameAgent(id, name) {
    const clean = String(name ?? '').trim();
    if (!clean || clean.length > 60) throw new LedgerError('Agent name must be 1–60 characters.');
    this.requireAgent(id);
    const clash = this.db.prepare('SELECT id FROM agents WHERE name = ? COLLATE NOCASE AND id != ?').get(clean, id);
    if (clash) throw new LedgerError(`There's already an agent called ${clean}.`, 409);
    const owner = this.#aliasOwner(clean);
    if (owner && owner !== Number(id)) throw new LedgerError(`${clean} was the old name of another agent you renamed, and an agent app may still use it. Pick another name.`, 409);
    const before = this.requireAgent(id).name;
    tx(this.db, () => {
      this.db.prepare('UPDATE agents SET name = ? WHERE id = ?').run(clean, id);
      // Apps connected with --agent <old name> keep reaching this agent: no setup to re-run.
      // The old name stays reserved for it (any letter case), so no other agent can take it.
      if (before.toLowerCase() !== clean.toLowerCase()) setMeta(this.db, `agent_alias:${before.toLowerCase()}`, String(id));
    });
    return { id, name: clean };
  }

  /** The agent an app's `--agent <name>` means: by name, or by a name it had before a rename. Never creates. */
  findAgentByName(name) {
    const clean = String(name ?? '').trim();
    const alias = this.#aliasOwner(clean);
    if (alias) return this.db.prepare('SELECT id, name FROM agents WHERE id = ?').get(alias) ?? null;
    return this.db.prepare('SELECT id, name FROM agents WHERE name = ? COLLATE NOCASE').get(clean) ?? null;
  }

  /** The agent a former name is reserved for, if any. */
  #aliasOwner(name) {
    const v = this.db.prepare('SELECT value FROM meta WHERE key = ?').get(`agent_alias:${String(name).trim().toLowerCase()}`)?.value;
    return v ? Number(v) : null;
  }

  requireAgent(id) {
    const a = this.db.prepare('SELECT id, name FROM agents WHERE id = ?').get(Number(id));
    if (!a) throw new LedgerError('No such agent.', 404);
    return a;
  }

  // ── Sources ───────────────────────────────────────────────────────────────

  /** csv, email and manual have one source row each; simplefin one per token; agent one per agent. */
  ensureSource(kind, label, { agentId = null } = {}) {
    if (kind === 'agent') {
      const row = this.db.prepare("SELECT id FROM sources WHERE kind = 'agent' AND agent_id = ?").get(agentId);
      if (row) return row.id;
    } else if (kind !== 'simplefin') {
      const row = this.db.prepare('SELECT id FROM sources WHERE kind = ?').get(kind);
      if (row) return row.id;
    }
    const { lastInsertRowid } = this.db
      .prepare('INSERT INTO sources (kind, label, agent_id, created_at) VALUES (?, ?, ?, ?)')
      .run(kind, label, agentId, this.now().toISOString());
    return Number(lastInsertRowid);
  }

  listSources() {
    return this.db.prepare(`
      SELECT s.id, s.kind, CASE WHEN s.kind = 'agent' THEN a.name ELSE s.label END AS label, s.agent_id,
             s.created_at, s.last_attempt_at, s.last_success_at, s.last_error
      FROM sources s LEFT JOIN agents a ON a.id = s.agent_id ORDER BY s.id`).all();
  }

  /** Looking at every source of this kind just worked, even if it found nothing (src/health.js). */
  markChecked(kind) {
    const nowIso = this.now().toISOString();
    for (const s of this.db.prepare('SELECT id FROM sources WHERE kind = ?').all(kind)) {
      setMeta(this.db, `checked_at:${s.id}`, nowIso);
      // Clears only a failed check of the source itself. Why captured lines were refused
      // (sources.last_error) stays until a later capture works: a refusal keeps its reason.
      this.db.prepare('DELETE FROM meta WHERE key = ?').run(`check_error:${s.id}`);
    }
  }

  /** A check of this source went wrong: shown as failed until a later check works. */
  markCheckFailed(sourceId, message) {
    const key = `check_error:${Number(sourceId)}`;
    const text = String(message).slice(0, 200);
    let prior = null;
    try { prior = JSON.parse(this.db.prepare('SELECT value FROM meta WHERE key = ?').get(key)?.value ?? 'null'); } catch { /* replace it */ }
    // The same failure going on keeps the time it started, so a dismissed item stays dismissed.
    if (prior?.message === text) return;
    setMeta(this.db, key, JSON.stringify({ at: this.now().toISOString(), message: text }));
  }

  sourceKind(sourceId) {
    const row = this.db.prepare('SELECT kind FROM sources WHERE id = ?').get(Number(sourceId));
    if (!row) throw new LedgerError('No such source.', 404);
    return row.kind;
  }

  // ── Ingestion + reconciliation ────────────────────────────────────────────

  /**
   * Insert normalized transactions from one source. Each one is, in order:
   *   1. a duplicate (same source, same external id) — ignored;
   *   2. the same charge another source already saw — stored as `merged` into that row,
   *      which becomes verified (and, if the agent is the one reporting, attributed);
   *   3. new — classified into the attribution state machine for its source kind.
   *
   * txn: { externalId, occurredOn, amountCents (positive = spend), currency, description,
   *        payee?, merchant? (clean name from an agent), agentId? (agent/manual),
   *        paymentMethod? }
   */
  ingest(sourceId, txns, { reportedBy = null } = {}) {
    const kind = this.sourceKind(sourceId);
    // checked: lines that landed on a purchase an agent reported (the moment that earns its ✓).
    const result = { inserted: 0, merged: 0, checked: 0, candidates: 0, auto: 0, duplicates: 0, ids: [] };
    const nowIso = this.now().toISOString();
    const exists = this.db.prepare('SELECT id FROM purchases WHERE source_id = ? AND external_id = ?');
    const insert = this.db.prepare(`
      INSERT INTO purchases
        (source_id, external_id, occurred_on, amount_cents, currency, merchant, merchant_key, description,
         payment_method, status, agent_id, match_reason, attributed_by, attributed_at, surfaced_at,
         merged_into, created_at, reported_by_agent_id)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`);
    tx(this.db, () => {
      for (const t of txns) {
        if (!isIsoDate(t.occurredOn) || !Number.isSafeInteger(t.amountCents) || t.amountCents === 0) continue;
        const prior = exists.get(sourceId, String(t.externalId));
        if (prior) {
          result.duplicates++;
          result.ids.push(prior.id);
          continue;
        }
        // Checked inside this transaction, so two processes can't both slip past the limit.
        if (reportedBy) this.checkAgentLimit(reportedBy);
        const description = redact(String(t.description ?? '')).slice(0, 200);
        const payee = t.payee ? redact(String(t.payee)).slice(0, 120) : null;
        const named = t.merchant ? redact(String(t.merchant)).trim().slice(0, 80) : null;
        const key = merchantKey(named ?? description, named ? null : payee);
        const merchant = named ? (detectKnownMerchant(named) ?? named) : displayMerchant(description, payee);
        const currency = t.currency || 'USD';
        const method = t.paymentMethod ?? null;
        const row = (status, c, mergedInto) => Number(insert.run(
          sourceId, String(t.externalId), t.occurredOn, t.amountCents, currency, merchant, key, description,
          method, status, c.agentId ?? null, c.reason ?? null, c.by ?? null, c.by ? nowIso : null,
          status === 'candidate' ? nowIso : null, mergedInto ?? null, nowIso, reportedBy,
        ).lastInsertRowid);

        const match = this.findMatch({ sourceId, kind, occurredOn: t.occurredOn, amountCents: t.amountCents, currency, key, agentId: t.agentId ?? null });
        if (match) {
          row('merged', { reason: 'same_charge' }, match.id);
          this.absorb(match, { kind, amountCents: t.amountCents, agentId: t.agentId, method, nowIso });
          if (match.amount_cents < 0) matchRefund(this, match.id); // new evidence may settle an expected refund
          result.merged++;
          if (match.agent_id != null && match.status === 'confirmed') result.checked++;
          result.ids.push(match.id);
          continue;
        }
        const c = this.classify(kind, key, `${named ?? ''} ${payee ?? ''} ${description}`, t.agentId, t.amountCents);
        const id = row(c.status, c);
        this.refreshVerified(id, nowIso);
        if (t.amountCents < 0) matchRefund(this, id); // a refund line may answer an expected refund
        result.inserted++;
        result.ids.push(id);
        if (c.status === 'candidate') result.candidates++;
        if (c.by === 'rule' && c.status === 'confirmed') result.auto++;
      }
    });
    return result;
  }

  /**
   * Is this charge one we already have from a different source? Same currency, amount
   * within 1%, date within ±4 days (banks post late), same merchant. Two reports from the
   * same kind of source are two purchases — except bank vs bank, where a CSV export and
   * the bank feed overlap. Each existing row absorbs at most one row per source group.
   * An agent's own report never lands on a charge already counted for a different agent:
   * two agents paying for the same plan days apart is two purchases, and merging them would
   * make one agent's spending vanish. The worst case is two visible lines, never one hidden.
   */
  findMatch({ sourceId, kind, occurredOn, amountCents, currency, key, agentId = null }) {
    const group = sourceGroup(kind);
    const rows = this.db.prepare(`
      SELECT p.id, p.status, p.agent_id, p.attributed_by, p.merchant_key, p.amount_cents, p.verified_at, s.kind
      FROM purchases p JOIN sources s ON s.id = p.source_id
      WHERE p.status != 'merged' AND p.source_id != ? AND p.currency = ?
        AND p.occurred_on BETWEEN ? AND ?
        AND abs(p.amount_cents - ?) <= max(1, abs(?) / 100)
      ORDER BY abs(julianday(p.occurred_on) - julianday(?)), abs(p.amount_cents - ?), p.id`)
      .all(sourceId, currency, addDays(occurredOn, -4), addDays(occurredOn, 4), amountCents, amountCents, occurredOn, amountCents);
    const childGroups = this.db.prepare(`
      SELECT s.kind FROM purchases c JOIN sources s ON s.id = c.source_id WHERE c.merged_into = ?`);
    for (const r of rows) {
      const g = sourceGroup(r.kind);
      if (g === group && group !== 'bank') continue;
      if (Math.sign(r.amount_cents) !== Math.sign(amountCents)) continue;
      if (kind === 'agent' && agentId != null && r.status === 'confirmed' && r.agent_id != null && r.agent_id !== Number(agentId)) continue;
      if (!sameMerchant(r.merchant_key, key)) continue;
      if (childGroups.all(r.id).some((c) => sourceGroup(c.kind) === group)) continue;
      return r;
    }
    return null;
  }

  /**
   * A second source saw `survivor`'s charge. Let the bank correct the amount; recompute the ✓;
   * let an agent's claim ask the user. An agent never moves a charge into Agents by itself:
   * claiming a waiting or personal charge puts it in the inbox with that agent as the guess.
   */
  absorb(survivor, { kind, amountCents, agentId, method, nowIso }) {
    const set = [];
    const args = [];
    if (sourceGroup(kind) === 'bank' && sourceGroup(survivor.kind) !== 'bank' && amountCents !== survivor.amount_cents) {
      set.push('amount_cents = ?');
      args.push(amountCents); // what the card was actually charged
    }
    if (method) { set.push('payment_method = COALESCE(payment_method, ?)'); args.push(method); }
    let claimed = null;
    if (kind === 'agent' && agentId && survivor.status !== 'confirmed') {
      // The agent says it bought a charge the user hasn't put in Agents. Ask; never move it.
      set.push("status = 'candidate'", "match_reason = 'agent_reported'", 'surfaced_at = COALESCE(surfaced_at, ?)',
        'agent_id = NULL', 'attributed_by = NULL', 'attributed_at = NULL');
      args.push(nowIso);
      claimed = Number(agentId);
    } else if (kind === 'manual' && agentId && survivor.status !== 'confirmed') {
      // The user, adding it by hand, says which agent bought it.
      set.push("status = 'confirmed'", 'agent_id = ?', "attributed_by = 'user'", 'attributed_at = ?', "match_reason = 'manual'");
      args.push(Number(agentId), nowIso);
    }
    if (set.length) this.db.prepare(`UPDATE purchases SET ${set.join(', ')} WHERE id = ?`).run(...args, survivor.id);
    const wasVerified = Boolean(survivor.verified_at);
    const verified = this.refreshVerified(survivor.id, nowIso);
    if (claimed) {
      const name = this.db.prepare('SELECT name FROM agents WHERE id = ?').get(claimed)?.name ?? 'An agent';
      const was = survivor.status === 'candidate' ? 'waiting' : 'Mine';
      this.audit('agent_claim', survivor.id, `${name} says it bought this; it was ${was}, now waits for you`);
    } else if (set.length || verified !== wasVerified) {
      this.audit('matched', survivor.id, `seen again (${kind})${verified !== wasVerified ? (verified ? ', now verified' : '') : ''}`);
    }
  }

  /**
   * The one rule for ✓: something the agent didn't supply saw the charge. A bank line (feed or
   * CSV), the iPhone, or the local webhook, as the purchase's own source or a merged copy; or a
   * receipt file the user attached. Sets or clears verified_at to match. Returns the new state.
   */
  refreshVerified(id, nowIso = this.now().toISOString()) {
    const yes = Boolean(this.db.prepare(`SELECT ${INDEPENDENT_SQL('?')} AS v`).get(...Array(3).fill(Number(id))).v);
    if (yes) this.db.prepare('UPDATE purchases SET verified_at = COALESCE(verified_at, ?) WHERE id = ?').run(nowIso, Number(id));
    else this.db.prepare('UPDATE purchases SET verified_at = NULL WHERE id = ?').run(Number(id));
    return yes;
  }

  /** The user attached a receipt file: that's proof the agent didn't supply. */
  attachedReceipt(id) {
    const p = this.getPurchase(id);
    tx(this.db, () => {
      const was = Boolean(p.verified_at);
      const now = this.refreshVerified(p.id);
      this.audit('receipt', p.id, now && !was ? 'receipt attached, now verified' : 'receipt attached');
      if (now && !was && p.amount_cents < 0) matchRefund(this, p.id); // new proof may settle an expected refund
    });
    return this.getPurchase(p.id);
  }

  /** Refuse an agent's write past AGENT_HOURLY_LIMIT, with a reason. Call inside the insert's transaction. */
  checkAgentLimit(agentId) {
    const since = new Date(this.now().getTime() - HOUR).toISOString();
    // Everything this agent added: purchases, receipts and alerts, expected refunds, finished sweeps.
    // Plain ? placeholders: Node 22.13's SQLite binding refuses numbered ones (?1).
    const a = Number(agentId);
    const { n } = this.db.prepare(`SELECT
        (SELECT count(*) FROM purchases WHERE reported_by_agent_id = ? AND created_at > ?)
      + (SELECT count(*) FROM expected_refunds WHERE reported_by_agent_id = ? AND created_at > ?)
      + (SELECT count(*) FROM sweeps WHERE agent_id = ? AND finished_at > ?) AS n`).get(a, since, a, since, a, since);
    if (n >= AGENT_HOURLY_LIMIT) {
      throw new LedgerError(`This agent has added ${AGENT_HOURLY_LIMIT} purchases in the last hour, the most allowed. Stop and ask the user; they can add the rest in Twinslip, or you can continue in an hour.`, 429);
    }
  }

  classify(kind, key, text, agentId, amountCents = 1) {
    // A refund lowers spending, so an agent can't apply one on its own word: the user agrees first.
    if (kind === 'agent' && amountCents < 0) return { status: 'candidate', agentId: null, reason: 'agent_refund', by: null };
    if (kind === 'agent') return { status: 'confirmed', agentId: Number(agentId), reason: 'agent_reported', by: 'agent' };
    // Typed in by the user: theirs (Mine) unless they named the agent that bought it.
    if (kind === 'manual') {
      return agentId ? { status: 'confirmed', agentId: Number(agentId), reason: 'manual', by: 'user' } : { status: 'not_agent', agentId: null, reason: 'manual', by: 'user' };
    }
    const rule = this.db.prepare('SELECT action, agent_id FROM rules WHERE merchant_key = ?').get(key);
    if (rule?.action === 'attribute') {
      // What an agent found in email never counts by a rule alone; the rule's agent is the guess.
      if (AGENT_SUPPLIED.includes(kind)) return { status: 'candidate', agentId: null, reason: 'rule_suggests', by: null };
      return { status: 'confirmed', agentId: rule.agent_id, reason: 'rule', by: 'rule' };
    }
    if (rule?.action === 'ignore') {
      return { status: 'not_agent', agentId: null, reason: 'rule', by: 'rule' };
    }
    // A receipt the agent went looking for is always worth one tap.
    if (kind === 'email') return { status: 'candidate', agentId: null, reason: 'receipt', by: null };
    const known = detectKnownMerchant(text);
    if (known) return { status: 'candidate', agentId: null, reason: 'known_merchant', by: null };
    // Same merchant as reconciliation means it: "AMAZON" from an agent, "AMAZON MKTPL" from a bank.
    const learned = this.db
      .prepare("SELECT merchant_key FROM purchases WHERE status = 'confirmed' AND merchant_key LIKE ? ESCAPE '\\'")
      .all(`${firstToken(key).replace(/[%_\\]/g, '\\$&')}%`)
      .some((r) => sameMerchant(r.merchant_key, key));
    if (learned) return { status: 'candidate', agentId: null, reason: 'learned', by: null };
    return { status: 'background', agentId: null, reason: null, by: null };
  }

  // ── Attribution ───────────────────────────────────────────────────────────

  inbox() {
    const rows = this.db.prepare(`
      SELECT p.id, p.occurred_on, p.amount_cents, p.currency, p.merchant, p.merchant_key, p.description, p.match_reason,
             p.surfaced_at, s.kind AS source_kind, p.reported_by_agent_id, s.agent_id AS source_agent_id,
             -- The newest agent that reported this charge itself (an agent's source belongs to that agent),
             -- else the newest connection that found it in email.
             (SELECT cs.agent_id FROM purchases c JOIN sources cs ON cs.id = c.source_id
               WHERE c.merged_into = p.id AND cs.kind = 'agent' ORDER BY c.id DESC LIMIT 1) AS claimed_by_agent_id,
             (SELECT c.reported_by_agent_id FROM purchases c WHERE c.merged_into = p.id AND c.reported_by_agent_id IS NOT NULL
               ORDER BY c.id DESC LIMIT 1) AS found_by_agent_id
      FROM purchases p JOIN sources s ON s.id = p.source_id WHERE p.status = 'candidate'
      ORDER BY p.occurred_on DESC, p.id DESC`).all();
    const ctx = this.guessContext();
    const rule = this.db.prepare("SELECT agent_id FROM rules WHERE merchant_key = ? AND action = 'attribute'");
    return rows.map(({ reported_by_agent_id: reporter, source_agent_id: own, claimed_by_agent_id: claimer, found_by_agent_id: finder, ...r }) => {
      const g = guessAgents(r, ctx);
      // An agent's own word (a refund, a claim, a receipt it found) is a guess, never a sure one.
      const agentSaid = AGENT_SUPPLIED.includes(r.source_kind) || ['agent_refund', 'agent_reported', 'rule_suggests'].includes(r.match_reason);
      if (agentSaid) {
        const first = r.match_reason === 'rule_suggests' ? rule.get(r.merchant_key)?.agent_id : claimer ?? own ?? finder ?? reporter;
        const a = first && ctx.agents.find((x) => x.id === first);
        if (a && g.guesses[0]?.agent_id !== a.id) {
          g.guesses = [{ agent_id: a.id, agent_name: a.name, score: 0 }, ...g.guesses.filter((x) => x.agent_id !== a.id)].slice(0, 2);
        }
        if (g.confidence === 'high') g.confidence = 'medium';
        if (a) g.why = r.match_reason === 'rule_suggests' ? `your rule says ${a.name}; ${a.name} found this in email`
          : r.match_reason === 'agent_refund' ? `${a.name} reported this refund`
          : r.match_reason === 'agent_reported' ? `${a.name} says it bought this` : `${a.name} found this in email`;
      }
      return { ...r, ...g, suggested_agent_id: g.guesses[0]?.agent_id ?? null, suggested_agent_name: g.guesses[0]?.agent_name ?? null };
    });
  }

  /** What the guesses learn from: a year of confirmed purchases, the user's "not an agent" taps, recent activity. */
  guessContext() {
    const today = toLocalDate(this.now());
    return {
      agents: this.db.prepare(`
        SELECT a.id, a.name, (SELECT count(*) FROM purchases p WHERE p.agent_id = a.id AND p.status = 'confirmed'
          AND p.occurred_on >= ?) AS recent FROM agents a ORDER BY a.id`).all(addDays(today, -30)),
      history: this.db.prepare(`
        SELECT agent_id, merchant_key, amount_cents, currency, occurred_on FROM purchases
        WHERE status = 'confirmed' AND occurred_on >= ?`).all(addDays(today, -365)),
      rejected: this.db.prepare(`
        SELECT merchant_key FROM purchases WHERE status = 'not_agent' AND attributed_by = 'user'`).all().map((r) => r.merchant_key),
    };
  }

  /** Confirm every waiting charge whose guess is sure. One tap by the user, for the batch. */
  confirmSure() {
    const confirmed = [];
    for (const p of this.inbox().filter((x) => x.confidence === 'high')) {
      const agentId = p.guesses[0].agent_id;
      this.confirm(p.id, agentId, { via: 'batch' });
      confirmed.push({ id: p.id, merchant: p.merchant, agent_id: agentId });
    }
    if (confirmed.length) this.track('inbox_batch', { n: confirmed.length }); // one tap, however many
    return { confirmed };
  }

  getPurchase(id) {
    const p = this.db.prepare('SELECT * FROM purchases WHERE id = ?').get(Number(id));
    if (!p) throw new LedgerError('No such purchase.', 404);
    return p;
  }

  latencyHours(p) {
    if (!p.surfaced_at) return 0;
    return Math.max(0, Math.round(((this.now() - new Date(p.surfaced_at)) / HOUR) * 10) / 10);
  }

  confirm(id, agentId, { always = false, via = 'tap' } = {}) {
    const p = this.getPurchase(id);
    if (p.status !== 'candidate') throw new LedgerError('That purchase has already been sorted.', 409);
    this.requireAgent(agentId);
    // The guess the user saw (a claiming agent comes first), for the yes/reassign measure.
    const suggested = this.inbox().find((x) => x.id === p.id)?.suggested_agent_id ?? null;
    const nowIso = this.now().toISOString();
    let retro = 0;
    tx(this.db, () => {
      this.db.prepare(`UPDATE purchases SET status = 'confirmed', agent_id = ?, attributed_by = 'user', attributed_at = ?
        WHERE id = ?`).run(Number(agentId), nowIso, p.id);
      if (always) retro = this.upsertRule(p.merchant_key, 'attribute', Number(agentId), nowIso);
      this.audit('agent', p.id, via === 'batch' ? 'confirmed in a batch of sure guesses' : 'one tap');
    });
    this.track('attribution', {
      result: suggested === Number(agentId) ? 'yes' : 'reassign',
      via,
      latency_h: this.latencyHours(p),
    });
    if (always) this.track('rule_created', { action: 'attribute', retro });
    // A charge this agent itself said it bought: now that it counts as the agent's, check it
    // against the agent's mandate, exactly as if the report had counted at once.
    const claimedBySame = this.db.prepare(`SELECT 1 FROM purchases c JOIN sources s ON s.id = c.source_id
      WHERE c.merged_into = ? AND s.kind = 'agent' AND s.agent_id = ? LIMIT 1`).get(p.id, Number(agentId));
    if (claimedBySame) flagIfOutside(this, this.getPurchase(p.id));
    return { ...this.getPurchase(p.id), retroactive: retro };
  }

  reject(id, { never = false } = {}) {
    const p = this.getPurchase(id);
    if (p.status !== 'candidate') throw new LedgerError('That purchase has already been sorted.', 409);
    const nowIso = this.now().toISOString();
    let retro = 0;
    tx(this.db, () => {
      this.db.prepare(`UPDATE purchases SET status = 'not_agent', agent_id = NULL, attributed_by = 'user', attributed_at = ?
        WHERE id = ?`).run(nowIso, p.id);
      if (never) retro = this.upsertRule(p.merchant_key, 'ignore', null, nowIso);
      this.audit('mine', p.id, 'one tap');
    });
    this.track('attribution', { result: 'no', via: 'tap', latency_h: this.latencyHours(p) });
    if (never) this.track('rule_created', { action: 'ignore', retro });
    return { ...this.getPurchase(p.id), retroactive: retro };
  }

  /** Create/replace a merchant rule and apply it to anything still waiting in the inbox. */
  upsertRule(key, action, agentId, nowIso) {
    this.db.prepare(`INSERT INTO rules (merchant_key, action, agent_id, created_at) VALUES (?, ?, ?, ?)
      ON CONFLICT(merchant_key) DO UPDATE SET action = excluded.action, agent_id = excluded.agent_id`)
      .run(key, action, agentId, nowIso);
    // Never what an agent supplied (a receipt or alert it found, its own refund or claim): those wait for a tap.
    const { changes } = action === 'attribute'
      ? this.db.prepare(`UPDATE purchases SET status = 'confirmed', agent_id = ?, attributed_by = 'rule', attributed_at = ?
          WHERE status = 'candidate' AND merchant_key = ?
            AND COALESCE(match_reason, '') NOT IN ('agent_refund', 'agent_reported', 'rule_suggests')
            AND source_id NOT IN (SELECT id FROM sources WHERE kind IN (${AGENT_SUPPLIED.map((k) => `'${k}'`).join(', ')}))`)
        .run(agentId, nowIso, key)
      : this.db.prepare(`UPDATE purchases SET status = 'not_agent', attributed_by = 'rule', attributed_at = ?
          WHERE status = 'candidate' AND merchant_key = ?`).run(nowIso, key);
    return Number(changes);
  }

  /** "Always" / "Never" after the fact: turn a sorted purchase into a merchant rule. */
  ruleFromPurchase(id) {
    const p = this.getPurchase(id);
    if (p.status !== 'confirmed' && p.status !== 'not_agent') {
      throw new LedgerError('Sort the purchase first.', 409);
    }
    const action = p.status === 'confirmed' ? 'attribute' : 'ignore';
    const retro = tx(this.db, () => this.upsertRule(p.merchant_key, action, p.agent_id ?? null, this.now().toISOString()));
    this.audit('rule', p.id, action === 'attribute' ? `always Agents for ${p.merchant} (${retro} more sorted)` : `always Mine for ${p.merchant} (${retro} more sorted)`);
    this.track('rule_created', { action, retro });
    return { action, merchant: p.merchant, retroactive: retro };
  }

  undo(id) {
    const p = this.getPurchase(id);
    if (p.status !== 'confirmed' && p.status !== 'not_agent') {
      throw new LedgerError('Only sorted purchases can be undone.', 409);
    }
    this.db.prepare(`UPDATE purchases SET status = 'candidate', agent_id = NULL, attributed_by = NULL,
      attributed_at = NULL, surfaced_at = COALESCE(surfaced_at, ?) WHERE id = ?`)
      .run(this.now().toISOString(), p.id);
    this.audit('undo', p.id, `was ${p.status === 'confirmed' ? 'Agents' : 'Mine'}`);
    this.track('attribution_undone');
    return this.getPurchase(p.id);
  }

  /** "My agent bought this" — move a personal/background transaction into the inbox. */
  pullIn(id) {
    const p = this.getPurchase(id);
    if (p.status !== 'background' && p.status !== 'not_agent') {
      throw new LedgerError('That purchase is already in the agent bucket or inbox.', 409);
    }
    this.db.prepare(`UPDATE purchases SET status = 'candidate', agent_id = NULL, attributed_by = NULL,
      attributed_at = NULL, match_reason = 'pulled_in', surfaced_at = ? WHERE id = ?`)
      .run(this.now().toISOString(), p.id);
    this.track('pulled_in');
    return this.getPurchase(p.id);
  }

  /**
   * An expense typed in by the user. With an agent: that agent's spending (another card, a gift
   * card...). Without one: the user's own (Mine). No agent is ever needed.
   */
  addManual({ occurredOn, amountCents, merchant, agentId = null, currency = 'USD' }) {
    if (!isIsoDate(occurredOn)) throw new LedgerError('Date must be YYYY-MM-DD.');
    if (!Number.isSafeInteger(amountCents) || amountCents === 0) throw new LedgerError('Amount is required.');
    const name = String(merchant ?? '').trim().slice(0, 80);
    if (!name) throw new LedgerError('Merchant is required.');
    if (agentId !== null && agentId !== undefined && agentId !== '') this.requireAgent(agentId);
    else agentId = null;
    const sourceId = this.ensureSource('manual', 'Added by hand');
    const r = this.ingest(sourceId, [{
      externalId: `manual-${randomUUID()}`, occurredOn, amountCents, merchant: name, agentId: agentId === null ? null : Number(agentId),
      currency: /^[A-Z]{3}$/.test(currency) ? currency : 'USD',
    }]);
    this.track('manual_added');
    return this.getPurchase(r.ids[0]);
  }

  // ── Agent capture (MCP server and `twinslip record`) ──────────────────

  /**
   * The agent for an agent app. Identity is the key, never the name: renaming the agent keeps
   * it, and a name already in use gets the next free one ("Claude 2").
   */
  agentForKey(key) {
    if (!AGENT_KEYS[key]) throw new LedgerError(`Unknown agent app: ${key}`);
    return tx(this.db, () => this.#agentForKey(key));
  }

  #agentForKey(key) {
    const friendly = AGENT_KEYS[key];
    {
      const mapped = this.db.prepare('SELECT value FROM meta WHERE key = ?').get(`agent_key:${key}`)?.value;
      const existing = mapped && this.db.prepare('SELECT id, name FROM agents WHERE id = ?').get(Number(mapped));
      if (existing) return existing;
      let name = friendly;
      for (let n = 2; this.db.prepare('SELECT 1 FROM agents WHERE name = ?').get(name); n++) name = `${friendly} ${n}`;
      const agent = this.createAgent(name);
      setMeta(this.db, `agent_key:${key}`, String(agent.id));
      return agent;
    }
  }

  /**
   * An agent app's MCP process starting up: its agent and its source, found or created in one
   * write transaction, so two windows launching at once can't create two of either.
   */
  connectAgent({ agentKey = null, agentName = null, host = null } = {}) {
    if (agentKey && !AGENT_KEYS[agentKey]) throw new LedgerError(`Unknown agent app: ${agentKey}`);
    return tx(this.db, () => {
      // An app connected by name remembers which agent it is, so later renames or a reused name
      // can never move its purchases to another agent.
      const pinned = !agentKey && host && AGENT_KEYS[host] ? this.db.prepare('SELECT value FROM meta WHERE key = ?').get(`host_agent:${host}`)?.value : null;
      const pinnedAgent = pinned ? this.db.prepare('SELECT id, name FROM agents WHERE id = ?').get(Number(pinned)) : null;
      const agent = agentKey ? this.#agentForKey(agentKey) : pinnedAgent ?? this.ensureAgent(agentName);
      if (!agentKey && host && AGENT_KEYS[host] && !pinnedAgent) setMeta(this.db, `host_agent:${host}`, String(agent.id));
      const sourceId = this.ensureSource('agent', `Agent ${agent.name}`, { agentId: agent.id });
      return { agent, sourceId };
    });
  }

  /**
   * An agent proving its connection (MCP test_capture). Recorded as a check, never a purchase;
   * the same check_id again is a duplicate. Returns { duplicate }.
   */
  recordCaptureCheck(agentId, checkId, { host = null, client = null } = {}) {
    this.requireAgent(agentId);
    const id = redact(String(checkId ?? '').trim());
    if (!id || id.length > 80) throw new LedgerError('check_id must be 1 to 80 characters, like "setup-1".');
    return tx(this.db, () => {
      if (this.db.prepare('SELECT 1 FROM capture_checks WHERE agent_id = ? AND check_id = ?').get(Number(agentId), id)) return { duplicate: true };
      const since = new Date(this.now().getTime() - HOUR).toISOString();
      const { n } = this.db.prepare('SELECT count(*) AS n FROM capture_checks WHERE agent_id = ? AND at > ?').get(Number(agentId), since);
      if (n >= CAPTURE_CHECKS_PER_HOUR) throw new LedgerError(`That's ${CAPTURE_CHECKS_PER_HOUR} test captures in the last hour, the most allowed. One is enough to prove the connection.`, 429);
      this.db.prepare('INSERT INTO capture_checks (agent_id, check_id, host, client, at) VALUES (?, ?, ?, ?, ?)')
        .run(Number(agentId), id, host, client ? redact(client) : null, this.now().toISOString());
      // Only the newest checks are kept: they prove a connection, they aren't a record of spending.
      this.db.prepare(`DELETE FROM capture_checks WHERE agent_id = ? AND id NOT IN
        (SELECT id FROM capture_checks WHERE agent_id = ? ORDER BY id DESC LIMIT ?)`).run(Number(agentId), Number(agentId), CAPTURE_CHECKS_KEPT);
      return { duplicate: false };
    });
  }

  ensureAgent(name) {
    return this.findAgentByName(name) ?? this.createAgent(String(name ?? '').trim());
  }

  /**
   * The agent reports a purchase it just made. Counts immediately — this is the real-time
   * path, and the only one that sees payments no bank or inbox will (agent wallets,
   * crypto, prepaid balances). Idempotent on `reference`. If a receipt or bank line for
   * the same charge arrives later, it merges in and marks this verified.
   */
  recordAgentPurchase(agentId, { merchant, amountCents, currency = 'USD', occurredOn, paymentMethod = 'other', reference = null, note = '', job = null }, { reporter = null } = {}) {
    const agent = this.requireAgent(agentId);
    const name = redact(String(merchant ?? '')).trim().slice(0, 80);
    if (!name) throw new LedgerError('merchant is required.');
    if (!Number.isSafeInteger(amountCents) || amountCents === 0) throw new LedgerError('amount must be a non-zero number like "20.00".');
    checkReportedAmount(amountCents);
    if (!/^[A-Z]{3}$/.test(currency)) throw new LedgerError('currency must be a 3-letter code like USD.');
    if (!PAYMENT_METHODS.includes(paymentMethod)) throw new LedgerError(`payment_method must be one of: ${PAYMENT_METHODS.join(', ')}.`);
    const today = toLocalDate(this.now());
    const date = occurredOn ?? today;
    checkReportedDate(date, today, 'occurred_on');
    const ref = reference ? safeId(String(reference).trim()) : null; // the whole original, never a cut-off prefix
    const sourceId = this.ensureSource('agent', `Agent ${agent.name}`, { agentId: agent.id });
    const r = this.ingest(sourceId, [{
      externalId: ref ? `ref:${ref}` : `auto:${randomUUID()}`, occurredOn: date, amountCents, currency,
      merchant: name, description: String(note ?? '').slice(0, 200), agentId: agent.id, paymentMethod,
    }], { reportedBy: reporter });
    this.db.prepare('UPDATE sources SET last_success_at = ? WHERE id = ?').run(this.now().toISOString(), sourceId);
    const jobName = cleanJob(job);
    // The job goes on the row the report landed on: this agent's own, or a charge it claimed that
    // waits for the user's tap. Never on another agent's purchase, and a retry never renames it.
    if (jobName && !r.duplicates) {
      this.db.prepare("UPDATE purchases SET job = ? WHERE id = ? AND job IS NULL AND (agent_id = ? OR status = 'candidate')")
        .run(jobName, r.ids[0], agent.id);
    }
    const purchase = this.getPurchase(r.ids[0]);
    const outside = r.duplicates ? [] : flagIfOutside(this, purchase);
    if (!r.duplicates) this.track('agent_reported', { method: paymentMethod, merged: r.merged });
    return { purchase, duplicate: r.duplicates > 0, matchedExisting: r.merged > 0, outsideMandate: outside };
  }

  /**
   * A receipt an agent found in the user's email. Kept as evidence: it catches purchases the
   * agents forgot and goes in the tax pack, but it never gives the ✓ or counts on its own.
   */
  recordReceipt({ vendor, amountCents, currency = 'USD', occurredOn, messageId, subject = '' }, { reportedBy = null } = {}) {
    const name = redact(String(vendor ?? '')).trim().slice(0, 80);
    if (!name) throw new LedgerError('vendor is required.');
    if (!Number.isSafeInteger(amountCents) || amountCents === 0) throw new LedgerError('amount must be a non-zero number like "20.00".');
    checkReportedAmount(amountCents);
    if (!/^[A-Z]{3}$/.test(currency)) throw new LedgerError('currency must be a 3-letter code like USD.');
    checkReportedDate(occurredOn, toLocalDate(this.now()));
    const id = String(messageId ?? '').trim();
    if (!id) throw new LedgerError('message_id is required (it prevents recording the same email twice).');
    const sourceId = this.ensureSource('email', 'Email receipts');
    const r = this.ingest(sourceId, [{
      externalId: `msg:${safeId(id, 200)}`, occurredOn, amountCents, currency, merchant: name,
      description: String(subject ?? '').slice(0, 120),
    }], { reportedBy });
    this.db.prepare('UPDATE sources SET last_success_at = ? WHERE id = ?').run(this.now().toISOString(), sourceId);
    if (!r.duplicates) this.track('receipt_recorded', { merged: r.merged });
    return { purchase: this.getPurchase(r.ids[0]), duplicate: r.duplicates > 0, matchedExisting: r.merged > 0 };
  }

  /** Totals per agent for a calendar month, for agents asking "how much have I spent?". */
  monthSpend(month) {
    return this.db.prepare(`
      SELECT a.name AS agent, p.currency, sum(p.amount_cents) AS cents, count(*) AS purchases
      FROM purchases p JOIN agents a ON a.id = p.agent_id
      WHERE p.status = 'confirmed' AND substr(p.occurred_on, 1, 7) = ?
      GROUP BY a.id, p.currency ORDER BY cents DESC`).all(month);
  }

  // ── Reads ─────────────────────────────────────────────────────────────────

  /**
   * Search the agent bucket. Plain words match the merchant (or an agent's name); filters:
   * agent:, merchant:, method:, verified:yes|no, month:YYYY-MM, this-month, last-month,
   * this-year, last-year, >20, <100, >=, <=. Returns matching purchases (newest first) and
   * a running total per currency: { currency, cents, count, verified_count }.
   */
  search(query) {
    const thisMonth = monthKey(toLocalDate(this.now()));
    const year = Number(thisMonth.slice(0, 4));
    const verified = (p) => Boolean(p.verified_at);
    const has = (s, w) => String(s ?? '').toLowerCase().includes(w);
    const between = (from, to) => (p) => p.occurred_on >= from && p.occurred_on < to;
    const tests = [];
    for (const tok of String(query ?? '').trim().toLowerCase().split(/\s+/).filter(Boolean)) {
      let m;
      if ((m = /^(agent|merchant|method|verified|month):(.+)$/.exec(tok))) {
        const [, key, v] = m;
        if (key === 'agent') tests.push((p) => p.agent_name.toLowerCase() === v);
        else if (key === 'merchant') tests.push((p) => has(p.merchant, v));
        else if (key === 'method') tests.push((p) => p.payment_method === v);
        else if (key === 'verified') tests.push((p) => verified(p) === ['yes', 'true', 'y'].includes(v));
        else {
          if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(v)) throw new LedgerError('month must look like 2026-09.');
          tests.push(between(`${v}-01`, `${addMonths(v, 1)}-01`));
        }
      } else if ((m = /^(>=|<=|>|<)\$?(\d+(?:\.\d{1,2})?)$/.exec(tok))) {
        const cents = Math.round(Number(m[2]) * 100);
        const cmp = { '>': (a) => a > cents, '<': (a) => a < cents, '>=': (a) => a >= cents, '<=': (a) => a <= cents }[m[1]];
        tests.push((p) => cmp(p.amount_cents));
      } else if (tok === 'this-month') tests.push(between(`${thisMonth}-01`, `${addMonths(thisMonth, 1)}-01`));
      else if (tok === 'last-month') tests.push(between(`${addMonths(thisMonth, -1)}-01`, `${thisMonth}-01`));
      else if (tok === 'this-year') tests.push(between(`${year}-01-01`, `${year + 1}-01-01`));
      else if (tok === 'last-year') tests.push(between(`${year - 1}-01-01`, `${year}-01-01`));
      else tests.push((p) => has(p.merchant, tok) || p.agent_name.toLowerCase() === tok);
    }
    const purchases = this.confirmedPurchases().filter((p) => tests.every((t) => t(p)));
    const by = new Map();
    for (const p of purchases) {
      const t = by.get(p.currency) ?? { currency: p.currency, cents: 0, count: 0, verified_count: 0 };
      t.cents += p.amount_cents;
      t.count++;
      if (verified(p)) t.verified_count++;
      by.set(p.currency, t);
    }
    return { purchases, totals: [...by.values()].sort((a, b) => b.cents - a.cents) };
  }

  /** Write one line of the audit trail: what was decided, when, about which purchase. Local only. */
  audit(action, purchaseId, detail = '') {
    const p = purchaseId ? this.db.prepare('SELECT merchant, amount_cents, currency, agent_id FROM purchases WHERE id = ?').get(purchaseId) : null;
    this.db.prepare(`INSERT INTO audit_log (at, action, purchase_id, merchant, amount_cents, currency, agent_id, detail)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)`).run(this.now().toISOString(), action, purchaseId ?? null, p?.merchant ?? null,
      p?.amount_cents ?? null, p?.currency ?? null, p?.agent_id ?? null, String(detail));
  }

  /** The audit trail, newest first (Pro, seat two and up). */
  auditLog({ limit = 500 } = {}) {
    return this.db.prepare(`
      SELECT l.id, l.at, l.action, l.purchase_id, l.merchant, l.amount_cents, l.currency, a.name AS agent, l.detail
      FROM audit_log l LEFT JOIN agents a ON a.id = l.agent_id ORDER BY l.id DESC LIMIT ?`).all(Math.min(Number(limit) || 500, 5000));
  }

  /** Hide the setup checklist for good (see src/onboarding.js). */
  dismissOnboarding() {
    setMeta(this.db, 'onboarding_dismissed', '1');
    this.track('onboarding_dismissed');
  }

  /** Recurring charges each agent started (see src/subscriptions.js). */
  subscriptions() {
    const rows = this.db.prepare(`
      SELECT p.agent_id, a.name AS agent, p.merchant, p.merchant_key, p.amount_cents, p.currency, p.occurred_on
      FROM purchases p JOIN agents a ON a.id = p.agent_id WHERE p.status = 'confirmed'`).all()
      .map((r) => ({ ...r, group: firstToken(r.merchant_key) }));
    return findSubscriptions(rows, toLocalDate(this.now()));
  }

  /** The Mine bucket for a period: your own spending, newest first (no transfers, payments or deposits). */
  minePurchases({ from, to }) {
    return this.db.prepare(`
      SELECT p.id, p.occurred_on, p.amount_cents, p.currency, p.merchant, p.merchant_key, p.description, s.kind AS source_kind,
             COALESCE((SELECT a.name FROM purchases c JOIN sources cs ON cs.id = c.source_id JOIN agents a ON a.id = c.reported_by_agent_id
                        WHERE c.merged_into = p.id AND cs.kind = 'alert' ORDER BY c.id DESC LIMIT 1),
                       (SELECT a.name FROM agents a WHERE a.id = p.reported_by_agent_id AND s.kind = 'alert')) AS found_by,
             p.attributed_by, (SELECT group_concat(DISTINCT s2.kind) FROM purchases c JOIN sources s2 ON s2.id = c.source_id WHERE c.merged_into = p.id) AS also_seen_by
      FROM purchases p JOIN sources s ON s.id = p.source_id
      WHERE p.status IN ('background', 'not_agent') AND p.amount_cents > 0 AND p.occurred_on >= ? AND p.occurred_on < ?
      ORDER BY p.occurred_on DESC, p.id DESC`).all(from, to)
      .filter((p) => !NOT_SPENDING.test(`${p.merchant_key} ${String(p.description).toUpperCase()}`));
  }

  /** The agent bucket. Confirmed only — by construction, never personal spending. */
  confirmedPurchases({ from = null, to = null, agentId = null } = {}) {
    const where = ["p.status = 'confirmed'"];
    const args = [];
    if (from) { where.push('p.occurred_on >= ?'); args.push(from); }
    if (to) { where.push('p.occurred_on < ?'); args.push(to); }
    if (agentId) { where.push('p.agent_id = ?'); args.push(Number(agentId)); }
    return this.db.prepare(`
      SELECT p.id, p.occurred_on, p.amount_cents, p.currency, p.merchant, p.agent_id, a.name AS agent_name,
             p.attributed_by, s.kind AS source_kind, p.payment_method, p.verified_at, p.job,
             (SELECT group_concat(DISTINCT s2.kind) FROM purchases c JOIN sources s2 ON s2.id = c.source_id
               WHERE c.merged_into = p.id) AS also_seen_by,
             (SELECT count(*) FROM receipts r WHERE r.purchase_id = p.id) AS receipt_count
      FROM purchases p JOIN agents a ON a.id = p.agent_id JOIN sources s ON s.id = p.source_id
      WHERE ${where.join(' AND ')} ORDER BY p.occurred_on DESC, p.id DESC`).all(...args);
  }

  /** Search personal/background activity so a missed agent purchase can be pulled in. */
  searchActivity(q, limit = 25) {
    const term = `%${String(q ?? '').trim().toUpperCase()}%`;
    return this.db.prepare(`
      SELECT id, occurred_on, amount_cents, currency, merchant, status FROM purchases
      WHERE status IN ('background', 'not_agent') AND (upper(merchant) LIKE ? OR upper(description) LIKE ?)
      ORDER BY occurred_on DESC, id DESC LIMIT ?`).all(term, term, Math.min(Number(limit) || 25, 100));
  }

  listRules() {
    return this.db.prepare(`
      SELECT r.id, r.merchant_key, r.action, r.agent_id, a.name AS agent_name, r.created_at
      FROM rules r LEFT JOIN agents a ON a.id = r.agent_id ORDER BY r.id`).all();
  }

  deleteRule(id) {
    const { changes } = this.db.prepare('DELETE FROM rules WHERE id = ?').run(Number(id));
    if (!changes) throw new LedgerError('No such rule.', 404);
    this.track('rule_deleted');
  }

  counts() {
    const rows = this.db.prepare('SELECT status, count(*) AS n FROM purchases GROUP BY status').all();
    const out = { background: 0, candidate: 0, confirmed: 0, not_agent: 0, merged: 0 };
    for (const r of rows) out[r.status] = r.n;
    return out;
  }
}
