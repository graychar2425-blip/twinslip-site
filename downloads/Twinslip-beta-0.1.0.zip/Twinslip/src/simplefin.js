// SimpleFIN client — https://www.simplefin.org/protocol.html
//
// Flow: the user buys SimpleFIN Bridge themselves, connects their bank there, and pastes
// a one-time Setup Token here. We POST to the claim URL inside it once and get back an
// Access URL (Basic-auth credentials embedded). From then on: GET {access}/accounts.
//
// Bridge limits (https://beta-bridge.simplefin.org/info/developers): ≤24 requests/day,
// overlap windows by ~5 days. The guide says ≤90 days per request, but the live Bridge
// (checked 2026-10-02) warns above 45 days that it "may be capped" — so we use 45.
// Exceeding limits can get the user's access disabled; we auto-sync at most every 6h.

import { epochToLocalDate } from './dates.js';
import { parseAmountToCents } from './money.js';
import { LedgerError } from './ledger.js';
import { getSimplefinAccessUrl, setSimplefinAccessUrl } from './credentials.js';

const DAY = 86400;
const MAX_WINDOW_DAYS = 45;
const OVERLAP_DAYS = 5;
const FIRST_SYNC_DAYS = 90;
const MAX_WINDOWS_PER_SYNC = 4; // first sync = 3 requests; a long gap is capped, not burst
export const AUTO_SYNC_INTERVAL_MS = 6 * 3600 * 1000;
export const MAX_SYNCS_PER_DAY = 20;

export class SimplefinError extends LedgerError {
  constructor(message, code, status = 502) {
    super(message, status);
    this.code = code;
  }
}

/** Setup Token → claim URL. Tokens are base64 URLs; anything else is rejected. */
export function decodeSetupToken(token) {
  const t = String(token ?? '').trim();
  if (!/^[A-Za-z0-9+/_-]+={0,2}$/.test(t)) {
    throw new SimplefinError("That doesn't look like a SimpleFIN Setup Token.", 'bad_token', 400);
  }
  const decoded = Buffer.from(t, 'base64').toString('utf8').trim();
  let url;
  try {
    url = new URL(decoded);
  } catch {
    throw new SimplefinError("That doesn't look like a SimpleFIN Setup Token.", 'bad_token', 400);
  }
  if (url.protocol !== 'https:') {
    throw new SimplefinError('Setup Token must point at an https:// SimpleFIN server.', 'not_https', 400);
  }
  if (url.username || url.password) {
    throw new SimplefinError('That looks like an Access URL, not a Setup Token.', 'bad_token', 400);
  }
  return url.toString();
}

/** Access URL → { base, authorization }. Node's fetch refuses credentials inside URLs. */
export function parseAccessUrl(accessUrl) {
  let url;
  try {
    url = new URL(String(accessUrl).trim());
  } catch {
    throw new SimplefinError('SimpleFIN returned an invalid Access URL.', 'bad_access_url');
  }
  if (url.protocol !== 'https:') throw new SimplefinError('SimpleFIN Access URL is not https.', 'not_https');
  if (!url.username) throw new SimplefinError('SimpleFIN Access URL has no credentials.', 'bad_access_url');
  const user = decodeURIComponent(url.username);
  const pass = decodeURIComponent(url.password);
  url.username = '';
  url.password = '';
  return {
    base: url.toString().replace(/\/+$/, ''),
    authorization: `Basic ${Buffer.from(`${user}:${pass}`).toString('base64')}`,
  };
}

/** Outbound calls give up after this long, so a stuck bank feed never holds the sync lock. */
export const FETCH_TIMEOUT_MS = 15_000;

export async function claimAccessUrl(setupToken, { fetch = globalThis.fetch, timeoutMs = FETCH_TIMEOUT_MS } = {}) {
  const claimUrl = decodeSetupToken(setupToken);
  let res;
  try {
    res = await fetch(claimUrl, { method: 'POST', headers: { 'Content-Length': '0' }, signal: AbortSignal.timeout(timeoutMs) });
  } catch (err) {
    throw new SimplefinError(`Couldn't reach SimpleFIN (${err.cause?.code ?? err.message}).`, 'network');
  }
  if (res.status === 403) {
    // Required by the SimpleFIN checklist: a 403 here can mean someone else claimed it.
    throw new SimplefinError(
      'SimpleFIN says this token was already used or does not exist. If you did not use it ' +
      'yourself, disable it in SimpleFIN Bridge now — someone else may have claimed access — ' +
      'then create a new token.', 'claim_forbidden', 403);
  }
  if (!res.ok) throw new SimplefinError(`SimpleFIN claim failed (HTTP ${res.status}).`, 'claim_failed');
  const accessUrl = (await res.text()).trim();
  parseAccessUrl(accessUrl); // validate before we store it
  return accessUrl;
}

export async function fetchAccountSet(accessUrl, { startDate, endDate, fetch = globalThis.fetch, timeoutMs = FETCH_TIMEOUT_MS } = {}) {
  const { base, authorization } = parseAccessUrl(accessUrl);
  const q = new URLSearchParams({ version: '2' });
  if (startDate !== undefined) q.set('start-date', String(startDate));
  if (endDate !== undefined) q.set('end-date', String(endDate));
  let res;
  try {
    res = await fetch(`${base}/accounts?${q}`, { headers: { Authorization: authorization, Accept: 'application/json' }, signal: AbortSignal.timeout(timeoutMs) });
  } catch (err) {
    throw new SimplefinError(`Couldn't reach SimpleFIN (${err.cause?.code ?? err.message}).`, 'network');
  }
  if (res.status === 402) {
    throw new SimplefinError('SimpleFIN says payment is required — check your SimpleFIN Bridge subscription.', 'payment_required', 402);
  }
  if (res.status === 403) {
    throw new SimplefinError('SimpleFIN rejected the saved access (it may have been disabled). Reconnect with a new Setup Token.', 'access_revoked', 403);
  }
  if (!res.ok) throw new SimplefinError(`SimpleFIN returned HTTP ${res.status}.`, 'http_error');
  try {
    return await res.json();
  } catch {
    throw new SimplefinError('SimpleFIN returned something that is not JSON.', 'bad_json');
  }
}

/** Plain-text, length-limited error messages (the spec requires sanitizing them). */
function cleanMessage(s) {
  return String(s ?? '').replace(/[\u0000-\u001f\u007f<>]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 300);
}

/**
 * Account Set (v1 or v2) → { txns, errors }. Keeps only what the ledger stores: date,
 * amount, merchant text. Account ids go into the dedupe key (transaction ids are only
 * unique within an account) but are hashed out of anything human-readable.
 */
export function normalizeAccountSet(set) {
  const errors = [];
  for (const e of set?.errlist ?? []) errors.push(cleanMessage(e?.msg ?? e?.code));
  for (const e of set?.errors ?? []) errors.push(cleanMessage(e)); // v1
  const txns = [];
  for (const acct of set?.accounts ?? []) {
    const conn = acct.conn_id ?? acct.org?.domain ?? acct.org?.name ?? '';
    const currency = /^[A-Z]{3}$/.test(acct.currency ?? '') ? acct.currency : null;
    if (!currency) continue; // custom currencies (points, miles) are not agent spend
    for (const t of acct.transactions ?? []) {
      if (t.pending) continue; // pending ids change when they post; wait for the posted row
      const when = Number(t.transacted_at) > 0 ? Number(t.transacted_at) : Number(t.posted);
      if (!(when > 0)) continue;
      const cents = parseAmountToCents(String(t.amount));
      if (cents === null || cents === 0) continue;
      txns.push({
        externalId: `${conn}|${acct.id}|${t.id}`,
        occurredOn: epochToLocalDate(when),
        amountCents: -cents, // SimpleFIN: negative = money out. Ledger: positive = spend.
        currency,
        description: String(t.description ?? ''),
        payee: t.payee ? String(t.payee) : null,
      });
    }
  }
  return { txns, errors };
}

/** Windows to request: from (last success − overlap) or 90 days ago, up to now. */
export function syncWindows(lastSuccessIso, nowMs) {
  const end = Math.floor(nowMs / 1000) + DAY;
  let start = lastSuccessIso
    ? Math.floor(new Date(lastSuccessIso).getTime() / 1000) - OVERLAP_DAYS * DAY
    : end - (FIRST_SYNC_DAYS + 1) * DAY;
  const windows = [];
  while (start < end) {
    const wEnd = Math.min(start + MAX_WINDOW_DAYS * DAY, end);
    windows.push({ startDate: start, endDate: wEnd });
    start = wEnd;
  }
  // If we've been offline a long time, take the most recent windows and say so.
  const kept = windows.slice(-MAX_WINDOWS_PER_SYNC);
  kept.truncated = windows.length > kept.length;
  return kept;
}

export async function connectSimplefin(ledger, setupToken, { fetch = globalThis.fetch } = {}) {
  if (!ledger.dataDir) throw new LedgerError('SimpleFIN needs a data directory to store access.', 500);
  const accessUrl = await claimAccessUrl(setupToken, { fetch });
  const host = new URL(parseAccessUrl(accessUrl).base).host;
  const sourceId = ledger.ensureSource('simplefin', `SimpleFIN (${host})`);
  setSimplefinAccessUrl(ledger.dataDir, sourceId, accessUrl);
  ledger.track('source_connected', { kind: 'simplefin' });
  return { sourceId };
}

export function syncsInLastDay(ledger) {
  const since = new Date(ledger.now().getTime() - DAY * 1000).toISOString();
  return ledger.db.prepare("SELECT count(*) AS n FROM events WHERE name = 'sync_attempt' AND at >= ?").get(since).n;
}

export async function syncSimplefin(ledger, sourceId, { fetch = globalThis.fetch } = {}) {
  const source = ledger.db.prepare("SELECT * FROM sources WHERE id = ? AND kind = 'simplefin'").get(Number(sourceId));
  if (!source) throw new LedgerError('No such SimpleFIN connection.', 404);
  const accessUrl = getSimplefinAccessUrl(ledger.dataDir, source.id);
  if (!accessUrl) throw new LedgerError('This SimpleFIN connection has no saved access. Reconnect it.', 409);
  if (syncsInLastDay(ledger) >= MAX_SYNCS_PER_DAY) {
    throw new LedgerError('Synced a lot today already — SimpleFIN allows about 24 requests a day. Try again later.', 429);
  }
  const nowIso = ledger.now().toISOString();
  ledger.db.prepare('UPDATE sources SET last_attempt_at = ? WHERE id = ?').run(nowIso, source.id);
  ledger.track('sync_attempt', { kind: 'simplefin' });
  const total = { inserted: 0, merged: 0, candidates: 0, auto: 0, duplicates: 0, errors: [] };
  try {
    const windows = syncWindows(source.last_success_at, ledger.now().getTime());
    if (windows.truncated) {
      total.errors.push('Only the most recent 180 days were fetched. Import a CSV export to fill the older gap.');
    }
    for (const w of windows) {
      const set = await fetchAccountSet(accessUrl, { ...w, fetch });
      const { txns, errors } = normalizeAccountSet(set);
      const r = ledger.ingest(source.id, txns);
      for (const k of ['inserted', 'merged', 'candidates', 'auto', 'duplicates']) total[k] += r[k];
      total.errors.push(...errors);
    }
  } catch (err) {
    ledger.db.prepare('UPDATE sources SET last_error = ? WHERE id = ?').run(cleanMessage(err.message), source.id);
    ledger.track('sync_failed', { kind: 'simplefin', code: err.code ?? 'error' });
    throw err;
  }
  const errText = total.errors.length ? [...new Set(total.errors)].join(' · ') : null;
  ledger.db.prepare('UPDATE sources SET last_success_at = ?, last_error = ? WHERE id = ?').run(nowIso, errText, source.id);
  ledger.track('sync_completed', { kind: 'simplefin', inserted: total.inserted, candidates: total.candidates, auto: total.auto });
  return total;
}
