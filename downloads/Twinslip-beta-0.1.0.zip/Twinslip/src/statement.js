// The client statement (Pro): what the user attaches to their own invoice, as a PDF and a CSV,
// and invoice lines to bring into their invoicing tool. Each line says how it was checked; agent
// reports with no independent proof are marked; the handling fee is its own line, never folded
// into the amounts. Twinslip never sends an invoice.
//
// The invoice lines are a plain CSV whose columns are named like Xero's sales invoice import, so
// they line up with its template; QuickBooks Online's invoice import asks you to match columns.
// Neither has been tried with a real account yet, and both need settings only the user has (an
// account code and tax rate in Xero, products and tax codes in QuickBooks).

import { makePdf, textWidth, lineRoom } from './pdf.js';
import { csvField } from './export.js';
import { formatCents } from './money.js';
import { addDays } from './dates.js';

// File names: accents dropped (Zürich → Zurich), anything else that isn't a plain letter or digit becomes "-".
const safe = (s) => String(s).normalize('NFKD').replace(/[\u0300-\u036f]/g, '')
  .replace(/[^A-Za-z0-9._-]+/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '').slice(0, 60) || 'client';
const decimal = (cents) => (cents / 100).toFixed(2);
const num = (s) => ({ raw: s }); // already-formatted amounts: never apostrophe-prefixed
const row = (fields) => fields.map((f) => (f && f.raw !== undefined ? f.raw : csvField(f))).join(',');

export const STATEMENT_TITLE = 'Statement of AI costs';
// What each check means, said on the statement only for the checks it has.
const LEGEND = {
  bank: 'Bank: a line on the bank statement.',
  iphone: 'iPhone: a Wallet tap or a bank text, recorded on the iPhone.',
  receipt: 'Receipt attached: a receipt file the preparer attached.',
  webhook: "Webhook: recorded by the preparer's own system, not by the agent.",
  verified: 'Verified: seen by a source other than the agent.',
  by_hand: 'Added by hand: typed in by the preparer, with nothing else to check it against.',
};

export const PROOF_NOTE = [
  '* Reported by an agent, with no independent proof yet: no bank line, iPhone record or receipt attached by hand',
  '  has seen the charge.',
];

export function statementFilename(st, ext) {
  return `Twinslip-statement-${safe(st.client.name)}-${st.period.slug}.${ext}`;
}

export function invoiceLinesFilename(st) {
  return `Twinslip-invoice-lines-${safe(st.client.name)}-${st.period.slug}.csv`;
}

/** "Handling fee (12.5%)" from hundredths of a percent. */
export function feeLabel(bp) {
  return `Handling fee (${String(bp / 100)}%)`;
}

/**
 * One statement line, fitted beside its amount: the longest of merchant, agent and job is
 * shortened with "..." until it fits, so the date and how the line was checked are never cut.
 */
function lineText(l, size, amount) {
  const head = `${l.marked ? '* ' : ''}${l.occurred_on}  `;
  const tail = ` - ${l.evidence_label}`;
  const parts = [l.merchant, l.agent, l.job].filter(Boolean);
  const text = () => `${head}${parts.join(' - ')}${tail}`;
  const room = lineRoom(size, amount);
  while (textWidth(text(), size) > room) {
    const i = parts.reduce((best, p, k) => (p.length > (parts[best]?.length ?? 4) ? k : best), -1);
    if (i < 0) break; // nothing left to shorten; the writer cuts the rest
    const base = parts[i].endsWith('...') ? parts[i].slice(0, -3) : parts[i];
    parts[i] = `${base.slice(0, -1).trimEnd()}...`;
  }
  return text();
}

/** The statement as a PDF (src/pdf.js): a Buffer. */
export function statementPdf(st) {
  const multi = st.totals.length > 1;
  const lines = [];
  if (st.business_name) lines.push({ text: st.business_name, size: 18, bold: true });
  lines.push({ text: STATEMENT_TITLE, size: st.business_name ? 13 : 18, bold: true, gap: st.business_name ? 4 : 0 });
  lines.push({ text: `Client: ${st.client.name}`, gap: 6 });
  lines.push({ text: `Period: ${st.period.label}` });
  lines.push({ text: `Prepared on ${st.prepared_on}. Amounts are as charged, in the currency charged.` });
  lines.push({ text: 'Date, merchant, agent, job, and how the charge was checked', size: 9, bold: true, gap: 12 });
  for (const l of st.lines) {
    const amount = formatCents(l.cents, l.currency);
    lines.push({ text: lineText(l, 9, amount), right: amount, size: 9 });
  }
  if (!st.lines.length) lines.push({ text: 'Nothing to bill for this period.' });
  for (const t of st.totals) {
    const cur = multi ? ` (${t.currency})` : '';
    lines.push({ text: `Subtotal${cur}`, right: formatCents(t.subtotal_cents, t.currency), bold: true, gap: 8 });
    if (t.markup_cents) lines.push({ text: `${feeLabel(st.client.markup_bp)}${cur}`, right: formatCents(t.markup_cents, t.currency) });
    lines.push({ text: `Total${cur}`, right: formatCents(t.total_cents, t.currency), bold: true, size: 12 });
  }
  if (st.marked) lines.push({ text: PROOF_NOTE[0], size: 8, gap: 12 }, { text: PROOF_NOTE[1], size: 8 });
  const checks = [...new Set(st.lines.map((l) => l.evidence))].filter((e) => LEGEND[e]);
  if (checks.length) lines.push({ text: 'How each line was checked:', size: 8, bold: true, gap: st.marked ? 6 : 12 }, ...checks.map((e) => ({ text: LEGEND[e], size: 8 })));
  lines.push({ text: 'A record of costs to go with an invoice, made with Twinslip on the preparer\'s own computer. It is not an invoice.', size: 8, gap: 6 });
  const who = st.business_name ? `${st.business_name} - ` : '';
  return makePdf(lines, { title: `${STATEMENT_TITLE} - ${st.client.name} - ${st.period.label}`, footer: `${who}${STATEMENT_TITLE} for ${st.client.name}, ${st.period.label}` });
}

const PROVEN = new Set(['bank', 'iphone', 'receipt', 'webhook', 'verified']);

/** The statement as a CSV: a row per line, then subtotal, fee and total rows per currency (column Kind tells them apart). */
export function statementCsv(st) {
  const tail = [st.client.name, st.period.label, st.business_name];
  const out = [row(['Kind', 'Date', 'Merchant', 'Agent', 'Job', 'Checked by', 'Independent proof', 'Amount', 'Currency', 'Ledger ID', 'Client', 'Period', 'Prepared by'])];
  for (const l of st.lines) {
    out.push(row(['line', l.occurred_on, l.merchant, l.agent, l.job ?? '', l.evidence_label, PROVEN.has(l.evidence) ? 'yes' : 'no', num(decimal(l.cents)), l.currency, l.id, ...tail]));
  }
  for (const t of st.totals) {
    out.push(row(['subtotal', '', '', '', '', '', '', num(decimal(t.subtotal_cents)), t.currency, '', ...tail]));
    if (t.markup_cents) out.push(row(['fee', '', feeLabel(st.client.markup_bp), '', '', '', '', num(decimal(t.markup_cents)), t.currency, '', ...tail]));
    out.push(row(['total', '', '', '', '', '', '', num(decimal(t.total_cents)), t.currency, '', ...tail]));
  }
  return `${out.join('\r\n')}\r\n`;
}

/**
 * Invoice lines: one row per cost and one for the handling fee, dated `issuedOn` and due 30 days
 * later. An invoice holds one currency, so with two currencies the invoice number gets each
 * currency appended (INV-7-USD, INV-7-EUR). With no invoice number the column is left for yours.
 */
export function invoiceLinesCsv(st, { invoice = '', issuedOn = st.prepared_on, dueDays = 30 } = {}) {
  const number = String(invoice ?? '').trim();
  const due = addDays(issuedOn, dueDays);
  const multi = st.totals.length > 1;
  const out = [row(['ContactName', 'InvoiceNumber', 'InvoiceDate', 'DueDate', 'Description', 'Quantity', 'UnitAmount', 'AccountCode', 'TaxType', 'Currency'])];
  for (const t of st.totals) {
    const inv = number && multi ? `${number}-${t.currency}` : number;
    const line = (description, cents) => row([st.client.name, inv, issuedOn, due, description, 1, num(decimal(cents)), '', '', t.currency]);
    for (const l of st.lines.filter((x) => x.currency === t.currency)) {
      out.push(line(`${l.merchant}, ${l.occurred_on}${l.job ? `, ${l.job}` : ''}`, l.cents));
    }
    if (t.markup_cents) out.push(line(`${feeLabel(st.client.markup_bp)} on AI costs`, t.markup_cents));
  }
  return `${out.join('\r\n')}\r\n`;
}
