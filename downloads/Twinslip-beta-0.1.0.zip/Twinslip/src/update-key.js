// The public half of Twinslip's release key (Ed25519, SPKI DER in base64). The app trusts an
// update file (`<site>/updates/latest.json`) only when its signature checks out against this key.
//
// It is null until Daniel makes the release key once on his Mac:
//   node scripts/release-key.mjs init
// That keeps the private half in ~/.twinslip-release (never in this repo) and writes the public
// half here. While it is null, the app makes no update request: there would be nothing to trust.
export const UPDATE_PUBLIC_KEY = 'MCowBQYDK2VwAyEAPUI7settIeLpRDZD73QGtKuysiiBs831F8b3pX/krEA=';
