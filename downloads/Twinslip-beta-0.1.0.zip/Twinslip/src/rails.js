// Receipts agents already hold (docs/CONTRACTS.md §8; why and where from:
// docs/research/agent-distribution-and-payments-2026-10-23.md, Move 5 and §2).
//
// Every rail an agent can pay on hands the agent a machine-readable result, and none of them
// pushes anything to an app on the user's computer. So the agent passes on what it got back
// (`rail` and `receipt` on record_purchase and record_usage), and this reads it:
//
//   x402  the SettlementResponse: the PAYMENT-RESPONSE header (base64) or the tool result's
//         _meta["x402/payment-response"]. With the requirements it paid (`accepted`, or the 402's
//         PaymentRequired) and the `resource`, the amount and the merchant can be read too.
//   mpp   the Payment-Receipt header (base64url JSON) or _meta["org.paymentauth/receipt"]
//   l402  the BOLT11 invoice, plus the preimage that paid it
//   ap2   the payment or checkout receipt (JWTs) and the closed payment mandate (SD-JWT)
//   acp   the completed checkout session, or the order
//   card, other: nothing is read; the receipt is only fingerprinted
//
// What a receipt says is evidence, never verification: the agent supplied it. No signature is
// checked and nothing is looked up anywhere. (Looking an x402 transaction up on its chain would
// hand it to a public RPC provider; that is an opt-in for later.) What comes out is what can be
// read: amount, currency, merchant, date, a reference, and a SHA-256 of the receipt as given.
// The receipt itself is never stored.
//
// Anything that can spend money or sign in is refused with a reason: card details, keys, payment
// tokens (a Skyfire PAY token, a Stripe shared payment token), an L402 macaroon, or the signed
// payment the agent sent instead of the receipt it got back.

import { createHash } from 'node:crypto';
import { LedgerError, sameMerchant } from './ledger.js';
import { merchantKey } from './merchants.js';
import { secretIn, redact } from './redact.js';
import { epochToLocalDate, isIsoDate, toLocalDate } from './dates.js';

export const RAILS = ['x402', 'mpp', 'l402', 'ap2', 'acp', 'card', 'other'];
/** The largest receipt read (its text, or an object's JSON). Real ones are a few KB. */
export const MAX_RECEIPT_BYTES = 64 * 1024;
const MAX_DEPTH = 32;
const RAIL_NAME = { x402: 'x402', mpp: 'MPP', l402: 'L402', ap2: 'AP2', acp: 'ACP', card: 'card', other: 'payment' };

const sha256 = (data) => createHash('sha256').update(data).digest('hex');
const isObject = (v) => Boolean(v) && typeof v === 'object' && !Array.isArray(v);

/** An object's JSON with its keys sorted at every level, so the same receipt always hashes the same. */
function canonical(v) {
  if (Array.isArray(v)) return `[${v.map(canonical).join(',')}]`;
  if (isObject(v)) return `{${Object.keys(v).sort().map((k) => `${JSON.stringify(k)}:${canonical(v[k])}`).join(',')}}`;
  return JSON.stringify(v) ?? 'null';
}

function deeperThan(v, max, depth = 0) {
  if (depth > max) return true;
  if (v && typeof v === 'object') for (const x of Object.values(v)) if (deeperThan(x, max, depth + 1)) return true;
  return false;
}

// ── decoding ────────────────────────────────────────────────────────────────

function fromJsonText(s) {
  const t = s.trim();
  if (!/^[[{]/.test(t)) return undefined;
  try { const v = JSON.parse(t); return v && typeof v === 'object' ? v : undefined; } catch { return undefined; }
}

function fromBase64Json(s) {
  const t = s.trim();
  if (t.length < 8 || !/^[A-Za-z0-9+/_-]+={0,2}$/.test(t)) return undefined;
  try { const v = JSON.parse(Buffer.from(t, 'base64').toString('utf8')); return v && typeof v === 'object' ? v : undefined; } catch { return undefined; }
}

/** A header value or JSON text, as the object it holds (or undefined). */
const decodeText = (s) => (typeof s === 'string' ? fromJsonText(s) ?? fromBase64Json(s) : undefined);

const JWS = /^[A-Za-z0-9_-]{2,}\.[A-Za-z0-9_-]{2,}\.[A-Za-z0-9_-]*$/;

/** A JWT (or an SD-JWT: the JWT, then ~-separated disclosures) decoded without checking anything. */
function decodeJwt(s) {
  const [jws, ...rest] = String(s).trim().split('~');
  if (!JWS.test(jws)) return null;
  const [h, p] = jws.split('.');
  let header;
  let payload;
  try {
    header = JSON.parse(Buffer.from(h, 'base64url').toString('utf8'));
    payload = JSON.parse(Buffer.from(p, 'base64url').toString('utf8'));
  } catch { return null; }
  if (!isObject(header) || !isObject(payload)) return null;
  const disclosed = {};
  for (const d of rest) {
    if (!d || d.includes('.')) continue; // the empty tail, or a key-binding JWT
    try {
      const a = JSON.parse(Buffer.from(d, 'base64url').toString('utf8'));
      if (Array.isArray(a) && a.length === 3 && typeof a[1] === 'string') disclosed[a[1]] = a[2];
    } catch { /* not a disclosure */ }
  }
  return { header, payload, disclosed };
}

/** The first value under `name`, depth first. */
function find(v, name, depth = 0) {
  if (!v || typeof v !== 'object' || depth > MAX_DEPTH) return undefined;
  if (!Array.isArray(v) && Object.hasOwn(v, name) && v[name] !== null) return v[name];
  for (const x of Object.values(v)) {
    const r = find(x, name, depth + 1);
    if (r !== undefined) return r;
  }
  return undefined;
}

/** The first value under any of `names` (in that order) across `bags` (in that order). */
function firstIn(bags, names) {
  for (const n of names) for (const b of bags) { const r = find(b, n); if (r !== undefined) return r; }
  return undefined;
}

const TIME = /^(\d{4}-\d{2}-\d{2})[T ](\d{2}:\d{2}(?::\d{2})?)(\.\d+)?\s*(Z|[+-]\d{2}:?\d{2})?/i;

/**
 * A local date from an epoch in seconds, milliseconds, microseconds or nanoseconds; an RFC 3339
 * time, or one with a space for the T (as Go and SQLite write them); or a date. Anything else, or
 * anything that doesn't come out a real date, is null: an unreadable date is never guessed.
 */
export function dateOf(v) {
  let d = null;
  if (typeof v === 'number' && Number.isFinite(v) && v > 0) {
    d = epochToLocalDate(v >= 1e17 ? v / 1e9 : v >= 1e14 ? v / 1e6 : v >= 1e11 ? v / 1e3 : v);
  } else if (typeof v === 'string') {
    const t = v.trim();
    if (isIsoDate(t)) return t;
    if (/^\d{9,19}$/.test(t)) return dateOf(Number(t));
    const m = TIME.exec(t);
    if (m) {
      const zone = m[4] ? (m[4].toUpperCase() === 'Z' ? 'Z' : m[4].replace(/^([+-]\d{2})(\d{2})$/, '$1:$2')) : '';
      const at = new Date(`${m[1]}T${m[2]}${m[3] ?? ''}${zone}`);
      if (!Number.isNaN(at.getTime())) d = toLocalDate(at);
    }
  }
  return d && isIsoDate(d) ? d : null;
}

const text = (v, max = 80) => (typeof v === 'string' && v.trim() ? redact(v).replace(/\s+/g, ' ').trim().slice(0, max) : null);
/**
 * A reference exactly as the receipt gives it: never redacted or cut here, so two ids never collapse
 * into one ("[redacted]") and a retry still matches. What Twinslip stores of it goes through safeId,
 * which keeps only a hash of anything that looks like a secret.
 */
const ident = (v) => ((typeof v === 'string' || typeof v === 'number') && String(v).trim() ? String(v).trim() : null);

export function hostOf(url) {
  try { return new URL(String(url)).hostname.replace(/^www\./, '') || null; } catch { return null; }
}

// Words too common in merchant names and hosts to say two names are the same merchant.
const GENERIC_WORDS = new Set(['api', 'www', 'com', 'net', 'org', 'app', 'dev', 'inc', 'llc', 'ltd', 'the', 'pay', 'payments']);
const nameWords = (s) => String(s).toLowerCase().split(/[^a-z0-9]+/).filter((w) => w.length >= 3 && !GENERIC_WORDS.has(w));

/** "Example Data", "api.example.com" and "EXAMPLE INC" are one merchant; "Acme" and "Example" aren't. */
export function sameName(a, b) {
  if (sameMerchant(merchantKey(a), merchantKey(b))) return true;
  const words = new Set(nameWords(a));
  return nameWords(b).some((w) => words.has(w));
}

// ── money ───────────────────────────────────────────────────────────────────

const ZERO_DECIMAL = ['BIF', 'CLP', 'DJF', 'GNF', 'ISK', 'JPY', 'KMF', 'KRW', 'PYG', 'RWF', 'UGX', 'VND', 'VUV', 'XAF', 'XOF', 'XPF'];
const THREE_DECIMAL = ['BHD', 'IQD', 'JOD', 'KWD', 'LYD', 'OMR', 'TND'];
/** How many decimals a currency's minor unit has: 2 for USD, 0 for JPY, 3 for KWD. */
export const exponentOf = (c) => (ZERO_DECIMAL.includes(c) ? 0 : THREE_DECIMAL.includes(c) ? 3 : 2);

function amount(micros, currency) {
  return Number.isSafeInteger(micros) && /^[A-Z]{3}$/.test(currency) ? { micros, currency } : null;
}

/** An amount in the currency's minor units (cents; yen), as ACP and AP2 v0.2 give it. */
function fromMinor(value, currency) {
  const c = String(currency ?? '').toUpperCase();
  const n = typeof value === 'string' && /^-?\d+$/.test(value) ? Number(value) : value;
  if (!Number.isSafeInteger(n) || !/^[A-Z]{3}$/.test(c)) return null;
  return amount(n * 10 ** (6 - exponentOf(c)), c);
}

/** A decimal amount in major units ("19.99", 120.0), as W3C payment requests (AP2 v0.1) give it. */
function fromMajor(value, currency) {
  const m = /^(-?)(\d{1,12})(?:\.(\d+))?$/.exec(String(value ?? '').trim());
  if (!m) return null;
  const frac = (m[3] ?? '').padEnd(7, '0');
  const micros = Number(m[2]) * 1e6 + Number(frac.slice(0, 6)) + (Number(frac[6]) >= 5 ? 1 : 0);
  return amount(m[1] ? -micros : micros, String(currency ?? '').toUpperCase());
}

// x402 assets Twinslip knows, so their atomic amounts can be read. A stablecoin counts as its
// currency (USDC as USD), the way agents are asked to report crypto. Anything else: no amount.
const USDC = { currency: 'USD', decimals: 6 };
const ASSETS = new Map([
  ['eip155:1|0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48', USDC], // Ethereum
  ['eip155:8453|0x833589fcd6edb6e08f4c7c32d4f71b54bda02913', USDC], // Base
  ['eip155:84532|0x036cbd53842c5426634e7929541ec2318f3dcf7e', USDC], // Base Sepolia
  ['eip155:137|0x3c499c542cef5e3811e1192ce70d8cc03d5c3359', USDC], // Polygon
  ['eip155:42161|0xaf88d065e77c8cc2239327c5edb3a432268e5831', USDC], // Arbitrum One
  ['eip155:10|0x0b2c639c533813f4aa9d7837caf62653d097ff85', USDC], // OP Mainnet
  ['eip155:43114|0xb97ef9ef8734c71904d8002f8b6bc66dd9c48a6e', USDC], // Avalanche C-Chain
  ['solana:5eykt4UsFv8P8NJdTREpY1vzqKqZKvdp|EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v', USDC], // Solana
  ['solana:EtWTRABZaYq6iMfeYKouRu166VU2xqa1|4zMMC9srt5Ri5X14GAgXhaHii3GnPAEERYPJgZJDncDU', USDC], // Solana devnet
]);
// x402 v1 named its networks; v2 uses CAIP-2.
const V1_NETWORKS = {
  base: 'eip155:8453', 'base-sepolia': 'eip155:84532', ethereum: 'eip155:1', polygon: 'eip155:137', arbitrum: 'eip155:42161',
  optimism: 'eip155:10', avalanche: 'eip155:43114', solana: 'solana:5eykt4UsFv8P8NJdTREpY1vzqKqZKvdp', 'solana-devnet': 'solana:EtWTRABZaYq6iMfeYKouRu166VU2xqa1',
};
const caip = (network) => V1_NETWORKS[network] ?? network;

function assetAmount(network, asset, atomic) {
  const net = caip(String(network ?? ''));
  const a = String(asset ?? '');
  const info = ASSETS.get(`${net}|${net.startsWith('eip155:') ? a.toLowerCase() : a}`);
  if (!info || !/^\d{1,30}$/.test(String(atomic ?? ''))) return null;
  const micros = BigInt(atomic) * 10n ** BigInt(6 - info.decimals);
  return micros <= BigInt(Number.MAX_SAFE_INTEGER) ? amount(Number(micros), info.currency) : null;
}

// ── refusals ────────────────────────────────────────────────────────────────

function unreadable(rail, hint) {
  return new LedgerError(`Twinslip couldn't read this as an ${RAIL_NAME[rail]} receipt: ${hint}. Nothing was recorded; ` +
    'pass the receipt as the rail gave it to you, or call again without a receipt.');
}

function failed(status) {
  return new LedgerError(`This receipt says the payment didn't go through (${text(String(status), 60) ?? 'failed'}). Nothing was recorded; ` +
    'record only payments that completed.');
}

const NEVER_KEPT = 'Twinslip never keeps anything that can spend money or sign in, so nothing was recorded. ' +
  'Leave it out of the receipt (or leave the receipt out) and call again.';

// Fields that hold a secret whatever their value, compared without case or punctuation.
const SECRET_FIELDS = new Set([
  'password', 'passphrase', 'secret', 'clientsecret', 'secretkey', 'privatekey', 'apikey', 'accesstoken', 'refreshtoken',
  'idtoken', 'sessiontoken', 'bearertoken', 'paymenttoken', 'sharedpaymenttoken', 'vaulttoken', 'mnemonic', 'seed',
  'seedphrase', 'xprv', 'macaroon', 'credential', 'credentials', 'l402', 'lsat',
]);
// Fields that hold card details only when they carry the digits (a masked card, "***", is fine).
const CODE_FIELDS = new Set(['cvc', 'cvv', 'cvv2', 'cvc2', 'csc', 'securitycode']);
const PAN_FIELDS = new Set(['pan', 'cardnumber', 'primaryaccountnumber', 'cardno', 'cardnum']);
// A `token` that only names an asset (a symbol, a contract address) is not a credential.
const ASSET_NAME = /^(?:[A-Z0-9]{2,10}|0x[0-9a-fA-F]{40})$/;
// Identifiers and times: a long number there is an id or a timestamp, not a card (whatever its Luhn
// digit says). What Twinslip keeps of one is hashed if it looks like a card anyway (safeId).
const ID_KEY = /^(?:id|ref|reference|hash|nonce|created|timestamp|time|date|iat|exp|nbf)$|(?:_id|Id|_ref|_hash|_number|Number|_no|_at|_time|_date)$/;

/** Why a field holds something that can spend or sign in, or null. */
function credentialField(k, x) {
  if (x === null || x === undefined || x === '' || x === false) return null;
  const key = k.toLowerCase().replace(/[^a-z0-9]/g, '');
  const flat = typeof x === 'object' ? JSON.stringify(x) : String(x);
  if (SECRET_FIELDS.has(key)) return 'looks like a payment credential or a secret';
  if (CODE_FIELDS.has(key) && /\d{3,4}/.test(flat)) return 'looks like a card security code';
  if (PAN_FIELDS.has(key) && flat.replace(/\D/g, '').length >= 12) return 'looks like a card number';
  if (key === 'token' && (typeof x === 'string' ? !ASSET_NAME.test(x.trim())
    : isObject(x) && ['value', 'id', 'token', 'secret'].some((f) => typeof x[f] === 'string'))) return 'looks like a payment token';
  if (key === 'authorization' && (typeof x === 'object'
    || /^\s*(?:Bearer|Basic|Digest|Payment|L402|LSAT)\s/i.test(flat) || flat.trim().length > 40)) return 'looks like a payment authorization or a credential';
  return null;
}

const STRING_CREDENTIALS = [
  [/\bspt_[A-Za-z0-9]{8,}/, 'a Stripe shared payment token (whoever holds one can charge it)'],
  [/-----BEGIN [A-Z ]*PRIVATE KEY-----|\b[xtyz]prv[1-9A-HJ-NP-Za-km-z]{100,}/, 'a private key'],
  [/^\s*(?:L402|LSAT)\s+[A-Za-z0-9+/=_-]{8,}:[0-9a-f]{64}\s*$/i, 'an L402 credential (a macaroon with its preimage lets anyone use what you paid for)'],
  [/^(?:0201036c6e64[0-9a-f]{8,}|AgEDbG5k[A-Za-z0-9+/=_-]{4,})$/i, 'an lnd macaroon'],
];

/** "Payment <base64url JSON with the challenge>": the MPP credential an agent sends, not the receipt it gets. */
function isMppCredential(s) {
  const m = /^\s*Payment\s+([A-Za-z0-9_-]{8,}={0,2})\s*$/.exec(s);
  return Boolean(m) && isObject(fromBase64Json(m[1])) && 'challenge' in fromBase64Json(m[1]);
}

function isX402PaymentPayload(o) {
  const p = o.payload;
  return isObject(p) && ('signature' in p || 'authorization' in p || 'transaction' in p) && ('x402Version' in o || 'accepted' in o || 'scheme' in o);
}

/**
 * Throw if anything in the receipt looks like it can spend or sign in. What can be decoded (a JWT's
 * payload and disclosures, JSON as text or base64) is checked field by field, so a field's meaning
 * decides: a number is never taken for a card, and an id or a time is never a card number.
 */
function refuseCredentials(v, path = 'receipt', depth = 0, { idKey = false } = {}) {
  if (depth > MAX_DEPTH) return;
  if (typeof v === 'string') {
    const j = decodeJwt(v);
    if (j) {
      if (/(?:^|\+)pay(?:\+|$)/i.test(String(j.header.typ ?? '')) || 'sti' in j.payload || 'ssi' in j.payload) {
        throw new LedgerError(`${path} looks like a Skyfire PAY token: whoever holds one can spend it, and it can carry card details. ` +
          'Twinslip never keeps it, so nothing was recorded. Pass the token\'s id (jti) as reference instead.');
      }
      refuseCredentials(j.payload, `${path} (its JWT)`, depth + 1);
      refuseCredentials(j.disclosed, `${path} (its disclosures)`, depth + 1);
      return;
    }
    const decoded = depth < 8 ? decodeText(v) : undefined;
    if (decoded) {
      refuseCredentials(decoded, `${path} (decoded)`, depth + 1);
      return;
    }
    const found = secretIn(v, { cards: !idKey });
    if (found) throw new LedgerError(`${path} holds ${found}. ${NEVER_KEPT}`);
    for (const [re, what] of STRING_CREDENTIALS) if (re.test(v)) throw new LedgerError(`${path} looks like ${what}. ${NEVER_KEPT}`);
    if (isMppCredential(v)) {
      throw new LedgerError(`${path} looks like an MPP payment credential (the Authorization header you sent, not the Payment-Receipt you got back). ${NEVER_KEPT}`);
    }
    return;
  }
  if (Array.isArray(v)) {
    v.forEach((x, i) => refuseCredentials(x, `${path}[${i}]`, depth + 1));
    return;
  }
  if (!isObject(v)) return;
  if (isX402PaymentPayload(v)) {
    throw new LedgerError('That\'s the payment you sent (the PAYMENT-SIGNATURE header, or _meta["x402/payment"]): it carries your signed ' +
      'authorization, which Twinslip never keeps, so nothing was recorded. Pass the receipt you got back instead: the PAYMENT-RESPONSE ' +
      'header, or _meta["x402/payment-response"].');
  }
  for (const [k, x] of Object.entries(v)) {
    const why = credentialField(k, x);
    if (why) throw new LedgerError(`${path}.${k} ${why}. ${NEVER_KEPT}`);
    refuseCredentials(x, `${path}.${k}`, depth + 1, { idKey: ID_KEY.test(k) });
  }
}

// ── BOLT #11 (Lightning invoices) ───────────────────────────────────────────

const CHARSET = 'qpzry9x8gf2tvdw0s3jn54khce6mua7l';

function polymod(values) {
  const GEN = [0x3b6a57b2, 0x26508e6d, 0x1ea119fa, 0x3d4233dd, 0x2a1462b3];
  let chk = 1;
  for (const v of values) {
    const top = chk >>> 25;
    chk = ((chk & 0x1ffffff) << 5) ^ v;
    for (let i = 0; i < 5; i++) if ((top >>> i) & 1) chk ^= GEN[i];
  }
  return chk;
}

const hrpExpand = (hrp) => [...[...hrp].map((c) => c.charCodeAt(0) >> 5), 0, ...[...hrp].map((c) => c.charCodeAt(0) & 31)];

function fromWords(words) {
  let acc = 0;
  let bits = 0;
  const out = [];
  for (const w of words) {
    acc = (acc << 5) | w;
    bits += 5;
    while (bits >= 8) { bits -= 8; out.push((acc >> bits) & 255); }
    acc &= (1 << bits) - 1;
  }
  return Buffer.from(out);
}

const MSAT_PER = { m: 100_000_000n, u: 100_000n, n: 100n };

/**
 * A BOLT #11 invoice, decoded and its checksum checked (its signature isn't: evidence only).
 * Returns { network, msat (null for "any amount"), paymentHash (hex), description, expiry, timestamp } or null.
 */
export function decodeBolt11(invoice) {
  const raw = String(invoice ?? '').trim();
  if (raw !== raw.toLowerCase() && raw !== raw.toUpperCase()) return null;
  const s = raw.toLowerCase().replace(/^lightning:/, '');
  const sep = s.lastIndexOf('1');
  if (sep < 4 || s.length - sep - 1 < 7 + 104 + 6) return null;
  const hrp = s.slice(0, sep);
  const m = /^ln(bcrt|bc|tbs|tb|sb)(?:(\d+)([munp])?)?$/.exec(hrp);
  if (!m) return null;
  const data = [];
  for (const c of s.slice(sep + 1)) {
    const d = CHARSET.indexOf(c);
    if (d < 0) return null;
    data.push(d);
  }
  if (polymod([...hrpExpand(hrp), ...data]) !== 1) return null;
  const words = data.slice(0, -6);
  const timestamp = words.slice(0, 7).reduce((t, w) => t * 32 + w, 0);
  const fields = words.slice(7, -104);
  let paymentHash = null;
  let description = null;
  let expiry = null;
  for (let i = 0; i + 3 <= fields.length;) {
    const type = fields[i];
    const len = fields[i + 1] * 32 + fields[i + 2];
    const body = fields.slice(i + 3, i + 3 + len);
    if (body.length < len) return null;
    if (type === 1 && len === 52) paymentHash = fromWords(body).toString('hex');
    else if (type === 13) description = fromWords(body).toString('utf8');
    else if (type === 6) expiry = body.reduce((t, w) => t * 32 + w, 0);
    i += 3 + len;
  }
  if (!paymentHash) return null;
  let msat = null;
  if (m[2] !== undefined) {
    const n = BigInt(m[2]);
    if (m[3] === 'p' && n % 10n) return null; // a fraction of a millisatoshi
    const v = m[3] === 'p' ? n / 10n : m[3] ? n * MSAT_PER[m[3]] : n * 100_000_000_000n;
    if (v > BigInt(Number.MAX_SAFE_INTEGER)) return null;
    msat = Number(v);
  }
  const network = { bc: 'bitcoin', tb: 'testnet', tbs: 'signet', bcrt: 'regtest', sb: 'simnet' }[m[1]];
  return { network, msat, paymentHash, description, expiry, timestamp };
}

// ── the rails ───────────────────────────────────────────────────────────────

const decodedOr = (v) => (typeof v === 'string' ? decodeText(v) : v);

function x402(receipt) {
  const bag = decodedOr(receipt);
  const hint = 'pass the PAYMENT-RESPONSE header as you got it, or the _meta["x402/payment-response"] object';
  if (!isObject(bag)) throw unreadable('x402', hint);
  let settled = null;
  for (const k of ['x402/payment-response', 'PAYMENT-RESPONSE', 'X-PAYMENT-RESPONSE', 'paymentResponse']) {
    if (bag[k] !== undefined) { settled = decodedOr(bag[k]); break; }
  }
  if (!settled && ('transaction' in bag || 'success' in bag) && 'network' in bag) settled = bag;
  if (!isObject(settled) || typeof settled.network !== 'string' || !settled.network.trim()) throw unreadable('x402', hint);
  if (settled.success === false || settled.errorReason) throw failed(settled.errorReason ?? 'success: false');
  const required = decodedOr(bag['x402/payment-required'] ?? bag['PAYMENT-REQUIRED'] ?? bag.paymentRequired);
  const accepts = Array.isArray(required?.accepts) ? required.accepts.filter(isObject) : [];
  const accepted = isObject(bag.accepted) ? bag.accepted
    : accepts.find((a) => caip(a.network) === caip(settled.network)) ?? (accepts.length === 1 ? accepts[0] : null);
  const resource = isObject(bag.resource) ? bag.resource : isObject(required?.resource) ? required.resource : null;
  const tx = typeof settled.transaction === 'string' ? settled.transaction.trim() : '';
  // The settled amount (upto settles what was used); for `exact`, the amount asked is the amount paid.
  const atomic = settled.amount ?? (accepted?.scheme === 'exact' ? accepted.amount : undefined);
  const sameNetwork = accepted && caip(String(accepted.network ?? settled.network)) === caip(settled.network);
  return {
    reference: tx ? `${settled.network.trim()}:${tx}` : null,
    amount: sameNetwork ? assetAmount(settled.network, accepted.asset, atomic) : null,
    merchant: text(resource?.serviceName) ?? hostOf(resource?.url),
  };
}

const MPP_METHODS = { tempo: 'crypto', lightning: 'crypto', solana: 'crypto', stripe: 'card', card: 'card' };

function mpp(receipt) {
  let bag = decodedOr(receipt);
  if (isObject(bag)) {
    for (const k of ['org.paymentauth/receipt', 'Payment-Receipt', 'payment-receipt']) if (bag[k] !== undefined) { bag = decodedOr(bag[k]); break; }
  }
  if (!isObject(bag) || typeof bag.status !== 'string' || !text(bag.method, 40)) {
    throw unreadable('mpp', 'pass the Payment-Receipt header as you got it, or the _meta["org.paymentauth/receipt"] object');
  }
  if (!/^(?:success|succeeded|paid|settled|completed?)$/i.test(bag.status.trim())) throw failed(bag.status);
  const method = text(bag.method, 40);
  const ref = ident(bag.reference);
  return { reference: ref ? `${method}:${ref}` : null, date: dateOf(bag.timestamp), method: MPP_METHODS[method.toLowerCase()] ?? null };
}

function l402(receipt) {
  const bag = decodedOr(receipt);
  const hint = 'pass { "invoice": "lnbc…", "preimage": "<64 hex characters>" }';
  if (!isObject(bag)) throw unreadable('l402', hint);
  const invoice = bag.invoice ?? bag.payment_request ?? bag.bolt11;
  if (typeof invoice !== 'string') throw unreadable('l402', hint);
  const inv = decodeBolt11(invoice);
  if (!inv) {
    throw new LedgerError("Twinslip couldn't read the invoice: it isn't a valid BOLT11 invoice (lnbc…). Nothing was recorded; " +
      'pass the invoice from the L402 challenge as it was, with its preimage.');
  }
  const preimage = typeof bag.preimage === 'string' ? bag.preimage.trim().toLowerCase() : '';
  if (!preimage) {
    throw new LedgerError('An invoice alone is a bill, not a receipt: pass the preimage you got for paying it too (64 hex characters), ' +
      'or call again without a receipt. Nothing was recorded.');
  }
  if (!/^[0-9a-f]{64}$/.test(preimage)) throw new LedgerError('preimage must be 64 hex characters. Nothing was recorded.');
  if (sha256(Buffer.from(preimage, 'hex')) !== inv.paymentHash) {
    throw new LedgerError("The preimage doesn't match the invoice's payment hash, so this doesn't show the invoice was paid. " +
      'Nothing was recorded; pass the preimage you got for this invoice, or call again without a receipt.');
  }
  return { reference: inv.paymentHash, msat: inv.msat, date: epochToLocalDate(inv.timestamp) };
}

/** AP2's JWTs and objects, as claim sets: receipts first (their `iat` is the payment's day). */
function ap2Claims(receipt) {
  const receipts = [];
  const others = [];
  const add = (v, isReceipt) => {
    if (typeof v === 'string') {
      const j = decodeJwt(v);
      if (j) {
        (isReceipt ? receipts : others).push(j.payload);
        if (Object.keys(j.disclosed).length) (isReceipt ? receipts : others).push(j.disclosed);
        return;
      }
      const d = decodeText(v);
      if (isObject(d)) add(d, isReceipt);
      return;
    }
    if (!isObject(v)) return;
    (isReceipt ? receipts : others).push(v);
    for (const [k, x] of Object.entries(v)) if (typeof x === 'string' && JWS.test(x.split('~')[0])) add(x, /receipt/i.test(k));
  };
  add(receipt, typeof receipt === 'string');
  return { receipts, all: [...receipts, ...others] };
}

function ap2(receipt) {
  const { receipts, all } = ap2Claims(receipt);
  if (!all.length) throw unreadable('ap2', 'pass the receipt JWT, the closed payment mandate, or an object holding them');
  const status = firstIn(all, ['status', 'payment_status']);
  if (typeof status === 'string' && /fail|declin|cancel|reject|error|revers|void/i.test(status)) throw failed(status);
  // v0.2: the closed payment mandate's payment_amount, in minor units. v0.1: a W3C total, in major units.
  const pa = firstIn(all, ['payment_amount']);
  const total = firstIn(all, ['payment_details_total', 'total']);
  const found = isObject(pa) ? fromMinor(pa.amount, pa.currency)
    : isObject(total?.amount) ? fromMajor(total.amount.value, total.amount.currency) : null;
  const payee = firstIn(all, ['payee']);
  const reference = firstIn(all, ['payment_id', 'order_id', 'transaction_id', 'payment_mandate_id']);
  return {
    amount: found,
    merchant: text(isObject(payee) ? payee.name : payee) ?? text(firstIn(all, ['merchant_name'])),
    reference: ident(reference),
    date: dateOf(firstIn(receipts, ['iat'])) ?? dateOf(firstIn(all, ['timestamp'])) ?? dateOf(firstIn(all, ['iat'])),
  };
}

function acp(receipt) {
  let o = decodedOr(receipt);
  if (isObject(o) && isObject(o.data) && /^order_/.test(String(o.type ?? ''))) o = o.data; // an order webhook's envelope
  if (!isObject(o)) throw unreadable('acp', 'pass the checkout session complete_checkout_session returned, or the order');
  const status = typeof o.status === 'string' ? o.status : null;
  let reference;
  if (isObject(o.order)) {
    // A checkout session: only a completed one is a payment.
    if (status && status !== 'completed') {
      throw new LedgerError(`This checkout isn't completed (status ${text(status, 40)}). Nothing was recorded; record it after ` +
        'complete_checkout_session, with what that returns.');
    }
    reference = o.order.id ?? o.id;
  } else {
    if (status && /cancel|fail|declin/i.test(status)) throw failed(status);
    reference = o.id ?? o.order_id ?? o.checkout_session_id;
  }
  const totals = Array.isArray(o.totals) ? o.totals : [];
  const total = totals.find((t) => isObject(t) && t.type === 'total');
  return {
    amount: total && o.currency ? fromMinor(total.amount, o.currency) : null,
    reference: ident(reference),
    date: dateOf(o.created_at ?? o.created),
  };
}

/**
 * What every receipt or mandate an agent passes goes through first: not empty, the right kind,
 * not absurdly nested or large, and nothing that can spend or sign in. Returns its text for the
 * fingerprint: a string as given, an object as sorted-key JSON.
 */
function admit(value, field, what) {
  if (value === undefined || value === null || (typeof value === 'string' && !value.trim()) || (isObject(value) && !Object.keys(value).length)) {
    throw new LedgerError(`${field} is empty. Pass what the payment rail gave you, or leave ${field} out.`);
  }
  if (typeof value !== 'string' && typeof value !== 'object') throw new LedgerError(`${field} must be the object or the text the payment rail gave you.`);
  if (typeof value === 'object' && deeperThan(value, MAX_DEPTH)) throw new LedgerError(`${field} is nested too deeply to be ${what}.`);
  const raw = typeof value === 'string' ? value : canonical(value);
  if (Buffer.byteLength(raw) > MAX_RECEIPT_BYTES) throw new LedgerError(`${field} is too large (over ${MAX_RECEIPT_BYTES / 1024} KB) to be ${what}.`);
  refuseCredentials(value, field);
  return raw;
}

/** The first object (depth first) holding `key` as an object, so a field and its siblings are read together. */
function holderOf(bags, key, depth = 0) {
  for (const v of bags) {
    if (!v || typeof v !== 'object' || depth > MAX_DEPTH) continue;
    if (!Array.isArray(v) && isObject(v[key])) return v;
    const r = holderOf(Object.values(v), key, depth + 1);
    if (r) return r;
  }
  return null;
}

/**
 * An AP2 mandate an agent holds (v0.1 intent or cart mandate; v0.2 checkout or payment mandate,
 * open or closed, as an object, a JWT or an SD-JWT), mapped onto the three parts of a Twinslip
 * mandate it can say something about (research §2.3):
 *   merchants  allowed_merchants, allowed_payees (v0.2); merchants (intent); merchant_name (cart)
 *   max        amount_range.max, minor units (v0.2); the cart's total (v0.1)
 *   until      the earliest of exp, execution_date.not_after, intent_expiry, cart_expiry
 * Returns { merchants: [{ name, field }], max: { micros, currency, field } | null, until: { date, field } | null }.
 * Nothing is verified, stored or applied: check_mandate names these next to the user's answer.
 */
export function readAp2Mandate(mandate) {
  admit(mandate, 'ap2_mandate', 'an AP2 mandate');
  const { all } = ap2Claims(mandate);
  if (!all.length) {
    throw new LedgerError("Twinslip couldn't read ap2_mandate: pass the AP2 mandate as you hold it (the object, or its JWT). Nothing was checked.");
  }
  const merchants = [];
  const add = (raw, field) => {
    const name = text(isObject(raw) ? raw.name ?? raw.id : raw);
    if (name && !merchants.some((m) => m.name.toLowerCase() === name.toLowerCase())) merchants.push({ name, field });
  };
  for (const field of ['allowed_merchants', 'allowed_payees', 'merchants']) {
    const list = firstIn(all, [field]);
    if (Array.isArray(list)) for (const m of list.slice(0, 50)) add(m, field);
  }
  add(firstIn(all, ['merchant_name']), 'merchant_name');
  let max = null;
  const holder = holderOf(all, 'amount_range');
  if (holder) {
    const found = fromMinor(holder.amount_range.max, holder.amount_range.currency ?? holder.currency ?? firstIn(all, ['currency']));
    if (found) max = { ...found, field: 'amount_range.max' };
  }
  const total = firstIn(all, ['total']);
  if (!max && isObject(total?.amount)) {
    const found = fromMajor(total.amount.value, total.amount.currency);
    if (found) max = { ...found, field: 'total' };
  }
  const execution = firstIn(all, ['execution_date']);
  const ends = [
    ['exp', firstIn(all, ['exp'])], ['execution_date.not_after', isObject(execution) ? execution.not_after : undefined],
    ['intent_expiry', firstIn(all, ['intent_expiry'])], ['cart_expiry', firstIn(all, ['cart_expiry'])],
  ].map(([field, v]) => ({ field, date: dateOf(v) })).filter((e) => e.date);
  const until = ends.sort((a, b) => a.date.localeCompare(b.date))[0] ?? null;
  return { merchants, max, until };
}

const READERS = { x402, mpp, l402, ap2, acp };
const METHOD = { x402: 'crypto', l402: 'crypto', acp: 'card', card: 'card' };
/** How each rail is named to people: "the x402 receipt". */
export const RAIL_LABEL = RAIL_NAME;

/**
 * `rail` and `receipt` as an agent passed them to a tool. Null when neither came; a rail on its
 * own is kept without a receipt; a receipt needs its rail. Otherwise what readReceipt returns.
 */
export function readRail(rail, receipt) {
  if (rail === undefined && receipt === undefined) return null;
  if (rail === undefined) throw new LedgerError(`Say which rail the receipt is from: pass rail, one of ${RAILS.join(', ')}. Nothing was recorded.`);
  if (!RAILS.includes(rail)) throw new LedgerError(`rail must be one of: ${RAILS.join(', ')}.`);
  if (receipt === undefined) return { rail, sha256: null, reference: null, amount: null, merchant: null, date: null, method: METHOD[rail] ?? null, msat: null };
  return readReceipt(rail, receipt);
}

/**
 * Read a receipt an agent got back from a payment rail. Returns
 *   { rail, sha256, reference, amount: { micros, currency } | null, merchant, date, method, msat }
 * where each read field is null when the receipt doesn't say it. `msat` is an L402 invoice's
 * amount (sats are never converted: no price is looked up). Throws a LedgerError with a plain
 * reason for an unknown rail, a receipt it can't read, one that says the payment failed, and
 * anything that can spend or sign in.
 */
export function readReceipt(rail, receipt) {
  if (!RAILS.includes(rail)) throw new LedgerError(`rail must be one of: ${RAILS.join(', ')}.`);
  const raw = admit(receipt, 'receipt', 'a payment receipt');
  const base = { rail, sha256: sha256(raw), reference: null, amount: null, merchant: null, date: null, method: METHOD[rail] ?? null, msat: null };
  const read = READERS[rail];
  if (!read) return base;
  const found = read(receipt);
  return { ...base, ...Object.fromEntries(Object.entries(found).filter(([, v]) => v !== undefined && v !== null)) };
}
