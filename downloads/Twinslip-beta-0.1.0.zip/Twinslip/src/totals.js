import { addDays, addMonths, monthKey, toLocalDate, weekStart } from './dates.js';
import { heldSpend } from './plan.js';

/**
 * Per-agent totals for the last `count` weeks (Mon–Sun) or calendar months, oldest first.
 * Confirmed purchases only. Currencies are never added together.
 *
 * Returns { period, buckets: [{ key, label, from, to }], series: [{ agent_id, agent_name,
 *   currency, values: [cents per bucket], total }], totals: { [currency]: [cents per bucket] } }
 */
export function totals(ledger, { period = 'month', count = 6 } = {}) {
  const today = toLocalDate(ledger.now());
  const n = Math.max(1, Math.min(Number(count) || 6, 104));
  const buckets = [];
  if (period === 'week') {
    const thisWeek = weekStart(today);
    for (let i = n - 1; i >= 0; i--) {
      const from = addDays(thisWeek, -7 * i);
      buckets.push({ key: from, label: `Week of ${from}`, from, to: addDays(from, 7) });
    }
  } else {
    const thisMonth = monthKey(today);
    for (let i = n - 1; i >= 0; i--) {
      const m = addMonths(thisMonth, -i);
      buckets.push({ key: m, label: m, from: `${m}-01`, to: `${addMonths(m, 1)}-01` });
    }
  }
  const bucketExpr = period === 'week'
    ? "date(p.occurred_on, '-6 days', 'weekday 1')"
    : "substr(p.occurred_on, 1, 7)";
  const rows = ledger.db.prepare(`
    SELECT p.agent_id, a.name AS agent_name, p.currency, ${bucketExpr} AS bucket, sum(p.amount_cents) AS cents
    FROM purchases p JOIN agents a ON a.id = p.agent_id
    WHERE p.status = 'confirmed' AND p.occurred_on >= ? AND p.occurred_on < ?
    GROUP BY p.agent_id, p.currency, bucket`).all(buckets[0].from, buckets[buckets.length - 1].to);

  const index = new Map(buckets.map((b, i) => [b.key, i]));
  const seriesByKey = new Map();
  const totalsByCurrency = {};
  for (const r of rows) {
    const i = index.get(r.bucket);
    if (i === undefined) continue;
    const k = `${r.agent_id}|${r.currency}`;
    if (!seriesByKey.has(k)) {
      seriesByKey.set(k, {
        agent_id: r.agent_id, agent_name: r.agent_name, currency: r.currency,
        values: new Array(buckets.length).fill(0), total: 0,
      });
    }
    const s = seriesByKey.get(k);
    s.values[i] += r.cents;
    s.total += r.cents;
    totalsByCurrency[r.currency] ??= new Array(buckets.length).fill(0);
    totalsByCurrency[r.currency][i] += r.cents;
  }
  const series = [...seriesByKey.values()].sort((a, b) => b.total - a.total);
  return { period: period === 'week' ? 'week' : 'month', buckets, series, totals: totalsByCurrency };
}

const PACE_FROM_DAY = 5;

// Money moving between your own accounts, or coming in, isn't spending.
export const NOT_SPENDING = /\b(TRANSFER|XFER|AUTOPAY|AUTO PAY|PAYMENT THANK YOU|ONLINE PAYMENT|CARD PAYMENT|CREDIT CARD|ACH PMT|DEPOSIT|PAYROLL|INTEREST PAID)\b/;

/**
 * The Mine bucket: what you spent yourself. Every sorted non-agent purchase from any
 * capture source, spending only (no transfers, card payments or deposits). Per currency.
 */
export function mineSpend(ledger, from, to) {
  const rows = ledger.db.prepare(`
    SELECT p.currency, p.amount_cents, p.merchant_key, p.description FROM purchases p
    WHERE p.status IN ('background', 'not_agent') AND p.amount_cents > 0 AND p.occurred_on >= ? AND p.occurred_on < ?`).all(from, to);
  const by = new Map();
  for (const r of rows) {
    if (NOT_SPENDING.test(`${r.merchant_key} ${String(r.description).toUpperCase()}`)) continue;
    const t = by.get(r.currency) ?? { currency: r.currency, cents: 0, n: 0 };
    t.cents += r.amount_cents;
    t.n++;
    by.set(r.currency, t);
  }
  return [...by.values()].sort((a, b) => b.cents - a.cents);
}

/**
 * The month as a line, for the hero: the agents' running total at the end of each day, this
 * month through today and all of last month, in one currency (the main one). Confirmed
 * purchases only, as the headline counts them. Null when there's nothing to draw.
 *
 * Returns { currency, days_in_month, this_month: [cents, day 1..today], last_month: [cents,
 * day 1..its last day] }.
 */
export function trend(ledger, currency, thisMonth, today, daysInMonth) {
  if (!currency) return null;
  const lastMonth = addMonths(thisMonth, -1);
  const running = (month, days) => {
    const rows = ledger.db.prepare(`
      SELECT occurred_on, sum(amount_cents) AS cents FROM purchases
      WHERE status = 'confirmed' AND currency = ? AND occurred_on >= ? AND occurred_on < ?
      GROUP BY occurred_on`).all(currency, `${month}-01`, `${addMonths(month, 1)}-01`);
    const perDay = new Array(days).fill(0);
    for (const r of rows) {
      const d = Number(r.occurred_on.slice(8, 10));
      if (d >= 1 && d <= days) perDay[d - 1] += r.cents;
    }
    let total = 0;
    return perDay.map((cents) => (total += cents));
  };
  const [ly, lm] = lastMonth.split('-').map(Number);
  const daysInLast = new Date(Date.UTC(ly, lm, 0)).getUTCDate();
  const line = { currency, days_in_month: daysInMonth, this_month: running(thisMonth, today), last_month: running(lastMonth, daysInLast) };
  const isEmpty = line.this_month.at(-1) === 0 && line.last_month.at(-1) === 0;
  return isEmpty ? null : line;
}

/** "What did my agents cost me last month?" — the headline number, per currency. */
export function headline(ledger) {
  const today = toLocalDate(ledger.now());
  const thisMonth = monthKey(today);
  const lastMonth = addMonths(thisMonth, -1);
  // verified_cents: the part with independent proof (bank, iPhone, webhook, a receipt you attached). The product.
  const sum = (from, to) => ledger.db.prepare(`
    SELECT currency, sum(amount_cents) AS cents, count(*) AS n,
           sum(CASE WHEN verified_at IS NOT NULL THEN amount_cents ELSE 0 END) AS verified_cents
    FROM purchases
    WHERE status = 'confirmed' AND occurred_on >= ? AND occurred_on < ? GROUP BY currency ORDER BY cents DESC`)
    .all(from, to);
  const current = sum(`${thisMonth}-01`, `${addMonths(thisMonth, 1)}-01`);
  // Straight-line projection. Too noisy in the first days, when one top-up dominates.
  const day = Number(today.slice(8));
  const [y, m] = thisMonth.split('-').map(Number);
  const daysInMonth = new Date(Date.UTC(y, m, 0)).getUTCDate();
  const pace = day >= PACE_FROM_DAY ? current.map((r) => ({ currency: r.currency, cents: Math.round((r.cents * daysInMonth) / day) })) : [];
  const mine = mineSpend(ledger, `${thisMonth}-01`, `${addMonths(thisMonth, 1)}-01`);
  const previous = sum(`${lastMonth}-01`, `${thisMonth}-01`);
  return {
    trend: trend(ledger, current[0]?.currency ?? previous[0]?.currency, thisMonth, day, daysInMonth),
    // held: purchases saved in the inbox from agents the free plan doesn't cover (src/plan.js). Not in
    // the agents' total until they're sorted or Pro counts them, and always shown beside it.
    last_month: { month: lastMonth, by_currency: previous, by_agent: ledger.monthSpend(lastMonth), held: heldSpend(ledger, `${lastMonth}-01`, `${thisMonth}-01`) },
    this_month: {
      month: thisMonth,
      today,
      by_currency: current,
      by_agent: ledger.monthSpend(thisMonth),
      pace,
      budgets: ledger.budgetStatus(thisMonth),
      mine,
      held: heldSpend(ledger, `${thisMonth}-01`, `${addMonths(thisMonth, 1)}-01`),
    },
  };
}
