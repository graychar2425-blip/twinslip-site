// The update channel (docs/PRODUCT.md §5): once a day while the app is open, and when the user
// asks in Settings, fetch one small file from the website, `<site>/updates/latest.json`, and its
// detached Ed25519 signature, `latest.json.sig`. The requests carry nothing about the user: no
// ledger data, no ids, no query string, no headers of ours. A file whose signature or fields don't
// check out counts as "nothing available", and the reason goes to the log. Twinslip never downloads
// or runs an update on its own: the user sees the version and notes, and installs it themselves.

import { createPublicKey, verify } from 'node:crypto';
import { getMeta, setMeta } from './db.js';
import { PRO_CONFIG } from './pro-config.js';
import { UPDATE_PUBLIC_KEY } from './update-key.js';

const DAY = 86_400_000;
const MAX_MANIFEST_BYTES = 64 * 1024;
const MAX_SIG_BYTES = 1024;
export const UPDATE_TIMEOUT_MS = 15_000;
/** Turns update checks off for this process: TWINSLIP_UPDATE_CHECKS=off (or 0, false, no). */
export const UPDATE_ENV = 'TWINSLIP_UPDATE_CHECKS';

const VERSION_RE = /^(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z.-]+))?$/;

/** -1, 0 or 1. A pre-release (1.2.0-beta.1) comes before its release (1.2.0). */
export function compareVersions(a, b) {
  const pa = VERSION_RE.exec(String(a));
  const pb = VERSION_RE.exec(String(b));
  if (!pa || !pb) throw new Error(`Not a version: ${pa ? b : a}`);
  for (let i = 1; i <= 3; i++) {
    const d = Number(pa[i]) - Number(pb[i]);
    if (d) return Math.sign(d);
  }
  if (pa[4] === pb[4]) return 0;
  if (!pa[4]) return 1;
  if (!pb[4]) return -1;
  return pa[4] < pb[4] ? -1 : 1;
}

/** Whether Node `have` (e.g. "22.13.1") is at least `need` (e.g. "22.13"). */
export function nodeAtLeast(have, need) {
  const h = String(have).replace(/^v/, '').split('.').map(Number);
  const n = String(need).split('.').map(Number);
  for (let i = 0; i < 3; i++) {
    const d = (h[i] || 0) - (n[i] || 0);
    if (d) return d > 0;
  }
  return true;
}

/** The fields of latest.json, or a reason it isn't one. */
export function checkManifestFields(m) {
  if (!m || typeof m !== 'object' || Array.isArray(m)) return 'it is not a JSON object';
  if (typeof m.version !== 'string' || !VERSION_RE.test(m.version)) return 'its version is not a version number';
  if (typeof m.released !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(m.released)) return 'its release date is not YYYY-MM-DD';
  let url;
  try { url = new URL(m.download); } catch { return 'its download address is not an address'; }
  if (url.protocol !== 'https:' || url.username || url.password) return 'its download address is not a plain https address';
  if (typeof m.sha256 !== 'string' || !/^[0-9a-f]{64}$/.test(m.sha256)) return 'its sha256 is not a SHA-256 hash';
  if (typeof m.notes !== 'string' || m.notes.length > 4000) return 'its notes are missing or too long';
  if (typeof m.minNode !== 'string' || !/^\d+(\.\d+){0,2}$/.test(m.minNode)) return 'its minNode is not a Node version';
  return null;
}

/**
 * Check latest.json's exact bytes against its detached signature (base64 Ed25519) and the public
 * key (SPKI DER, base64). { manifest } when everything checks out, otherwise { problem }.
 */
export function verifyManifest(bytes, sigText, publicKey) {
  if (!publicKey) return { problem: 'this build has no release key to check updates against' };
  let key;
  try { key = createPublicKey({ key: Buffer.from(publicKey, 'base64'), format: 'der', type: 'spki' }); } catch { return { problem: "this build's release key can't be read" }; }
  if (key.asymmetricKeyType !== 'ed25519') return { problem: "this build's release key is not an Ed25519 key" };
  const sig = Buffer.from(String(sigText ?? '').trim(), 'base64');
  if (sig.length !== 64) return { problem: 'the signature file is not an Ed25519 signature' };
  let ok = false;
  try { ok = verify(null, Buffer.from(bytes), key, sig); } catch { ok = false; }
  if (!ok) return { problem: "the update file's signature doesn't match the release key" };
  let manifest;
  try { manifest = JSON.parse(Buffer.from(bytes).toString('utf8')); } catch { return { problem: 'the update file is not JSON' }; }
  const bad = checkManifestFields(manifest);
  if (bad) return { problem: `the update file is signed but ${bad}` };
  const { version, released, download, sha256, notes, minNode } = manifest;
  return { manifest: { version, released, download, sha256, notes, minNode } };
}

/** Read at most `limit` bytes of a response; more than that is refused. */
async function readCapped(res, limit) {
  if (!res.body) return Buffer.alloc(0);
  const chunks = [];
  let size = 0;
  for await (const c of res.body) {
    size += c.length;
    if (size > limit) throw new Error('too large');
    chunks.push(Buffer.from(c));
  }
  return Buffer.concat(chunks);
}

function loadStatus(ledger) {
  try { return JSON.parse(getMeta(ledger.db, 'update_status') ?? 'null'); } catch { return null; }
}

/** Off by the environment, by the user's switch in Settings, or on. */
export function updateChecksOff(ledger, env = process.env) {
  if (/^(off|0|false|no)$/i.test(String(env[UPDATE_ENV] ?? '').trim())) return 'env';
  if (getMeta(ledger.db, 'update_checks') === 'off') return 'settings';
  return null;
}

/** The Settings switch. Turning checks off also forgets what the last check found. */
export function setUpdateChecks(ledger, on) {
  setMeta(ledger.db, 'update_checks', on ? 'on' : 'off');
  if (!on) ledger.db.prepare("DELETE FROM meta WHERE key = 'update_status'").run();
}

/** A newer version this app could install, from the last check; null otherwise. Reads only. */
export function availableUpdate(ledger, { appVersion, env = process.env, nodeVersion = process.versions.node } = {}) {
  if (updateChecksOff(ledger, env)) return null;
  const m = loadStatus(ledger)?.latest;
  if (!m || checkManifestFields(m)) return null;
  try { if (compareVersions(m.version, appVersion) <= 0) return null; } catch { return null; }
  return { version: m.version, released: m.released, notes: m.notes, download: m.download, sha256: m.sha256, min_node: m.minNode, node_ok: nodeAtLeast(nodeVersion, m.minNode) };
}

/** What the page shows in Settings and on the home screen. Reads only. */
export function updateView(ledger, { appVersion, env = process.env, publicKey = UPDATE_PUBLIC_KEY } = {}) {
  const off = updateChecksOff(ledger, env);
  const status = off ? null : loadStatus(ledger);
  return {
    on: !off,
    off_by: off,
    ready: Boolean(publicKey),
    current: appVersion,
    checked_at: status?.checked_at ?? null,
    available: availableUpdate(ledger, { appVersion, env }),
  };
}

/**
 * Fetch and check latest.json now. No request at all when checks are off or this build has no
 * release key. Never throws: a failed check is logged and leaves "nothing available".
 */
export async function checkForUpdate(ledger, {
  fetch = globalThis.fetch, siteUrl = PRO_CONFIG.siteUrl, publicKey = UPDATE_PUBLIC_KEY,
  appVersion, log = () => {}, env = process.env, timeoutMs = UPDATE_TIMEOUT_MS,
} = {}) {
  const view = () => updateView(ledger, { appVersion, env, publicKey });
  if (updateChecksOff(ledger, env)) return view();
  if (!publicKey) { log('twinslip: update check skipped: this build has no release key yet.'); return view(); }
  const base = `${String(siteUrl).replace(/\/+$/, '')}/updates/latest.json`;
  let latest = null;
  let problem = null;
  try {
    // Exactly two plain GETs: no headers, no body, no query string, nothing about the user.
    const get = (url, limit) => fetch(url, { signal: AbortSignal.timeout(timeoutMs) }).then(async (res) => {
      if (!res.ok) throw new Error(`${url} answered ${res.status}`);
      return readCapped(res, limit);
    });
    const [bytes, sig] = await Promise.all([get(base, MAX_MANIFEST_BYTES), get(`${base}.sig`, MAX_SIG_BYTES)]);
    const r = verifyManifest(bytes, sig.toString('utf8'), publicKey);
    if (r.problem) problem = r.problem;
    else latest = r.manifest;
  } catch (err) {
    problem = `couldn't fetch the update file (${err.message})`;
  }
  if (problem) log(`twinslip: update check: nothing available, because ${problem}. Nothing was downloaded.`);
  setMeta(ledger.db, 'update_status', JSON.stringify({ checked_at: ledger.now().toISOString(), latest, problem }));
  return view();
}

/**
 * The daily check while the app is open: on start, then hourly looks at whether a day has passed
 * since the last check. `stop()` clears the timer.
 */
export function updateChecker({ ledger, fetch, appVersion, log, siteUrl, publicKey, env, everyMs = 60 * 60 * 1000 } = {}) {
  let timer = null;
  let running = null;
  const opts = () => ({
    fetch, appVersion, log, env,
    ...(siteUrl !== undefined ? { siteUrl } : {}),
    ...(publicKey !== undefined ? { publicKey } : {}),
  });
  const keyOf = () => (publicKey !== undefined ? publicKey : UPDATE_PUBLIC_KEY);
  function checkNow() {
    running ??= checkForUpdate(ledger, opts()).finally(() => { running = null; });
    return running;
  }
  function tick() {
    if (updateChecksOff(ledger, env ?? process.env) || !keyOf()) return Promise.resolve(null);
    const last = loadStatus(ledger)?.checked_at;
    if (last && ledger.now() - new Date(last) < DAY) return Promise.resolve(null);
    return checkNow().catch(() => null);
  }
  return {
    checkNow,
    tick,
    start() {
      tick();
      timer = setInterval(tick, everyMs);
      timer.unref();
    },
    stop() { if (timer) clearInterval(timer); timer = null; },
  };
}
