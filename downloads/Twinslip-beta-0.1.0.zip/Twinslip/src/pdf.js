// A minimal text PDF writer (no dependencies): Letter pages, Helvetica, automatic page
// breaks, simple right-aligned columns. Enough for the tax pack's summary and client statements.

const PAGE_W = 612;
const PAGE_H = 792;
const MARGIN = 54;
const GAP = 12; // the least space between a line's text and its right-hand column

// The standard fonts use WinAnsi: Latin-1 letters print as they are (é, ü, ø), the euro sign is
// 0x80, a few symbols are mapped, and anything else becomes "?".
function printable(s) {
  return String(s)
    .replace(/[✓✔]/g, 'v').replace(/[–—]/g, '-').replace(/[‘’]/g, "'").replace(/[“”]/g, '"')
    .replace(/·/g, '-').replace(/…/g, '...').replace(/€/g, '\x80')
    .replace(/[^\x20-\x7e\x80\xa0-\xff]/g, '?');
}
const escape = (s) => s.replace(/\\/g, '\\\\').replace(/\(/g, '\\(').replace(/\)/g, '\\)');

// Helvetica's advance widths (per 1000 em), from its standard font metrics.
const AFM = {
  278: ' !,./:;I[\\]ft', 191: "'", 355: '"', 556: '#$0123456789?L_abdeghnopqu', 889: '%', 667: '&ABEKPSVXY', 333: '()-`r',
  389: '*', 584: '+<=>~', 1015: '@', 722: 'CDHNRUw', 611: 'FTZ', 778: 'GOQ', 500: 'Jckszvxy', 833: 'Mm', 944: 'W', 469: '^',
  222: 'ijl', 334: '{}', 260: '|',
};
const WIDTHS = new Map(Object.entries(AFM).flatMap(([w, chars]) => [...chars].map((c) => [c, Number(w)])));

/** How wide `s` prints in Helvetica at `size` points. Latin-1 letters and the bold face are taken a little wide, never narrow. */
export function textWidth(s, size, { bold = false } = {}) {
  let w = 0;
  for (const c of printable(s)) w += WIDTHS.get(c) ?? 722;
  return (w * size / 1000) * (bold ? 1.1 : 1);
}

/** The width a line's text has beside its right-hand text (or none). */
export function lineRoom(size, right) {
  return PAGE_W - 2 * MARGIN - (right === undefined ? 0 : textWidth(right, size) + GAP);
}

/** `text` as it prints, cut with "..." where it would run into its right-hand text or the margin. */
export function fitText(text, size, { right, bold = false } = {}) {
  const s = printable(text);
  const room = lineRoom(size, right);
  if (textWidth(s, size, { bold }) <= room) return s;
  let n = s.length;
  while (n > 0 && textWidth(`${s.slice(0, n).trimEnd()}...`, size, { bold }) > room) n--;
  return `${s.slice(0, n).trimEnd()}...`;
}

/**
 * lines: [{ text, size = 10, bold = false, right = undefined (string, right-aligned), gap = 0 }]
 * Returns a Buffer holding a valid PDF 1.4 document.
 */
export function makePdf(lines, { title = 'Twinslip', footer = '' } = {}) {
  const pages = [];
  let ops = [];
  let y = PAGE_H - MARGIN;
  const flush = () => { pages.push(ops); ops = []; y = PAGE_H - MARGIN; };
  for (const l of lines) {
    const size = l.size ?? 10;
    const lead = size * 1.45 + (l.gap ?? 0);
    if (y - lead < MARGIN + 20) flush();
    y -= lead;
    const font = l.bold ? 'F2' : 'F1';
    ops.push(`BT /${font} ${size} Tf ${MARGIN} ${y.toFixed(1)} Td (${escape(fitText(l.text ?? '', size, { right: l.right, bold: l.bold }))}) Tj ET`);
    if (l.right !== undefined) {
      const x = PAGE_W - MARGIN - textWidth(l.right, size);
      ops.push(`BT /${font} ${size} Tf ${x.toFixed(1)} ${y.toFixed(1)} Td (${escape(printable(l.right))}) Tj ET`);
    }
  }
  flush();

  const objects = [];
  const add = (body) => { objects.push(body); return objects.length; };
  const catalog = add(null);
  const pagesObj = add(null);
  const f1 = add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>');
  const f2 = add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>');
  const kids = pages.map((p, i) => {
    const foot = `BT /F1 8 Tf ${MARGIN} 30 Td (${escape(fitText(`${footer}${footer ? '   -   ' : ''}Page ${i + 1} of ${pages.length}`, 8))}) Tj ET`;
    const stream = [...p, foot].join('\n');
    const content = add(`<< /Length ${Buffer.byteLength(stream, 'latin1')} >>\nstream\n${stream}\nendstream`);
    return add(`<< /Type /Page /Parent ${pagesObj} 0 R /MediaBox [0 0 ${PAGE_W} ${PAGE_H}] /Resources << /Font << /F1 ${f1} 0 R /F2 ${f2} 0 R >> >> /Contents ${content} 0 R >>`);
  });
  objects[catalog - 1] = `<< /Type /Catalog /Pages ${pagesObj} 0 R >>`;
  objects[pagesObj - 1] = `<< /Type /Pages /Kids [${kids.map((k) => `${k} 0 R`).join(' ')}] /Count ${kids.length} >>`;
  const info = add(`<< /Title (${escape(printable(title).replace(/\x80/g, 'EUR'))}) /Producer (Twinslip) >>`); // 0x80 is a bullet in metadata

  let out = '%PDF-1.4\n%\xe2\xe3\xcf\xd3\n';
  const offsets = [];
  objects.forEach((body, i) => {
    offsets.push(Buffer.byteLength(out, 'latin1'));
    out += `${i + 1} 0 obj\n${body}\nendobj\n`;
  });
  const xref = Buffer.byteLength(out, 'latin1');
  out += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n${offsets.map((o) => `${String(o).padStart(10, '0')} 00000 n \n`).join('')}`;
  out += `trailer\n<< /Size ${objects.length + 1} /Root ${catalog} 0 R /Info ${info} 0 R >>\nstartxref\n${xref}\n%%EOF\n`;
  return Buffer.from(out, 'latin1');
}
