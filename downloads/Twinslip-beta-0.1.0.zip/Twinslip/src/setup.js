// `twinslip setup` and `twinslip doctor` — connect the wires and prove they're connected.
//
// setup: registers the Twinslip MCP server with each agent app found on this machine,
//        so the agent can report purchases the moment it makes them.
// doctor: checks every link — ledger file, each host's config, the server actually
//         answering MCP, and whether each host has really launched it.
//
// Agent Ledger is now Twinslip (2026-10-23). An app connected under the old server name,
// agent-ledger, keeps working: setup replaces that entry with the twinslip one (same backup
// and atomic write), and doctor accepts it until then.
//
// Apps setup edits a settings file for (docs/research/agent-distribution-and-payments-2026-10-23.md,
// Move 2): plain JSON (Claude Desktop, Cursor, Windsurf, Devin Desktop, Gemini CLI), JSON with
// comments (VS Code, Zed: src/jsonc.js keeps every comment) and TOML (Codex and the ChatGPT
// desktop app: src/toml.js). Claude Code goes through its own CLI.

import { existsSync, readFileSync, writeFileSync, copyFileSync, renameSync, statSync, mkdtempSync, rmSync, realpathSync, readdirSync } from 'node:fs';
import { randomBytes } from 'node:crypto';
import { basename, dirname, join } from 'node:path';
import { tmpdir, homedir } from 'node:os';
import { spawn, spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { getMeta, setMeta } from './db.js';
import { AGENT_KEYS, LedgerError } from './ledger.js';
import { parseJsonc, valueOf, putMember, JsoncError } from './jsonc.js';
import { parseToml, plain, putServerTable, tableText, TomlError } from './toml.js';
import { planSentence, planView } from './plan.js';

export const BIN_PATH = fileURLToPath(new URL('../bin/twinslip.js', import.meta.url));
export const SERVER_NAME = 'twinslip';
/** Our server's names before the rename. setup replaces them; doctor accepts them. */
export const OLD_SERVER_NAMES = ['agent-ledger'];

/**
 * Whether an entry launches our server, so an old name is only ever replaced when it is ours:
 * it runs our script (bin/agent-ledger.js or bin/twinslip.js) with `mcp`. Someone else's
 * server that happens to be called agent-ledger is left alone.
 */
export function isOurEntry(entry) {
  const args = Array.isArray(entry?.args) ? entry.args.filter((a) => typeof a === 'string') : [];
  return args.includes('mcp') && args.some((a) => /(^|[\\/])(agent-ledger|twinslip)\.js$/.test(a));
}

/** The old names this config still has an entry of ours under. */
export function oldNamesIn(servers) {
  return OLD_SERVER_NAMES.filter((n) => servers && Object.hasOwn(servers, n) && isOurEntry(servers[n]));
}

/** Our entry in a config: under our name, else under an old name. */
function ourEntry(servers) {
  if (servers?.[SERVER_NAME]) return { entry: servers[SERVER_NAME], name: SERVER_NAME };
  const old = oldNamesIn(servers)[0];
  return old ? { entry: servers[old], name: old } : { entry: null, name: null };
}

/**
 * Agent apps setup connects by editing their settings file, with the paths each one documents.
 * `format` is how the file is written, `key` where its servers are, `shape` what one entry looks
 * like there, and `keep` the entry's own on/off switch, which setup carries over so it never turns
 * back on a server the person switched off in the app.
 *
 * Environment variables only count when the caller passes `env` (the CLI passes process.env), so
 * tests never reach a real settings folder. On a Mac, apps opened from the Dock don't see a
 * shell's $XDG_CONFIG_HOME, so the documented default folders are used there.
 */
export function fileHosts({ home, platform = process.platform, env = {} }) {
  const appData = env.APPDATA || join(home, 'AppData', 'Roaming');
  const config = platform === 'linux' && env.XDG_CONFIG_HOME ? env.XDG_CONFIG_HOME : join(home, '.config');
  const claudeDesktopDir = platform === 'darwin' ? join(home, 'Library', 'Application Support', 'Claude')
    : platform === 'win32' ? join(appData, 'Claude')
    : join(home, '.config', 'Claude');
  const devinDir = platform === 'win32' ? join(appData, 'devin') : join(config, 'devin');
  const codexDir = env.CODEX_HOME || join(home, '.codex');
  const vscodeDir = platform === 'darwin' ? join(home, 'Library', 'Application Support', 'Code', 'User')
    : platform === 'win32' ? join(appData, 'Code', 'User')
    : join(config, 'Code', 'User');
  const zedDir = platform === 'win32' ? join(appData, 'Zed') : join(config, 'zed');
  const json = { format: 'json', key: 'mcpServers' };
  return [
    { id: 'claude-desktop', name: 'Claude Desktop', ...json, dir: claudeDesktopDir, file: join(claudeDesktopDir, 'claude_desktop_config.json'), restart: 'Quit and reopen Claude Desktop.' },
    { id: 'cursor', name: 'Cursor', ...json, dir: join(home, '.cursor'), file: join(home, '.cursor', 'mcp.json'), restart: 'Quit and reopen Cursor. Twinslip then shows under Customize → MCPs (Settings → MCP in older versions).' },
    // Windsurf is now Devin Desktop. Older Windsurf installs still keep this file.
    { id: 'windsurf', name: 'Windsurf', ...json, dir: join(home, '.codeium', 'windsurf'), file: join(home, '.codeium', 'windsurf', 'mcp_config.json'), restart: 'Refresh MCP servers in Windsurf.' },
    { id: 'devin', name: 'Devin Desktop', ...json, dir: devinDir, file: join(devinDir, 'mcp_config.json'), restart: 'Quit and reopen Devin Desktop.' },
    // One file for the Codex CLI, the Codex IDE extension and the ChatGPT desktop app.
    { id: 'codex', name: 'ChatGPT or Codex', format: 'toml', key: 'mcp_servers', keep: ['enabled'], dir: codexDir, file: join(codexDir, 'config.toml'), restart: 'Quit and reopen the ChatGPT desktop app, or start a new Codex session.' },
    // The user profile's mcp.json: the file `code --add-mcp` writes, edited here directly so the
    // backup, the atomic write and the "changed while we worked" check all apply, with or
    // without the `code` command installed.
    { id: 'vscode', name: 'VS Code', format: 'jsonc', key: 'servers', shape: (e) => ({ type: 'stdio', ...e }), dir: vscodeDir, file: join(vscodeDir, 'mcp.json'), restart: 'Quit and reopen VS Code.' },
    { id: 'gemini', name: 'Gemini CLI', ...json, dir: join(home, '.gemini'), file: join(home, '.gemini', 'settings.json'), restart: 'Start a new Gemini CLI session.' },
    { id: 'zed', name: 'Zed', format: 'jsonc', key: 'context_servers', keep: ['enabled'], dir: zedDir, file: join(zedDir, 'settings.json'), restart: 'Quit and reopen Zed.' },
  ];
}

/**
 * The servers in one host's settings file, as plain values ({} when there's no file). Throws
 * when it can't be read. JSON is read leniently (comments allowed): reading never writes, and a
 * person who added our lines by hand to a file with comments is connected.
 */
export function readServers(host) {
  const file = existsSync(host.file) ? realpathSync(host.file) : host.file;
  const raw = readRaw(file);
  if (raw === null || !raw.trim()) return {};
  return serversIn(host.format === 'toml' ? plain(parseToml(raw).data) : valueOf(parseJsonc(raw).root), host.key ?? 'mcpServers');
}
const serversIn = (config, key) => {
  const servers = config && typeof config === 'object' && !Array.isArray(config) ? config[key] : null;
  return servers && typeof servers === 'object' && !Array.isArray(servers) ? servers : {};
};

/** The lines to add by hand when setup leaves a file alone. */
export function snippetFor(host, entry) {
  if (host.format === 'toml') return tableText(['mcp_servers', SERVER_NAME], entry).trimEnd();
  return JSON.stringify({ [host.key ?? 'mcpServers']: { [SERVER_NAME]: entry } }, null, 2);
}

/**
 * One host's server entry. With a name, the agent is that name (as before); without one, the
 * agent is keyed by the app ("Claude", "Cursor", ...; docs/design/AGENT-SETUP-PLAN.md). `--host`
 * only tells the server which app launched it, for the setup screen.
 */
export function serverEntry({ agentName = null, agentKey = null, host = null, dataDir, nodePath = process.execPath, binPath = BIN_PATH }) {
  // Absolute node path on purpose: desktop apps don't inherit the shell PATH (nvm, fnm, asdf).
  const who = agentName ? ['--agent', agentName] : ['--agent-key', agentKey];
  return { command: nodePath, args: [binPath, 'mcp', ...who, '--data-dir', dataDir, ...(host ? ['--host', host] : [])] };
}

/** The agent name in an existing entry written with `--agent <name>`, if any. */
export function legacyAgentName(entry) {
  const args = Array.isArray(entry?.args) ? entry.args : [];
  const i = args.indexOf('--agent');
  return i >= 0 && typeof args[i + 1] === 'string' && args[i + 1].trim() ? args[i + 1] : null;
}

/** Plain-words fix for a host setup couldn't connect. */
function fixFor(r) {
  if (r.status !== 'error') return undefined;
  if (r.reason === 'keep') return `Setup left ${r.file} as it is (${r.why}), so nothing in it is lost. Add the lines setup prints to it yourself.`;
  if (r.reason === 'unreadable' && r.syntax === 'TOML') return `Its settings file isn't valid TOML (${r.why}). Fix ${r.file}, then run setup again.`;
  if (r.reason === 'unreadable' && r.syntax === 'JSONC') return `Its settings file couldn't be read (${r.why}). Fix ${r.file}, then run setup again.`;
  if (r.reason === 'unreadable' || /parse|JSON object/.test(r.message ?? '')) return `Its settings file isn't valid JSON. Fix or remove ${r.file}, then run setup again.`;
  if (/couldn't write/.test(r.message ?? '')) return 'Check there is free disk space and that the app is closed, then run setup again.';
  if (/couldn't read Claude Code/.test(r.message ?? '')) return 'In a terminal, run: claude mcp remove twinslip (or agent-ledger, its old name). Then run setup again.';
  return 'Run setup again. If it still fails, connect it by hand with the command shown in Settings.';
}

function readJson(file) {
  return parseJson(readRaw(file));
}
const readRaw = (file) => (existsSync(file) ? readFileSync(file, 'utf8') : null);
function parseJson(raw) {
  if (raw === null || !raw.trim()) return {};
  return JSON.parse(raw); // throws on invalid JSON: never overwrite a file we can't read
}

/** Backups we keep per config file; older ones are removed. */
export const KEEP_BACKUPS = 3;

/** The suffix of our config backups (before the rename: agent-ledger-backup, left as they are). */
export const BACKUP_TAG = 'twinslip-backup';

function pruneBackups(file) {
  const dir = dirname(file);
  const prefix = `${basename(file)}.${BACKUP_TAG}-`;
  const ours = readdirSync(dir).filter((n) => n.startsWith(prefix)).sort(); // ISO stamps sort by time
  for (const old of ours.slice(0, Math.max(0, ours.length - KEEP_BACKUPS))) rmSync(join(dir, old), { force: true });
}

const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
/** The same entry, whatever order its keys are in. */
const sameEntry = (a, b) => {
  const sorted = (v) => JSON.stringify(v, (_, x) => (x && typeof x === 'object' && !Array.isArray(x) ? Object.fromEntries(Object.keys(x).sort().map((k) => [k, x[k]])) : x));
  return a !== undefined && sorted(a) === sorted(b);
};

/** The same folder, even when one path is the link the move left (~/.agent-ledger → ~/.twinslip). */
function sameFolder(a, b) {
  if (a === b) return true;
  try { return typeof a === 'string' && realpathSync(a) === realpathSync(b); } catch { return false; }
}

/**
 * Put `text` in place of `file`, whose content was `raw` (null when there was no file): the
 * original is backed up first, and the replace is atomic. If another program changed the file
 * while we worked, nothing is written. Returns { backup } or { error }.
 */
function commit(host, file, raw, text, { now, beforeWrite }) {
  let backup;
  if (raw !== null) {
    backup = `${file}.${BACKUP_TAG}-${now.toISOString().replace(/[:.]/g, '-')}`;
    copyFileSync(file, backup);
    pruneBackups(file);
  }
  const mode = raw !== null ? statSync(file).mode & 0o777 : 0o600;
  const tmp = `${file}.${randomBytes(6).toString('hex')}.tmp`;
  try {
    writeFileSync(tmp, text, { mode, flag: 'wx' });
    beforeWrite(); // tests: another program edits the config right now
    // The app may have saved its own change while we worked. Never write over it.
    if (readRaw(file) !== raw) {
      rmSync(tmp, { force: true });
      return { error: { status: 'error', file: host.file, message: `${host.file} changed while setup was running; left it untouched. Run setup again.` } };
    }
    renameSync(tmp, file);
  } catch (err) {
    rmSync(tmp, { force: true });
    throw err;
  }
  return { backup };
}

/**
 * Add/refresh our server in one host's JSON config. Leaves every other server alone,
 * backs up the original, writes atomically. An entry of ours under an old name is replaced by
 * the new one, in the same place. Returns { status, file, backup?, renamed? }.
 */
export function connectJsonHost(host, entry, { now = new Date(), dryRun = false, beforeWrite = () => {} } = {}) {
  // A symlinked config (dotfiles repos) is written through to its real file; the link stays.
  const file = existsSync(host.file) ? realpathSync(host.file) : host.file;
  const key = host.key ?? 'mcpServers';
  let config;
  let raw;
  try {
    raw = readRaw(file);
    config = parseJson(raw);
  } catch {
    // Readable once its comments or trailing commas are allowed, but rewriting it would drop them.
    let lenient;
    try { lenient = typeof raw === 'string' ? valueOf(parseJsonc(raw).root) : undefined; } catch { /* not even that */ }
    if (lenient && typeof lenient === 'object' && !Array.isArray(lenient)) {
      const servers = serversIn(lenient, key);
      // Our lines, added by hand as setup asked: connected, nothing to do.
      if (sameEntry(servers[SERVER_NAME], entry) && !oldNamesIn(servers).length) return { status: 'unchanged', file: host.file };
      return { status: 'error', reason: 'keep', why: 'it has comments or trailing commas, which setup would drop', file: host.file, message: `left ${host.file} as it is: it has comments or trailing commas` };
    }
    return { status: 'error', reason: 'unreadable', syntax: 'JSON', file: host.file, message: `couldn't parse ${host.file}; left it untouched` };
  }
  if (typeof config !== 'object' || config === null || Array.isArray(config)) {
    return { status: 'error', reason: 'unreadable', syntax: 'JSON', file: host.file, message: `${host.file} isn't a JSON object; left it untouched` };
  }
  const servers = config[key] && typeof config[key] === 'object' ? config[key] : {};
  const old = oldNamesIn(servers);
  const renamed = old.length ? { renamed: old[0] } : {};
  if (same(servers[SERVER_NAME], entry) && !old.length) return { status: 'unchanged', file: host.file };
  const replacing = Boolean(servers[SERVER_NAME]) || old.length > 0;
  if (dryRun) return { status: replacing ? 'would-update' : 'would-add', file: host.file, ...renamed };
  // Our entry takes the place of the first one it replaces; every other server stays as it is.
  const nextServers = {};
  for (const [name, e] of Object.entries(servers)) {
    if (name === SERVER_NAME || old.includes(name)) {
      if (!(SERVER_NAME in nextServers)) nextServers[SERVER_NAME] = entry;
    } else nextServers[name] = e;
  }
  if (!(SERVER_NAME in nextServers)) nextServers[SERVER_NAME] = entry;
  const written = commit(host, file, raw, `${JSON.stringify({ ...config, [key]: nextServers }, null, 2)}\n`, { now, beforeWrite });
  if (written.error) return written.error;
  return { status: replacing ? 'updated' : 'added', file: host.file, backup: written.backup, ...renamed };
}

/**
 * The same for JSON with comments (VS Code, Zed): only our entry changes; every comment, blank
 * line and the layout stay. A file it can't change that way is left as it is, with the reason.
 */
export function connectJsoncHost(host, entry, { now = new Date(), dryRun = false, beforeWrite = () => {} } = {}) {
  const file = existsSync(host.file) ? realpathSync(host.file) : host.file;
  const keep = (why) => ({ status: 'error', reason: 'keep', why, file: host.file, message: `left ${host.file} as it is: ${why}` });
  let raw;
  let servers = {};
  try {
    raw = readRaw(file);
    if (raw !== null && raw.trim()) {
      const config = valueOf(parseJsonc(raw).root);
      if (config === null || typeof config !== 'object' || Array.isArray(config)) return keep("it isn't a JSON object");
      const s = Object.hasOwn(config, host.key) ? config[host.key] : undefined;
      if (s !== undefined && (s === null || typeof s !== 'object' || Array.isArray(s))) return keep(`its "${host.key}" isn't an object`);
      servers = s ?? {};
    }
  } catch (err) {
    if (err instanceof JsoncError && /appears twice/.test(err.message)) return keep(err.message);
    return { status: 'error', reason: 'unreadable', syntax: 'JSONC', why: err instanceof JsoncError ? err.message : err.code ?? 'error', file: host.file, message: `couldn't parse ${host.file}; left it untouched` };
  }
  const old = oldNamesIn(servers);
  const renamed = old.length ? { renamed: old[0] } : {};
  if (sameEntry(servers[SERVER_NAME], entry) && !old.length) return { status: 'unchanged', file: host.file };
  const replacing = Boolean(servers[SERVER_NAME]) || old.length > 0;
  if (dryRun) return { status: replacing ? 'would-update' : 'would-add', file: host.file, ...renamed };
  let text;
  if (raw === null || !raw.trim()) text = `${JSON.stringify({ [host.key]: { [SERVER_NAME]: entry } }, null, 2)}\n`;
  else {
    try { text = putMember(raw, { section: host.key, name: SERVER_NAME, value: entry, remove: old }); } catch (err) {
      if (err instanceof JsoncError) return keep(err.message);
      throw err;
    }
  }
  const written = commit(host, file, raw, text, { now, beforeWrite });
  if (written.error) return written.error;
  return { status: replacing ? 'updated' : 'added', file: host.file, backup: written.backup, ...renamed };
}

/**
 * The same for Codex's config.toml: our [mcp_servers.twinslip] table is replaced where it is, or
 * added at the end; nothing else in the file changes. A file it can't read, or one that defines
 * our server some other way, is left as it is, with the reason.
 */
export function connectTomlHost(host, entry, { now = new Date(), dryRun = false, beforeWrite = () => {} } = {}) {
  const file = existsSync(host.file) ? realpathSync(host.file) : host.file;
  let raw;
  let servers = {};
  try {
    raw = readRaw(file);
    if (raw !== null && raw.trim()) {
      const s = plain(parseToml(raw).data).mcp_servers;
      servers = s && typeof s === 'object' && !Array.isArray(s) ? s : {};
    }
  } catch (err) {
    return { status: 'error', reason: 'unreadable', syntax: 'TOML', why: err instanceof TomlError ? err.message : err.code ?? 'error', file: host.file, message: `couldn't parse ${host.file}; left it untouched` };
  }
  const old = oldNamesIn(servers);
  const renamed = old.length ? { renamed: old[0] } : {};
  if (sameEntry(servers[SERVER_NAME], entry) && !old.length) return { status: 'unchanged', file: host.file };
  const replacing = Boolean(servers[SERVER_NAME]) || old.length > 0;
  if (dryRun) return { status: replacing ? 'would-update' : 'would-add', file: host.file, ...renamed };
  let text;
  try { text = putServerTable(raw ?? '', { name: SERVER_NAME, entry, remove: old }); } catch (err) {
    if (err instanceof TomlError) return { status: 'error', reason: 'keep', why: err.message, file: host.file, message: `left ${host.file} as it is: ${err.message}` };
    throw err;
  }
  const written = commit(host, file, raw, text, { now, beforeWrite });
  if (written.error) return written.error;
  return { status: replacing ? 'updated' : 'added', file: host.file, backup: written.backup, ...renamed };
}

/** Connect one app by editing its settings file, the way that file is written. */
export function connectHost(host, entry, opts) {
  if (host.format === 'toml') return connectTomlHost(host, entry, opts);
  if (host.format === 'jsonc') return connectJsoncHost(host, entry, opts);
  return connectJsonHost(host, entry, opts);
}

/** One host's entry: shaped the way the app wants it, keeping the app's own on/off switch. */
function entryFor(host, entry, existing) {
  const shaped = host.shape ? host.shape(entry) : { ...entry };
  for (const k of host.keep ?? []) if (typeof existing?.[k] === 'boolean') shaped[k] = existing[k];
  return shaped;
}

/** Claude Code keeps MCP servers in its own store; go through its CLI. */
export function claudeCode({ run = spawnSync, home = homedir() } = {}) {
  const probe = run('claude', ['--version'], { encoding: 'utf8' });
  const installed = !probe.error && probe.status === 0;
  // Claude Code keeps user-scope servers in ~/.claude.json. Reading it gives the exact command and
  // arguments (paths with spaces included), which its printed `mcp get` output can't.
  const file = join(home, '.claude.json');
  const okRun = (x) => Boolean(x) && !x.error && x.status === 0;
  const servers = () => {
    if (!existsSync(file)) return { ok: true, servers: {} };
    try { return { ok: true, servers: readJson(file).mcpServers ?? {} }; } catch { return { ok: false, servers: {} }; }
  };
  // One registration as the file has it: `full` with every field, `entry` its command and arguments.
  const pick = (e) => ({ full: e, entry: e && typeof e.command === 'string' && Array.isArray(e.args) ? { command: e.command, args: e.args } : e });
  const current = () => {
    const s = servers();
    return { ok: s.ok, ...pick(s.servers?.[SERVER_NAME] ?? null) };
  };
  /** Old names Claude Code still has our server under (agent-ledger, from before the rename). */
  const oldNames = () => oldNamesIn(servers().servers);
  /** Remove our registrations under old names. Returns the ones that wouldn't go. */
  const retireOld = (names = oldNames()) => names.filter((n) => !okRun(run('claude', ['mcp', 'remove', '--scope', 'user', n], { encoding: 'utf8' })));
  return {
    installed,
    oldNames,
    retireOld,
    /** The name Claude Code has our server under: twinslip, an old name of ours, or null. */
    registeredAs() {
      if (okRun(run('claude', ['mcp', 'get', SERVER_NAME], { encoding: 'utf8' }))) return SERVER_NAME;
      return oldNames().find((n) => okRun(run('claude', ['mcp', 'get', n], { encoding: 'utf8' }))) ?? null;
    },
    /** The `--agent <name>` an existing Claude Code registration uses (either name), so setup keeps it. */
    existingAgentName() {
      return legacyAgentName(ourEntry(servers().servers).entry);
    },
    /** Is our server registered with exactly this command and these arguments? */
    matches(entry) {
      const c = current().entry;
      return Boolean(c && c.command === entry.command && same(c.args, entry.args));
    },
    /** Replace our registration. Removes the old one only if it could be read exactly, and puts it
     *  back if the new one can't be added. One under an old name goes only once the new one is in. */
    add(entry) {
      const before = current();
      const old = before.ok ? oldNames() : [];
      if (!before.ok || (before.entry && !Array.isArray(before.entry.args))) {
        return { ok: false, restored: false, output: "couldn't read Claude Code's settings file, so the existing connection was left as it is" };
      }
      // Fields beyond the command (env, cwd...) can only be put back with `claude mcp add-json`.
      // If this Claude Code can't do that, don't remove what we couldn't restore exactly.
      const extra = before.full && Object.keys(before.full).some((k) => !['command', 'args', 'type'].includes(k));
      if (extra && !okRun(run('claude', ['mcp', 'add-json', '--help'], { encoding: 'utf8' }))) {
        return { ok: false, restored: false, output: "this Claude Code can't restore the existing connection's settings exactly, so it was left as it is" };
      }
      if (before.entry) run('claude', ['mcp', 'remove', '--scope', 'user', SERVER_NAME], { encoding: 'utf8' });
      const r = run('claude', ['mcp', 'add', '--scope', 'user', SERVER_NAME, '--', entry.command, ...entry.args], { encoding: 'utf8' });
      const ok = okRun(r);
      let restored = false;
      if (!ok && before.entry) {
        const back = extra
          ? run('claude', ['mcp', 'add-json', '--scope', 'user', SERVER_NAME, JSON.stringify(before.full)], { encoding: 'utf8' })
          : run('claude', ['mcp', 'add', '--scope', 'user', SERVER_NAME, '--', before.entry.command, ...before.entry.args], { encoding: 'utf8' });
        restored = okRun(back);
      }
      const left = ok ? retireOld(old) : [];
      return { ok, restored, renamed: ok ? old[0] : undefined, left, output: `${r.stdout ?? ''}${r.stderr ?? ''}`.trim() };
    },
    command(entry) {
      const q = (x) => (/[\s"']/.test(x) ? `"${x.replace(/"/g, '\\"')}"` : x);
      return `claude mcp add --scope user ${SERVER_NAME} -- ${[entry.command, ...entry.args].map(q).join(' ')}`;
    },
  };
}

export const SETUP_HOSTS_KEY = 'setup_hosts';

/**
 * Connect every agent app on this machine. Without `agentName`, each app gets its own agent
 * named after it, except apps already connected with a name: those keep their agent (and get
 * fresh paths). Records what happened for the app's first screen. Returns the per-host results.
 */
export const HOST_IDS = ['claude-desktop', 'claude-code', 'cursor', 'windsurf', 'devin', 'codex', 'vscode', 'gemini', 'zed'];

export function setup({ ledger, agentName = null, dataDir, home, platform, env = {}, hosts: only = null, dryRun = false, quiet = false, run = spawnSync, log = console.log, now = new Date() }) {
  const unknown = (only ?? []).filter((id) => !HOST_IDS.includes(id));
  if (unknown.length) throw new LedgerError(`Unknown app${unknown.length > 1 ? 's' : ''}: ${unknown.join(', ')}. Use: ${HOST_IDS.join(', ')}.`);
  if (agentName) ledger.ensureAgent(agentName);
  const results = [];
  for (const host of fileHosts({ home, platform, env })) {
    if (only && !only.includes(host.id)) continue;
    if (!existsSync(host.dir)) {
      results.push({ id: host.id, host: host.name, status: 'not-installed' });
      continue;
    }
    let existing = null;
    try { existing = ourEntry(readServers(host)).entry; } catch { /* connectHost reports it */ }
    const name = agentName ?? legacyAgentName(existing);
    const entry = entryFor(host, serverEntry({ agentName: name, agentKey: name ? null : host.id, host: host.id, dataDir }), existing);
    let outcome;
    try { outcome = connectHost(host, entry, { dryRun, now }); } catch (err) {
      // A full disk or a locked file: report it for this app and carry on with the others.
      outcome = { status: 'error', file: host.file, message: `couldn't write its settings (${err.code ?? 'error'})` };
    }
    // A file setup left alone: the lines to add by hand.
    if (outcome.reason) outcome.snippet = snippetFor(host, entry);
    results.push({ id: host.id, host: host.name, form: name ? 'legacy' : 'key', agent: name ?? AGENT_KEYS[host.id], restart: host.restart, ...outcome });
  }
  if (!only || only.includes('claude-code')) {
    const cc = claudeCode({ run, home });
    if (!cc.installed) results.push({ id: 'claude-code', host: 'Claude Code', status: 'not-installed' });
    else {
      const name = agentName ?? cc.existingAgentName();
      const entry = serverEntry({ agentName: name, agentKey: name ? null : 'claude-code', host: 'claude-code', dataDir });
      const base = { id: 'claude-code', host: 'Claude Code', form: name ? 'legacy' : 'key', agent: name ?? AGENT_KEYS['claude-code'], command: cc.command(entry), restart: 'Start a new Claude Code session.' };
      const old = cc.oldNames();
      const stillOld = (left) => (left.length ? { message: `the old connection is still there too; remove it with: claude mcp remove ${left[0]}` } : {});
      if (cc.matches(entry) && !old.length) results.push({ ...base, status: 'unchanged' });
      else if (dryRun) results.push({ ...base, status: 'would-add' });
      else if (cc.matches(entry)) {
        // Already connected as twinslip; only the old name is left to go.
        results.push({ ...base, status: 'added', renamed: old[0], ...stillOld(cc.retireOld(old)) });
      } else {
        const r = cc.add(entry);
        results.push({ ...base, status: r.ok ? 'added' : 'error', renamed: r.renamed, ...(r.ok ? stillOld(r.left) : { message: `${r.output.startsWith("couldn't read") ? r.output : 'the claude command refused the connection'}${r.restored ? '; the previous connection was put back' : ''}` }) });
      }
    }
  }
  for (const r of results) r.fix = fixFor(r);
  if (!dryRun) {
    // When a host's entry didn't change, it keeps the time it was last configured, so an
    // agent app that already launched it still counts as connected (the launcher re-runs setup).
    let before = [];
    try { before = JSON.parse(getMeta(ledger.db, SETUP_HOSTS_KEY) ?? '[]'); } catch { /* start fresh */ }
    const prevAt = Object.fromEntries(before.map((h) => [h.id, h.at]));
    const fresh = results.map(({ id, host, status, form, agent, message, fix, restart }) => ({
      id, name: host, status, form, agent, message, fix, restart,
      at: status === 'unchanged' && prevAt[id] ? prevAt[id] : now.toISOString(),
    }));
    // A run limited to some apps (--host) updates those and keeps what's known about the others.
    const merged = only ? [...before.filter((h) => !fresh.some((f) => f.id === h.id)), ...fresh] : fresh;
    setMeta(ledger.db, SETUP_HOSTS_KEY, JSON.stringify(merged));
  }

  // --quiet (the launcher): say nothing when nothing changed; changes and failures still print.
  if (quiet && results.every((x) => ['unchanged', 'not-installed'].includes(x.status))) return results;
  log(`Connecting your agent apps to Twinslip (${dataDir})\n`);
  const width = Math.max(15, ...results.map((r) => r.host.length));
  for (const r of results) {
    const mark = { added: '✓', updated: '✓', unchanged: '✓', 'would-add': '•', 'would-update': '•', error: '✗', 'not-installed': '–' }[r.status];
    const what = {
      added: r.renamed ? `connected (it was ${r.renamed}, Twinslip's old name)` : 'connected',
      updated: r.renamed ? `connection updated (it was ${r.renamed}, Twinslip's old name)` : 'connection updated',
      unchanged: 'already connected',
      'would-add': 'would connect', 'would-update': 'would update', 'not-installed': 'not found on this machine',
      error: r.reason === 'keep' ? 'not connected: its settings file was left as it is' : `failed: ${r.message}`,
    }[r.status];
    log(`  ${mark} ${r.host.padEnd(width)} ${what}${r.agent && r.status !== 'not-installed' ? ` (agent "${r.agent}")` : ''}${r.backup ? `  (backup: ${r.backup})` : ''}`);
    if (r.fix) log(`      → ${r.fix}`);
    if (r.snippet) log(r.snippet.split('\n').map((l) => `        ${l}`).join('\n'));
  }
  const connected = results.filter((r) => ['added', 'updated', 'unchanged'].includes(r.status));
  if (connected.length) {
    log('\nNext:');
    for (const r of connected.filter((x) => x.restart && x.status !== 'unchanged')) log(`  ${r.host}: ${r.restart}`);
    log('  Then open your agent app and say: "Set up Twinslip." It does the rest.');
    log(`\n${planSentence(ledger)}`);
  } else {
    log('\nNo agent app was found. Any MCP-capable agent can use Twinslip with this entry:');
    log(JSON.stringify({ mcpServers: { [SERVER_NAME]: serverEntry({ agentName: agentName ?? 'My agent', dataDir }) } }, null, 2).split('\n').map((l) => `  ${l}`).join('\n'));
  }
  return results;
}

/** What the app's first screen shows: each app setup connected, and whether it has launched since. */
export function setupHosts(ledger) {
  const raw = getMeta(ledger.db, SETUP_HOSTS_KEY);
  if (!raw) return [];
  let hosts;
  try { hosts = JSON.parse(raw); } catch { return []; }
  return hosts.map((h) => {
    const seen = getMeta(ledger.db, `host_seen:${h.id}`);
    const configured = ['added', 'updated', 'unchanged'].includes(h.status);
    // The agent's name as it is now (after a collision suffix or a rename), once it exists.
    const mapped = h.form === 'key' ? getMeta(ledger.db, `agent_key:${h.id}`) : null;
    const current = mapped ? ledger.db.prepare('SELECT name FROM agents WHERE id = ?').get(Number(mapped))?.name
      : h.form === 'legacy' && h.agent ? ledger.findAgentByName(h.agent)?.name : null;
    return { ...h, agent: current ?? h.agent, configured, connected: Boolean(configured && seen && seen >= h.at) };
  });
}

/** Talk real MCP to a freshly spawned server: initialize → tools/list → get_spend. */
export function probeMcpServer({ nodePath = process.execPath, binPath = BIN_PATH, timeoutMs = 8000 } = {}) {
  const dir = mkdtempSync(join(tmpdir(), 'twinslip-probe-'));
  return new Promise((resolve) => {
    const child = spawn(nodePath, [binPath, 'mcp', '--agent', 'Probe', '--data-dir', dir], { stdio: ['pipe', 'pipe', 'pipe'] });
    let buf = '';
    const replies = new Map();
    let finished = false;
    const done = (ok, detail) => {
      if (finished) return;
      finished = true;
      clearTimeout(timer);
      // Windows won't delete the probe's database while the server still has it open:
      // wait for the server to exit, then clean up. A leftover temp folder never fails the check.
      const cleanup = () => {
        try { rmSync(dir, { recursive: true, force: true, maxRetries: 3 }); } catch { /* harmless */ }
        resolve({ ok, detail });
      };
      if (child.exitCode !== null || child.signalCode !== null || !child.pid) return cleanup();
      child.once('exit', cleanup);
      child.kill();
    };
    const timer = setTimeout(() => done(false, 'no answer within 8s'), timeoutMs);
    child.on('error', (e) => done(false, e.message));
    child.stdout.on('data', (d) => {
      buf += d;
      let i;
      while ((i = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, i);
        buf = buf.slice(i + 1);
        try {
          const m = JSON.parse(line);
          replies.set(m.id, m);
        } catch {
          return done(false, `server wrote non-protocol output to stdout: ${line.slice(0, 80)}`);
        }
      }
      if (replies.has(3)) {
        const tools = replies.get(2)?.result?.tools?.map((t) => t.name) ?? [];
        const spend = replies.get(3)?.result?.content?.[0]?.text ?? '';
        const ok = replies.get(1)?.result?.serverInfo?.name === SERVER_NAME && tools.includes('record_purchase') && /spending/.test(spend);
        done(ok, ok ? `answers MCP (${tools.join(', ')})` : 'unexpected MCP replies');
      }
    });
    const send = (m) => child.stdin.write(`${JSON.stringify(m)}\n`);
    send({ jsonrpc: '2.0', id: 1, method: 'initialize', params: { protocolVersion: '2025-06-18', capabilities: {}, clientInfo: { name: 'twinslip-doctor', version: '1' } } });
    send({ jsonrpc: '2.0', method: 'notifications/initialized' });
    send({ jsonrpc: '2.0', id: 2, method: 'tools/list' });
    send({ jsonrpc: '2.0', id: 3, method: 'tools/call', params: { name: 'get_spend', arguments: {} } });
  });
}

function ago(iso, now) {
  if (!iso) return null;
  const mins = Math.round((now - new Date(iso)) / 60000);
  if (mins < 60) return `${Math.max(mins, 0)} min ago`;
  if (mins < 48 * 60) return `${Math.round(mins / 60)}h ago`;
  return `${Math.round(mins / 1440)} days ago`;
}

export async function doctor({ ledger, dataDir, home, platform, env = {}, run = spawnSync, log = console.log, probe = probeMcpServer }) {
  const now = ledger.now();
  const checks = [];
  const add = (ok, label, detail = '', fix = '') => checks.push({ ok, label, detail, fix });

  const [maj, min] = process.versions.node.split('.').map(Number);
  add(maj > 22 || (maj === 22 && min >= 13), 'Node', process.versions.node, 'Install Node 22.13 or newer.');
  add(true, 'Ledger', join(dataDir, 'ledger.db'));

  const agents = ledger.listAgents();
  add(agents.length > 0, 'Agents', agents.map((a) => a.name).join(', ') || 'none', 'Run: twinslip setup');

  const p = await probe({});
  add(p.ok, 'MCP server', p.detail, 'Reinstall Twinslip; the server did not start cleanly.');

  for (const host of fileHosts({ home, platform, env })) {
    if (!existsSync(host.dir)) continue;
    // Connected under the old name (agent-ledger) still counts while the rename settles in.
    let found = { entry: null, name: null };
    try { found = ourEntry(readServers(host)); } catch {
      add(false, host.name, "can't read its settings file", 'Run: twinslip setup. It says what to fix.');
      continue;
    }
    const { entry } = found;
    if (!entry) {
      add(false, host.name, 'not connected', 'Run: twinslip setup');
      continue;
    }
    const args = entry.args ?? [];
    const problems = [];
    if (!existsSync(entry.command)) problems.push(`node not found at ${entry.command}`);
    if (!existsSync(args[0] ?? '')) problems.push(`Twinslip not found at ${args[0]}`);
    const dd = args[args.indexOf('--data-dir') + 1];
    if (!sameFolder(dd, dataDir)) problems.push(`points at a different ledger (${dd})`);
    const key = args.includes('--agent-key') ? args[args.indexOf('--agent-key') + 1] : null;
    const named = legacyAgentName(entry);
    if (!named && key !== host.id) problems.push(key ? `uses the agent of another app (${key}); run setup again` : 'has no agent; run setup again');
    if (args.includes('--host') && args[args.indexOf('--host') + 1] !== host.id) problems.push('says it is a different app; run setup again');
    const name = named ?? AGENT_KEYS[key] ?? '?';
    const oldName = found.name !== SERVER_NAME ? ` (under its old name, ${found.name}; setup renames it)` : '';
    add(problems.length === 0, host.name, problems.length ? problems.join('; ') : `connected as "${name}"${oldName}`, 'Run: twinslip setup');
  }
  const cc = claudeCode({ run, home });
  if (cc.installed) {
    const as = cc.registeredAs();
    add(Boolean(as), 'Claude Code', !as ? 'not connected' : as === SERVER_NAME ? 'connected' : `connected (under its old name, ${as}; setup renames it)`, 'Run: twinslip setup');
  }

  // The end of the wire: has a host actually launched the server, and has the agent reported?
  for (const s of ledger.listSources().filter((x) => x.kind === 'agent')) {
    const seen = ago(s.last_attempt_at, now);
    const reported = ago(s.last_success_at, now);
    add(Boolean(seen), `Agent "${s.label}"`,
      seen ? `last connected ${seen}; ${reported ? `last purchase reported ${reported}` : 'no purchases reported yet'}` : 'never connected',
      'Restart the agent app so it launches the Twinslip server.');
  }
  for (const s of ledger.listSources().filter((x) => x.kind === 'simplefin')) {
    // Retired (docs/PRODUCT.md §7): its records stay; nothing syncs, so there's nothing to fix.
    add(true, 'Bank feed (retired)', `records kept; last synced ${ago(s.last_success_at, now) ?? 'never'}`, '');
  }
  for (const [kind, label] of [['receipts', 'Receipt sweep'], ['bank_alerts', 'Bank alert sweep']]) {
    const last = ledger.db.prepare('SELECT finished_at, found FROM sweeps WHERE kind = ? ORDER BY id DESC LIMIT 1').get(kind);
    checks.push({ ok: null, label, detail: last ? `last finished ${ago(last.finished_at, now)} (${last.found} recorded)` : 'never run (optional: ask your agent to "Set up Twinslip")' });
  }

  log('Twinslip — connection check\n');
  for (const c of checks) {
    log(`  ${c.ok === null ? '–' : c.ok ? '✓' : '✗'} ${c.label.padEnd(18)} ${c.detail}`);
    if (c.ok === false && c.fix) log(`      → ${c.fix}`);
  }
  const failed = checks.filter((c) => c.ok === false).length;
  log(failed ? `\n${failed} problem${failed === 1 ? '' : 's'} found.` : '\nAll connections look good.');
  return { checks, failed };
}

