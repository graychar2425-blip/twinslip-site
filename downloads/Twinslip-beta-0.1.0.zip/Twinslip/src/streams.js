// Usage streams: many tiny payments, one honest line a day.
//
// Pay-per-request rails (x402 over HTTP 402, metered APIs, agent-to-agent calls) let an agent
// make thousands of sub-cent payments a day. As separate purchases they would bury the ledger
// and trip the 300-an-hour limit; summed by hand they'd be wrong. So an agent reports usage
// with record_usage, in millionths of the currency unit, and the ledger keeps one running
// stream per agent, merchant, day and job:
//
//   - The stream's exact total lives in usage_streams (micros, payment count).
//   - Once a day's total reaches a cent, it appears as one agent purchase, rounded from the
//     exact total (never a sum of rounded parts), and moves as the day goes on.
//   - Like any agent report, it counts as that agent's spending right away and stays
//     reported-unverified until something the agent didn't supply sees it.
//
// Limits per call and per hour keep a confused or prompt-injected agent from flooding it.

import { LedgerError, PAYMENT_METHODS, checkReportedDate, cleanJob } from './ledger.js';
import { merchantKey, detectKnownMerchant } from './merchants.js';
import { formatCents } from './money.js';
import { HELD, coversAgent } from './plan.js';
import { toLocalDate } from './dates.js';
import { redact } from './redact.js';
import { tx } from './db.js';
import { flagIfOutside } from './mandates.js';
import { reportedClient, assignClient } from './clients.js';

export const STREAM_LIMITS = {
  perCallMicros: 10_000_000, // 10.00 in one report: bigger payments are purchases, not usage
  perCallPayments: 100_000,
  callsPerHour: 3_600,
};
const MICRO = 1_000_000;

/** "0.0012" → 1200 micros. Positive, at most six decimal places. */
export function parseMicros(raw) {
  const s = String(raw ?? '').trim();
  const m = /^(\d{1,7})(?:\.(\d{1,6}))?$/.exec(s);
  if (!m) throw new LedgerError('amount must be a positive number with at most six decimals, like "0.0012".');
  const micros = Number(m[1]) * MICRO + Number((m[2] ?? '').padEnd(6, '0') || 0);
  if (micros <= 0) throw new LedgerError('amount must be more than zero.');
  return micros;
}

/** Micros as a plain decimal string: 1200 → "0.0012", 2_500_000 → "2.50". */
export function formatMicros(micros, currency = 'USD') {
  const whole = Math.trunc(micros / MICRO);
  const frac = String(micros % MICRO).padStart(6, '0').replace(/0+$/, '').padEnd(2, '0');
  return `${currency === 'USD' ? '$' : `${currency} `}${whole.toLocaleString('en-US')}.${frac}`;
}

const centsOf = (micros) => Math.round(micros / 10_000);

function checkCallLimit(ledger, agentId) {
  const hour = ledger.now().toISOString().slice(0, 13);
  const row = ledger.db.prepare('SELECT calls FROM usage_calls WHERE agent_id = ? AND hour = ?').get(agentId, hour);
  if ((row?.calls ?? 0) >= STREAM_LIMITS.callsPerHour) {
    throw new LedgerError(`This agent has reported usage ${STREAM_LIMITS.callsPerHour} times in the last hour, the most allowed. Batch payments into fewer reports (pass payments: N), or continue next hour.`, 429);
  }
  ledger.db.prepare(`INSERT INTO usage_calls (agent_id, hour, calls) VALUES (?, ?, 1)
    ON CONFLICT(agent_id, hour) DO UPDATE SET calls = calls + 1`).run(agentId, hour);
  ledger.db.prepare('DELETE FROM usage_calls WHERE agent_id = ? AND hour < ?')
    .run(agentId, new Date(ledger.now().getTime() - 48 * 3600e3).toISOString().slice(0, 13));
}

/**
 * An agent reports usage: `amount` (a decimal string, possibly sub-cent) across `payments`
 * payments to one merchant. Returns { stream, purchase, outsideMandate }. `purchase` is the
 * day's ledger line, or null while the day is still under a cent. `rail`: { rail, reference, sha256 }
 * from the receipt the agent passed on, if any (src/rails.js); a receipt never dedupes a report.
 */
export function recordUsage(ledger, agentId, { merchant, amount, payments = 1, currency = 'USD', occurredOn = null, job = null, paymentMethod = 'other', rail = null, client = null }, { reporter = null } = {}) {
  const agent = ledger.requireAgent(agentId);
  const name = redact(String(merchant ?? '')).trim().slice(0, 80);
  if (!name) throw new LedgerError('merchant is required.');
  const micros = parseMicros(amount);
  if (micros > STREAM_LIMITS.perCallMicros) {
    throw new LedgerError(`One usage report can be at most ${formatMicros(STREAM_LIMITS.perCallMicros, currency)}. Report a larger payment with record_purchase.`);
  }
  if (!Number.isSafeInteger(payments) || payments < 1 || payments > STREAM_LIMITS.perCallPayments) {
    throw new LedgerError(`payments must be a whole number from 1 to ${STREAM_LIMITS.perCallPayments}.`);
  }
  if (!/^[A-Z]{3}$/.test(currency)) throw new LedgerError('currency must be a 3-letter code like USD.');
  if (!PAYMENT_METHODS.includes(paymentMethod)) throw new LedgerError(`payment_method must be one of: ${PAYMENT_METHODS.join(', ')}.`);
  const today = toLocalDate(ledger.now());
  const day = occurredOn ?? today;
  checkReportedDate(day, today, 'occurred_on');
  const jobName = cleanJob(job) ?? '';
  const key = merchantKey(name);
  const display = detectKnownMerchant(name) ?? name;
  const nowIso = ledger.now().toISOString();

  let newLine = false;
  const out = tx(ledger.db, () => {
    checkCallLimit(ledger, agent.id);
    ledger.db.prepare(`
      INSERT INTO usage_streams (agent_id, merchant, merchant_key, day, currency, job, micros, payments, first_at, last_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(agent_id, merchant_key, day, currency, job)
      DO UPDATE SET micros = micros + excluded.micros, payments = payments + excluded.payments, last_at = excluded.last_at`)
      .run(agent.id, display, key, day, currency, jobName, micros, payments, nowIso, nowIso);
    // A client named for the day's usage is kept on the stream (set once) until its line appears (src/clients.js).
    const named = reportedClient(ledger, { job: jobName || null, client });
    if (named) ledger.db.prepare('UPDATE usage_streams SET client_id = COALESCE(client_id, ?) WHERE agent_id = ? AND merchant_key = ? AND day = ? AND currency = ? AND job = ?')
      .run(named, agent.id, key, day, currency, jobName);
    const s = ledger.db.prepare('SELECT * FROM usage_streams WHERE agent_id = ? AND merchant_key = ? AND day = ? AND currency = ? AND job = ?')
      .get(agent.id, key, day, currency, jobName);
    // What the payment's rail said (src/rails.js), kept with the stream it was added to: evidence only.
    if (rail) ledger.keepRailReceipt(agent.id, rail, { streamId: s.id });
    const cents = centsOf(s.micros);
    const description = `${s.payments.toLocaleString('en-US')} payment${s.payments === 1 ? '' : 's'}, ${formatMicros(s.micros, currency)} exactly`;
    if (cents > 0 && s.purchase_id == null) {
      // The day's line, written the way an agent's own report is: counted for this agent now,
      // unverified until something the agent didn't supply sees it.
      ledger.checkAgentLimit(reporter ?? agent.id);
      const sourceId = ledger.ensureSource('agent', `Agent ${agent.name}`, { agentId: agent.id });
      // An agent the free plan doesn't cover: the line is saved in full and waits in the inbox (src/plan.js).
      const covered = coversAgent(ledger, agent.id);
      const id = Number(ledger.db.prepare(`
        INSERT INTO purchases (source_id, external_id, occurred_on, amount_cents, currency, merchant, merchant_key, description,
          payment_method, status, agent_id, match_reason, attributed_by, attributed_at, surfaced_at, created_at, reported_by_agent_id, job, held_agent_id)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
        .run(sourceId, `stream:${s.id}`, day, cents, currency, display, key, description,
          paymentMethod, covered ? 'confirmed' : 'candidate', covered ? agent.id : null, covered ? 'agent_usage' : HELD,
          covered ? 'agent' : null, covered ? nowIso : null, covered ? null : nowIso, nowIso, reporter ?? agent.id, jobName || null,
          covered ? null : agent.id).lastInsertRowid);
      if (!covered) ledger.track('over_free_limit', { kind: 'usage' });
      ledger.db.prepare('UPDATE usage_streams SET purchase_id = ? WHERE id = ?').run(id, s.id);
      ledger.db.prepare('UPDATE sources SET last_success_at = ? WHERE id = ?').run(nowIso, sourceId);
      newLine = true;
      return { stream: { ...s, purchase_id: id }, purchaseId: id };
    }
    if (s.purchase_id != null) {
      ledger.db.prepare("UPDATE purchases SET amount_cents = ?, description = ? WHERE id = ? AND (status = 'confirmed' OR match_reason = ?)")
        .run(Math.max(cents, 1), description, s.purchase_id, HELD);
    }
    return { stream: s, purchaseId: s.purchase_id };
  });
  if (out.purchaseId != null) assignClient(ledger, out.purchaseId, { reportedId: out.stream.client_id ?? null, agentId: agent.id });
  const purchase = out.purchaseId == null ? null : ledger.getPurchase(out.purchaseId);
  const outside = newLine && purchase.status === 'confirmed' ? flagIfOutside(ledger, purchase, { stream: true }) : [];
  ledger.track('usage_recorded', { new_line: newLine ? 1 : 0 });
  return { stream: out.stream, purchase, outsideMandate: outside };
}

/** Today's (or a day's) streams for the page: exact totals, payment counts, the line they feed. */
export function listStreams(ledger, { from = null, to = null } = {}) {
  const where = [];
  const args = [];
  if (from) { where.push('s.day >= ?'); args.push(from); }
  if (to) { where.push('s.day < ?'); args.push(to); }
  return ledger.db.prepare(`
    SELECT s.id, s.agent_id, a.name AS agent, s.merchant, s.day, s.currency, s.job, s.micros, s.payments, s.purchase_id, s.last_at
    FROM usage_streams s JOIN agents a ON a.id = s.agent_id
    ${where.length ? `WHERE ${where.join(' AND ')}` : ''} ORDER BY s.day DESC, s.micros DESC`).all(...args)
    .map((s) => ({ ...s, exact: formatMicros(s.micros, s.currency), counted: formatCents(centsOf(s.micros), s.currency) }));
}
