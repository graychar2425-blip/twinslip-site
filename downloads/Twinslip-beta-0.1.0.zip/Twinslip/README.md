# Twinslip

**What did your agents cost you last month?** Twinslip is local-first expense tracking
that keeps what your AI agents spend apart from what you spend: two buckets, Mine and
Agents. Your agents report each purchase the moment they pay; your bank's CSV, your iPhone
or a receipt you add checks it. Receipts your agent finds are kept as evidence. The ledger
lives on your computer.

What the product does today, and what is only planned, is in
[`docs/PRODUCT.md`](docs/PRODUCT.md). When this page and that one disagree, that one wins.

![Twinslip](docs/screenshots/ledger.png)

**Free**

- **Agents report as they pay,** by any method: card, prepaid credits, crypto. They report
  over a local MCP server, or with one CLI call or the local webhook. Setup configures
  Claude Code, Claude Desktop, Codex and the ChatGPT desktop app, Cursor, VS Code, Gemini CLI,
  Zed, Windsurf and Devin Desktop; only Claude Code is verified end to end so far. Other
  agents can use the CLI or the webhook (untested).
- **One agent and one bank or card account,** with unlimited purchases and all your history.
  Each agent app gets its own key, so renaming an agent or changing its model keeps its history.
  Other agents' purchases are never dropped: they're saved and wait in the inbox, marked, until
  Pro counts them (or you choose that agent as the free one). A second account's statement is
  kept and listed; with Pro it checks agent purchases too.
- **Three states:**
  - **verified ✓:** a bank line (your bank's CSV), your iPhone, the local webhook or a
    receipt you attached saw this charge too
    (receipts and bank alert emails your agent finds are kept as evidence, but never give
    the ✓);
  - **unverified:** flagged, never hidden;
  - **to sort:** one tap, Mine or Agents. The inbox suggests the likeliest agent with a
    reason, and confirms the sure ones in one tap.
- **The capture ladder,** every rung on your side:
  - iPhone Shortcuts (Wallet taps and the bank texts you set up) through iCloud Drive. The
    iPhone app is a simulator build for now and isn't distributed;
  - receipt and bank alert emails your own agent sweeps when you ask it, using the email
    access you already gave that agent app (Twinslip never gets your mailbox login, and
    nothing is scheduled);
  - CSV import of the file your bank lets you download (no bank logins, no aggregators);
  - a localhost webhook for anything else (`docs/CONTRACTS.md`).
- **Mine:** your own spending, kept separate, without transfers or card payments.
- **Budgets per agent,** with warnings, and readable by the agent itself (`get_budget`).
- **Subscriptions agents started,** monthly totals for Agents vs Mine, all your history,
  plain CSV export.
- **Source status:** whether a source is stale, failed or never checked is always shown,
  never behind Pro.
- **A share card:** "My agents cost me $87.00 last month." No merchants, nothing personal.

**Pro** ($10 a month or $96 a year per person; a seat is one human user): every agent and every
bank or card account, billing clients for agent costs (a statement per
client and month with how every line was checked and your handling fee as its own line, invoice
lines, and lines marked billed with your invoice number; seeing what a job cost stays free), and
ongoing oversight of agent spending, meaning
exceptions with follow-up (missing refunds, coverage gaps, failed or overdue sources),
scheduled checks with notifications, and a briefing of what was checked, what's unknown and
what needs you. Plus the tax pack (summary PDF, a CSV with provenance per row, receipts, as
one ZIP), accounting export (YNAB, Lunch Money), search with running totals, unusual-spend
alerts, per-agent history, and an audit trail from 2 seats. Renewals, mismatched charges,
monthly close, sync between devices and collaboration are planned, not built. The price is in
`docs/PRODUCT.md` §2. Activate a Pro key once; after that, checks are local and offline except a key check at
most every 30 days. Cancelling never takes your data.

**Private by design:** amounts, merchants and dates only, in `~/.twinslip`. Never card
numbers, passwords or keys. Agents can add and read. They can't confirm, delete or hide
anything: what they add either counts as their own spending or waits for your tap. Local
doesn't mean nothing leaves: your agent's AI provider sees what the agent reads (including
email it sweeps and totals it asks for), and iCloud carries iPhone captures if you use the
iPhone app. See `PRIVACY.md`.

Status: **launch-ready build, private.** Nothing is published; see `docs/LAUNCH-CHECKLIST.md`.

## Run it

**Beta testers:** follow [`docs/INSTALL.md`](docs/INSTALL.md), a step-by-step guide that
assumes no coding. Daniel's plan for the beta is in [`docs/BETA.md`](docs/BETA.md).

Needs Node 22.13+. No `npm install`; there are no dependencies.

```bash
node bin/twinslip.js setup     # connect your agent apps, then tell your agent "Set up Twinslip"
node bin/twinslip.js doctor    # check every connection
node bin/twinslip.js           # open the live ledger at http://127.0.0.1:4747
node bin/twinslip.js demo      # walkthrough with invented data
```

Restart the agent app after `setup`, then ask your agent *"how much have you spent this
month?"* It answers from the ledger, which proves the connection works. From then on it
records each purchase as it makes it.

| Command | |
|---|---|
| `twinslip setup [--agent <name>] [--host ...] [--dry-run] [--yes --json]` | Register the MCP server with Claude Desktop, Claude Code, Codex and the ChatGPT desktop app, Cursor, VS Code, Gemini CLI, Zed, Windsurf and Devin Desktop. Each app gets its own agent, named after it, unless you give a name; never asks anything. `--json` is for agents installing it. |
| `twinslip doctor` | Verify every link end to end |
| `twinslip record --agent <name> --merchant <m> --amount <0.00> --method <m> [--ref id]` | Record a purchase from any script or agent framework |
| `twinslip mcp --agent-key <app> \| --agent <name>` | The MCP server (agent apps launch it; you don't) |
| `twinslip import file.csv [--spend-sign negative\|positive] [--dry-run]` | Import the CSV file your bank lets you download |
| `twinslip import --from link-cli\|lnget [--dry-run]` | Import your Stripe Link wallet's charges (runs your own link-cli, read-only), or the Lightning payments lnget made |
| `twinslip export --format <csv\|ynab\|lunchmoney> [--month YYYY-MM]` | Export agent purchases for a spreadsheet, YNAB or Lunch Money |
| `twinslip report` | Print the beta report (counts only; nothing is sent) |

`connect` and `sync` are retired with the SimpleFIN bank feed (2026-10-06): they refuse with
a reason. Records from an old bank feed stay, and still count as bank evidence.

Options: `--data-dir`, `--port`, `--no-open`. `$TWINSLIP_HOME` sets the data directory.

**Twinslip was called Agent Ledger** (renamed 2026-10-23, `docs/RENAME.md`). What was set up
under the old name keeps working: the `agent-ledger` command, `$AGENT_LEDGER_HOME`, agent
apps connected as `agent-ledger` (`setup` renames them; `doctor` accepts them), the
`agentledger://` links and the iPhone's old Shortcuts folder. A ledger in `~/.agent-ledger`
moves to `~/.twinslip` the first time Twinslip starts.

## Test

```bash
npm test               # node:test, no dependencies
npm run test:coverage  # with a coverage report
npm run smoke:mcp      # the MCP server against the official MCP Inspector
```

## Docs

- [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md): how capture works (agent first, then
  receipts, then bank), reconciliation, what it can't do, security and the threat model
- [`docs/WHERE-IT-LIVES.md`](docs/WHERE-IT-LIVES.md): repo and platform proposal
- [`docs/METRICS.md`](docs/METRICS.md): activation, weekly active, confirm rate
- [`docs/ROADMAP.md`](docs/ROADMAP.md): subscription directions, mapped and not priced

## Layout

```
bin/twinslip.js       CLI (bin/agent-ledger.js: its old name)
src/db.js             schema + attribution state machine
src/ledger.js         ingest, classify, confirm/reject/undo, rules
src/simplefin.js      retired bank feed (unused)      src/csv.js       CSV import
src/totals.js         weekly/monthly per agent        src/report.js    beta report
src/server.js         hardened localhost server       src/receipts.js  receipt files
src/merchants.js      agent-merchant detection        public/          UI (vanilla JS)
src/mcp.js            MCP server (agent capture)      src/setup.js     setup + doctor
```
