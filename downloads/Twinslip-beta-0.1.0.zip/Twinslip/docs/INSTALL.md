# Install Twinslip (beta)

About 10 minutes. You don't need to know how to code. You'll type a few lines into
Terminal, and each one is written out for you to copy. These steps are for a Mac; Windows
notes are at the end.

Twinslip runs on your computer. There's no account to create, and your ledger lives on
your computer: we never see it. Your agent's AI provider does see what your agent reads and
is told, including totals it asks for. `PRIVACY.md` lists exactly what leaves, and when.

## 1. Install Node (once)

Twinslip runs on Node, a free program many apps use.

1. Go to **nodejs.org** and download the version marked **LTS**. Run the installer.
2. Check it worked. Open **Terminal**: press ⌘ Space, type `Terminal`, press Return.
   Then paste this and press Return:

   ```bash
   node --version
   ```

   You should see `v22.13` or a higher number. If you see "command not found", restart
   Terminal and try again.

## 2. Get Twinslip

You'll get access to the Twinslip page on GitHub.

1. On that page, click the green **Code** button, then **Download ZIP**.
2. Open the downloaded file. You get a folder called `agent-ledger-main`: the page on GitHub
   still has the app's old name, Agent Ledger.
3. Rename it to `twinslip` and move it into your home folder: in Finder, Go → Home.

Don't move this folder again after the next step. If you do, run step 3 again.

## 3. Connect your agent

In Terminal, paste these two lines and press Return:

```bash
cd ~/twinslip
node bin/twinslip.js setup
```

This connects Twinslip to the agent apps it finds on your computer: Claude Desktop,
Claude Code, Cursor and Windsurf. Each gets its own agent, named after the app ("Claude",
"Cursor"); you can rename it later in Settings. It doesn't touch anything else in those apps.
So far only Claude Code has been checked end to end; the others are set up the same way but
not yet verified, so please tell us what happens.

**Then quit and reopen your agent app, and say to it: "Set up Twinslip."** Your agent
does the rest and tells you if anything is left for you.

## 4. Open your ledger

```bash
node bin/twinslip.js
```

Your browser opens at `http://127.0.0.1:4747`. That address is your own computer, not a
website. A checklist shows what's set up so far, and ticks itself as things start working.

You can close Terminal whenever you like. Your agent keeps recording purchases either way.
To see your ledger again, open Terminal and run the two lines below:

```bash
cd ~/twinslip
node bin/twinslip.js
```

## 5. Check it works

Ask your agent: **"How much have you spent this month?"** It answers from your ledger,
which means the connection works. From then on, each purchase it reports shows up in your
ledger within a second. An agent can forget to report; that's what the bank check below is
for.

If something seems off, run this. It checks every link and says what to fix:

```bash
node bin/twinslip.js doctor
```

## Optional: verify purchases

The ✓ next to a purchase means your bank's file, your iPhone or a receipt you attached saw
the charge too: something your agent didn't supply.

- **Your bank:** download the CSV file your bank's website offers, then drop it on the
  ledger page. Twinslip never logs into your bank.
- **A receipt you have:** click Attach receipt on the purchase and pick the file.
- **Email receipts:** ask your agent, "Sweep my email for agent receipts." This works only
  if your agent app can already read your email; Twinslip never gets your email login,
  and nothing runs on a schedule. It looks for receipts from AI and developer-tool vendors,
  not ordinary purchases. Receipts your agent finds are kept as evidence and catch purchases
  it forgot, but they don't give the ✓ on their own. No email in your agent app? Use your
  bank's CSV instead.

## Just want to look first?

```bash
node bin/twinslip.js demo
```

This opens the ledger filled with invented purchases. Your real data isn't touched.

## Updating

Download the ZIP again and replace the `twinslip` folder. Your data is stored
separately, so nothing is lost. Then run step 3 again.

Installed it before the rename, when it was called Agent Ledger? Your `agent-ledger` folder
keeps working. Replace it the same way (or rename it to `twinslip`), then run step 3 again: it
moves your connections over to the new name. Your data moves from `~/.agent-ledger` to
`~/.twinslip` by itself the first time Twinslip starts.

## Removing it

1. Delete the `twinslip` folder.
2. Delete your data folder, `~/.twinslip`. In Finder, Go → Go to Folder, then type
   `~/.twinslip`.
3. Remove "twinslip" from your agent app's MCP or connector settings ("agent-ledger" if it
   was connected before the rename). For Claude Code, run:

   ```bash
   claude mcp remove twinslip --scope user
   ```

## Windows

The same steps work in **PowerShell**. Use `cd $HOME\twinslip` in steps 3 and 4. Your
data lives in `%USERPROFILE%\.twinslip`.
