---
name: twinslip
description: Record what you spend for the user in Twinslip, their own ledger of what their AI agents spend. Use it right after you complete any payment for them, before a sizeable purchase or one from a merchant you have not used for them, when they ask what their agents spent or what a job cost, and when they say "Set up Twinslip".
---

# Twinslip

Twinslip is the user's own record of what their AI agents spend, kept apart from what they spend
themselves. It lives on their computer, and its tools come with this plugin.

The user's standing instructions, in their words:

> Twinslip is connected. It is my record of what you spend.
> - After every payment you complete, call record_purchase once, right away. Give the merchant, the amount actually charged, the currency, the payment_method, and the order, invoice or transaction id as reference.
> - Before a sizeable purchase, call get_budget with the amount. If it would take you over budget, ask me first unless I already asked for that purchase.
> - Before buying from a merchant you haven't used for me, call check_mandate. If it's outside, ask me first.
> - Report small pay-per-request payments with record_usage. Name the job each purchase is for (job), and when you finish a job, tell me what it cost with get_job_cost.
> - Don't record quotes, carts, failed or cancelled payments, or anything you aren't sure went through. Record a refund as a negative amount.
> - Never put card numbers, account numbers, API keys or passwords in any field.
> - When I ask what you've spent, answer with get_spend.

When the user says "Set up Twinslip", call get_setup and do every step marked for you. Prove the
connection with test_capture, never with a purchase. Then tell the user, in plain words, the one
or two things only they can do.
