# Twinslip

**What did your agents cost you last month?** Twinslip keeps what your AI agents spend apart from
what you spend. Your agent records each purchase the moment it pays. Your bank's statement file
(CSV), your iPhone or a receipt you add checks it. Your ledger stays on your computer: amounts,
merchants and dates, never card numbers, passwords or keys.

This plugin connects your agent to Twinslip and tells it when to record, so you don't paste
instructions. Agents can add and read. They can't confirm, delete or hide anything: what they add
either counts as their own spending or waits for your tap.

Website: https://graychar2425-blip.github.io/twinslip-site · For agents and developers: https://graychar2425-blip.github.io/twinslip-site/agents

## What you need

Node 22.13 or later on your computer. Check with `node --version`. If it's missing or older,
install the LTS version from https://nodejs.org.

## Install

**Claude Code** (version 2.1.224 or later):

```
claude plugin marketplace add https://graychar2425-blip.github.io/twinslip-site/claude/marketplace.json
claude plugin install twinslip@twinslip
```

Then start a new session and say "Set up Twinslip."

**Cowork:** download [twinslip-plugin-0.1.0.zip](https://graychar2425-blip.github.io/twinslip-site/claude/twinslip-plugin-0.1.0.zip), then choose Customize → Plugins → Add →
Upload plugin.

**VS Code, Cursor and Codex** read this folder's `plugin.json` and `mcp.json` (Agent Plugins 1.0).
Their purchases are recorded under one agent, "Plugin agent". You can rename it in your ledger.

Twinslip has been checked end to end in Claude Code only. This plugin package is new and hasn't
been checked end to end in any app yet.

Your ledger page, where you sort purchases and add your bank's statement file, opens with
`node app/bin/twinslip.js` from this folder. It also comes with the Mac download at
https://graychar2425-blip.github.io/twinslip-site/download, which connects Claude Desktop and Claude Code by itself: with that, you don't
need this plugin there.

## What it adds

Tools your agent can use:

- `record_purchase`: Record a purchase or payment you just completed for the user, by any method. Refunds wait for the user's tap.
- `record_receipt`: Record a payment receipt found in the user's email. A matching purchase keeps it as evidence; it never verifies.
- `record_bank_alert`: Record a purchase alert from the user's own bank or card found in their email. Kept as evidence; never verifies.
- `finish_sweep`: Say an email sweep is finished, even if it found nothing. Adds or changes no purchases.
- `get_spend`: How much the user's agents have spent in a month, per agent. Read-only.
- `get_budget`: Your monthly budget and whether a purchase would fit. Read-only.
- `check_mandate`: Check whether a purchase is inside the mandate the user wrote for this agent. Guidance, never a block.
- `record_usage`: Record small pay-per-request payments; kept exactly and shown as one line per merchant per day.
- `get_job_cost`: What a piece of work cost across every agent and vendor.
- `get_unbilled`: What each client has not been billed for yet, line by line, to help draft an invoice. Read-only; only the user marks lines billed.
- `get_setup`: What is left to set up, who does each step, and exactly how. Read-only.
- `record_expected_refund`: Record a refund the user is owed. Changes no total; only the user's bank or the user resolves it.
- `test_capture`: Prove the connection without spending anything. Recorded as a check, never a purchase.

Prompts: "Set up Twinslip", "Sweep my email for agent receipts", "Sweep my email for bank purchase alerts".

A skill, `twinslip`, with standing instructions for your agent: record each payment right away,
check the budget before a sizeable purchase, and never put card numbers or keys in any field.

## What it runs

- **The Twinslip program, started by your agent app.** Claude Code and Cowork run
  `node ${CLAUDE_PLUGIN_ROOT}/app/bin/twinslip.js mcp --agent-key claude-code --host claude-code`. Apps that read
  `mcp.json` run the same file with `mcp --agent "Plugin agent"`. It talks only to the app that
  started it, through standard input and output, and reads and writes your ledger in
  `~/.twinslip` (or the folder named by `$TWINSLIP_HOME`). A ledger left in `~/.agent-ledger`,
  Twinslip's old name, moves there once. It opens no network connections and starts no other
  programs.
- **The rest of Twinslip, only if you start it yourself.** The `app` folder holds the whole app.
  `node app/bin/twinslip.js` opens your ledger page in your browser. On a Mac the page can show
  notifications, read the iPhone's capture file in iCloud Drive › Shortcuts › Twinslip and write
  this month's totals back for the phone, and, only if you turn on scheduled checks, add a
  background job with `launchctl`. `node app/bin/twinslip.js setup` adds Twinslip to your agent
  apps' settings files, backing each one up first, and uses the `claude` command for Claude Code.

## Privacy Policy

The full policy is at https://graychar2425-blip.github.io/twinslip-site/privacy. In short: there is no Twinslip account, no Twinslip
server and no analytics, and we never see your ledger.

**Network connections.** These are the only ones Twinslip can make:

1. **Your ledger page, on this computer only.** When you open your ledger, Twinslip serves it at
   http://127.0.0.1:4747, or another free port if that one is taken. It listens on 127.0.0.1, so other computers
   can't reach it, and it refuses requests from other web pages.
2. **The Pro key check, only if you activate Pro.** The ledger page sends your Pro key and a
   device name ("Twinslip on" and your computer's name) to Lemon Squeezy, our checkout provider,
   at `https://api.lemonsqueezy.com/v1/licenses`: when you activate the key, at most once every
   30 days after that, and when you remove Pro from this computer. No purchase data is sent.
3. **Imports you run yourself, on this computer only.** `twinslip import --from lnget` reads
   lnget's payment log from lnget's own page at http://127.0.0.1:2402, or from its file.
   `twinslip import --from link-cli` runs your own Stripe Link tool, which talks to Stripe with
   your sign-in. Twinslip sends nothing to either.

The tools this plugin adds make no network connections at all.

**What leaves your computer anyway.** Your agent's AI provider sees what your agent reads and is
told, including the totals it asks Twinslip for and any email it sweeps when you ask it to. If
you use the iPhone app, iCloud carries new purchases from your phone and this month's totals back
to it.

**What Twinslip keeps, on your computer only:** purchases (amount, merchant, date, which agent,
how it was paid, a short note), receipts, lines from your bank's CSV, bank alerts, the limits you
set for each agent, and your Pro key if you buy Pro. Never card numbers, account numbers,
passwords or API keys: text from agents is scrubbed of anything that looks like one before it's
saved.

**Deleting your data:** delete the `~/.twinslip` folder. If you use the iPhone app, also delete
iCloud Drive › Shortcuts › Twinslip.

## Help

Something not working? Tell us at https://github.com/graychar2425-blip/agent-ledger-site/issues.
