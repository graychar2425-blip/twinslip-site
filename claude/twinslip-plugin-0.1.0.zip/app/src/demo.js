// `twinslip demo` — a walkthrough with invented data, in its own data directory.
// It goes through the real ingestion path, as lines from an imported bank statement (CSV),
// so what you see is what a real statement would produce. Nothing here touches a real bank.

import { addDays, toLocalDate } from './dates.js';
import { expectRefund } from './refunds.js';
import { oversee } from './oversight.js';
import { setMandate } from './mandates.js';
import { recordUsage } from './streams.js';

function rng(seed) {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 2 ** 32;
  };
}

const PERSONAL = [
  ['WHOLEFDS MKT #10234 AUSTIN TX', 4000, 16000, 6],
  ['SHELL OIL 57444 AUSTIN TX', 3000, 6500, 3],
  ['STARBUCKS STORE 08821', 450, 1100, 8],
  ['UBER *TRIP HELP.UBER.COM', 900, 3400, 4],
  ['AMAZON MKTPL*2K41L0 AMZN.COM/BILL WA', 1200, 9000, 4],
  ['TRADER JOE S #411', 2500, 9000, 3],
];
const MONTHLY_PERSONAL = [
  ['NETFLIX.COM 866-579-7172 CA', 1549],
  ['SPOTIFY USA 877-778-1161 NY', 1199],
  ['GITHUB, INC. GITHUB.COM CA', 400], // personal GitHub Pro — the user will say "never"
  ['NOTION LABS INC NOTION.SO CA', 1000], // the user's own Notion; an agent starts its own seat below
];
// [description, agent, typical cents, per-month count]
const AGENT = [
  ['OPENAI *API 0927 SAN FRANCISCO CA', 'Muse', [2000, 5000], 3],
  ['ANTHROPIC SAN FRANCISCO CA', 'Muse', [5000, 10000], 2],
  ['EXA.AI SAN FRANCISCO CA', 'Muse', [1000, 1000], 1],
  ['PAYPAL *OPENROUTER 4029357733', 'Scout', [1000, 2500], 3],
  ['REPLICATE.COM SAN FRANCISCO', 'Scout', [300, 1800], 2],
];
const MONTHLY_AGENT = [
  ['BROWSERBASE.COM SAN FRANCISCO CA', 'Muse', 3900],
  ['ELEVENLABS.IO NEW YORK NY', 'Muse', 2200],
  ['VERCEL INC. COVINA CA', 'Scout', 2000],
  ['AMAZON WEB SERVICES AWS.AMAZON.CO WA', 'Scout', 1312],
];

export function seedDemo(ledger) {
  if (ledger.listAgents().length) return { seeded: false };
  const rand = rng(40);
  const muse = ledger.createAgent('Muse');
  const scout = ledger.createAgent('Scout');
  ledger.setAgentBudget(muse.id, 15000); // invented, like everything here
  ledger.setAgentBudget(scout.id, 20000); // pay-per-use made $15 read as 1,254% over
  const byName = { Muse: muse.id, Scout: scout.id };
  const today = toLocalDate(ledger.now());
  const start = addDays(today, -110);

  const txns = [];
  const expected = new Map(); // description → agent name
  let n = 0;
  const push = (date, desc, cents) => {
    txns.push({ externalId: `demo-${++n}`, occurredOn: date, amountCents: cents, currency: 'USD', description: desc, payee: null });
  };
  for (let day = start; day <= today; day = addDays(day, 1)) {
    const dom = Number(day.slice(8));
    for (const [desc, lo, hi, perMonth] of PERSONAL) {
      if (rand() < perMonth / 30) push(day, desc, Math.round(lo + rand() * (hi - lo)));
    }
    for (const [desc, agent, [lo, hi], perMonth] of AGENT) {
      if (rand() < perMonth / 30) {
        push(day, desc, Math.round((lo + rand() * (hi - lo)) / 100) * 100);
        expected.set(desc, agent);
      }
    }
    if (dom === 3) for (const [desc, cents] of MONTHLY_PERSONAL) push(day, desc, cents);
    if (dom === 5) for (const [desc, agent, cents] of MONTHLY_AGENT) { push(day, desc, cents); expected.set(desc, agent); }
    if (dom === 1) push(day, 'PAYROLL ACME CO DIRECT DEP', -640000);
  }
  // One agent purchase from a merchant nobody would flag: the agent bought a book.
  push(addDays(today, -40), 'AMAZON MKTPL*7HX20 AMZN.COM/BILL WA', 3499);

  const sourceId = ledger.ensureSource('csv', 'Bank statement (demo, invented)');
  const nowIso = ledger.now().toISOString();
  ledger.db.prepare('UPDATE sources SET last_attempt_at = ?, last_success_at = ? WHERE id = ?').run(nowIso, nowIso, sourceId);
  ledger.track('source_connected', { kind: 'csv' });
  ledger.ingest(sourceId, txns);

  // Sort everything older than ~10 days the way the user would have; leave the rest waiting.
  const cutoff = addDays(today, -10);
  const rows = ledger.db.prepare("SELECT id, description, occurred_on FROM purchases WHERE status = 'candidate' ORDER BY occurred_on").all();
  for (const r of rows) {
    if (r.occurred_on >= cutoff) continue;
    const agent = expected.get(r.description);
    if (agent) ledger.confirm(r.id, byName[agent]);
    else ledger.reject(r.id);
  }
  const anthropic = ledger.db.prepare("SELECT id FROM purchases WHERE merchant = 'Anthropic' AND status = 'confirmed' LIMIT 1").get();
  if (anthropic) ledger.ruleFromPurchase(anthropic.id);
  const github = ledger.db.prepare("SELECT id FROM purchases WHERE merchant = 'GitHub' AND status = 'not_agent' LIMIT 1").get();
  if (github) ledger.ruleFromPurchase(github.id);
  const book = ledger.db.prepare("SELECT id FROM purchases WHERE description LIKE 'AMAZON MKTPL*7HX20%'").get();
  if (book) {
    ledger.pullIn(book.id);
    ledger.confirm(book.id, muse.id);
  }

  // The agents report their own purchases. Older ones match bank lines already here and
  // verify them; this month's arrive before the bank has posted anything — that's the
  // real-time part — and one was paid in crypto, which no bank feed will ever show.
  const agentSources = {};
  for (const a of [muse, scout]) {
    agentSources[a.name] = ledger.ensureSource('agent', `Agent ${a.name}`, { agentId: a.id });
    ledger.db.prepare('UPDATE sources SET last_attempt_at = ? WHERE id = ?').run(nowIso, agentSources[a.name]);
  }
  const reportable = ledger.db.prepare(`SELECT p.occurred_on, p.amount_cents, p.merchant, a.name AS agent FROM purchases p
    JOIN agents a ON a.id = p.agent_id WHERE p.status = 'confirmed' AND p.occurred_on >= ? ORDER BY p.occurred_on`).all(addDays(today, -30));
  let ref = 0;
  for (const r of reportable) {
    if (rand() < 0.3) continue; // not every agent reports everything; the bank catches the rest
    ledger.recordAgentPurchase(byName[r.agent], {
      merchant: r.merchant, amountCents: r.amount_cents, occurredOn: r.occurred_on,
      paymentMethod: 'card', reference: `demo-${++ref}`,
    });
  }
  ledger.recordAgentPurchase(scout.id, { merchant: 'Apify', amountCents: 1200, occurredOn: addDays(today, -1), paymentMethod: 'crypto', reference: 'demo-crypto-1', note: 'scraping run, paid in USDC' });
  ledger.recordAgentPurchase(muse.id, { merchant: 'OpenRouter', amountCents: 2500, occurredOn: today, paymentMethod: 'prepaid_credits', reference: 'demo-or-1' });
  ledger.recordAgentPurchase(muse.id, { merchant: 'Anthropic', amountCents: 5000, occurredOn: today, paymentMethod: 'card', reference: 'demo-an-1' });
  // Where agent spending is heading (docs/design/AHEAD.md), invented like everything here.
  // Scout started its own Browserbase plan (Muse already has one) and its own Notion seat (the
  // user already pays for Notion): paying twice, both ways.
  for (const [i, back] of [70, 40, 10].entries()) {
    ledger.recordAgentPurchase(scout.id, { merchant: 'Browserbase', amountCents: 3900, occurredOn: addDays(today, -back), paymentMethod: 'card', reference: `demo-bb-${i}` });
    ledger.recordAgentPurchase(scout.id, { merchant: 'Notion', amountCents: 1000, occurredOn: addDays(today, -back + 1), paymentMethod: 'card', reference: `demo-nt-${i}` });
  }
  // Scout's mandate, and one purchase outside it.
  setMandate(ledger, scout.id, { merchants: ['OpenRouter', 'Replicate', 'Vercel', 'Amazon Web Services', 'Apify', 'Browserbase', 'Notion'], maxPurchaseCents: 5000, note: 'scraping and hosting only' });
  ledger.recordAgentPurchase(scout.id, { merchant: 'Bright Data', amountCents: 7500, occurredOn: addDays(today, -2), paymentMethod: 'card', reference: 'demo-bd-1', note: 'residential proxies', job: 'Competitor price watch' });
  // Jobs and pay-per-use: what one piece of work cost across vendors, and thousands of tiny payments.
  ledger.recordAgentPurchase(muse.id, { merchant: 'OpenAI', amountCents: 1840, occurredOn: addDays(today, -1), paymentMethod: 'prepaid_credits', reference: 'demo-job-1', job: 'Q3 market report' });
  recordUsage(ledger, muse.id, { merchant: 'api.exa.ai', amount: '2.418', payments: 806, paymentMethod: 'crypto', job: 'Q3 market report' });
  recordUsage(ledger, scout.id, { merchant: 'firecrawl.dev', amount: '0.9312', payments: 3104, paymentMethod: 'crypto', job: 'Competitor price watch' });
  // The bank posts Anthropic's charge the same day: that's what gives it the ✓. The receipt
  // the agent found in email is kept with it as evidence, and never verifies on its own.
  ledger.ingest(sourceId, [{ externalId: 'demo-anthropic-today', occurredOn: today, amountCents: 5000, currency: 'USD', description: 'ANTHROPIC ANTHROPIC.COM CA', payee: null }]);
  ledger.recordReceipt({ vendor: 'Anthropic', amountCents: 5000, occurredOn: today, messageId: '<demo-receipt-1@mail.anthropic.com>', subject: 'Your receipt from Anthropic' });
  // Oversight: a refund Muse asked for that hasn't arrived, followed up by one run (invented).
  expectRefund(ledger, { merchant: 'Replicate', amountCents: 1800, dueOn: addDays(today, -3), note: 'cancelled a duplicate run' },
    { by: 'agent', agentId: muse.id, reference: 'demo-refund-1' });
  oversee(ledger, { trigger: 'start', pro: false });
  return { seeded: true, transactions: txns.length };
}
