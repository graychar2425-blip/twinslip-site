// Zed's settings.json and VS Code's mcp.json are JSON with comments, and both allow trailing
// commas. Setup changes one entry in them and nothing else: every comment, blank line and the
// layout stay exactly as they were. With no dependencies (CLAUDE.md), this is a small, strict
// reader plus three edits (add, replace or remove one member). A file it can't read, or an
// edit that would lose a comment, is refused with a reason.

export class JsoncError extends Error {}

const ESCAPES = { '"': '"', '\\': '\\', '/': '/', b: '\b', f: '\f', n: '\n', r: '\r', t: '\t' };
const NUMBER = /-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?/y;
const put = (o, k, v) => Object.defineProperty(o, k, { value: v, enumerable: true, writable: true, configurable: true });

/**
 * Read JSON with // and /* comments and trailing commas. Returns { root, comments }: every node
 * knows where it starts and ends in the text, object members where their key and comma are.
 * Throws JsoncError on anything else.
 */
export function parseJsonc(text) {
  const n = text.length;
  let i = text.charCodeAt(0) === 0xfeff ? 1 : 0;
  const comments = [];
  const fail = (what) => {
    throw new JsoncError(`${what} (line ${text.slice(0, i).split('\n').length})`);
  };
  function gap() {
    for (;;) {
      const c = text[i];
      if (c === ' ' || c === '\t' || c === '\n' || c === '\r') i++;
      else if (c === '/' && text[i + 1] === '/') {
        const start = i;
        while (i < n && text[i] !== '\n' && text[i] !== '\r') i++;
        comments.push({ start, end: i });
      } else if (c === '/' && text[i + 1] === '*') {
        const start = i;
        const close = text.indexOf('*/', i + 2);
        if (close < 0) fail('a comment that never ends');
        i = close + 2;
        comments.push({ start, end: i });
      } else return;
    }
  }
  function string() {
    const start = i;
    i++;
    let out = '';
    for (;;) {
      if (i >= n) fail('a string that never ends');
      const ch = text[i];
      if (ch === '"') {
        i++;
        return { type: 'string', start, end: i, value: out };
      }
      if (ch === '\\') {
        const e = text[i + 1];
        if (e === 'u') {
          const hex = text.slice(i + 2, i + 6);
          if (!/^[0-9A-Fa-f]{4}$/.test(hex)) fail('a bad \\u escape');
          out += String.fromCharCode(parseInt(hex, 16));
          i += 6;
        } else if (e !== undefined && Object.hasOwn(ESCAPES, e)) {
          out += ESCAPES[e];
          i += 2;
        } else fail('a bad escape');
        continue;
      }
      if (text.charCodeAt(i) < 0x20) fail('a control character in a string');
      out += ch;
      i++;
    }
  }
  function value(depth) {
    if (depth > 200) fail('values nested too deep');
    gap();
    const start = i;
    const c = text[i];
    if (c === '{') return object(depth);
    if (c === '[') return array(depth);
    if (c === '"') return string();
    for (const [word, v] of [['true', true], ['false', false], ['null', null]]) {
      if (text.startsWith(word, i) && !/[\w$]/.test(text[i + word.length] ?? '')) {
        i += word.length;
        return { type: 'literal', start, end: i, value: v };
      }
    }
    NUMBER.lastIndex = i;
    const m = NUMBER.exec(text);
    if (m && !/[\w.$+-]/.test(text[i + m[0].length] ?? '')) {
      i += m[0].length;
      return { type: 'number', start, end: i, value: Number(m[0]) };
    }
    return fail("a value setup can't read");
  }
  function object(depth) {
    const start = i;
    i++;
    const members = [];
    for (;;) {
      gap();
      if (text[i] === '}') {
        i++;
        return { type: 'object', start, end: i, members };
      }
      if (text[i] !== '"') fail('a quoted key was expected');
      const k = string();
      gap();
      if (text[i] !== ':') fail("a ':' was expected");
      i++;
      const member = { key: k.value, keyStart: k.start, value: value(depth + 1), comma: null };
      members.push(member);
      gap();
      if (text[i] === ',') member.comma = i++;
      else if (text[i] !== '}') fail("a ',' or '}' was expected");
    }
  }
  function array(depth) {
    const start = i;
    i++;
    const items = [];
    for (;;) {
      gap();
      if (text[i] === ']') {
        i++;
        return { type: 'array', start, end: i, items };
      }
      items.push(value(depth + 1));
      gap();
      if (text[i] === ',') i++;
      else if (text[i] !== ']') fail("a ',' or ']' was expected");
    }
  }
  const root = value(0);
  gap();
  if (i < n) fail('more text after the end');
  return { root, comments };
}

/** The plain value of a parsed node. A key that appears twice in one object is refused. */
export function valueOf(node) {
  if (node.type === 'object') {
    const o = {};
    for (const m of node.members) {
      if (Object.hasOwn(o, m.key)) throw new JsoncError(`"${m.key}" appears twice`);
      put(o, m.key, valueOf(m.value));
    }
    return o;
  }
  if (node.type === 'array') return node.items.map(valueOf);
  return node.value;
}

/** One text per value, whatever its key order: for comparing before and after. */
const canonical = (v) => JSON.stringify(v, (_, x) => {
  if (x === null || typeof x !== 'object' || Array.isArray(x)) return x;
  const o = {};
  for (const k of Object.keys(x).sort()) put(o, k, x[k]);
  return o;
});

const lineStart = (text, pos) => text.lastIndexOf('\n', pos - 1) + 1;
const indentAt = (text, pos) => /^[ \t]*/.exec(text.slice(lineStart(text, pos)))[0];
const firstOnLine = (text, pos) => /^[ \t]*$/.test(text.slice(lineStart(text, pos), pos));

function styleOf(text, root) {
  const first = root.members[0];
  const unit = first && firstOnLine(text, first.keyStart) ? indentAt(text, first.keyStart) : '';
  return { eol: text.includes('\r\n') ? '\r\n' : '\n', unit: unit || '  ' };
}
const pretty = (value, style, indent) => JSON.stringify(value, null, style.unit).split('\n').join(style.eol + indent);

/** Where to add text after `pos`: the end of its line, past a comment there, if nothing else follows. */
function lineEndAfter(text, pos, comments) {
  let j = pos;
  for (;;) {
    while (text[j] === ' ' || text[j] === '\t') j++;
    const c = comments.find((x) => x.start === j);
    if (c) {
      if (/[\r\n]/.test(text.slice(c.start, c.end))) return pos;
      j = c.end;
      continue;
    }
    return j >= text.length || text[j] === '\n' || text[j] === '\r' ? j : pos;
  }
}

/** A span to delete, widened to whole lines when it is alone on them. */
function wholeLines(text, start, end) {
  let s = start;
  while (s > 0 && (text[s - 1] === ' ' || text[s - 1] === '\t')) s--;
  let e = end;
  while (text[e] === ' ' || text[e] === '\t') e++;
  if (s > 0 && text[s - 1] !== '\n') return { start, end, text: '' };
  if (text.startsWith('\r\n', e)) return { start: s, end: e + 2, text: '' };
  if (text[e] === '\n') return { start: s, end: e + 1, text: '' };
  return e >= text.length ? { start: s, end: e, text: '' } : { start, end, text: '' };
}

function insertMember(text, obj, key, value, style, comments) {
  const member = (indent) => `${JSON.stringify(key)}: ${pretty(value, style, indent)}`;
  const last = obj.members.at(-1);
  if (last) {
    const indent = firstOnLine(text, last.keyStart) ? indentAt(text, last.keyStart) : indentAt(text, obj.start) + style.unit;
    const addComma = last.comma === null;
    const anchor = addComma ? last.value.end : last.comma + 1;
    const at = lineEndAfter(text, anchor, comments);
    const body = `${style.eol}${indent}${member(indent)}${addComma ? '' : ','}`; // keeps a trailing-comma style
    if (addComma && at !== anchor) return [{ start: anchor, end: anchor, text: ',' }, { start: at, end: at, text: body }];
    return [{ start: at, end: at, text: `${addComma ? ',' : ''}${body}` }];
  }
  const close = obj.end - 1;
  if (firstOnLine(text, close) && lineStart(text, close) > obj.start) {
    // An empty object whose closing brace has its own line: our member goes on the line above it.
    const indent = indentAt(text, close) + style.unit;
    const at = lineStart(text, close);
    return [{ start: at, end: at, text: `${indent}${member(indent)}${style.eol}` }];
  }
  const outer = indentAt(text, obj.start);
  return [{ start: close, end: close, text: `${style.eol}${outer}${style.unit}${member(outer + style.unit)}${style.eol}${outer}` }];
}

function removeMember(text, obj, m) {
  if (m.comma !== null) return [wholeLines(text, m.keyStart, m.comma + 1)];
  const k = obj.members.indexOf(m);
  const edits = [wholeLines(text, m.keyStart, m.value.end)];
  if (k > 0) edits.push({ start: obj.members[k - 1].comma, end: obj.members[k - 1].comma + 1, text: '' });
  return edits;
}

/**
 * `text` with `"<section>": { "<name>": value }` set in its top-level object, and the members
 * named in `remove` (old names of ours) taken out of that section. The entry goes where it, or
 * else the first of `remove`, already is; otherwise it's added last. Throws JsoncError when the
 * change can't be made without losing a comment or changing anything else.
 */
export function putMember(text, { section, name, value, remove = [] }) {
  const doc = parseJsonc(text);
  const { root } = doc;
  if (root.type !== 'object') throw new JsoncError("the file isn't a JSON object");
  const expected = valueOf(root);
  const style = styleOf(text, root);
  const find = (obj, key) => obj.members.find((m) => m.key === key);
  const sec = find(root, section);
  const edits = [];
  if (!sec) {
    edits.push(...insertMember(text, root, section, Object.fromEntries([[name, value]]), style, doc.comments));
    put(expected, section, Object.fromEntries([[name, value]]));
  } else {
    if (sec.value.type !== 'object') throw new JsoncError(`its "${section}" isn't an object`);
    const obj = sec.value;
    const mine = find(obj, name);
    const olds = remove.map((k) => find(obj, k)).filter(Boolean);
    if (mine) {
      const indent = firstOnLine(text, mine.keyStart) ? indentAt(text, mine.keyStart) : indentAt(text, mine.value.start);
      edits.push({ start: mine.value.start, end: mine.value.end, text: pretty(value, style, indent) });
    } else if (olds.length) {
      const old = olds.shift();
      const indent = firstOnLine(text, old.keyStart) ? indentAt(text, old.keyStart) : indentAt(text, old.value.start);
      edits.push({ start: old.keyStart, end: old.value.end, text: `${JSON.stringify(name)}: ${pretty(value, style, indent)}` });
    } else edits.push(...insertMember(text, obj, name, value, style, doc.comments));
    for (const old of olds) edits.push(...removeMember(text, obj, old));
    for (const k of remove) delete expected[section][k];
    put(expected[section], name, value);
  }

  // Nothing we replace or delete may hold a comment, and nothing we add may land inside one.
  for (const e of edits) {
    for (const c of doc.comments) {
      const hit = e.start === e.end ? c.start < e.start && e.start < c.end : c.start < e.end && c.end > e.start;
      if (hit) throw new JsoncError("a comment sits where Twinslip's entry goes");
    }
  }
  edits.sort((a, b) => a.start - b.start);
  for (let k = 1; k < edits.length; k++) if (edits[k].start < edits[k - 1].end) throw new JsoncError('two changes would overlap');
  let out = text;
  for (const e of [...edits].reverse()) out = out.slice(0, e.start) + e.text + out.slice(e.end);

  // The check: the same document, with only our entry changed, and every comment still there.
  let after;
  try {
    after = parseJsonc(out);
  } catch {
    throw new JsoncError("the change wouldn't have been valid");
  }
  if (canonical(valueOf(after.root)) !== canonical(expected)) throw new JsoncError('the change would have touched more than our entry');
  const commentTexts = (d, t) => JSON.stringify(d.comments.map((c) => t.slice(c.start, c.end)));
  if (commentTexts(after, out) !== commentTexts(doc, text)) throw new JsoncError('the change would have lost a comment');
  return out;
}
