// CSV import — the fallback capture path. Every bank exports a slightly different CSV,
// so we detect the date/description/amount columns and the sign convention, show the
// user what we detected, and let them override the one thing we can't always know:
// whether a purchase is a negative or a positive number.

import { createHash } from 'node:crypto';
import { detectDateOrder, parseFlexibleDate } from './dates.js';
import { parseAmountToCents } from './money.js';
import { detectKnownMerchant } from './merchants.js';
import { LedgerError } from './ledger.js';

export const MAX_CSV_BYTES = 5 * 1024 * 1024;

/** RFC 4180-ish: quoted fields, doubled quotes, CRLF/LF, BOM. */
export function parseCsv(text) {
  const s = String(text ?? '').replace(/^﻿/, '');
  const rows = [];
  let row = [];
  let field = '';
  let inQuotes = false;
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (inQuotes) {
      if (c === '"') {
        if (s[i + 1] === '"') { field += '"'; i++; } else inQuotes = false;
      } else field += c;
    } else if (c === '"') inQuotes = true;
    else if (c === ',') { row.push(field); field = ''; }
    else if (c === '\n' || c === '\r') {
      if (c === '\r' && s[i + 1] === '\n') i++;
      row.push(field); field = '';
      if (row.some((f) => f.trim() !== '')) rows.push(row);
      row = [];
    } else field += c;
  }
  row.push(field);
  if (row.some((f) => f.trim() !== '')) rows.push(row);
  return rows;
}

const H = {
  date: [/^(transaction )?date$/, /^trans\.? date$/, /^post(ed|ing)? date$/, /^date posted$/, /^booking date$/],
  description: [/^description$/, /^merchant( name)?$/, /^payee$/, /^name$/, /^details$/, /^memo$/, /^transaction description$/],
  amount: [/^amount$/, /^transaction amount$/, /^amount \(usd\)$/],
  debit: [/^debit$/, /^withdrawals?$/, /^debit amount$/, /^money out$/],
  credit: [/^credit$/, /^deposits?$/, /^credit amount$/, /^money in$/],
  currency: [/^currency$/],
};

function findColumn(header, patterns) {
  for (const p of patterns) {
    const i = header.findIndex((h) => p.test(h));
    if (i !== -1) return i;
  }
  return -1;
}

export function detectMapping(headerRow) {
  const header = headerRow.map((h) => h.trim().toLowerCase());
  const m = {
    date: findColumn(header, H.date),
    description: findColumn(header, H.description),
    amount: findColumn(header, H.amount),
    debit: findColumn(header, H.debit),
    credit: findColumn(header, H.credit),
    currency: findColumn(header, H.currency),
  };
  const problems = [];
  if (m.date === -1) problems.push('no date column');
  if (m.description === -1) problems.push('no description/merchant column');
  if (m.amount === -1 && m.debit === -1) problems.push('no amount or debit column');
  return { mapping: m, problems, header: headerRow };
}

/**
 * Which sign means "money out"? Debit/credit columns answer it directly. A single amount
 * column usually means purchases are negative (bank accounts, most cards) — but some card
 * issuers export purchases as positive. Majority sign is the best guess; the user confirms.
 */
function guessSpendSign(values) {
  let neg = 0;
  let pos = 0;
  for (const v of values) {
    if (v < 0) neg++;
    else if (v > 0) pos++;
  }
  return pos > neg ? 'positive' : 'negative';
}

/**
 * CSV text → { mapping, dateOrder, spendSign, txns, skipped, problems }.
 * opts.spendSign: 'negative' | 'positive' to override the guess.
 */
export function csvToTransactions(text, opts = {}) {
  if (Buffer.byteLength(String(text ?? ''), 'utf8') > MAX_CSV_BYTES) {
    throw new LedgerError('That CSV is over 5 MB — export a shorter date range.', 413);
  }
  const rows = parseCsv(text);
  if (rows.length < 2) throw new LedgerError('That CSV has no transaction rows.');
  const { mapping: m, problems, header } = detectMapping(rows[0]);
  if (problems.length) {
    throw new LedgerError(`Couldn't read that CSV (${problems.join(', ')}). Columns found: ${header.join(', ').slice(0, 200)}`);
  }
  const body = rows.slice(1);
  const dateOrder = detectDateOrder(body.map((r) => r[m.date] ?? ''));
  const splitColumns = m.amount === -1;

  const raw = [];
  let skipped = 0;
  for (const r of body) {
    const date = parseFlexibleDate(r[m.date] ?? '', dateOrder);
    const description = String(r[m.description] ?? '').trim();
    let signed = null; // amount as exported
    if (splitColumns) {
      const d = parseAmountToCents(r[m.debit] ?? '');
      const c = m.credit !== -1 ? parseAmountToCents(r[m.credit] ?? '') : null;
      if (d) signed = -Math.abs(d);
      else if (c) signed = Math.abs(c);
    } else {
      signed = parseAmountToCents(r[m.amount] ?? '');
    }
    if (!date || !description || !signed) { skipped++; continue; }
    const currency = m.currency !== -1 && /^[A-Z]{3}$/.test((r[m.currency] ?? '').trim()) ? r[m.currency].trim() : 'USD';
    raw.push({ date, description, signed, currency });
  }

  const spendSign = splitColumns ? 'negative'
    : opts.spendSign === 'positive' || opts.spendSign === 'negative' ? opts.spendSign
    : guessSpendSign(raw.map((t) => t.signed));

  // Stable ids so re-importing the same (or an overlapping) export doesn't duplicate.
  // Identical rows on the same day get an occurrence index.
  const seen = new Map();
  const txns = raw.map((t) => {
    const amountCents = spendSign === 'negative' ? -t.signed : t.signed;
    const base = `${t.date}|${amountCents}|${t.description.toUpperCase().replace(/\s+/g, ' ')}`;
    const n = (seen.get(base) ?? 0) + 1;
    seen.set(base, n);
    const externalId = createHash('sha256').update(`${base}|${n}`).digest('hex').slice(0, 32);
    return { externalId, occurredOn: t.date, amountCents, currency: t.currency, description: t.description, payee: null };
  });

  return {
    mapping: Object.fromEntries(Object.entries(m).filter(([, i]) => i !== -1).map(([k, i]) => [k, header[i]])),
    dateOrder,
    spendSign,
    signDetected: !splitColumns && !opts.spendSign,
    txns,
    skipped,
    likelyAgentRows: txns.filter((t) => detectKnownMerchant(t.description)).length,
  };
}

export function previewCsv(text, opts) {
  const r = csvToTransactions(text, opts);
  const dates = r.txns.map((t) => t.occurredOn).sort();
  return {
    mapping: r.mapping,
    dateOrder: r.dateOrder,
    spendSign: r.spendSign,
    signDetected: r.signDetected,
    rows: r.txns.length,
    skipped: r.skipped,
    likelyAgentRows: r.likelyAgentRows,
    from: dates[0] ?? null,
    to: dates[dates.length - 1] ?? null,
    sample: r.txns
      .filter((t) => detectKnownMerchant(t.description))
      .concat(r.txns.filter((t) => !detectKnownMerchant(t.description)))
      .slice(0, 5)
      .map((t) => ({ date: t.occurredOn, description: t.description, amount_cents: t.amountCents })),
  };
}

export function importCsv(ledger, text, opts = {}) {
  const r = csvToTransactions(text, opts);
  const sourceId = ledger.ensureSource('csv', 'CSV imports');
  const { ids, ...result } = ledger.ingest(sourceId, r.txns);
  const now = ledger.now().toISOString();
  // The dates this statement spans, so coverage can say which days the bank has shown.
  const dates = r.txns.map((t) => t.occurredOn).filter(Boolean).sort();
  if (dates.length) {
    ledger.db.prepare('INSERT INTO bank_imports (source_id, from_date, to_date, lines, at) VALUES (?, ?, ?, ?, ?)')
      .run(sourceId, dates[0], dates.at(-1), dates.length, now);
  }
  ledger.db.prepare('UPDATE sources SET last_attempt_at = ?, last_success_at = ?, last_error = NULL WHERE id = ?')
    .run(now, now, sourceId);
  ledger.track('csv_imported', { ...result, duplicates: result.duplicates + result.merged });
  if (ledger.db.prepare("SELECT count(*) AS n FROM events WHERE name = 'csv_imported'").get().n === 1) {
    ledger.track('source_connected', { kind: 'csv' });
  }
  return { ...result, skipped: r.skipped, spendSign: r.spendSign };
}
