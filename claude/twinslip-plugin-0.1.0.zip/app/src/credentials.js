import { readFileSync, writeFileSync, renameSync, chmodSync, existsSync, mkdirSync, rmSync } from 'node:fs';
import { join } from 'node:path';

// The user's SimpleFIN access URL is a bearer credential to their transaction data.
// SimpleFIN is retired (docs/PRODUCT.md): nothing new is saved, and an old saved access is
// removed only when the user chooses to (removeSimplefinAccess). It is the only secret this
// app has ever held. It lives in its own 0600 file — never in the
// database, never in logs, never in an API response, never sent anywhere but SimpleFIN.

const FILE = 'credentials.json';

export function loadCredentials(dataDir) {
  if (!dataDir) return {};
  const p = join(dataDir, FILE);
  if (!existsSync(p)) return {};
  try {
    return JSON.parse(readFileSync(p, 'utf8'));
  } catch {
    return {};
  }
}

export function saveCredentials(dataDir, creds) {
  if (!dataDir) throw new Error('no data directory');
  mkdirSync(dataDir, { recursive: true, mode: 0o700 });
  const p = join(dataDir, FILE);
  const tmp = `${p}.${process.pid}.tmp`;
  writeFileSync(tmp, JSON.stringify(creds, null, 2), { mode: 0o600 });
  chmodSync(tmp, 0o600);
  renameSync(tmp, p);
}

export function getSimplefinAccessUrl(dataDir, sourceId) {
  return loadCredentials(dataDir).simplefin?.[String(sourceId)] ?? null;
}

export function setSimplefinAccessUrl(dataDir, sourceId, accessUrl) {
  const creds = loadCredentials(dataDir);
  creds.simplefin ??= {};
  creds.simplefin[String(sourceId)] = accessUrl;
  saveCredentials(dataDir, creds);
}

/** The user chose to remove saved bank-feed access. Deletes only the access, never a record. Returns how many were removed. */
export function removeSimplefinAccess(dataDir) {
  const p = join(dataDir, FILE);
  if (existsSync(p)) {
    let parsed = null;
    try { parsed = JSON.parse(readFileSync(p, 'utf8')); } catch { parsed = null; }
    if (parsed === null || typeof parsed !== 'object') {
      // Can't be read, so it may still hold the access link: remove the whole file, as asked.
      rmSync(p, { force: true });
      return 1;
    }
  }
  const creds = loadCredentials(dataDir);
  const n = Object.keys(creds.simplefin ?? {}).length;
  if (!n) return 0;
  delete creds.simplefin;
  saveCredentials(dataDir, creds);
  return n;
}
