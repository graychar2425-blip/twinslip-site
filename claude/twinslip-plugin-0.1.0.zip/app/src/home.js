// Where the ledger lives on this computer. Agent Ledger is now Twinslip (2026-10-23).
//
// The folder is ~/.twinslip, or $TWINSLIP_HOME ($AGENT_LEDGER_HOME is still read). A ledger
// left in the old ~/.agent-ledger moves on first start in one rename, so nothing is copied and
// nothing can be half moved. A link at the old path keeps older settings working: agent apps
// and the background job that still name ~/.agent-ledger reach the same ledger. When the
// folder can't be moved, or the link can't be made, the old folder is used where it is. An
// existing ~/.twinslip is never touched. Never lose a purchase (CLAUDE.md).

import { existsSync, renameSync, symlinkSync } from 'node:fs';
import { homedir } from 'node:os';
import { dirname, join, relative, resolve, sep } from 'node:path';
import { getMeta, setMeta } from './db.js';

export const HOME_FOLDER = '.twinslip';
export const OLD_HOME_FOLDER = '.agent-ledger';
/** Meta key: which move note this ledger has shown ('moved' or 'in-place'), so it's said once. */
export const HOME_NOTE_KEY = 'home_note';

const realFs = { existsSync, renameSync, symlinkSync };

/**
 * The ledger's folder: { dir, moved?, from?, to?, reason? }. `moved` is 'moved' when this start
 * moved the old folder, 'in-place' when the old folder is used where it is.
 */
export function ledgerHome({ env = process.env, home = homedir(), platform = process.platform, fs = realFs } = {}) {
  const chosen = env.TWINSLIP_HOME || env.AGENT_LEDGER_HOME;
  if (chosen) return { dir: resolve(chosen) };
  return moveOldHome({ from: join(home, OLD_HOME_FOLDER), to: join(home, HOME_FOLDER), platform, fs });
}

/** Move `from` to `to` unless `to` exists, leaving a link at `from`. See the top of this file. */
export function moveOldHome({ from, to, platform = process.platform, fs = realFs }) {
  if (fs.existsSync(to) || !fs.existsSync(from)) return { dir: to };
  const why = (err) => err?.code ?? String(err?.message ?? err);
  try {
    fs.renameSync(from, to);
  } catch (err) {
    if (fs.existsSync(to)) return { dir: to }; // another start moved it a moment ago
    return { dir: from, moved: 'in-place', from, to, reason: why(err) };
  }
  try {
    // A junction needs no special rights on Windows; elsewhere the type is ignored.
    fs.symlinkSync(platform === 'win32' ? to : relative(dirname(from), to), from, 'junction');
  } catch (err) {
    // Without the link, settings that still name the old folder would start an empty ledger
    // there. Put the folder back and use it where it is.
    try {
      fs.renameSync(to, from);
      return { dir: from, moved: 'in-place', from, to, reason: why(err) };
    } catch {
      return { dir: to, moved: 'moved', from, to, linked: false };
    }
  }
  return { dir: to, moved: 'moved', from, to };
}

/** A path as a person reads it: ~/.twinslip rather than /Users/you/.twinslip. */
export function shownPath(p, home = homedir()) {
  return p === home || p.startsWith(home + sep) ? `~${p.slice(home.length)}` : p;
}

/** What happened to the old folder, in one line, said once per ledger. null when there's nothing to say. */
export function homeNote(ledger, where, { home = homedir() } = {}) {
  if (!where?.moved || getMeta(ledger.db, HOME_NOTE_KEY) === where.moved) return null;
  setMeta(ledger.db, HOME_NOTE_KEY, where.moved);
  const from = shownPath(where.from, home);
  const to = shownPath(where.to, home);
  if (where.moved === 'in-place') {
    return `Agent Ledger is now Twinslip. Your ledger stays in ${from} for now (it couldn't be moved to ${to}: ${where.reason}). Everything works from there; Twinslip tries the move again next time.`;
  }
  return `Agent Ledger is now Twinslip. Your ledger moved from ${from} to ${to}; nothing in it changed.` +
    (where.linked === false ? ' Run twinslip setup once so your agent apps follow it.' : '');
}
