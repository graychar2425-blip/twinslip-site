import { createServer } from 'node:http';
import { readFileSync, createReadStream, existsSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomBytes, timingSafeEqual } from 'node:crypto';
import { LedgerError } from './ledger.js';
import { totals, headline } from './totals.js';
import { previewCsv, importCsv, MAX_CSV_BYTES } from './csv.js';
import { addReceipt, listReceipts, getReceipt, MAX_RECEIPT_BYTES } from './receipts.js';
import { removeSimplefinAccess } from './credentials.js';
import { betaReport } from './report.js';
import { exportPurchases } from './export.js';
import { onboarding } from './onboarding.js';
import { setupHosts } from './setup.js';
import { captureEvents, captureKey } from './capture.js';
import { pruneEvents, servingGet } from './events.js';
import { readCaptureFile, writeSummary, summary } from './syncfile.js';
import { proState, requirePro, activatePro, deactivatePro, revalidatePro, PRO_FEATURES } from './pro.js';
import { PRO_CONFIG } from './pro-config.js';
import { buildTaxPack } from './taxpack.js';
import { unusualSpend } from './alerts.js';
import { expectRefund, listRefunds, resolveRefund, dismissRefund } from './refunds.js';
import { sourceHealth, coverage } from './health.js';
import { addMonths, monthKey, toLocalDate } from './dates.js';
import { oversee, listExceptions, resolveException, dismissException, briefing } from './oversight.js';
import { installSchedule, removeSchedule, scheduleStatus, scheduleHealth, stableNodePath } from './schedule.js';
import { mineSpend } from './totals.js';
import { parseAmountToCents } from './money.js';
import { listMandates, setMandate, clearMandate, openFlags, resolveFlag, describeMandate } from './mandates.js';
import { listStreams } from './streams.js';
import { jobCosts } from './jobs.js';
import { findOverlaps } from './overlap.js';
import { listClients, setJobClient, updateClient, parseMarkup } from './clients.js';
import { clientOverview, unbilledLines, clientStatement, markBilled, undoBilling, listBillings, setBusinessName, proBillingLine } from './billing.js';
import { statementPdf, statementCsv, invoiceLinesCsv, statementFilename, invoiceLinesFilename } from './statement.js';
import { applyPlan, planView, chooseFreeAgent, chooseFreeAccount } from './plan.js';

// A web UI on localhost is reachable by every website the user visits (via fetch/forms to
// 127.0.0.1) and by DNS-rebinding attacks. So:
//   1. Bind to 127.0.0.1 only.
//   2. Reject any request whose Host header isn't our own loopback host:port (rebinding).
//   3. Every state-changing request must carry a per-launch random token in a custom
//      header. Cross-origin pages can't read the token, and can't send custom headers
//      without a CORS preflight we never approve.
//   4. If an Origin header is present, it must be ours.

const PUBLIC_DIR = join(dirname(fileURLToPath(import.meta.url)), '..', 'public');
const STATIC = {
  '/app.js': ['app.js', 'text/javascript; charset=utf-8'],
  '/style.css': ['style.css', 'text/css; charset=utf-8'],
  '/favicon.svg': ['favicon.svg', 'image/svg+xml'],
  '/fonts/schibsted-grotesk-latin.woff2': ['fonts/schibsted-grotesk-latin.woff2', 'font/woff2'],
  '/fonts/azeret-mono-latin.woff2': ['fonts/azeret-mono-latin.woff2', 'font/woff2'],
};
const SECURITY_HEADERS = {
  'Content-Security-Policy': "default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'",
  'X-Content-Type-Options': 'nosniff',
  'Referrer-Policy': 'no-referrer',
  'Cache-Control': 'no-store',
};

class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

function send(res, status, body, headers = {}) {
  const isJson = typeof body !== 'string' && !Buffer.isBuffer(body);
  const payload = isJson ? JSON.stringify(body) : body;
  res.writeHead(status, {
    ...SECURITY_HEADERS,
    'Content-Type': isJson ? 'application/json; charset=utf-8' : 'text/plain; charset=utf-8',
    ...headers,
  });
  res.end(payload);
}

function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) {
        reject(new HttpError(413, 'Request too large.'));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

async function readJson(req, limit = 64 * 1024) {
  const buf = await readBody(req, limit);
  if (!buf.length) return {};
  try {
    const v = JSON.parse(buf.toString('utf8'));
    if (!v || typeof v !== 'object' || Array.isArray(v)) throw new Error();
    return v;
  } catch {
    throw new HttpError(400, 'Body must be a JSON object.');
  }
}

const id = (s) => {
  const n = Number(s);
  if (!Number.isSafeInteger(n) || n <= 0) throw new HttpError(404, 'Not found.');
  return n;
};

const RETIRED_FEED = 'Bank feeds through SimpleFIN are retired: Twinslip no longer connects to bank aggregators. Your existing bank-feed records stay as they were. To keep checking purchases against your bank, import the CSV file your bank lets you download.';

export function startServer({ ledger, port = 4747, host = '127.0.0.1', appVersion = '0.0.0', fetch = globalThis.fetch, autoSync = true, log = console.log, setupCommand = null, syncDir = null, oldSyncDirs = [], oversight = false, notify = () => {}, schedule = { installSchedule, removeSchedule, scheduleStatus } } = {}) {
  const token = randomBytes(32).toString('hex');
  const tokenBuf = Buffer.from(token);
  const indexHtml = readFileSync(join(PUBLIC_DIR, 'index.html'), 'utf8');
  let actualPort = port;

  const allowedHosts = () => new Set([`127.0.0.1:${actualPort}`, `localhost:${actualPort}`]);
  const allowedOrigins = () => new Set([`http://127.0.0.1:${actualPort}`, `http://localhost:${actualPort}`]);

  function checkToken(req) {
    const got = Buffer.from(String(req.headers['x-ledger-token'] ?? ''));
    if (got.length !== tokenBuf.length || !timingSafeEqual(got, tokenBuf)) {
      throw new HttpError(403, 'Missing or wrong session token. Reload the page.');
    }
  }

  // The capture webhook authenticates with the stable capture key, not the page token.
  function checkCaptureKey(req) {
    const want = Buffer.from(captureKey(ledger.dataDir));
    const got = Buffer.from(String(req.headers.authorization ?? '').replace(/^Bearer\s+/i, '').trim());
    if (!got.length || got.length !== want.length || !timingSafeEqual(got, want)) {
      throw new HttpError(401, 'Missing or wrong capture key. It is in Twinslip: Menu → Settings → Capture.');
    }
  }

  /** Background checks: installed, and whether launchd has really been running them. */
  function scheduleView() {
    const status = schedule.scheduleStatus();
    const last = ledger.db.prepare("SELECT max(started_at) AS at FROM monitor_runs WHERE trigger = 'launchd'").get().at ?? null;
    return { ...status, ...scheduleHealth(status, last, ledger.now()) };
  }

  // ── Oversight schedule (src/oversight.js) ──
  // On start, then every hour. A tick checks the wall clock each minute: a jump of more than
  // 10 minutes means the Mac slept, so it runs right away. Time when nothing ran is recorded as
  // a gap by oversee() itself, so a restart or a long sleep never claims to have watched.
  let overseeTimer = null;
  let lastTickMs = null;
  let lastRunMs = null;
  function runOversight(trigger) {
    try {
      oversee(ledger, { trigger, notify });
      lastRunMs = ledger.now().getTime();
      broadcast();
    } catch (err) { log(`twinslip: oversight: ${err.message}`); }
  }
  function oversightTick() {
    const nowMs = ledger.now().getTime();
    if (lastTickMs !== null && nowMs - lastTickMs > 10 * 60 * 1000) runOversight('wake');
    else if (lastRunMs === null || nowMs - lastRunMs >= 60 * 60 * 1000) runOversight('hourly');
    lastTickMs = nowMs;
  }

  // ── Live updates ──
  // Agents report purchases from their own processes (the MCP server), which write to
  // the same SQLite file. PRAGMA data_version changes whenever another connection
  // commits, so one cheap query a second tells us to push "changed" to open pages.
  const liveClients = new Set();
  let dataVersion = ledger.db.prepare('PRAGMA data_version').get().data_version;
  function broadcast() {
    for (const c of liveClients) c.write('event: change\ndata: {}\n\n');
  }
  const livePoll = setInterval(() => {
    try {
      const v = ledger.db.prepare('PRAGMA data_version').get().data_version;
      if (v !== dataVersion) {
        dataVersion = v;
        broadcast();
      }
    } catch { /* busy; next tick */ }
  }, 1000);
  livePoll.unref();

  // The phone bridge: pick up new lines from the synced capture file; keep the glance current.
  let lastSummary = '';
  // Phone checks (src/health.js): a missing iCloud folder is a failed check; a readable one is a
  // successful check even with nothing new. Written at most every 10 minutes, not every tick.
  let lastPhoneMark = 0;
  const markPhone = () => {
    const phone = ledger.listSources().find((x) => x.kind === 'phone');
    if (!phone || Date.now() - lastPhoneMark < 10 * 60 * 1000) return;
    lastPhoneMark = Date.now();
    if (existsSync(syncDir)) ledger.markChecked('phone');
    else ledger.markCheckFailed(phone.id, "The iPhone's iCloud folder isn't on this Mac. Check that iCloud Drive is on and the iPhone app's three steps are done.");
  };
  // iPhones set up before the rename still write to the old folder (oldSyncDirs): read it while
  // it's there, and keep its summary.json current too, so their shortcuts keep working.
  const syncTick = () => {
    if (!syncDir) return;
    const dirs = [syncDir, ...oldSyncDirs.filter((d) => d !== syncDir && existsSync(d))];
    try { markPhone(); } catch (err) { log(`twinslip: phone sync: ${err.message}`); }
    let captured = 0;
    for (const dir of dirs) {
      try { captured += readCaptureFile(ledger, dir).captured; } catch (err) { log(`twinslip: phone sync: ${err.message}`); }
    }
    if (captured) broadcast();
    let fingerprint;
    try { fingerprint = JSON.stringify({ ...summary(ledger), updated_at: null }); } catch (err) { return log(`twinslip: phone sync: ${err.message}`); }
    if (fingerprint === lastSummary) return; // only touch iCloud when the numbers changed
    let wrote = false;
    for (const dir of dirs) {
      try { if (writeSummary(ledger, dir)) wrote = true; } catch (err) { log(`twinslip: phone sync: ${err.message}`); }
    }
    if (wrote) lastSummary = fingerprint;
  };
  const syncTimer = setInterval(syncTick, 5000);
  syncTimer.unref();
  syncTick();
  const heartbeat = setInterval(() => { for (const c of liveClients) c.write(': ping\n\n'); }, 25000);
  heartbeat.unref();

  function state() {
    return {
      app_version: appVersion,
      setup_command: setupCommand,
      agents: ledger.listAgents(),
      sources: ledger.listSources(), // no secrets live in this table
      counts: ledger.counts(),
      headline: headline(ledger),
      onboarding: onboarding(ledger),
      setup_hosts: setupHosts(ledger),
      health: sourceHealth(ledger), // free, always: stale, failed or unknown is never paywalled
      // Free too (Daniel, 2026-10-06): how far last month is checked against the bank.
      coverage: coverage(ledger, addMonths(monthKey(toLocalDate(ledger.now())), -1)),
      sweeps: ledger.db.prepare("SELECT kind, finished_at, found FROM sweeps WHERE id IN (SELECT max(id) FROM sweeps GROUP BY kind)").all(),
      pro: proState(ledger),
      // What the free plan covers: one agent and one bank or card account (src/plan.js).
      plan: planView(ledger),
      site_url: PRO_CONFIG.siteUrl,
      phone_sync: Boolean(syncDir),
      rules: ledger.listRules(),
    };
  }

  async function route(req, res, url) {
    const { pathname } = url;
    const m = req.method;
    let match;

    if (m === 'GET' && pathname === '/') {
      ledger.track('ui_view');
      const html = indexHtml.replace('__LEDGER_TOKEN__', token);
      return send(res, 200, html, { 'Content-Type': 'text/html; charset=utf-8' });
    }
    if (m === 'GET' && STATIC[pathname]) {
      const [file, type] = STATIC[pathname];
      const cache = type === 'font/woff2' ? { 'Cache-Control': 'public, max-age=31536000, immutable' } : {};
      return send(res, 200, readFileSync(join(PUBLIC_DIR, file)), { 'Content-Type': type, ...cache });
    }
    if (!pathname.startsWith('/api/')) throw new HttpError(404, 'Not found.');
    // Pro switched on or off (or ran out) since the last request: count what may now count, and
    // recompute the ✓, before answering anything. A no-op when the plan hasn't changed.
    applyPlan(ledger);
    if (m === 'POST' && pathname === '/api/capture') {
      checkCaptureKey(req);
      const b = await readJson(req);
      const results = captureEvents(ledger, Array.isArray(b?.events) ? b.events : [b]); // committed before we answer
      broadcast();
      return send(res, 200, { results });
    }
    if (m !== 'GET') checkToken(req);

    // ── reads ──
    if (m === 'GET' && pathname === '/api/state') return send(res, 200, state());
    if (m === 'GET' && pathname === '/api/live') {
      res.writeHead(200, { ...SECURITY_HEADERS, 'Content-Type': 'text/event-stream; charset=utf-8', Connection: 'keep-alive' });
      res.write('retry: 2000\n\n');
      liveClients.add(res);
      req.on('close', () => liveClients.delete(res));
      return undefined;
    }
    if (m === 'GET' && pathname === '/api/inbox') return send(res, 200, { inbox: ledger.inbox() });
    if (m === 'GET' && pathname === '/api/search') {
      requirePro(ledger, 'search');
      return send(res, 200, ledger.search(url.searchParams.get('q') ?? ''));
    }
    if (m === 'GET' && pathname === '/api/mine') {
      return send(res, 200, { purchases: ledger.minePurchases({ from: url.searchParams.get('from'), to: url.searchParams.get('to') }) });
    }
    if (m === 'GET' && pathname === '/api/pro') {
      return send(res, 200, { ...proState(ledger), features: PRO_FEATURES, buy_url: PRO_CONFIG.buyUrl, on_sale: Boolean(PRO_CONFIG.storeId) });
    }
    if (m === 'GET' && pathname === '/api/taxpack') {
      requirePro(ledger, 'tax_pack');
      const pack = buildTaxPack(ledger, { year: url.searchParams.get('year') });
      return send(res, 200, pack.buffer, { 'Content-Type': 'application/zip', 'Content-Disposition': `attachment; filename="${pack.filename}"` });
    }
    // Refunds you expect: your records, so free (docs/PRODUCT.md §2). Follow-up on overdue ones is Pro.
    if (m === 'GET' && pathname === '/api/refunds') return send(res, 200, { refunds: listRefunds(ledger) });
    // Oversight (Pro): exceptions with their evidence and history, and the briefing. The
    // disclosure that sources are stale or failed stays free in /api/state (health).
    if (m === 'GET' && pathname === '/api/exceptions') {
      requirePro(ledger, 'oversight');
      return send(res, 200, { exceptions: listExceptions(ledger) });
    }
    if (m === 'GET' && pathname === '/api/briefing') {
      requirePro(ledger, 'oversight');
      const month = url.searchParams.get('month');
      if (month && !/^\d{4}-(0[1-9]|1[0-2])$/.test(month)) throw new HttpError(400, 'month must look like 2026-10.');
      return send(res, 200, briefing(ledger, month ? { month } : {}));
    }
    // Background checks (macOS launchd): status is free; turning them on is Pro; off always works.
    if (m === 'GET' && pathname === '/api/schedule') return send(res, 200, scheduleView());
    if (m === 'GET' && pathname === '/api/alerts') {
      requirePro(ledger, 'alerts');
      return send(res, 200, { alerts: unusualSpend(ledger) });
    }
    if (m === 'GET' && pathname === '/api/audit') {
      requirePro(ledger, 'audit', { seats: 2 });
      return send(res, 200, { audit: ledger.auditLog() });
    }
    if (m === 'GET' && pathname === '/api/subscriptions') return send(res, 200, ledger.subscriptions());
    // Where agent spending is heading (docs/design/AHEAD.md): awareness, free, like budgets.
    if (m === 'GET' && pathname === '/api/ahead') {
      const view = url.searchParams.get('view') ?? 'home';
      if (!['home', 'jobs', 'settings'].includes(view)) throw new HttpError(400, 'view must be home, jobs or settings.');
      const today = toLocalDate(ledger.now());
      if (view === 'home') return send(res, 200, { flags: openFlags(ledger), overlaps: findOverlaps(ledger) });
      if (view === 'jobs') {
        return send(res, 200, {
          jobs: jobCosts(ledger, { limit: 24 }), streams: listStreams(ledger, { from: `${monthKey(today)}-01` }),
          clients: clientOverview(ledger), client_names: listClients(ledger).map((c) => c.name),
        });
      }
      return send(res, 200, { mandates: listMandates(ledger).map((x) => ({ ...x, text: describeMandate(x, x.agent) })) });
    }
    // Billing clients (src/billing.js): what a client hasn't been billed yet and a preview of its
    // statement are free; the statement files and invoice lines are Pro (docs/PRODUCT.md §2).
    if (m === 'GET' && (match = pathname.match(/^\/api\/clients\/(\d+)\/(statement|statement\.pdf|statement\.csv|invoice-lines\.csv)$/))) {
      const clientId = id(match[1]);
      const period = url.searchParams.get('period') ?? 'all';
      if (match[2] === 'statement') {
        const st = clientStatement(ledger, clientId, { period });
        const pro = proState(ledger).pro;
        ledger.track('statement_previewed', { pro: pro ? 1 : 0 });
        const months = [...new Set(unbilledLines(ledger, { clientId }).map((l) => monthKey(l.occurred_on)))].sort().reverse();
        return send(res, 200, { ...st, pro, preview: !pro, pro_line: pro ? null : proBillingLine(), months, billings: listBillings(ledger, clientId) });
      }
      requirePro(ledger, 'billing');
      const st = clientStatement(ledger, clientId, { period });
      const file = match[2] === 'statement.pdf'
        ? { type: 'application/pdf', name: statementFilename(st, 'pdf'), body: statementPdf(st), format: 'pdf' }
        : match[2] === 'statement.csv'
          ? { type: 'text/csv; charset=utf-8', name: statementFilename(st, 'csv'), body: statementCsv(st), format: 'csv' }
          : { type: 'text/csv; charset=utf-8', name: invoiceLinesFilename(st), body: invoiceLinesCsv(st, { invoice: url.searchParams.get('invoice') ?? '' }), format: 'invoice_lines' };
      ledger.track('statement_built', { format: file.format });
      return send(res, 200, file.body, { 'Content-Type': file.type, 'Content-Disposition': `attachment; filename="${file.name}"` });
    }
    if (m === 'GET' && pathname === '/api/export') {
      const q = (k) => url.searchParams.get(k) ?? undefined;
      if ((q('format') ?? 'csv') !== 'csv') requirePro(ledger, 'accounting_export'); // plain CSV is always free: your data is yours
      const r = exportPurchases(ledger, { format: q('format'), from: q('from'), to: q('to'), currency: q('currency') });
      return send(res, 200, r.csv, {
        'Content-Type': 'text/csv; charset=utf-8',
        'Content-Disposition': `attachment; filename="${r.filename}"`,
        'X-Export-Rows': String(r.rows),
        'X-Export-Skipped': JSON.stringify(r.skipped),
      });
    }
    if (m === 'GET' && pathname === '/api/totals') {
      const t = totals(ledger, {
        period: url.searchParams.get('period') ?? 'month',
        count: url.searchParams.get('count') ?? undefined,
      });
      // Basic reports are free: Agents vs Mine per period. Per-agent history is Pro.
      t.mine = t.buckets.map((b) => mineSpend(ledger, b.from, b.to));
      if (!proState(ledger).pro && t.series.length) {
        const by = new Map();
        for (const s of t.series) {
          const c = by.get(s.currency) ?? { agent_id: null, agent_name: 'All agents', currency: s.currency, values: s.values.map(() => 0), total: 0 };
          s.values.forEach((v, i) => { c.values[i] += v; });
          c.total += s.total;
          by.set(s.currency, c);
        }
        t.series = [...by.values()];
        t.per_agent_is_pro = true;
      }
      return send(res, 200, t);
    }
    if (m === 'GET' && pathname === '/api/purchases') {
      return send(res, 200, {
        purchases: ledger.confirmedPurchases({
          from: url.searchParams.get('from'),
          to: url.searchParams.get('to'),
          agentId: url.searchParams.get('agent'),
        }),
      });
    }
    if (m === 'GET' && pathname === '/api/activity') {
      return send(res, 200, { activity: ledger.searchActivity(url.searchParams.get('q') ?? '') });
    }
    if (m === 'GET' && pathname === '/api/report') {
      ledger.track('report_viewed');
      return send(res, 200, betaReport(ledger, { appVersion }));
    }
    if (m === 'GET' && (match = pathname.match(/^\/api\/purchases\/(\d+)\/receipts$/))) {
      return send(res, 200, { receipts: listReceipts(ledger, id(match[1])) });
    }
    if (m === 'GET' && (match = pathname.match(/^\/api\/receipts\/(\d+)$/))) {
      const r = getReceipt(ledger, id(match[1]));
      if (!existsSync(r.path)) throw new HttpError(404, "That receipt's file is missing from the data folder.");
      const inline = r.mime === 'application/pdf' || r.mime.startsWith('image/');
      res.writeHead(200, {
        ...SECURITY_HEADERS,
        // A receipt is untrusted content: never let it run script on this origin.
        'Content-Security-Policy': "sandbox; default-src 'none'; img-src 'self' data:; style-src 'unsafe-inline'; frame-ancestors 'none'",
        'Content-Type': r.mime,
        'Content-Disposition': `${inline ? 'inline' : 'attachment'}; filename="${r.filename.replace(/"/g, '')}"`,
      });
      // A file that vanishes or can't be read mid-way ends the response; it never crashes the app.
      return createReadStream(r.path).on('error', () => res.destroy()).pipe(res);
    }

    // ── writes ──
    if (m === 'POST' && pathname === '/api/pro/activate') {
      const b = await readJson(req);
      const s = await activatePro(ledger, b.key, { fetch });
      const { released } = applyPlan(ledger); // every agent's waiting purchases count for it now
      broadcast();
      return send(res, 200, { ...s, released });
    }
    if (m === 'POST' && pathname === '/api/pro/deactivate') {
      await readJson(req);
      const s = await deactivatePro(ledger, { fetch });
      applyPlan(ledger);
      broadcast();
      return send(res, 200, s);
    }
    if (m === 'POST' && pathname === '/api/share-event') {
      const b = await readJson(req);
      ledger.track('share_card', { channel: String(b.channel ?? 'unknown'), size: String(b.size ?? 'social') });
      return send(res, 200, { ok: true });
    }
    if (m === 'POST' && pathname === '/api/capture-info') {
      await readJson(req);
      return send(res, 200, {
        key: captureKey(ledger.dataDir),
        webhook_url: `http://127.0.0.1:${actualPort}/api/capture`,
        sync_dir: syncDir,
      });
    }
    if (m === 'POST' && pathname === '/api/onboarding/dismiss') {
      await readJson(req);
      ledger.dismissOnboarding();
      return send(res, 200, { ok: true });
    }
    if (m === 'POST' && pathname === '/api/inbox/confirm-sure') {
      await readJson(req);
      return send(res, 200, ledger.confirmSure());
    }
    // The user chooses which agent, and which bank or card account, the free plan covers.
    if (m === 'PUT' && pathname === '/api/plan') {
      const b = await readJson(req);
      let r = null;
      if (b.freeAgentId !== undefined) r = chooseFreeAgent(ledger, id(String(b.freeAgentId)));
      if (b.freeAccountId !== undefined) r = chooseFreeAccount(ledger, id(String(b.freeAccountId)));
      if (!r) throw new LedgerError('Say which agent (freeAgentId) or account (freeAccountId) the free plan covers.');
      broadcast();
      return send(res, 200, r);
    }
    if (m === 'POST' && pathname === '/api/agents') {
      const b = await readJson(req);
      return send(res, 201, ledger.createAgent(b.name));
    }
    if (m === 'PATCH' && (match = pathname.match(/^\/api\/agents\/(\d+)$/))) {
      const b = await readJson(req);
      const agentId = id(match[1]);
      if ('budget' in b) {
        // "" or null clears it; anything else must read as money.
        const raw = b.budget === null ? '' : String(b.budget).trim();
        const cents = raw === '' ? null : parseAmountToCents(raw);
        if (raw !== '' && cents === null) throw new LedgerError('A budget must be an amount like "50.00", or empty for no budget.');
        ledger.setAgentBudget(agentId, cents);
      }
      if ('name' in b) ledger.renameAgent(agentId, b.name);
      return send(res, 200, ledger.listAgents().find((a) => a.id === agentId) ?? ledger.requireAgent(agentId));
    }
    if (m === 'PUT' && (match = pathname.match(/^\/api\/agents\/(\d+)\/mandate$/))) {
      const b = await readJson(req);
      const raw = b.max_purchase === null || b.max_purchase === undefined ? '' : String(b.max_purchase).trim();
      const cents = raw === '' ? null : parseAmountToCents(raw);
      if (raw !== '' && (cents === null || cents <= 0)) throw new LedgerError('The most for one purchase must be an amount like "50.00", or empty for no limit.');
      const merchants = Array.isArray(b.merchants) ? b.merchants : String(b.merchants ?? '').split(/[,\n]/);
      const r = setMandate(ledger, id(match[1]), {
        merchants, maxPurchaseCents: cents, currency: b.currency ?? 'USD',
        methods: Array.isArray(b.methods) ? b.methods : [], until: b.until ? String(b.until) : null, note: b.note ?? '',
      });
      broadcast();
      return send(res, 200, r);
    }
    if (m === 'DELETE' && (match = pathname.match(/^\/api\/agents\/(\d+)\/mandate$/))) {
      const r = clearMandate(ledger, id(match[1]));
      broadcast();
      return send(res, 200, r);
    }
    // Billing clients (src/clients.js, src/billing.js). A job's client, a client's handling fee and
    // the business name are free; marking lines billed is Pro; undoing a billing always works.
    if (m === 'PUT' && pathname === '/api/jobs/client') {
      const b = await readJson(req);
      const r = setJobClient(ledger, b.job, b.client ?? null);
      broadcast();
      return send(res, 200, r);
    }
    if (m === 'PATCH' && (match = pathname.match(/^\/api\/clients\/(\d+)$/))) {
      const b = await readJson(req);
      const r = updateClient(ledger, id(match[1]), { name: b.name, markupBp: 'markup' in b ? parseMarkup(b.markup) : undefined });
      broadcast();
      return send(res, 200, r);
    }
    if (m === 'PUT' && pathname === '/api/business') {
      const b = await readJson(req);
      return send(res, 200, { business_name: setBusinessName(ledger, b.name) });
    }
    if (m === 'POST' && (match = pathname.match(/^\/api\/clients\/(\d+)\/bill$/))) {
      requirePro(ledger, 'billing');
      const b = await readJson(req, 1024 * 1024);
      const r = markBilled(ledger, id(match[1]), { reference: b.reference, period: b.period ?? 'all', lines: b.lines });
      broadcast();
      return send(res, 201, r);
    }
    if (m === 'POST' && (match = pathname.match(/^\/api\/billings\/(\d+)\/undo$/))) {
      await readJson(req);
      const r = undoBilling(ledger, id(match[1]));
      broadcast();
      return send(res, 200, r);
    }
    if (m === 'POST' && (match = pathname.match(/^\/api\/mandate-flags\/(\d+)$/))) {
      const b = await readJson(req);
      const r = resolveFlag(ledger, id(match[1]), b.how);
      broadcast();
      return send(res, 200, r);
    }
    if (m === 'POST' && (match = pathname.match(/^\/api\/exceptions\/(\d+)\/(resolve|dismiss)$/))) {
      requirePro(ledger, 'oversight');
      const b = await readJson(req);
      const fn = match[2] === 'resolve' ? resolveException : dismissException;
      const r = fn(ledger, id(match[1]), { note: b.note ?? '' });
      broadcast();
      return send(res, 200, r);
    }
    if (m === 'POST' && pathname === '/api/schedule') {
      const b = await readJson(req);
      if (b.on) {
        requirePro(ledger, 'oversight');
        const r = schedule.installSchedule({ nodePath: stableNodePath(process.execPath), binPath: fileURLToPath(new URL('../bin/twinslip.js', import.meta.url)), dataDir: ledger.dataDir });
        if (!r.ok) throw new HttpError(400, `Background checks weren't turned on: ${r.reason}`);
      } else {
        const off = schedule.removeSchedule();
        if (!off.ok) throw new HttpError(400, `Background checks couldn't be turned off: ${off.reason}`);
      }
      return send(res, 200, scheduleView());
    }
    if (m === 'POST' && pathname === '/api/refunds') {
      const b = await readJson(req);
      const given = b.amount != null && String(b.amount).trim() !== '';
      const cents = given ? parseAmountToCents(String(b.amount)) : undefined;
      // From a purchase: its merchant, currency and amount, unless the user changed them.
      return send(res, 201, expectRefund(ledger, {
        purchaseId: b.purchaseId ? id(b.purchaseId) : null, merchant: b.merchant || undefined, amountCents: given ? (cents ?? NaN) : undefined,
        currency: b.currency || undefined, dueOn: b.dueOn, note: b.note ?? '',
      }, { by: 'user' }));
    }
    if (m === 'POST' && (match = pathname.match(/^\/api\/refunds\/(\d+)\/(resolve|dismiss)$/))) {
      const b = await readJson(req);
      const fn = match[2] === 'resolve' ? resolveRefund : dismissRefund;
      return send(res, 200, fn(ledger, id(match[1]), { note: b.note ?? '' }));
    }
    if (m === 'POST' && (match = pathname.match(/^\/api\/purchases\/(\d+)\/(confirm|reject|undo|pull-in)$/))) {
      const b = await readJson(req);
      const pid = id(match[1]);
      const action = match[2];
      if (action === 'confirm') return send(res, 200, ledger.confirm(pid, id(b.agentId), { always: b.always === true }));
      if (action === 'reject') return send(res, 200, ledger.reject(pid, { never: b.never === true }));
      if (action === 'undo') return send(res, 200, ledger.undo(pid));
      return send(res, 200, ledger.pullIn(pid));
    }
    if (m === 'POST' && pathname === '/api/purchases') {
      const b = await readJson(req);
      const cents = parseAmountToCents(String(b.amount ?? ''));
      return send(res, 201, ledger.addManual({
        occurredOn: b.date, amountCents: cents ?? NaN, merchant: b.merchant, agentId: b.agentId == null || b.agentId === '' ? null : id(b.agentId),
      }));
    }
    if (m === 'POST' && (match = pathname.match(/^\/api\/purchases\/(\d+)\/receipts$/))) {
      const bytes = await readBody(req, MAX_RECEIPT_BYTES + 1);
      let filename = 'receipt';
      try { filename = decodeURIComponent(String(req.headers['x-filename'] ?? 'receipt')); } catch { /* keep default */ }
      return send(res, 201, { receipts: addReceipt(ledger, id(match[1]), { filename, mime: req.headers['content-type'], bytes }) });
    }
    if (m === 'POST' && pathname === '/api/rules') {
      const b = await readJson(req);
      return send(res, 201, ledger.ruleFromPurchase(id(b.purchaseId)));
    }
    if (m === 'DELETE' && (match = pathname.match(/^\/api\/rules\/(\d+)$/))) {
      ledger.deleteRule(id(match[1]));
      return send(res, 200, { ok: true });
    }
    // Bank aggregators are retired (docs/PRODUCT.md). Old bank-feed records stay, with their
    // provenance and their ✓; nothing new connects or syncs. Import your bank's CSV instead.
    if (m === 'POST' && (pathname === '/api/simplefin/connect' || pathname === '/api/sync')) {
      throw new HttpError(410, RETIRED_FEED);
    }
    if (m === 'DELETE' && pathname === '/api/simplefin/access') {
      return send(res, 200, { removed: removeSimplefinAccess(ledger.dataDir) });
    }
    if (m === 'POST' && pathname === '/api/import/csv/preview') {
      const b = await readJson(req, MAX_CSV_BYTES * 2);
      return send(res, 200, previewCsv(b.csv, { spendSign: b.spendSign }));
    }
    if (m === 'POST' && pathname === '/api/import/csv') {
      const b = await readJson(req, MAX_CSV_BYTES * 2);
      const r = importCsv(ledger, b.csv, { spendSign: b.spendSign, account: b.account ?? null });
      broadcast();
      return send(res, 201, r);
    }
    throw new HttpError(404, 'Not found.');
  }

  const server = createServer((req, res) => (req.method === 'GET' ? servingGet.run(true, () => handle(req, res)) : handle(req, res)));
  async function handle(req, res) {
    try {
      if (!allowedHosts().has(String(req.headers.host ?? '').toLowerCase())) {
        throw new HttpError(421, 'Wrong host.');
      }
      const origin = req.headers.origin;
      if (origin !== undefined && !allowedOrigins().has(origin)) throw new HttpError(403, 'Cross-origin request refused.');
      const url = new URL(req.url, `http://127.0.0.1:${actualPort}`);
      await route(req, res, url);
    } catch (err) {
      const status = err instanceof HttpError || err instanceof LedgerError ? err.status : 500;
      if (status === 500) log(`twinslip: ${err.stack ?? err}`);
      if (!res.headersSent) send(res, status, { error: status === 500 ? 'Something went wrong.' : err.message });
      else res.end();
    }
  }

  let timer = null;
  const ready = new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(port, host, () => {
      actualPort = server.address().port;
      pruneEvents(ledger.db, ledger.now());
      if (oversight) {
        runOversight('start');
        lastTickMs = ledger.now().getTime();
        overseeTimer = setInterval(oversightTick, 60 * 1000);
        overseeTimer.unref();
      }
      ledger.track('app_started');
      revalidatePro(ledger, { fetch }).catch(() => {});
      resolve({ port: actualPort, url: `http://127.0.0.1:${actualPort}/` });
    });
  });

  return {
    ready,
    token,
    oversightTick,
    server,
    close: () => new Promise((r) => {
      if (timer) clearInterval(timer);
      if (overseeTimer) clearInterval(overseeTimer);
      clearInterval(livePoll);
      clearInterval(heartbeat);
      clearInterval(syncTimer);
      for (const c of liveClients) c.end();
      liveClients.clear();
      server.close(() => r());
      server.closeAllConnections();
    }),
  };
}
