// Money is integer minor units (cents) everywhere. Never floats.

const AMOUNT_RE = /^([+-])?\$?(\d{1,3}(?:,\d{3})+|\d+)?(?:\.(\d+))?$/;

/**
 * Parse a numeric amount string into integer cents.
 * Accepts "-33293.43", "1,234.56", "$12", "(12.00)" (accounting negative), "+5.1".
 * Returns null when the string is not an amount.
 */
export function parseAmountToCents(input) {
  if (typeof input === 'number') {
    if (!Number.isFinite(input)) return null;
    return Math.round(input * 100);
  }
  if (typeof input !== 'string') return null;
  let s = input.trim().replace(/\s+/g, '');
  if (s === '') return null;
  let negative = false;
  if (s.startsWith('(') && s.endsWith(')')) {
    negative = true;
    s = s.slice(1, -1);
  }
  // "-$12.00" and "$-12.00" both occur in bank exports.
  if (s.startsWith('-$')) s = '-' + s.slice(2);
  if (s.startsWith('$-')) s = '-' + s.slice(2);
  const m = AMOUNT_RE.exec(s);
  if (!m || (m[2] === undefined && m[3] === undefined)) return null;
  if (m[1] === '-') negative = !negative;
  const whole = Number((m[2] ?? '0').replace(/,/g, ''));
  const fracDigits = (m[3] ?? '').padEnd(3, '0');
  // Round half away from zero on the third decimal.
  let cents = whole * 100 + Number(fracDigits.slice(0, 2));
  if (Number(fracDigits[2]) >= 5) cents += 1;
  if (!Number.isSafeInteger(cents)) return null;
  return negative ? -cents : cents;
}

export function formatCents(cents, currency = 'USD') {
  const sign = cents < 0 ? '-' : '';
  const abs = Math.abs(cents);
  const whole = Math.floor(abs / 100).toLocaleString('en-US');
  const frac = String(abs % 100).padStart(2, '0');
  const symbol = currency === 'USD' ? '$' : '';
  const suffix = currency === 'USD' ? '' : ` ${currency}`;
  return `${sign}${symbol}${whole}.${frac}${suffix}`;
}
