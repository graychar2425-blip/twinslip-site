// Which checkout store sells Twinslip Pro. Placeholders until Daniel creates the Lemon
// Squeezy (or Paddle) account; while they're null, Pro simply isn't on sale yet and the app
// says so. Fill these in from the Lemon Squeezy dashboard: Store ID and Product ID(s).
export const PRO_CONFIG = {
  provider: 'lemonsqueezy',
  storeId: null, // e.g. 12345
  productIds: [], // e.g. [67890] (the Pro product; annual and monthly variants share it)
  // A seat is one person, on up to this many of their computers (Daniel, 2026-10-06). In the
  // checkout, set each key's activation limit to seats x this number; the app divides it back.
  computersPerSeat: 2,
  // Each seat includes 3 agents (src/pro.js). Extra agents are sold as checkout variants of the same
  // product ("Pro yearly + 2 agents"), so one key carries them: map each variant id (Lemon Squeezy)
  // or benefit id (Polar) to the extra agents it adds, e.g. { '123456': 1, '123457': 2 }.
  // A key whose variant isn't listed covers 3 agents per seat. docs/LAUNCH-CHECKLIST.md, step 4.
  extraAgentsByVariant: {},
  api: 'https://api.lemonsqueezy.com/v1/licenses',
  // The price as docs/PRODUCT.md §2 sets it (Daniel, 2026-10-23): per person, monthly or yearly,
  // with 3 agents; each extra agent $3 a month or $29 a year. The founding price is yearly, for the
  // base. A new price is Daniel's call.
  price: { seatMonth: 10, seatYear: 96, agents: 3, agentMonth: 3, agentYear: 29, founding: 72, foundingUntil: '15 April 2027', opens: 'February 2027' },
  // The live site until a custom domain is chosen; GitHub Pages then redirects this address to it.
  siteUrl: 'https://graychar2425-blip.github.io/twinslip-site',
  buyUrl: 'https://graychar2425-blip.github.io/twinslip-site/pro', // the website's Pro page (siteUrl + /pro)
};
