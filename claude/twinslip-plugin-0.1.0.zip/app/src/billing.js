// Billing clients for agent costs (docs/PRODUCT.md §2): what each client hasn't been billed yet,
// line by line with how each line was checked, and the user marking lines billed with their own
// invoice reference. Seeing the unbilled total is free; the statement files, invoice lines and
// marking lines billed are Pro (the gates sit where the user reaches them: src/server.js and
// src/mcp.js). Twinslip never sends an invoice: the user's own invoicing tool does.
//
// Unbilled is per purchase: its amount less what billings that weren't undone already covered,
// so a pay-per-use line that grows after it was billed shows only the growth. Marking lines billed
// takes the exact lines and amounts the user saw: a line that changed in between is refused, never
// billed blind. Only counted (confirmed) purchases are billed; currencies are never added together.

import { LedgerError } from './ledger.js';
import { getClient, findClient, listClients, cleanClient } from './clients.js';
import { jobCosts, jobSentence } from './jobs.js';
import { formatCents } from './money.js';
import { getMeta, setMeta, tx } from './db.js';
import { addMonths, monthKey, toLocalDate } from './dates.js';
import { redact } from './redact.js';
import { PRO_CONFIG } from './pro-config.js';

const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const MAX_BILL_LINES = 5000;
const REFERENCE_MAX = 60;
const CHANGED = 'Some of these lines changed since you opened them: billed already, moved to another client, or no longer counted. Open the statement again before marking it billed.';

/** How each line was checked. Only `verified_at` says whether it was; this says by what. */
export const EVIDENCE_LABELS = {
  bank: 'Bank',
  iphone: 'iPhone',
  receipt: 'Receipt attached',
  webhook: 'Webhook',
  verified: 'Verified',
  by_hand: 'Added by hand',
  agent_only: 'Agent report only',
};

/** The one line a free user sees under the statement preview: what Pro adds here, and its price. */
export function proBillingLine(config = PRO_CONFIG) {
  const p = config.price;
  return 'Sending it takes Pro: the PDF and CSV, a CSV of invoice lines, and marking lines billed with your invoice number. ' +
    `Pro is $${p.seatYear} a seat a year ($${p.founding} if you buy by ${p.foundingUntil})${config.storeId ? '' : `, from ${p.opens}`}.`;
}

/** "all" (everything not billed yet), "this_month", "last_month" or YYYY-MM → { key, from, to (exclusive), label, slug }. */
export function resolvePeriod(period = 'all', today) {
  const p = period ?? 'all';
  if (p === 'all') return { key: 'all', from: null, to: null, label: `Everything not billed yet, up to ${today}`, slug: `to-${today}` };
  let month = null;
  if (p === 'this_month') month = monthKey(today);
  else if (p === 'last_month') month = addMonths(monthKey(today), -1);
  else if (/^\d{4}-(0[1-9]|1[0-2])$/.test(p)) month = p;
  if (!month) throw new LedgerError('period must be "all", "this_month", "last_month", or a month like 2026-10.');
  return { key: month, from: `${month}-01`, to: `${addMonths(month, 1)}-01`, label: `${MONTHS[Number(month.slice(5)) - 1]} ${month.slice(0, 4)}`, slug: month };
}

/** The handling fee on a subtotal, in hundredths of a percent: rounded once, half up; never on a net refund. */
export function markupCents(subtotalCents, bp) {
  if (!(bp > 0) || !(subtotalCents > 0)) return 0;
  return Math.floor((subtotalCents * bp + 5000) / 10000);
}

export function businessName(ledger) {
  return getMeta(ledger.db, 'business_name') ?? '';
}

/** The user's business name, printed on statements. '' clears it. */
export function setBusinessName(ledger, raw) {
  const name = redact(String(raw ?? '')).replace(/\s+/g, ' ').trim().slice(0, 80).trim();
  if (name) setMeta(ledger.db, 'business_name', name);
  else ledger.db.prepare("DELETE FROM meta WHERE key = 'business_name'").run();
  return name;
}

function evidenceOf(p) {
  if (p.verified_at) {
    const kinds = new Set([p.source_kind, ...(p.also_seen_by ? p.also_seen_by.split(',') : [])]);
    if (kinds.has('csv') || kinds.has('simplefin')) return 'bank';
    if (kinds.has('phone')) return 'iphone';
    if (p.receipt_count > 0) return 'receipt';
    if (kinds.has('webhook')) return 'webhook';
    return 'verified';
  }
  return p.source_kind === 'manual' ? 'by_hand' : 'agent_only';
}

/**
 * Counted purchases with a client and something left to bill, oldest first: { id, occurred_on,
 * merchant, agent, job, client_id, client, currency, amount_cents, billed_cents, cents (left to
 * bill), evidence, evidence_label, marked (an agent's report with no independent proof) }.
 */
export function unbilledLines(ledger, { clientId = null, from = null, to = null } = {}) {
  const where = ["p.status = 'confirmed'", 'p.client_id IS NOT NULL'];
  const args = [];
  if (clientId != null) { where.push('p.client_id = ?'); args.push(Number(clientId)); }
  if (from) { where.push('p.occurred_on >= ?'); args.push(from); }
  if (to) { where.push('p.occurred_on < ?'); args.push(to); }
  return ledger.db.prepare(`
    SELECT p.id, p.occurred_on, p.merchant, p.amount_cents, p.currency, p.job, p.client_id, c.name AS client,
           a.name AS agent, s.kind AS source_kind, p.verified_at,
           (SELECT group_concat(DISTINCT s2.kind) FROM purchases m JOIN sources s2 ON s2.id = m.source_id WHERE m.merged_into = p.id) AS also_seen_by,
           (SELECT count(*) FROM receipts r WHERE r.purchase_id = p.id) AS receipt_count,
           COALESCE((SELECT sum(bl.cents) FROM billing_lines bl JOIN billings b ON b.id = bl.billing_id
                      WHERE bl.purchase_id = p.id AND b.undone_at IS NULL), 0) AS billed_cents
    FROM purchases p JOIN agents a ON a.id = p.agent_id JOIN sources s ON s.id = p.source_id JOIN clients c ON c.id = p.client_id
    WHERE ${where.join(' AND ')} ORDER BY p.occurred_on, p.id`).all(...args)
    .filter((p) => p.amount_cents !== p.billed_cents)
    .map((p) => {
      const evidence = evidenceOf(p);
      return {
        id: p.id, occurred_on: p.occurred_on, merchant: p.merchant, agent: p.agent, job: p.job ?? null,
        client_id: p.client_id, client: p.client, currency: p.currency,
        amount_cents: p.amount_cents, billed_cents: p.billed_cents, cents: p.amount_cents - p.billed_cents,
        evidence, evidence_label: EVIDENCE_LABELS[evidence], marked: evidence === 'agent_only',
      };
    });
}

/** Per currency, in the order the lines first use it: { currency, lines, subtotal_cents, markup_cents, total_cents }. */
export function statementTotals(lines, markupBp) {
  const by = new Map();
  for (const l of lines) {
    const t = by.get(l.currency) ?? by.set(l.currency, { currency: l.currency, lines: 0, subtotal_cents: 0 }).get(l.currency);
    t.lines++;
    t.subtotal_cents += l.cents;
  }
  return [...by.values()].map((t) => {
    const markup = markupCents(t.subtotal_cents, markupBp);
    return { ...t, markup_cents: markup, total_cents: t.subtotal_cents + markup };
  });
}

/**
 * What each client hasn't been billed yet (free): { client_id, client, markup_bp, lines, marked,
 * jobs, first_on, last_on, totals: [{ currency, cents }] (the costs), billable: [{ currency, cents }]
 * (with the handling fee: what the statement's total says) }.
 */
export function unbilledByClient(ledger, { from = null, to = null } = {}) {
  const fees = new Map(ledger.db.prepare('SELECT id, markup_bp FROM clients').all().map((c) => [c.id, c.markup_bp]));
  const by = new Map();
  for (const l of unbilledLines(ledger, { from, to })) {
    const c = by.get(l.client_id) ?? by.set(l.client_id, {
      client_id: l.client_id, client: l.client, markup_bp: fees.get(l.client_id) ?? 0, lines: [], jobs: new Set(),
    }).get(l.client_id);
    c.lines.push(l);
    if (l.job) c.jobs.add(l.job);
  }
  return [...by.values()].map((c) => {
    const t = statementTotals(c.lines, c.markup_bp);
    return {
      client_id: c.client_id, client: c.client, markup_bp: c.markup_bp,
      lines: c.lines.length, marked: c.lines.filter((l) => l.marked).length, jobs: [...c.jobs],
      first_on: c.lines[0].occurred_on, last_on: c.lines.at(-1).occurred_on,
      totals: t.map((x) => ({ currency: x.currency, cents: x.subtotal_cents })),
      billable: t.map((x) => ({ currency: x.currency, cents: x.total_cents })),
    };
  }).sort((a, b) => a.client.localeCompare(b.client));
}

/**
 * The Jobs view's client list: every client with something to bill (as unbilledByClient) or a
 * billing to look back on and undo, with `billings` counting the billings not undone. A client
 * with neither isn't listed. A client is reachable here even when none of its jobs is.
 */
export function clientOverview(ledger) {
  const out = unbilledByClient(ledger).map((c) => ({ ...c, billings: 0 }));
  const billed = ledger.db.prepare(`SELECT c.id, c.name, c.markup_bp, count(b.id) AS n FROM clients c
    JOIN billings b ON b.client_id = c.id AND b.undone_at IS NULL GROUP BY c.id`).all();
  for (const b of billed) {
    const c = out.find((x) => x.client_id === b.id);
    if (c) c.billings = b.n;
    else {
      out.push({ client_id: b.id, client: b.name, markup_bp: b.markup_bp, lines: 0, marked: 0, jobs: [], first_on: null, last_on: null, totals: [], billable: [], billings: b.n });
    }
  }
  return out.sort((a, b) => a.client.localeCompare(b.client));
}

/** One client's statement for a period: who it's from, the lines, the totals with the handling fee. */
export function clientStatement(ledger, clientId, { period = 'all' } = {}) {
  const client = getClient(ledger, clientId);
  const today = toLocalDate(ledger.now());
  const p = resolvePeriod(period, today);
  const lines = unbilledLines(ledger, { clientId: client.id, from: p.from, to: p.to });
  return {
    business_name: businessName(ledger),
    client: { id: client.id, name: client.name, markup_bp: client.markup_bp },
    period: p,
    prepared_on: today,
    lines,
    totals: statementTotals(lines, client.markup_bp),
    marked: lines.filter((l) => l.marked).length,
  };
}

function cleanReference(raw) {
  const ref = redact(String(raw ?? '')).replace(/\s+/g, ' ').trim();
  if (!ref) throw new LedgerError('Give the invoice number (or another reference you will recognise) to mark these lines billed.');
  if (ref.length > REFERENCE_MAX) throw new LedgerError(`An invoice number can be at most ${REFERENCE_MAX} characters.`);
  return ref;
}

function sumByCurrency(rows) {
  const by = new Map();
  for (const r of rows) by.set(r.currency, (by.get(r.currency) ?? 0) + r.cents);
  return [...by].map(([currency, cents]) => ({ currency, cents }));
}

/**
 * The user marks the lines they billed, with their invoice reference. `lines` are the exact
 * [{ id, cents }] the user saw; any that changed since is refused with a 409. Returns
 * { id, reference, lines, totals }.
 */
export function markBilled(ledger, clientId, { reference, period = 'all', lines } = {}) {
  const client = getClient(ledger, clientId);
  const ref = cleanReference(reference);
  if (!Array.isArray(lines) || !lines.length) throw new LedgerError('There are no lines to mark billed.');
  if (lines.length > MAX_BILL_LINES) throw new LedgerError(`At most ${MAX_BILL_LINES} lines can be marked billed at once.`);
  const seen = new Set();
  const want = lines.map((l) => {
    const id = Number(l?.id);
    if (!Number.isSafeInteger(id) || id <= 0 || !Number.isSafeInteger(l?.cents) || l.cents === 0) {
      throw new LedgerError('Each line needs the purchase id and the amount you saw, in cents.');
    }
    if (seen.has(id)) throw new LedgerError('The same line is listed twice.');
    seen.add(id);
    return { id, cents: l.cents };
  });
  const p = resolvePeriod(period, toLocalDate(ledger.now()));
  const billed = tx(ledger.db, () => {
    const open = new Map(unbilledLines(ledger, { clientId: client.id }).map((u) => [u.id, u]));
    for (const l of want) {
      const u = open.get(l.id);
      if (!u || Math.sign(u.cents) !== Math.sign(l.cents) || Math.abs(l.cents) > Math.abs(u.cents)) throw new LedgerError(CHANGED, 409);
      l.currency = u.currency;
    }
    const id = Number(ledger.db.prepare('INSERT INTO billings (client_id, reference, period_from, period_to, markup_bp, billed_at) VALUES (?, ?, ?, ?, ?, ?)')
      .run(client.id, ref, p.from, p.to, client.markup_bp, ledger.now().toISOString()).lastInsertRowid);
    const add = ledger.db.prepare('INSERT INTO billing_lines (billing_id, purchase_id, cents, currency) VALUES (?, ?, ?, ?)');
    for (const l of want) add.run(id, l.id, l.cents, l.currency);
    return id;
  });
  ledger.track('billed', { lines: want.length });
  return { id: billed, client_id: client.id, reference: ref, lines: want.length, totals: sumByCurrency(want) };
}

/** Undo a "Mark as billed": its lines are unbilled again. The record stays, marked undone. */
export function undoBilling(ledger, billingId) {
  const b = ledger.db.prepare('SELECT id, client_id, reference, undone_at FROM billings WHERE id = ?').get(Number(billingId));
  if (!b) throw new LedgerError('No such billing.', 404);
  if (b.undone_at) throw new LedgerError('That billing was already undone.', 409);
  const at = ledger.now().toISOString();
  ledger.db.prepare('UPDATE billings SET undone_at = ? WHERE id = ? AND undone_at IS NULL').run(at, b.id);
  ledger.track('billing_undone');
  return { id: b.id, client_id: b.client_id, reference: b.reference, undone_at: at };
}

/** A client's billings, newest first: its purchases, the costs it covered per currency, and with its handling fee (billable). */
export function listBillings(ledger, clientId, { limit = 50 } = {}) {
  const rows = ledger.db.prepare(`SELECT id, reference, period_from, period_to, markup_bp, billed_at FROM billings
    WHERE client_id = ? AND undone_at IS NULL ORDER BY billed_at DESC, id DESC LIMIT ?`).all(Number(clientId), limit);
  const linesOf = ledger.db.prepare(`SELECT bl.purchase_id AS id, bl.cents, bl.currency, p.occurred_on, p.merchant, p.job, a.name AS agent
    FROM billing_lines bl JOIN purchases p ON p.id = bl.purchase_id LEFT JOIN agents a ON a.id = p.agent_id
    WHERE bl.billing_id = ? ORDER BY p.occurred_on, p.id`);
  return rows.map((b) => {
    const purchases = linesOf.all(b.id).map((x) => ({ ...x }));
    const totals = sumByCurrency(purchases);
    return { ...b, lines: purchases.length, purchases, totals, billable: totals.map((t) => ({ currency: t.currency, cents: t.cents + markupCents(t.cents, b.markup_bp) })) };
  });
}

const CHECKED = {
  bank: 'checked by the bank', iphone: 'checked by the iPhone', receipt: 'receipt attached', webhook: 'checked by the webhook',
  verified: 'verified', by_hand: 'added by hand', agent_only: 'agent report only',
};
const amounts = (totals) => totals.map((t) => formatCents(t.cents, t.currency)).join(' + ');
const SHOW_CLIENTS = 20;
const SHOW_LINES = 60;

/**
 * What an agent hears from get_unbilled. Free: each client's unbilled total and its jobs' costs
 * (both free), and one sentence on Pro. Pro: each line with how it was checked, the subtotal,
 * the handling fee and the total. Read-only, and never says anything is billed.
 */
export function describeUnbilled(ledger, { client = null, period = 'all', pro = false } = {}) {
  const today = toLocalDate(ledger.now());
  const p = resolvePeriod(period, today);
  const when = p.key === 'all' ? `everything not billed yet, up to ${today}` : p.label;
  let only = null;
  if (cleanClient(client)) {
    only = findClient(ledger, client);
    if (!only) {
      const names = listClients(ledger).map((c) => c.name);
      return `No client called "${cleanClient(client)}". ${names.length ? `Clients: ${names.join(', ')}.` : 'There are no clients yet.'}`;
    }
  }
  const clients = unbilledByClient(ledger, { from: p.from, to: p.to }).filter((c) => !only || c.client_id === only.id);
  if (!clients.length) {
    if (only) return `Nothing to bill for ${only.name} (${when}).`;
    if (!listClients(ledger).length) return "No client has anything to bill yet. Name the client when you report a purchase (`client`), or the user can give a job a client in Twinslip's Jobs view.";
    return `Nothing to bill (${when}).`;
  }
  const more = clients.length > SHOW_CLIENTS ? `\n…and ${clients.length - SHOW_CLIENTS} more clients.` : '';
  if (!pro) {
    const jobs = jobCosts(ledger, { from: p.from, to: p.to, limit: 1000 });
    const blocks = clients.slice(0, SHOW_CLIENTS).map((c) => {
      const n = c.jobs.length;
      return [`${c.client}: ${amounts(c.totals)} not billed yet${n ? `, on ${n} job${n === 1 ? '' : 's'}` : ''}.`,
        ...jobs.filter((j) => j.client_id === c.client_id).slice(0, 10).map(jobSentence)].join('\n');
    });
    return `Not billed yet (${when}):\n${blocks.join('\n')}${more}\n` +
      "Line-by-line statements, invoice lines and marking costs billed are part of Twinslip Pro; the user can preview the statement in Twinslip's Jobs view.";
  }
  const from = businessName(ledger);
  const blocks = clients.slice(0, SHOW_CLIENTS).map((c) => {
    const st = clientStatement(ledger, c.client_id, { period: p.key });
    const lines = st.lines.slice(0, SHOW_LINES).map((l) => `- ${l.occurred_on} ${l.merchant}, ${l.agent}${l.job ? `, "${l.job}"` : ''}: ${formatCents(l.cents, l.currency)} (${CHECKED[l.evidence]})`);
    if (st.lines.length > SHOW_LINES) lines.push(`- …and ${st.lines.length - SHOW_LINES} more lines, all of them in the statement`);
    const multi = st.totals.length > 1;
    const sums = st.totals.map((t) => `${multi ? `${t.currency}: subtotal` : 'Subtotal'} ${formatCents(t.subtotal_cents, t.currency)}; ` +
      `${t.markup_cents ? `handling fee (${st.client.markup_bp / 100}%) ${formatCents(t.markup_cents, t.currency)}; ` : ''}total ${formatCents(t.total_cents, t.currency)}.`);
    const marked = !st.marked ? [] : [st.marked === 1 ? "1 line is an agent's report with no independent proof yet; the statement marks it."
      : `${st.marked} lines are agents' reports with no independent proof yet; the statement marks them.`];
    return [`Not billed yet for ${c.client} (${when})${from ? `, from ${from}` : ''}:`, ...lines, ...sums, ...marked].join('\n');
  });
  const close = clients.length === 1
    ? `The user downloads the statement (PDF or CSV) and invoice lines in Twinslip's Jobs view (Bill ${clients[0].client}), and marks the lines billed there with their invoice number.`
    : "The user downloads each client's statement (PDF or CSV) and invoice lines in Twinslip's Jobs view, and marks the lines billed there with their invoice number.";
  return `${blocks.join('\n\n')}${more}\n${close} Only the user marks lines billed.`;
}
