import { mkdirSync, chmodSync } from 'node:fs';
import { join } from 'node:path';
import { randomUUID } from 'node:crypto';
import './quiet-sqlite.js';

// Loaded dynamically so quiet-sqlite.js is installed before the builtin emits its warning.
const { DatabaseSync } = await import('node:sqlite');

// Data model. One SQLite file on the user's machine.
//
// Capture sources, fastest first:
//   agent      the agent reports its own purchase the moment it makes it (MCP / CLI)
//   email      the agent sweeps the user's inbox for receipts
//   simplefin  bank feed;  csv  bank export;  manual  added by hand
//
// purchase.status is the attribution state machine:
//
//   background ──pull-in──▶ candidate ──confirm──▶ confirmed   (counted, has agent_id)
//                              │  ▲                    │
//                              │  └──────undo──────────┤
//                              └──reject──▶ not_agent ─┘
//   merged: the same charge seen again by another source (receipt, bank line). It points
//           at the row that counts (merged_into) and marks it verified. Never counted.
//
// Only `confirmed` rows are ever summed. `background` and `not_agent` are personal
// spending: they exist so the user can pull in a missed agent purchase, and are never
// shown in, or added to, the agent bucket.
//
// What is deliberately NOT stored: account numbers, card numbers, balances, account
// names, bank credentials. The SimpleFIN access URL lives in credentials.json (0600),
// never in this database.

/**
 * Source kinds that see a charge on their own: the bank (feed or CSV), the iPhone, the local
 * webhook, and Stripe Link's record of a charge on the user's Link wallet (read through the
 * user's own link-cli; the card issuer's record, like a bank line).
 */
export const INDEPENDENT_KINDS = ['simplefin', 'csv', 'phone', 'webhook', 'link'];

/** SQL: does purchase `id` have independent evidence (its own source, a merged copy, or an attached receipt)? */
export function INDEPENDENT_SQL(id) {
  const kinds = INDEPENDENT_KINDS.map((k) => `'${k}'`).join(', ');
  return `(EXISTS (SELECT 1 FROM purchases w JOIN sources ws ON ws.id = w.source_id
      WHERE (w.id = ${id} OR w.merged_into = ${id}) AND ws.kind IN (${kinds}))
    OR EXISTS (SELECT 1 FROM receipts wr WHERE wr.purchase_id = ${id}))`;
}

const MIGRATIONS = [
  `
  CREATE TABLE meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);

  CREATE TABLE agents (
    id          INTEGER PRIMARY KEY,
    name        TEXT NOT NULL UNIQUE COLLATE NOCASE CHECK (length(trim(name)) BETWEEN 1 AND 60),
    created_at  TEXT NOT NULL
  );

  CREATE TABLE sources (
    id               INTEGER PRIMARY KEY,
    kind             TEXT NOT NULL CHECK (kind IN ('agent', 'email', 'simplefin', 'csv', 'manual')),
    label            TEXT NOT NULL,
    agent_id         INTEGER REFERENCES agents(id),   -- kind = 'agent': whose reports these are
    created_at       TEXT NOT NULL,
    last_attempt_at  TEXT,
    last_success_at  TEXT,
    last_error       TEXT
  );

  CREATE TABLE purchases (
    id                  INTEGER PRIMARY KEY,
    source_id           INTEGER NOT NULL REFERENCES sources(id),
    external_id         TEXT NOT NULL,
    occurred_on         TEXT NOT NULL,             -- local date YYYY-MM-DD
    amount_cents        INTEGER NOT NULL,          -- positive = money out; refunds negative
    currency            TEXT NOT NULL DEFAULT 'USD',
    merchant            TEXT NOT NULL,             -- display name
    merchant_key        TEXT NOT NULL,             -- normalized, for rules
    description         TEXT NOT NULL DEFAULT '',  -- the bank's merchant text, nothing else
    payment_method      TEXT,                      -- as reported by the agent: card, credits, crypto...
    status              TEXT NOT NULL CHECK (status IN ('background', 'candidate', 'confirmed', 'not_agent', 'merged')),
    agent_id            INTEGER REFERENCES agents(id),
    match_reason        TEXT,
    attributed_by       TEXT CHECK (attributed_by IN ('user', 'rule', 'agent')),
    attributed_at       TEXT,
    surfaced_at         TEXT,                      -- when it first entered the inbox
    merged_into         INTEGER REFERENCES purchases(id),
    verified_at         TEXT,                      -- another source independently saw this charge
    created_at          TEXT NOT NULL,
    UNIQUE (source_id, external_id),
    CHECK ((status = 'confirmed') = (agent_id IS NOT NULL)),
    CHECK ((status = 'merged') = (merged_into IS NOT NULL))
  );
  CREATE INDEX purchases_merged ON purchases(merged_into);
  CREATE INDEX purchases_status ON purchases(status, occurred_on);
  CREATE INDEX purchases_key ON purchases(merchant_key);

  CREATE TABLE receipts (
    id           INTEGER PRIMARY KEY,
    purchase_id  INTEGER NOT NULL REFERENCES purchases(id),
    filename     TEXT NOT NULL,
    stored_name  TEXT NOT NULL,
    mime         TEXT NOT NULL,
    bytes        INTEGER NOT NULL,
    sha256       TEXT NOT NULL,
    added_at     TEXT NOT NULL,
    UNIQUE (purchase_id, sha256)
  );

  CREATE TABLE rules (
    id            INTEGER PRIMARY KEY,
    merchant_key  TEXT NOT NULL UNIQUE,
    action        TEXT NOT NULL CHECK (action IN ('attribute', 'ignore')),
    agent_id      INTEGER REFERENCES agents(id),
    created_at    TEXT NOT NULL,
    CHECK ((action = 'attribute') = (agent_id IS NOT NULL))
  );

  -- Local-only product analytics. Never transmitted. See docs/METRICS.md.
  CREATE TABLE events (
    id     INTEGER PRIMARY KEY,
    at     TEXT NOT NULL,
    name   TEXT NOT NULL,
    props  TEXT NOT NULL DEFAULT '{}'
  );
  CREATE INDEX events_name ON events(name, at);
  `,
  // Per-agent monthly budget: awareness, not enforcement. Counts confirmed spend in
  // budget_currency only; currencies are never added together.
  `
  ALTER TABLE agents ADD COLUMN monthly_budget_cents INTEGER CHECK (monthly_budget_cents IS NULL OR monthly_budget_cents > 0);
  ALTER TABLE agents ADD COLUMN budget_currency TEXT NOT NULL DEFAULT 'USD';
  `,
  // The capture ladder: phone (iPhone Shortcuts via the synced file), alert (bank alert
  // emails swept by the user's agent), webhook (anything local). Widening a CHECK means
  // rebuilding the table (SQLite's documented 12-step procedure), with foreign keys off.
  // Plus a local audit trail of every attribution decision (Pro, seat two and up).
  (db, done, stillNeeded) => {
    db.exec('PRAGMA foreign_keys = OFF');
    try {
      tx(db, () => {
        if (!stillNeeded()) return; // another process got here first
        db.exec(`
          CREATE TABLE sources_new (
            id               INTEGER PRIMARY KEY,
            kind             TEXT NOT NULL CHECK (kind IN ('agent', 'email', 'simplefin', 'csv', 'manual', 'phone', 'alert', 'webhook')),
            label            TEXT NOT NULL,
            agent_id         INTEGER REFERENCES agents(id),
            created_at       TEXT NOT NULL,
            last_attempt_at  TEXT,
            last_success_at  TEXT,
            last_error       TEXT
          );
          INSERT INTO sources_new (id, kind, label, agent_id, created_at, last_attempt_at, last_success_at, last_error)
            SELECT id, kind, label, agent_id, created_at, last_attempt_at, last_success_at, last_error FROM sources;
          DROP TABLE sources;
          ALTER TABLE sources_new RENAME TO sources;

          CREATE TABLE audit_log (
            id           INTEGER PRIMARY KEY,
            at           TEXT NOT NULL,
            action       TEXT NOT NULL,
            purchase_id  INTEGER,
            merchant     TEXT,
            amount_cents INTEGER,
            currency     TEXT,
            agent_id     INTEGER,
            detail       TEXT NOT NULL DEFAULT ''
          );
          CREATE INDEX audit_log_at ON audit_log(at);
        `);
        const broken = db.prepare('PRAGMA foreign_key_check').all();
        if (broken.length) throw new Error(`migration 3 left ${broken.length} broken references`);
        done();
      });
    } finally {
      db.exec('PRAGMA foreign_keys = ON');
    }
  },
  // Email sweeps an agent finished (docs/design/AGENT-SETUP-PLAN.md). Evidence for the setup
  // checklist only: it never moves a search window and never touches a purchase.
  `
  CREATE TABLE sweeps (
    id          INTEGER PRIMARY KEY,
    kind        TEXT NOT NULL CHECK (kind IN ('receipts', 'bank_alerts')),
    agent_id    INTEGER REFERENCES agents(id),
    finished_at TEXT NOT NULL,
    found       INTEGER NOT NULL CHECK (found >= 0)
  );
  `,
  // Trust fixes (docs/design/TRUST-PLAN.md). Which agent's connection added a row, kept apart
  // from whose spending it is, so one agent's writes can be limited. Not backfilled: older rows
  // can't prove which way they came in. And ✓ recomputed under one rule: something the
  // agent didn't supply saw the charge (a bank line, the iPhone, the local webhook, or a
  // receipt file the user attached). Agent-found receipts and alerts no longer count.
  `
  ALTER TABLE purchases ADD COLUMN reported_by_agent_id INTEGER REFERENCES agents(id);
  CREATE INDEX purchases_reporter ON purchases(reported_by_agent_id, created_at);
  UPDATE purchases SET verified_at = CASE WHEN ${INDEPENDENT_SQL('purchases.id')}
    THEN COALESCE(verified_at, created_at) ELSE NULL END WHERE status != 'merged';
  UPDATE purchases SET verified_at = NULL WHERE status = 'merged';
  `,
  // Purser slice 1 (docs/PRODUCT.md §4, §6). Only new tables: nothing here changes a purchase,
  // and none of these rows is ever spending.
  //   capture_checks    an agent proving its connection (test_capture); never a purchase
  //   expected_refunds  a refund someone expects; never lowers a total
  //   refund_links      the refund lines that answered an expectation (each line at most once)
  //   exceptions        what needs the user's attention, one row per (kind, subject)
  //   exception_events  each exception's history: opened, updated, cleared, resolved, dismissed
  //   monitor_runs      every oversight run, and any gap when nothing was watching
  // Foreign keys are NO ACTION on delete on purpose: the app never deletes a purchase or an
  // agent, and a financial record must never cascade away. Purely additive: an older build
  // ignores these tables (its migration loop stops at its own length).
  `
  CREATE TABLE capture_checks (
    id        INTEGER PRIMARY KEY,
    agent_id  INTEGER NOT NULL REFERENCES agents(id),
    check_id  TEXT NOT NULL CHECK (length(check_id) BETWEEN 1 AND 80),
    host      TEXT,
    client    TEXT,
    at        TEXT NOT NULL,
    UNIQUE (agent_id, check_id)
  );

  CREATE TABLE expected_refunds (
    id                   INTEGER PRIMARY KEY,
    purchase_id          INTEGER REFERENCES purchases(id),
    merchant             TEXT NOT NULL,
    merchant_key         TEXT NOT NULL,
    amount_cents         INTEGER NOT NULL CHECK (amount_cents > 0),
    currency             TEXT NOT NULL,
    due_on               TEXT NOT NULL,
    note                 TEXT NOT NULL DEFAULT '',
    created_by           TEXT NOT NULL CHECK (created_by IN ('user', 'agent')),
    reported_by_agent_id INTEGER REFERENCES agents(id),
    status               TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'evidence', 'resolved', 'dismissed')),
    reference            TEXT,                 -- an agent's id for it, so a retry is a duplicate
    created_at           TEXT NOT NULL,
    resolved_at          TEXT,
    CHECK ((status IN ('resolved', 'dismissed')) = (resolved_at IS NOT NULL))  -- closed exactly when it has a close time
  );
  CREATE INDEX expected_refunds_open ON expected_refunds(status, currency, merchant_key);
  CREATE INDEX expected_refunds_purchase ON expected_refunds(purchase_id);
  CREATE UNIQUE INDEX expected_refunds_ref ON expected_refunds(reported_by_agent_id, reference) WHERE reference IS NOT NULL;

  -- Which refund lines answered which expectation. A refund line answers at most one.
  CREATE TABLE refund_links (
    id                  INTEGER PRIMARY KEY,
    expected_refund_id  INTEGER NOT NULL REFERENCES expected_refunds(id),
    purchase_id         INTEGER NOT NULL UNIQUE REFERENCES purchases(id),
    cents               INTEGER NOT NULL CHECK (cents > 0),
    at                  TEXT NOT NULL
  );
  CREATE INDEX refund_links_by ON refund_links(expected_refund_id);

  CREATE TABLE exceptions (
    id           INTEGER PRIMARY KEY,
    kind         TEXT NOT NULL CHECK (kind IN ('missing_refund', 'refund_unconfirmed', 'source_failed', 'source_overdue', 'coverage_gap', 'monitoring_gap')),
    subject      TEXT NOT NULL,
    severity     TEXT NOT NULL CHECK (severity IN ('urgent', 'normal')),
    status       TEXT NOT NULL CHECK (status IN ('open', 'resolved', 'dismissed')),
    title        TEXT NOT NULL,
    evidence     TEXT NOT NULL DEFAULT '{}',
    uncertain    TEXT NOT NULL DEFAULT '',
    next_action  TEXT NOT NULL DEFAULT '',
    opened_at    TEXT NOT NULL,
    updated_at   TEXT NOT NULL,
    resolved_at  TEXT,
    notified_at  TEXT,
    UNIQUE (kind, subject)
  );
  CREATE INDEX exceptions_status ON exceptions(status, severity);

  CREATE TABLE exception_events (
    id            INTEGER PRIMARY KEY,
    exception_id  INTEGER NOT NULL REFERENCES exceptions(id),
    at            TEXT NOT NULL,
    actor         TEXT NOT NULL CHECK (actor IN ('system', 'user')),
    action        TEXT NOT NULL CHECK (action IN ('opened', 'updated', 'cleared', 'resolved', 'dismissed', 'reopened', 'notified')),
    note          TEXT NOT NULL DEFAULT ''
  );
  CREATE INDEX exception_events_by ON exception_events(exception_id, id);

  CREATE TABLE monitor_runs (
    id           INTEGER PRIMARY KEY,
    started_at   TEXT NOT NULL,
    finished_at  TEXT,
    trigger      TEXT NOT NULL CHECK (trigger IN ('start', 'hourly', 'wake', 'cli', 'launchd', 'test')),
    gap_from     TEXT,
    gap_to       TEXT
  );
  `,
  // The dates each bank CSV import spans (Codex inspection, PURSER-001): a month is checked
  // against the bank only when the imports cover it from its first days to its last, not when
  // any later bank line happens to exist. Additive; older imports fall back to dense runs of
  // their own lines.
  `
  CREATE TABLE bank_imports (
    id         INTEGER PRIMARY KEY,
    source_id  INTEGER NOT NULL REFERENCES sources(id),
    from_date  TEXT NOT NULL,
    to_date    TEXT NOT NULL CHECK (to_date >= from_date),
    lines      INTEGER NOT NULL CHECK (lines > 0),
    at         TEXT NOT NULL
  );
  CREATE INDEX bank_imports_dates ON bank_imports(from_date, to_date);
  `,
  // Where agent spending is heading (docs/design/AHEAD.md). Additive: nothing here changes how a
  // purchase counts.
  //   mandates        what the user says each agent may buy (merchants, a per-purchase ceiling,
  //                   payment methods, an end date). Awareness, not enforcement, like budgets.
  //   mandate_flags   an agent purchase outside its mandate, until the user notes or allows it
  //   purchases.job   the piece of work a purchase paid for, as the agent named it
  //   usage_streams   many tiny payments (pay-per-request, x402) rolled up per agent, merchant,
  //                   day and job; the day's total is one ledger line once it reaches a cent
  //   usage_calls     record_usage calls per agent per hour, for its own limit
  //   relay_kits      drop kits for cloud agents reporting through an encrypted relay
  //   relay_seen      relay drops already handled, so a drop is never applied twice
  `
  CREATE TABLE mandates (
    agent_id            INTEGER PRIMARY KEY REFERENCES agents(id),
    merchants           TEXT NOT NULL DEFAULT '[]',
    max_purchase_cents  INTEGER CHECK (max_purchase_cents IS NULL OR max_purchase_cents > 0),
    currency            TEXT NOT NULL DEFAULT 'USD',
    methods             TEXT NOT NULL DEFAULT '[]',
    until               TEXT,
    note                TEXT NOT NULL DEFAULT '',
    updated_at          TEXT NOT NULL
  );
  CREATE TABLE mandate_flags (
    id           INTEGER PRIMARY KEY,
    purchase_id  INTEGER NOT NULL UNIQUE REFERENCES purchases(id),
    agent_id     INTEGER NOT NULL REFERENCES agents(id),
    reasons      TEXT NOT NULL,
    created_at   TEXT NOT NULL,
    resolved_at  TEXT,
    resolution   TEXT CHECK (resolution IS NULL OR resolution IN ('noted', 'allowed')),
    CHECK ((resolved_at IS NULL) = (resolution IS NULL))
  );
  CREATE INDEX mandate_flags_open ON mandate_flags(resolved_at, agent_id);
  ALTER TABLE purchases ADD COLUMN job TEXT;
  CREATE INDEX purchases_job ON purchases(job);
  CREATE TABLE usage_streams (
    id            INTEGER PRIMARY KEY,
    agent_id      INTEGER NOT NULL REFERENCES agents(id),
    merchant      TEXT NOT NULL,
    merchant_key  TEXT NOT NULL,
    day           TEXT NOT NULL,
    currency      TEXT NOT NULL,
    job           TEXT NOT NULL DEFAULT '',
    micros        INTEGER NOT NULL CHECK (micros >= 0),
    payments      INTEGER NOT NULL CHECK (payments >= 0),
    purchase_id   INTEGER REFERENCES purchases(id),
    first_at      TEXT NOT NULL,
    last_at       TEXT NOT NULL,
    UNIQUE (agent_id, merchant_key, day, currency, job)
  );
  CREATE TABLE usage_calls (
    agent_id  INTEGER NOT NULL REFERENCES agents(id),
    hour      TEXT NOT NULL,
    calls     INTEGER NOT NULL,
    PRIMARY KEY (agent_id, hour)
  );
  CREATE TABLE relay_kits (
    id          INTEGER PRIMARY KEY,
    kit_id      TEXT NOT NULL UNIQUE,
    agent_id    INTEGER NOT NULL REFERENCES agents(id),
    relay_url   TEXT NOT NULL,
    created_at  TEXT NOT NULL,
    revoked_at  TEXT
  );
  CREATE TABLE relay_seen (
    drop_id  TEXT PRIMARY KEY,
    kit_id   TEXT NOT NULL,
    seen_at  TEXT NOT NULL,
    outcome  TEXT NOT NULL
  );
  `,
  // Receipts agents already hold from a payment rail (docs/CONTRACTS.md §8, src/rails.js). What an
  // agent passes is evidence, never verification, so nothing here touches verified_at. The
  // receipt itself is never stored: only its rail, the reference it names the payment by (a
  // transaction hash, a payment hash, an order id) and a SHA-256 of it as given. One row per
  // report: on the purchase it landed on (record_purchase), or on the day's stream (record_usage).
  // Purely additive.
  `
  CREATE TABLE rail_receipts (
    id              INTEGER PRIMARY KEY,
    agent_id        INTEGER NOT NULL REFERENCES agents(id),
    purchase_id     INTEGER REFERENCES purchases(id),
    stream_id       INTEGER REFERENCES usage_streams(id),
    rail            TEXT NOT NULL CHECK (rail IN ('x402', 'mpp', 'l402', 'ap2', 'acp', 'card', 'other')),
    reference       TEXT CHECK (reference IS NULL OR length(reference) BETWEEN 1 AND 200),
    receipt_sha256  TEXT CHECK (receipt_sha256 IS NULL OR length(receipt_sha256) = 64),
    created_at      TEXT NOT NULL,
    CHECK ((purchase_id IS NULL) <> (stream_id IS NULL))
  );
  CREATE INDEX rail_receipts_purchase ON rail_receipts(purchase_id);
  CREATE INDEX rail_receipts_stream ON rail_receipts(stream_id);
  CREATE INDEX rail_receipts_reference ON rail_receipts(rail, reference);
  `,
  // Two local importers that hold no keys of ours (src/importers.js): 'link', Stripe Link's own
  // record of the charges on the user's Link wallet, read through the user's link-cli (the card
  // issuer's record: independent, like a bank line); and 'lnget', the log of the Lightning client
  // an agent runs (agent-supplied evidence, like a receipt the agent found). Widening a CHECK
  // means rebuilding the table, as migration 3 did, with foreign keys off. No row changes.
  (db, done, stillNeeded) => {
    db.exec('PRAGMA foreign_keys = OFF');
    try {
      tx(db, () => {
        if (!stillNeeded()) return; // another process got here first
        db.exec(`
          CREATE TABLE sources_new (
            id               INTEGER PRIMARY KEY,
            kind             TEXT NOT NULL CHECK (kind IN ('agent', 'email', 'simplefin', 'csv', 'manual', 'phone', 'alert', 'webhook', 'link', 'lnget')),
            label            TEXT NOT NULL,
            agent_id         INTEGER REFERENCES agents(id),
            created_at       TEXT NOT NULL,
            last_attempt_at  TEXT,
            last_success_at  TEXT,
            last_error       TEXT
          );
          INSERT INTO sources_new (id, kind, label, agent_id, created_at, last_attempt_at, last_success_at, last_error)
            SELECT id, kind, label, agent_id, created_at, last_attempt_at, last_success_at, last_error FROM sources;
          DROP TABLE sources;
          ALTER TABLE sources_new RENAME TO sources;
        `);
        const broken = db.prepare('PRAGMA foreign_key_check').all();
        if (broken.length) throw new Error(`migration 10 left ${broken.length} broken references`);
        done();
      });
    } finally {
      db.exec('PRAGMA foreign_keys = ON');
    }
  },
  // Billing clients for agent costs (docs/CONTRACTS.md §9, src/clients.js, src/billing.js). Additive:
  // nothing here changes how a purchase counts. Appended after the payment-rail migrations, never
  // inserted before them: schema_version counts the migrations a ledger has already applied.
  //   clients        who the user bills, with an optional handling fee in hundredths of a percent
  //   job_clients    the rule "job X goes to client Y", keyed by lower(job); a NULL client is the
  //                  user saying "no client"
  //   client_id      on purchases and usage streams: the client a purchase (or a day of usage) is for
  //   billings       lines the user marked billed, with their invoice reference; undone_at is an undo
  //   billing_lines  which purchases a billing covered, and how much of each
  `
  CREATE TABLE clients (
    id          INTEGER PRIMARY KEY,
    name        TEXT NOT NULL UNIQUE COLLATE NOCASE CHECK (length(name) BETWEEN 1 AND 80),
    markup_bp   INTEGER NOT NULL DEFAULT 0 CHECK (markup_bp BETWEEN 0 AND 10000),
    created_at  TEXT NOT NULL,
    updated_at  TEXT NOT NULL
  );
  CREATE TABLE job_clients (
    job_key     TEXT PRIMARY KEY,
    client_id   INTEGER REFERENCES clients(id),
    set_by      TEXT NOT NULL CHECK (set_by IN ('user', 'agent')),
    updated_at  TEXT NOT NULL
  );
  ALTER TABLE purchases ADD COLUMN client_id INTEGER REFERENCES clients(id);
  CREATE INDEX purchases_client ON purchases(client_id);
  ALTER TABLE usage_streams ADD COLUMN client_id INTEGER REFERENCES clients(id);
  CREATE TABLE billings (
    id           INTEGER PRIMARY KEY,
    client_id    INTEGER NOT NULL REFERENCES clients(id),
    reference    TEXT NOT NULL CHECK (length(reference) BETWEEN 1 AND 60),
    period_from  TEXT,
    period_to    TEXT,
    markup_bp    INTEGER NOT NULL DEFAULT 0 CHECK (markup_bp BETWEEN 0 AND 10000),
    billed_at    TEXT NOT NULL,
    undone_at    TEXT
  );
  CREATE INDEX billings_client ON billings(client_id, undone_at);
  CREATE TABLE billing_lines (
    billing_id   INTEGER NOT NULL REFERENCES billings(id),
    purchase_id  INTEGER NOT NULL REFERENCES purchases(id),
    cents        INTEGER NOT NULL CHECK (cents <> 0),
    currency     TEXT NOT NULL,
    PRIMARY KEY (billing_id, purchase_id)
  );
  CREATE INDEX billing_lines_purchase ON billing_lines(purchase_id);
  `,
];

export function openDb(dataDir, { now = () => new Date(), upTo = MIGRATIONS.length } = {}) {
  let path = ':memory:';
  if (dataDir) {
    mkdirSync(dataDir, { recursive: true, mode: 0o700 });
    try { chmodSync(dataDir, 0o700); } catch { /* not ours to fix on exotic filesystems */ }
    path = join(dataDir, 'ledger.db');
  }
  const db = new DatabaseSync(path);
  if (dataDir) try { chmodSync(path, 0o600); } catch { /* best effort; the directory is 0700 */ }
  // The UI server and each agent's MCP process share this file; wait for locks, don't fail.
  db.exec('PRAGMA busy_timeout = 5000; PRAGMA foreign_keys = ON; PRAGMA journal_mode = WAL;'); // wait for locks first: switching to WAL needs one
  db.exec('CREATE TABLE IF NOT EXISTS schema_version (v INTEGER NOT NULL)');
  // The page server and each agent's MCP process can open the file at the same moment after an
  // update. Each migration is chosen under the write lock, from the version read there, so a
  // migration another process already applied is never run twice. upTo: tests build older files.
  tx(db, () => { if (!db.prepare('SELECT v FROM schema_version').get()) db.prepare('INSERT INTO schema_version (v) VALUES (0)').run(); });
  const current = () => db.prepare('SELECT v FROM schema_version').get().v;
  for (let version = current(); version < upTo; version = current()) {
    const m = MIGRATIONS[version];
    const bump = () => db.prepare('UPDATE schema_version SET v = ?').run(version + 1);
    const stillNeeded = () => current() === version;
    if (typeof m === 'function') m(db, bump, stillNeeded); // manages its own transaction
    else tx(db, () => { if (stillNeeded()) { db.exec(m); bump(); } });
  }
  if (!db.prepare("SELECT 1 FROM meta WHERE key = 'install_id'").get()) {
    const ins = db.prepare('INSERT INTO meta (key, value) VALUES (?, ?)');
    ins.run('install_id', randomUUID());
    ins.run('installed_at', now().toISOString());
  }
  return db;
}

const open = new WeakSet();

/** One write transaction. Nested calls join the outer one, so a check and its insert commit together. */
export function tx(db, fn) {
  if (open.has(db)) return fn();
  db.exec('BEGIN IMMEDIATE');
  open.add(db);
  try {
    const out = fn();
    open.delete(db);
    db.exec('COMMIT');
    return out;
  } catch (err) {
    open.delete(db);
    db.exec('ROLLBACK');
    throw err;
  }
}

export function getMeta(db, key) {
  return db.prepare('SELECT value FROM meta WHERE key = ?').get(key)?.value ?? null;
}

export function setMeta(db, key, value) {
  db.prepare('INSERT INTO meta (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value')
    .run(key, String(value));
}
