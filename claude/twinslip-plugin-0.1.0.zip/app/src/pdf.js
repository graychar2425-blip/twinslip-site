// A minimal text PDF writer (no dependencies): Letter pages, Helvetica, automatic page
// breaks, simple right-aligned columns. Enough for the tax pack's summary.

const PAGE_W = 612;
const PAGE_H = 792;
const MARGIN = 54;

// The standard fonts use WinAnsi: keep text to what renders, map the few symbols we use.
function clean(s) {
  return String(s)
    .replace(/[✓✔]/g, 'v').replace(/[–—]/g, '-').replace(/[‘’]/g, "'").replace(/[“”]/g, '"')
    .replace(/·/g, '-').replace(/…/g, '...').replace(/[^\x20-\x7e]/g, '?')
    .replace(/\\/g, '\\\\').replace(/\(/g, '\\(').replace(/\)/g, '\\)');
}
// Rough Helvetica widths (per 1000 em) for right-aligning numbers.
const width = (s, size) => [...String(s)].reduce((w, c) => w + (/[0-9$.,]/.test(c) ? 556 : /[il.,:;'|]/.test(c) ? 278 : 556), 0) * size / 1000;

/**
 * lines: [{ text, size = 10, bold = false, right = undefined (string, right-aligned), gap = 0 }]
 * Returns a Buffer holding a valid PDF 1.4 document.
 */
export function makePdf(lines, { title = 'Twinslip', footer = '' } = {}) {
  const pages = [];
  let ops = [];
  let y = PAGE_H - MARGIN;
  const flush = () => { pages.push(ops); ops = []; y = PAGE_H - MARGIN; };
  for (const l of lines) {
    const size = l.size ?? 10;
    const lead = size * 1.45 + (l.gap ?? 0);
    if (y - lead < MARGIN + 20) flush();
    y -= lead;
    const font = l.bold ? 'F2' : 'F1';
    ops.push(`BT /${font} ${size} Tf ${MARGIN} ${y.toFixed(1)} Td (${clean(l.text ?? '')}) Tj ET`);
    if (l.right !== undefined) {
      const x = PAGE_W - MARGIN - width(l.right, size);
      ops.push(`BT /${font} ${size} Tf ${x.toFixed(1)} ${y.toFixed(1)} Td (${clean(l.right)}) Tj ET`);
    }
  }
  flush();

  const objects = [];
  const add = (body) => { objects.push(body); return objects.length; };
  const catalog = add(null);
  const pagesObj = add(null);
  const f1 = add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>');
  const f2 = add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>');
  const kids = pages.map((p, i) => {
    const foot = `BT /F1 8 Tf ${MARGIN} 30 Td (${clean(`${footer}${footer ? '   -   ' : ''}Page ${i + 1} of ${pages.length}`)}) Tj ET`;
    const stream = [...p, foot].join('\n');
    const content = add(`<< /Length ${Buffer.byteLength(stream, 'latin1')} >>\nstream\n${stream}\nendstream`);
    return add(`<< /Type /Page /Parent ${pagesObj} 0 R /MediaBox [0 0 ${PAGE_W} ${PAGE_H}] /Resources << /Font << /F1 ${f1} 0 R /F2 ${f2} 0 R >> >> /Contents ${content} 0 R >>`);
  });
  objects[catalog - 1] = `<< /Type /Catalog /Pages ${pagesObj} 0 R >>`;
  objects[pagesObj - 1] = `<< /Type /Pages /Kids [${kids.map((k) => `${k} 0 R`).join(' ')}] /Count ${kids.length} >>`;
  const info = add(`<< /Title (${clean(title)}) /Producer (Twinslip) >>`);

  let out = '%PDF-1.4\n%\xe2\xe3\xcf\xd3\n';
  const offsets = [];
  objects.forEach((body, i) => {
    offsets.push(Buffer.byteLength(out, 'latin1'));
    out += `${i + 1} 0 obj\n${body}\nendobj\n`;
  });
  const xref = Buffer.byteLength(out, 'latin1');
  out += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n${offsets.map((o) => `${String(o).padStart(10, '0')} 00000 n \n`).join('')}`;
  out += `trailer\n<< /Size ${objects.length + 1} /Root ${catalog} 0 R /Info ${info} 0 R >>\nstartxref\n${xref}\n%%EOF\n`;
  return Buffer.from(out, 'latin1');
}
