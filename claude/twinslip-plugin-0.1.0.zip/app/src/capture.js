// The capture ladder's one door (docs/CONTRACTS.md §1–2). The localhost webhook and the
// synced phone file both end here. Every event becomes exactly one of: merge, inbox, mine,
// agent, duplicate. Nothing is dropped; an event we can't read is refused with a reason.

import { createHash, randomBytes } from 'node:crypto';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { LedgerError, checkReportedAmount, checkReportedDate, safeId } from './ledger.js';
import { parseAmountToCents } from './money.js';
import { isIsoDate, toLocalDate } from './dates.js';
import { redact } from './redact.js';

export const CAPTURE_SOURCES = {
  phone: 'iPhone (Shortcuts)',
  alert: 'Bank alert emails',
  webhook: 'This computer (webhook)',
};
const MAX_EVENTS = 500;
const MIN_KEY_LENGTH = 32; // a shorter (or empty) key file is treated as missing and replaced

/**
 * The webhook's key: stable across restarts (Shortcuts and scripts hold it), unlike the
 * page's per-launch token. Kept in the data folder, readable only by this user.
 */
let memoryKey = null;
export function captureKey(dataDir) {
  if (!dataDir) return (memoryKey ??= randomBytes(32).toString('hex'));
  const path = join(dataDir, 'capture-key');
  const read = () => (existsSync(path) ? readFileSync(path, 'utf8').trim() : '');
  const existing = read();
  if (existing.length >= MIN_KEY_LENGTH) return existing;
  const key = randomBytes(32).toString('hex');
  try {
    if (existing || existsSync(path)) writeFileSync(path, `${key}\n`, { mode: 0o600 }); // too short: replace it
    else writeFileSync(path, `${key}\n`, { mode: 0o600, flag: 'wx' });
    return key;
  } catch {
    const now = read(); // another process created it first
    if (now.length >= MIN_KEY_LENGTH) return now;
    throw new LedgerError("Couldn't create the capture key in the data folder.", 500);
  }
}

function readEvent(e, i, today) {
  const where = `event ${i + 1}`;
  if (!e || typeof e !== 'object' || Array.isArray(e)) throw new LedgerError(`${where}: must be a JSON object.`);
  if (e.v !== 1) throw new LedgerError(`${where}: v must be 1.`);
  if (!(e.source in CAPTURE_SOURCES)) throw new LedgerError(`${where}: source must be one of ${Object.keys(CAPTURE_SOURCES).join(', ')}.`);
  const merchant = redact(String(e.merchant ?? '')).trim().slice(0, 80);
  if (!merchant) throw new LedgerError(`${where}: merchant is required.`);
  const cents = parseAmountToCents(typeof e.amount === 'number' ? e.amount : String(e.amount ?? ''));
  if (cents === null || cents === 0) throw new LedgerError(`${where}: amount must be a non-zero number like "20.00".`);
  try { checkReportedAmount(cents); } catch (err) { throw new LedgerError(`${where}: ${err.message}`); }
  const currency = String(e.currency ?? 'USD').toUpperCase();
  if (!/^[A-Z]{3}$/.test(currency)) throw new LedgerError(`${where}: currency must be a 3-letter code like USD.`);
  const date = e.date ?? today;
  if (!isIsoDate(date)) throw new LedgerError(`${where}: date must be a real date like 2026-10-05.`);
  try { checkReportedDate(date, today); } catch (err) { throw new LedgerError(`${where}: ${err.message}`); }
  // A ref that looks like a secret is kept only as a hash (see safeId).
  const ref = e.ref == null ? null : safeId(String(e.ref).trim()) || null; // the whole original, never a cut-off prefix
  const kind = redact(String(e.kind ?? '')).slice(0, 40);
  // Without a ref, the event's own content is its identity, so a re-sent line is a duplicate.
  const identity = ref ? `ref:${ref}` : `h:${createHash('sha256').update(JSON.stringify([e.source, merchant, cents, currency, date, kind])).digest('hex').slice(0, 32)}`;
  return { source: e.source, merchant, cents, currency, date, ref, kind, identity, agent: e.agent == null ? null : String(e.agent).trim() };
}

const STATUS = { candidate: 'inbox', background: 'mine', not_agent: 'mine', confirmed: 'agent' };

/**
 * Validate every event first (all or nothing), then record each. Returns [{ status, id }].
 * `reportedBy`: the agent whose MCP connection sent these (bank alerts it found), so its
 * hourly limit applies. The capture key's webhook and the phone file have no reporter.
 */
export function captureEvents(ledger, events, { reportedBy = null } = {}) {
  if (!Array.isArray(events) || events.length === 0) throw new LedgerError('Send one event, or { "events": [...] }.');
  if (events.length > MAX_EVENTS) throw new LedgerError(`At most ${MAX_EVENTS} events per request.`);
  const today = toLocalDate(ledger.now());
  const parsed = events.map((e, i) => readEvent(e, i, today));
  for (const [i, e] of parsed.entries()) {
    if (e.agent && e.source !== 'webhook') throw new LedgerError(`event ${i + 1}: only webhook events may name an agent.`);
    if (e.agent && !ledger.listAgents().some((a) => a.name.toLowerCase() === e.agent.toLowerCase())) {
      throw new LedgerError(`event ${i + 1}: no agent called ${redact(e.agent).slice(0, 60)}. Add it in Settings first.`);
    }
  }
  return parsed.map((e) => {
    if (e.agent) {
      // An agent telling us about its own purchase: same path as the MCP tool.
      const agent = ledger.listAgents().find((a) => a.name.toLowerCase() === e.agent.toLowerCase());
      const r = ledger.recordAgentPurchase(agent.id, {
        merchant: e.merchant, amountCents: e.cents, currency: e.currency, occurredOn: e.date,
        paymentMethod: 'other', reference: e.ref ?? e.identity, note: e.kind,
      });
      const status = r.duplicate ? 'duplicate' : r.matchedExisting ? 'merge' : 'agent';
      ledger.track('captured', { source: e.source, status });
      return { status, id: r.purchase.id };
    }
    const sourceId = ledger.ensureSource(e.source, CAPTURE_SOURCES[e.source]);
    const r = ledger.ingest(sourceId, [{
      externalId: e.identity, occurredOn: e.date, amountCents: e.cents, currency: e.currency,
      merchant: e.merchant, description: e.kind,
    }], { reportedBy });
    const nowIso = ledger.now().toISOString();
    ledger.db.prepare('UPDATE sources SET last_attempt_at = ?, last_success_at = ?, last_error = NULL WHERE id = ?').run(nowIso, nowIso, sourceId);
    const id = r.ids[0] ?? ledger.db.prepare('SELECT COALESCE(merged_into, id) AS id FROM purchases WHERE source_id = ? AND external_id = ?').get(sourceId, e.identity)?.id;
    const status = r.duplicates ? 'duplicate' : r.merged ? 'merge' : STATUS[ledger.getPurchase(id).status] ?? 'inbox';
    ledger.track('captured', { source: e.source, status });
    return { status, id };
  });
}
