// Mandates: what the user says each agent may buy. Agent payment rails are moving to signed,
// scoped authority (AP2's mandates, card-network agent tokens), so "was this agent allowed to
// buy that?" becomes the question after "what did it cost?". This answers it on the user's own
// machine.
//
// Awareness, not enforcement, exactly like budgets: blocking a payment is the wallet's job.
//   - An agent can ask before buying (check_mandate).
//   - A purchase outside the mandate still counts in full. It is flagged for the user, never
//     hidden, refused or softened.
//   - Only the user writes a mandate. Agents read their own; they can't change it.
//
// A mandate has up to four parts, each optional:
//   merchants           who the agent may pay ([] = anyone)
//   max_purchase_cents  the most for any one purchase, in `currency`
//   methods             how it may pay ([] = any method)
//   until               the last day the mandate covers; after it, nothing is in mandate

import { LedgerError, PAYMENT_METHODS, sameMerchant } from './ledger.js';
import { merchantKey } from './merchants.js';
import { formatCents } from './money.js';
import { isIsoDate, toLocalDate } from './dates.js';
import { redact } from './redact.js';
import { tx } from './db.js';

export const MANDATE_MAX_MERCHANTS = 50;
const MAX_CEILING_CENTS = 10_000_000;

function parseRow(r) {
  if (!r) return null;
  return {
    agent_id: r.agent_id,
    merchants: JSON.parse(r.merchants),
    max_purchase_cents: r.max_purchase_cents,
    currency: r.currency,
    methods: JSON.parse(r.methods),
    until: r.until,
    note: r.note,
    updated_at: r.updated_at,
  };
}

export function getMandate(ledger, agentId) {
  return parseRow(ledger.db.prepare('SELECT * FROM mandates WHERE agent_id = ?').get(Number(agentId)));
}

export function listMandates(ledger) {
  return ledger.db.prepare('SELECT m.*, a.name AS agent FROM mandates m JOIN agents a ON a.id = m.agent_id ORDER BY a.id').all()
    .map((r) => ({ ...parseRow(r), agent: r.agent }));
}

/** The user writes (or rewrites) an agent's mandate. Every part is checked; nothing is guessed. */
export function setMandate(ledger, agentId, { merchants = [], maxPurchaseCents = null, currency = 'USD', methods = [], until = null, note = '' } = {}) {
  const agent = ledger.requireAgent(agentId);
  if (!Array.isArray(merchants)) throw new LedgerError('merchants must be a list of merchant names.');
  const names = [];
  for (const raw of merchants) {
    const name = redact(String(raw ?? '')).trim().slice(0, 80);
    if (!name) continue;
    if (!names.some((n) => sameMerchant(merchantKey(n), merchantKey(name)))) names.push(name);
  }
  if (names.length > MANDATE_MAX_MERCHANTS) throw new LedgerError(`A mandate can list at most ${MANDATE_MAX_MERCHANTS} merchants.`);
  if (maxPurchaseCents !== null && (!Number.isSafeInteger(maxPurchaseCents) || maxPurchaseCents <= 0 || maxPurchaseCents > MAX_CEILING_CENTS)) {
    throw new LedgerError('The most for one purchase must be an amount like "50.00", or empty for no limit.');
  }
  if (!/^[A-Z]{3}$/.test(currency)) throw new LedgerError('currency must be a 3-letter code like USD.');
  if (!Array.isArray(methods) || methods.some((m) => !PAYMENT_METHODS.includes(m))) {
    throw new LedgerError(`methods must be a list drawn from: ${PAYMENT_METHODS.join(', ')}.`);
  }
  if (until !== null && !isIsoDate(until)) throw new LedgerError('until must be a real date like 2026-12-31, or empty.');
  const clean = { merchants: names, max: maxPurchaseCents, currency, methods: [...new Set(methods)], until, note: redact(String(note ?? '')).trim().slice(0, 200) };
  ledger.db.prepare(`
    INSERT INTO mandates (agent_id, merchants, max_purchase_cents, currency, methods, until, note, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(agent_id) DO UPDATE SET merchants = excluded.merchants, max_purchase_cents = excluded.max_purchase_cents,
      currency = excluded.currency, methods = excluded.methods, until = excluded.until, note = excluded.note, updated_at = excluded.updated_at`)
    .run(agent.id, JSON.stringify(clean.merchants), clean.max, clean.currency, JSON.stringify(clean.methods), clean.until, clean.note, ledger.now().toISOString());
  ledger.track('mandate_set');
  return getMandate(ledger, agent.id);
}

export function clearMandate(ledger, agentId) {
  const agent = ledger.requireAgent(agentId);
  ledger.db.prepare('DELETE FROM mandates WHERE agent_id = ?').run(agent.id);
  ledger.track('mandate_cleared');
  return { agent_id: agent.id, cleared: true };
}

/**
 * Is a purchase inside the agent's mandate? Refunds always are. A day's micropayment stream
 * (`stream: true`) is checked for merchant, method and date, never against the per-purchase
 * ceiling: it is many payments, not one.
 * Returns { mandate, within, reasons: [{ code, text }] }; no mandate means within.
 */
export function checkMandate(ledger, agentId, { merchant, amountCents, currency = 'USD', paymentMethod = null, occurredOn = null, stream = false }) {
  const agent = ledger.requireAgent(agentId);
  const m = getMandate(ledger, agent.id);
  if (!m || amountCents < 0) return { mandate: m, within: true, reasons: [] };
  const reasons = [];
  const date = occurredOn ?? toLocalDate(ledger.now());
  if (m.until && date > m.until) {
    reasons.push({ code: 'expired', text: `${agent.name}'s mandate ended on ${m.until}.` });
  }
  if (m.merchants.length && !m.merchants.some((n) => sameMerchant(merchantKey(n), merchantKey(merchant)))) {
    reasons.push({ code: 'merchant', text: `${merchant} isn't one of the merchants in ${agent.name}'s mandate.` });
  }
  if (!stream && m.max_purchase_cents !== null) {
    if (currency !== m.currency) {
      reasons.push({ code: 'currency', text: `${agent.name}'s per-purchase limit is in ${m.currency}; this was in ${currency}, so it can't be checked against it.` });
    } else if (amountCents > m.max_purchase_cents) {
      reasons.push({ code: 'amount', text: `${formatCents(amountCents, currency)} is over ${agent.name}'s ${formatCents(m.max_purchase_cents, m.currency)} limit for one purchase.` });
    }
  }
  if (paymentMethod && m.methods.length && !m.methods.includes(paymentMethod)) {
    reasons.push({ code: 'method', text: `Paying by ${paymentMethod.replace('_', ' ')} isn't in ${agent.name}'s mandate.` });
  }
  return { mandate: m, within: reasons.length === 0, reasons };
}

/**
 * After an agent's own report lands as its spending: flag it if it's outside the mandate.
 * Each purchase is flagged at most once. Returns the reasons, or [] when it's within.
 */
export function flagIfOutside(ledger, purchase, { stream = false } = {}) {
  if (!purchase || purchase.status !== 'confirmed' || purchase.agent_id == null || purchase.amount_cents <= 0) return [];
  const r = checkMandate(ledger, purchase.agent_id, {
    merchant: purchase.merchant, amountCents: purchase.amount_cents, currency: purchase.currency,
    paymentMethod: purchase.payment_method, occurredOn: purchase.occurred_on, stream,
  });
  if (r.within) return [];
  const ins = ledger.db.prepare(`INSERT INTO mandate_flags (purchase_id, agent_id, reasons, created_at)
    VALUES (?, ?, ?, ?) ON CONFLICT(purchase_id) DO NOTHING`)
    .run(purchase.id, purchase.agent_id, JSON.stringify(r.reasons), ledger.now().toISOString());
  if (ins.changes) ledger.track('mandate_flagged', { reasons: r.reasons.length });
  return r.reasons;
}

/** Purchases outside a mandate that the user hasn't looked at yet, newest first. */
export function openFlags(ledger) {
  return ledger.db.prepare(`
    SELECT f.id, f.purchase_id, f.agent_id, a.name AS agent, f.reasons, f.created_at,
           p.merchant, p.amount_cents, p.currency, p.occurred_on, p.payment_method
    FROM mandate_flags f JOIN agents a ON a.id = f.agent_id JOIN purchases p ON p.id = f.purchase_id
    WHERE f.resolved_at IS NULL ORDER BY f.id DESC`).all()
    .map((r) => ({ ...r, reasons: JSON.parse(r.reasons) }));
}

/**
 * The user answers a flag. `noted`: seen, nothing changes. `allowed`: also widen the mandate so
 * the same thing is in mandate next time (adds the merchant; lifts the ceiling to this amount;
 * adds the payment method). An expired mandate is never extended by a tap: the user edits it.
 */
export function resolveFlag(ledger, flagId, how) {
  if (!['noted', 'allowed'].includes(how)) throw new LedgerError('Answer with "noted" or "allowed".');
  return tx(ledger.db, () => {
    const f = ledger.db.prepare(`SELECT f.*, p.merchant, p.amount_cents, p.currency, p.payment_method
      FROM mandate_flags f JOIN purchases p ON p.id = f.purchase_id WHERE f.id = ?`).get(Number(flagId));
    if (!f) throw new LedgerError('No such flag.', 404);
    if (f.resolved_at) return { id: f.id, resolution: f.resolution, already: true };
    if (how === 'allowed') {
      const m = getMandate(ledger, f.agent_id);
      if (m) {
        const codes = JSON.parse(f.reasons).map((x) => x.code);
        setMandate(ledger, f.agent_id, {
          merchants: codes.includes('merchant') ? [...m.merchants, f.merchant] : m.merchants,
          maxPurchaseCents: codes.includes('amount') && f.currency === m.currency ? Math.max(m.max_purchase_cents, f.amount_cents) : m.max_purchase_cents,
          currency: m.currency,
          methods: codes.includes('method') && f.payment_method ? [...m.methods, f.payment_method] : m.methods,
          until: m.until,
          note: m.note,
        });
      }
    }
    ledger.db.prepare('UPDATE mandate_flags SET resolved_at = ?, resolution = ? WHERE id = ?').run(ledger.now().toISOString(), how, f.id);
    ledger.track('mandate_flag_resolved', { how });
    return { id: f.id, resolution: how, already: false };
  });
}

/** One plain sentence describing a mandate, for the agent and the page. */
export function describeMandate(m, agentName) {
  if (!m) return `${agentName} has no mandate: the user hasn't said what it may buy.`;
  const parts = [];
  parts.push(m.merchants.length ? `may pay ${m.merchants.join(', ')}` : 'may pay any merchant');
  if (m.max_purchase_cents !== null) parts.push(`up to ${formatCents(m.max_purchase_cents, m.currency)} for one purchase`);
  if (m.methods.length) parts.push(`by ${m.methods.map((x) => x.replace('_', ' ')).join(' or ')}`);
  if (m.until) parts.push(`until ${m.until}`);
  return `${agentName} ${parts.join(', ')}.${m.note ? ` Note from the user: ${m.note}` : ''}`;
}
