// Codex keeps its MCP servers in ~/.codex/config.toml, a file the ChatGPT desktop app and the
// Codex IDE extension share. With no dependencies (CLAUDE.md), this is a small, strict TOML 1.0
// reader and one edit: put our [mcp_servers.<name>] table in, or replace it where it is. Every
// other byte of the file stays as it was. A file it can't read, or a layout it won't edit
// safely, is refused with a reason: setup never guesses with another app's settings.

export class TomlError extends Error {}

/** A number, boolean or date: never changed, only compared, so it is kept as written. */
export class Scalar {
  constructor(type, raw) {
    this.type = type;
    this.raw = raw;
  }
}

const BARE_KEY = /^[A-Za-z0-9_-]+$/;
const SCALARS = [
  ['datetime', /\d{4}-\d{2}-\d{2}(?:[Tt ]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:[Zz]|[+-]\d{2}:\d{2})?)?/y],
  ['time', /\d{2}:\d{2}:\d{2}(?:\.\d+)?/y],
  ['float', /[+-]?(?:inf|nan)|[+-]?(?:0|[1-9](?:_?\d)*)(?:\.\d(?:_?\d)*(?:[eE][+-]?\d(?:_?\d)*)?|[eE][+-]?\d(?:_?\d)*)/y],
  ['integer', /0x[0-9A-Fa-f](?:_?[0-9A-Fa-f])*|0o[0-7](?:_?[0-7])*|0b[01](?:_?[01])*|[+-]?(?:0|[1-9](?:_?\d)*)/y],
  ['boolean', /true|false/y],
];
// What may follow a number, boolean or date.
const VALUE_ENDS = new Set([undefined, ' ', '\t', '\n', '\r', '#', ',', ']', '}']);
const ESCAPES = { b: '\b', t: '\t', n: '\n', f: '\f', r: '\r', '"': '"', '\\': '\\' };

const put = (o, k, v) => Object.defineProperty(o, k, { value: v, enumerable: true, writable: true, configurable: true });
const own = (o, k) => (Object.hasOwn(o, k) ? o[k] : undefined);

/**
 * Read a TOML document. Returns { data, statements, comments, bom, isTable, kindOf }:
 * - data: tables are plain objects, arrays are arrays, strings are strings, everything else a Scalar;
 * - statements: every table header and key/value line, with where it starts and ends in the text
 *   (`end` is past its line break);
 * - comments: where each comment is.
 * Throws TomlError on anything TOML 1.0 doesn't allow (a key or table defined twice included).
 */
export function parseToml(text) {
  const n = text.length;
  const bom = text.charCodeAt(0) === 0xfeff ? 1 : 0;
  let i = bom;
  // How each table came to be: the root, a [header], a parent a header implied, dotted keys,
  // or an inline { } (which can never be added to). Arrays made by [[headers]] are 'tables'.
  const kinds = new WeakMap();
  const isTable = (v) => v !== null && typeof v === 'object' && !Array.isArray(v) && kinds.has(v);
  const newTable = (kind) => {
    const t = {};
    kinds.set(t, kind);
    return t;
  };
  const root = newTable('root');
  const statements = [];
  const comments = [];

  function fail(what) {
    throw new TomlError(`${what} (line ${text.slice(0, i).split('\n').length})`);
  }
  const spaces = () => {
    while (text[i] === ' ' || text[i] === '\t') i++;
  };
  const atLineBreak = () => text[i] === '\n' || (text[i] === '\r' && text[i + 1] === '\n');
  function comment() {
    if (text[i] !== '#') return;
    const start = i;
    while (i < n && !atLineBreak()) {
      const c = text.charCodeAt(i);
      if ((c < 0x20 && c !== 0x09) || c === 0x7f) fail('a control character in a comment');
      i++;
    }
    comments.push({ start, end: i });
  }
  function lineBreak() {
    if (text[i] === '\n') i++;
    else if (text[i] === '\r' && text[i + 1] === '\n') i += 2;
    else if (i < n) fail('more on a line than one statement');
  }
  // Inside an array: spaces, line breaks and comments.
  function gap() {
    for (;;) {
      spaces();
      if (text[i] === '#') comment();
      else if (atLineBreak()) lineBreak();
      else return;
    }
  }
  const plainChar = (c) => c === 0x09 || !(c < 0x20 || c === 0x7f);

  function unicode(len) {
    const hex = text.slice(i, i + len);
    if (hex.length !== len || !/^[0-9A-Fa-f]+$/.test(hex)) fail('a bad \\u escape');
    const cp = parseInt(hex, 16);
    if (cp > 0x10ffff || (cp >= 0xd800 && cp <= 0xdfff)) fail('a bad \\u escape');
    i += len;
    return String.fromCodePoint(cp);
  }
  function escape() {
    i++; // the backslash
    const e = text[i];
    if (e !== undefined && Object.hasOwn(ESCAPES, e)) {
      i++;
      return ESCAPES[e];
    }
    if (e === 'u' || e === 'U') {
      i++;
      return unicode(e === 'u' ? 4 : 8);
    }
    return fail('an escape TOML 1.0 does not have');
  }
  function basicString() {
    i++;
    let out = '';
    for (;;) {
      if (i >= n || atLineBreak() || text[i] === '\r') fail('a string that does not end on its line');
      const ch = text[i];
      if (ch === '"') {
        i++;
        return out;
      }
      if (ch === '\\') {
        out += escape();
        continue;
      }
      if (!plainChar(text.charCodeAt(i))) fail('a control character in a string');
      out += ch;
      i++;
    }
  }
  function literalString() {
    i++;
    const start = i;
    for (;;) {
      if (i >= n || atLineBreak() || text[i] === '\r') fail('a string that does not end on its line');
      if (text[i] === "'") {
        i++;
        return text.slice(start, i - 1);
      }
      if (!plainChar(text.charCodeAt(i))) fail('a control character in a string');
      i++;
    }
  }
  // """ or ''': a line break right after the opening quotes is dropped, and up to two quotes
  // may sit just before the closing ones.
  function multiline(quote) {
    i += 3;
    if (atLineBreak()) lineBreak();
    let out = '';
    for (;;) {
      if (i >= n) fail('a multi-line string that never ends');
      if (text.startsWith(quote.repeat(3), i)) {
        let run = 3;
        while (text[i + run] === quote) run++;
        if (run > 5) fail('too many quotes at the end of a string');
        out += quote.repeat(run - 3);
        i += run;
        return out;
      }
      const ch = text[i];
      if (quote === '"' && ch === '\\') {
        // A backslash at the end of a line joins it to the next non-blank text.
        let j = i + 1;
        while (text[j] === ' ' || text[j] === '\t') j++;
        if (text[j] === '\n' || (text[j] === '\r' && text[j + 1] === '\n')) {
          i = j;
          while (text[i] === ' ' || text[i] === '\t' || atLineBreak()) i += text[i] === '\r' ? 2 : 1;
          continue;
        }
        out += escape();
        continue;
      }
      if (ch === '\r') {
        if (text[i + 1] !== '\n') fail('a carriage return on its own');
        out += '\r\n';
        i += 2;
        continue;
      }
      if (ch !== '\n' && !plainChar(text.charCodeAt(i))) fail('a control character in a string');
      out += ch;
      i++;
    }
  }
  function simpleKey() {
    if (text[i] === '"') {
      if (text.startsWith('"""', i)) fail('a multi-line string used as a key');
      return basicString();
    }
    if (text[i] === "'") {
      if (text.startsWith("'''", i)) fail('a multi-line string used as a key');
      return literalString();
    }
    const start = i;
    while (i < n && /[A-Za-z0-9_-]/.test(text[i])) i++;
    if (i === start) fail('a key was expected');
    return text.slice(start, i);
  }
  function key() {
    const parts = [simpleKey()];
    for (;;) {
      const save = i;
      spaces();
      if (text[i] !== '.') {
        i = save;
        return parts;
      }
      i++;
      spaces();
      parts.push(simpleKey());
    }
  }
  function scalar() {
    for (const [type, re] of SCALARS) {
      re.lastIndex = i;
      const m = re.exec(text);
      if (m && VALUE_ENDS.has(text[i + m[0].length])) {
        i += m[0].length;
        return new Scalar(type, m[0]);
      }
    }
    return fail("a value setup can't read");
  }
  function value(depth) {
    if (depth > 100) fail('values nested too deep');
    const c = text[i];
    if (c === '"') return text.startsWith('"""', i) ? multiline('"') : basicString();
    if (c === "'") return text.startsWith("'''", i) ? multiline("'") : literalString();
    if (c === '[') return array(depth);
    if (c === '{') return inlineTable(depth);
    return scalar();
  }
  function array(depth) {
    i++;
    const items = [];
    for (;;) {
      gap();
      if (text[i] === ']') {
        i++;
        return items;
      }
      items.push(value(depth + 1));
      gap();
      if (text[i] === ',') i++;
      else if (text[i] === ']') {
        i++;
        return items;
      } else fail("a ',' or ']' was expected in an array");
    }
  }
  const sealInline = (t) => {
    kinds.set(t, 'inline');
    for (const v of Object.values(t)) if (isTable(v)) sealInline(v);
    return t;
  };
  // TOML 1.0: one line, no trailing comma.
  function inlineTable(depth) {
    i++;
    const t = newTable('dotted');
    spaces();
    if (text[i] === '}') {
      i++;
      return sealInline(t);
    }
    for (;;) {
      spaces();
      const k = key();
      spaces();
      if (text[i] !== '=') fail("an '=' was expected");
      i++;
      spaces();
      assign(t, k, value(depth + 1));
      spaces();
      if (text[i] === ',') i++;
      else if (text[i] === '}') {
        i++;
        return sealInline(t);
      } else fail("a ',' or '}' was expected in an inline table");
    }
  }

  // a.b.c = v: a and b are tables made by dotted keys, here or earlier in the same table.
  function assign(table, parts, v) {
    let node = table;
    for (const part of parts.slice(0, -1)) {
      let next = own(node, part);
      if (next === undefined) put(node, part, (next = newTable('dotted')));
      else if (!isTable(next) || kinds.get(next) !== 'dotted') fail(`"${part}" can't take more keys here`);
      node = next;
    }
    const last = parts.at(-1);
    if (own(node, last) !== undefined) fail(`"${last}" is defined twice`);
    put(node, last, v);
  }
  // The table a [a.b] or [[a.b]] header leads into, made as needed.
  function walk(path) {
    let node = root;
    for (const part of path.slice(0, -1)) {
      let next = own(node, part);
      if (next === undefined) put(node, part, (next = newTable('implicit')));
      else if (Array.isArray(next) && kinds.get(next) === 'tables') next = next.at(-1);
      else if (!isTable(next) || kinds.get(next) === 'inline') fail(`[${path.join('.')}] can't be added to "${part}"`);
      node = next;
    }
    return node;
  }
  function tableHeader(path) {
    const parent = walk(path);
    const last = path.at(-1);
    const existing = own(parent, last);
    if (existing === undefined) {
      const t = newTable('header');
      put(parent, last, t);
      return t;
    }
    if (isTable(existing) && kinds.get(existing) === 'implicit') {
      kinds.set(existing, 'header');
      return existing;
    }
    return fail(`[${path.join('.')}] is defined twice`);
  }
  function arrayHeader(path) {
    const parent = walk(path);
    const last = path.at(-1);
    let list = own(parent, last);
    if (list === undefined) {
      list = [];
      kinds.set(list, 'tables');
      put(parent, last, list);
    } else if (!Array.isArray(list) || kinds.get(list) !== 'tables') fail(`[[${path.join('.')}]] clashes with "${last}"`);
    const t = newTable('header');
    list.push(t);
    return t;
  }

  let current = root;
  let currentPath = [];
  for (;;) {
    spaces();
    if (i >= n) break;
    if (text[i] === '#') {
      comment();
      lineBreak();
      continue;
    }
    if (atLineBreak()) {
      lineBreak();
      continue;
    }
    const start = Math.max(text.lastIndexOf('\n', i - 1) + 1, bom);
    if (text[i] === '[') {
      const many = text[i + 1] === '[';
      i += many ? 2 : 1;
      spaces();
      const path = key();
      spaces();
      if (many ? !text.startsWith(']]', i) : text[i] !== ']') fail('a table header that does not close');
      i += many ? 2 : 1;
      spaces();
      comment();
      lineBreak();
      current = many ? arrayHeader(path) : tableHeader(path);
      currentPath = path;
      statements.push({ type: many ? 'tables' : 'table', path, start, end: i });
      continue;
    }
    const parts = key();
    spaces();
    if (text[i] !== '=') fail("an '=' was expected");
    i++;
    spaces();
    if (i >= n || atLineBreak() || text[i] === '#') fail('a key with no value');
    const v = value(0);
    spaces();
    comment();
    lineBreak();
    assign(current, parts, v);
    statements.push({ type: 'key', table: currentPath, key: parts, start, end: i });
  }
  return { data: root, statements, comments, bom, isTable, kindOf: (v) => kinds.get(v) };
}

/** A TOML value as plain JavaScript: booleans and numbers become themselves, dates stay text. */
export function plain(v) {
  if (v instanceof Scalar) {
    if (v.type === 'boolean') return v.raw === 'true';
    if (v.type === 'integer' || v.type === 'float') {
      const x = Number(v.raw.replace(/_/g, ''));
      return Number.isFinite(x) ? x : v.raw;
    }
    return v.raw;
  }
  if (Array.isArray(v)) return v.map(plain);
  if (v !== null && typeof v === 'object') {
    const o = {};
    for (const [k, x] of Object.entries(v)) put(o, k, plain(x));
    return o;
  }
  return v;
}

/** One text per document content, whatever its key order: for comparing before and after. */
function canonical(v) {
  const norm = (x) => {
    if (x instanceof Scalar) return ['\u0000', x.type, x.raw];
    if (Array.isArray(x)) return x.map(norm);
    if (x !== null && typeof x === 'object') {
      const o = {};
      for (const k of Object.keys(x).sort()) put(o, k, norm(x[k]));
      return o;
    }
    return x;
  };
  return JSON.stringify(norm(v));
}

const copy = (v) => {
  if (Array.isArray(v)) return v.map(copy);
  if (v !== null && typeof v === 'object' && !(v instanceof Scalar)) {
    const o = {};
    for (const [k, x] of Object.entries(v)) put(o, k, copy(x));
    return o;
  }
  return v;
};

/** A TOML basic string. */
export function tomlString(s) {
  const named = { '\\': '\\\\', '"': '\\"', '\b': '\\b', '\t': '\\t', '\n': '\\n', '\f': '\\f', '\r': '\\r' };
  return `"${s.replace(/[\\"\u0000-\u001f\u007f]/g, (c) => named[c] ?? `\\u${c.charCodeAt(0).toString(16).padStart(4, '0')}`)}"`;
}

function tomlValue(v) {
  if (typeof v === 'string') return tomlString(v);
  if (typeof v === 'boolean') return String(v);
  if (Number.isSafeInteger(v)) return String(v);
  if (Array.isArray(v)) return `[${v.map(tomlValue).join(', ')}]`;
  throw new TomlError(`can't write ${typeof v} values`);
}

/** The text of one table: a header and one line per key. */
export function tableText(path, entry, eol = '\n') {
  const keyText = (k) => (BARE_KEY.test(k) ? k : tomlString(k));
  const lines = [`[${path.map(keyText).join('.')}]`];
  for (const [k, v] of Object.entries(entry)) lines.push(`${keyText(k)} = ${tomlValue(v)}`);
  return `${lines.join(eol)}${eol}`;
}

/**
 * `text` with [mcp_servers.<name>] set to `entry` (command, args and any flags to keep), and the
 * tables under the old names in `remove` taken out. The table goes where it, or an old one, was;
 * otherwise at the end. Its own sub-tables ([mcp_servers.<name>.env]) go with it. Everything else
 * stays byte for byte. Throws TomlError when the file can't be read, when our server is written
 * some other way (dotted keys, an inline table), when a comment sits inside a table it would
 * replace, or when the result wouldn't be exactly the old document plus our change.
 */
export function putServerTable(text, { name, entry, remove = [] }) {
  const doc = parseToml(text);
  const servers = own(doc.data, 'mcp_servers');
  if (servers !== undefined && (!doc.isTable(servers) || doc.kindOf(servers) === 'inline')) {
    throw new TomlError('its mcp_servers is not written as [mcp_servers.<name>] tables');
  }
  const names = [name, ...remove];
  const ours = (path) => path.length >= 2 && path[0] === 'mcp_servers' && names.includes(path[1]);
  for (const s of doc.statements) {
    if (s.type === 'key' && ours([...s.table, ...s.key]) && !ours(s.table)) {
      throw new TomlError(`its ${[...s.table, ...s.key].slice(0, 2).join('.')} entry is written with dotted keys or an inline table`);
    }
    if (s.type === 'tables' && ours(s.path)) throw new TomlError(`its ${s.path.slice(0, 2).join('.')} entry is an array of tables`);
  }
  // Each header of ours, through its last key. Comments and blank lines after that stay put:
  // they usually belong to the table that follows.
  const headers = doc.statements.filter((s) => s.type !== 'key');
  const cuts = [];
  headers.forEach((h, k) => {
    if (!ours(h.path)) return;
    const next = headers[k + 1]?.start ?? text.length;
    const body = doc.statements.filter((s) => s.type === 'key' && s.start > h.start && s.start < next);
    cuts.push({ start: h.start, end: body.length ? body.at(-1).end : h.end });
  });
  if (cuts.some((c) => doc.comments.some((m) => m.start < c.end && m.end > c.start))) {
    throw new TomlError("a comment sits inside the table setup would replace");
  }
  // A table taken out entirely takes the blank lines after it too, so no gap is left behind.
  for (const c of cuts.slice(1)) c.end += /^(?:[ \t]*\r?\n)*/.exec(text.slice(c.end))[0].length;
  const eol = text.includes('\r\n') ? '\r\n' : '\n';
  const table = tableText(['mcp_servers', name], entry, eol);
  let out = text;
  if (cuts.length) {
    for (const c of [...cuts].reverse()) out = out.slice(0, c.start) + (c === cuts[0] ? table : '') + out.slice(c.end);
  } else {
    const body = out.slice(doc.bom);
    if (body.length && !body.endsWith('\n')) out += eol;
    if (body.trim() && !/\n[ \t]*\r?\n$/.test(out)) out += eol; // one blank line before our table
    out += table;
  }

  // The check: the same document, with only our server changed, and every comment still there.
  const after = parseToml(out);
  const expected = copy(doc.data);
  if (own(expected, 'mcp_servers') === undefined) put(expected, 'mcp_servers', {});
  for (const old of remove) delete expected.mcp_servers[old];
  put(expected.mcp_servers, name, parseToml(table).data.mcp_servers[name]);
  if (canonical(after.data) !== canonical(expected)) throw new TomlError('the change would have touched more than the twinslip table');
  const commentTexts = (d, t) => JSON.stringify(d.comments.map((c) => t.slice(c.start, c.end)));
  if (commentTexts(after, out) !== commentTexts(doc, text)) throw new TomlError('the change would have lost a comment');
  return out;
}
