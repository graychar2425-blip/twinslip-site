// Pro: free to use, paid to rely on (docs/CONTRACTS.md §4).
//
// A key bought at checkout is activated once against the provider's public License API (no
// secret of ours involved), checked against our store and product, and the result is kept
// in pro.json (0600). Every gate after that is a local, offline check. We re-check at most
// every 30 days, and keep working through 60 days without a successful check, so a flight
// or a flaky connection never locks anyone out. Cancelling never touches data.
//
// Pro includes 3 agents per seat, plus any extra agents bought with the key (docs/PRODUCT.md §2,
// Daniel, 2026-10-23); the key's checkout variant says how many extras (pro-config.js).
//
// Fair cancel, "keep what you paid for": each check stores the date the key is paid through.
// When the key lapses, Pro keeps working in every app version released on or before that date
// (package.json "releaseDate", stamped by scripts/package-beta.sh); later versions run as Free
// until the key is renewed. Data is never touched either way.

import { existsSync, readFileSync, writeFileSync, rmSync, renameSync } from 'node:fs';
import { join } from 'node:path';
import { hostname } from 'node:os';
import { LedgerError } from './ledger.js';
import { PRO_CONFIG } from './pro-config.js';

const DAY = 86400000;
const RECHECK_DAYS = 30;
const GRACE_DAYS = 60;
/** Agents a Pro seat includes (docs/PRODUCT.md §2). */
export const PRO_AGENTS_PER_SEAT = 3;

/** The day this version of the app was released (YYYY-MM-DD), from package.json; null if unknown. */
export const RELEASE_DATE = (() => {
  try {
    const d = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8')).releaseDate;
    return /^\d{4}-\d{2}-\d{2}$/.test(String(d ?? '')) ? d : null;
  } catch { return null; }
})();

export const PRO_FEATURES = {
  billing: 'Billing clients',
  tax_pack: 'The tax pack',
  accounting_export: 'Accounting export (YNAB, Lunch Money)',
  search: 'Search with running totals',
  alerts: 'Unusual-spend alerts',
  history: 'Per-agent history',
  audit: 'The audit trail',
  oversight: 'Oversight: follow-up on missing refunds, failed or late sources and unchecked months, with a briefing',
};

function file(ledger) {
  return ledger.dataDir ? join(ledger.dataDir, 'pro.json') : null;
}
function load(ledger) {
  const f = file(ledger);
  if (!f) return ledger.memoryPro ?? null;
  if (!existsSync(f)) return null;
  try { return JSON.parse(readFileSync(f, 'utf8')); } catch { return null; }
}
function save(ledger, data) {
  const f = file(ledger);
  if (!f) { ledger.memoryPro = data; return; }
  const tmp = `${f}.${process.pid}.tmp`;
  writeFileSync(tmp, `${JSON.stringify(data, null, 2)}\n`, { mode: 0o600 });
  renameSync(tmp, f);
}
function clear(ledger) {
  const f = file(ledger);
  if (!f) { ledger.memoryPro = null; return; }
  rmSync(f, { force: true });
}

/** The last day the key is known to be paid for: stored at each check; for a file from before that, the last check that found it active. */
function paidThrough(d) {
  if (d.paid_through) return d.paid_through;
  return d.status === 'active' && d.checked_at ? String(d.checked_at).slice(0, 10) : null;
}

/** How many agents a key covers: 3 per seat, plus the extras its checkout variant carries. */
function agentsOf(d) {
  const seats = Math.max(1, Number(d.seats) || 1);
  return Math.max(1, Number(d.agents) || seats * PRO_AGENTS_PER_SEAT);
}

/**
 * { pro, seats, agents, status, paid_through } from what's on this computer. No network, ever.
 * status: 'free', 'active', 'demo', 'kept' (the key lapsed, but this version was released before
 * it did, so Pro keeps working here), 'needs_check', or the key's own status ('expired', ...).
 */
export function proState(ledger) {
  if (ledger.proOverride) {
    const seats = ledger.proOverride.seats ?? 1;
    return { pro: true, seats, agents: ledger.proOverride.agents ?? seats * PRO_AGENTS_PER_SEAT, status: 'demo' };
  }
  const d = load(ledger);
  if (!d) return { pro: false, seats: 1, agents: 0, status: 'free' };
  const fresh = ledger.now() - new Date(d.checked_at) <= GRACE_DAYS * DAY;
  const through = paidThrough(d);
  const status = d.status === 'active' && !fresh ? 'needs_check' : d.status;
  const release = ledger.releaseDate !== undefined ? ledger.releaseDate : RELEASE_DATE;
  const active = d.status === 'active' && fresh;
  // Keep what you paid for: a version released on or before the paid-through day keeps Pro.
  const kept = !active && Boolean(through && release && release <= through);
  const pro = active || kept;
  return {
    pro,
    seats: pro ? d.seats : 1,
    agents: pro ? agentsOf(d) : 0,
    computers: pro ? d.computers ?? d.seats : 1,
    status: kept ? 'kept' : status,
    paid_through: through,
    release_date: release,
    ...(kept ? { lapsed: status } : {}),
  };
}

/** Throw a 402 the UI can show as-is when a free user reaches a Pro feature. */
export function requirePro(ledger, feature, { seats = 1 } = {}) {
  const s = proState(ledger);
  if (s.pro && s.seats >= seats) return s;
  ledger.track('pro_gate_hit', { feature });
  const what = PRO_FEATURES[feature] ?? 'This';
  const msg = seats > 1 && s.pro
    ? `${what} comes with Pro for ${seats} or more seats.`
    : `${what} is part of Twinslip Pro. Your data and everything free keep working either way.`;
  throw new LedgerError(msg, 402);
}

/** Outbound calls give up after this long, so a stuck network never holds anything open. */
export const FETCH_TIMEOUT_MS = 15_000;

async function call(fetch, config, action, params) {
  const res = await fetch(`${config.api}/${action}`, {
    signal: AbortSignal.timeout(config.timeoutMs ?? FETCH_TIMEOUT_MS),
    method: 'POST',
    headers: { Accept: 'application/json', 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams(params).toString(),
  });
  const body = await res.json().catch(() => ({}));
  return { ok: res.ok, body };
}

/** A seat is one person on up to computersPerSeat computers: the key's activation limit, divided back into people. */
function seatsFrom(limit, config, prior = null) {
  const computers = Number(limit) > 0 ? Number(limit) : prior?.computers ?? prior?.seats ?? 1;
  const per = Math.max(1, Number(config.computersPerSeat) || 1);
  return { seats: Math.max(1, Math.floor(computers / per)), computers };
}

function friendly(error, config = {}) {
  const e = String(error ?? '').toLowerCase();
  if (e.includes('activation limit')) {
    const per = Math.max(1, Number(config.computersPerSeat) || 1);
    return `Every computer on this key is in use${per > 1 ? `: each seat is one person on up to ${per} computers` : ''}. On another computer, choose Settings → Pro → Remove Pro from this computer, or add seats.`;
  }
  if (e.includes('not found') || e.includes('invalid')) return "We didn't recognise that key. Check it against the email from checkout.";
  if (e.includes('expired') || e.includes('disabled')) return 'That key is no longer active. Renew Pro to turn it back on.';
  return `Activation didn't work: ${error || 'unknown error'}.`;
}

/** Extra agents bought with the key: its checkout variant (Lemon Squeezy) or benefit (Polar), mapped in pro-config.js. */
function extraAgents(body, config, prior = null) {
  const map = config.extraAgentsByVariant ?? {};
  for (const id of [body?.meta?.variant_id, body?.license_key?.benefit_id, body?.benefit_id]) {
    if (id !== undefined && id !== null && Object.hasOwn(map, String(id))) return Math.max(0, Math.floor(Number(map[String(id)]) || 0));
  }
  return Math.max(0, Number(prior?.extra_agents) || 0);
}

/** The day a check shows the key paid through: never earlier than what was already known. */
function paidFrom(body, active, nowIso, prior = null) {
  const dates = [prior ? paidThrough(prior) : null];
  if (active) dates.push(nowIso.slice(0, 10));
  const exp = body?.license_key?.expires_at ?? body?.expires_at;
  if (exp && Number.isFinite(Date.parse(exp)) && (active || Date.parse(exp) <= Date.parse(nowIso))) dates.push(new Date(exp).toISOString().slice(0, 10));
  return dates.filter(Boolean).sort().pop() ?? null;
}

/** Seats, extra agents and the agents the key covers, as stored. */
function coverage(body, config, prior = null) {
  const s = seatsFrom(body?.license_key?.activation_limit, config, prior);
  const extra = extraAgents(body, config, prior);
  return { ...s, extra_agents: extra, agents: s.seats * PRO_AGENTS_PER_SEAT + extra };
}

function ours(meta, config) {
  return meta && Number(meta.store_id) === Number(config.storeId)
    && (config.productIds.length === 0 || config.productIds.map(Number).includes(Number(meta.product_id)));
}

export async function activatePro(ledger, key, { fetch = globalThis.fetch, config = PRO_CONFIG, instanceName = hostname() } = {}) {
  const k = String(key ?? '').trim();
  if (!k) throw new LedgerError('Paste the Pro key from your checkout email.');
  if (!config.storeId) throw new LedgerError("Pro isn't on sale yet. Everything free keeps working.");
  let r;
  try {
    r = await call(fetch, config, 'activate', { license_key: k, instance_name: `Twinslip on ${instanceName}`.slice(0, 100) });
  } catch {
    throw new LedgerError("Couldn't reach the checkout service to activate. Check your connection and try again.", 503);
  }
  if (!r.ok || !r.body.activated) throw new LedgerError(friendly(r.body.error, config), 400);
  if (!ours(r.body.meta, config)) throw new LedgerError("That isn't a Twinslip Pro key.", 400);
  const nowIso = ledger.now().toISOString();
  save(ledger, {
    v: 1,
    key: k, // our own product key, needed to re-check and to deactivate; never sent anywhere else
    instance_id: r.body.instance?.id ?? null,
    status: r.body.license_key?.status ?? 'active',
    ...coverage(r.body, config),
    store_id: r.body.meta.store_id,
    product_id: r.body.meta.product_id,
    variant_id: r.body.meta.variant_id ?? null,
    activated_at: nowIso,
    checked_at: nowIso,
    paid_through: paidFrom(r.body, (r.body.license_key?.status ?? 'active') === 'active', nowIso),
  });
  const s = proState(ledger);
  ledger.track('pro_activated', { seats: s.seats, agents: s.agents });
  return s;
}

/** Re-check at most every 30 days. Offline is fine within the grace window. */
export async function revalidatePro(ledger, { fetch = globalThis.fetch, config = PRO_CONFIG } = {}) {
  const d = load(ledger);
  if (!d) return proState(ledger);
  if (ledger.now() - new Date(d.checked_at) < RECHECK_DAYS * DAY) return proState(ledger);
  try {
    const r = await call(fetch, config, 'validate', { license_key: d.key, ...(d.instance_id ? { instance_id: d.instance_id } : {}) });
    if (!ours(r.body.meta, config)) return proState(ledger);
    const nowIso = ledger.now().toISOString();
    const status = r.body.valid ? 'active' : (r.body.license_key?.status ?? 'invalid');
    save(ledger, {
      ...d,
      status,
      ...coverage(r.body, config, d),
      checked_at: nowIso,
      paid_through: paidFrom(r.body, status === 'active', nowIso, d),
    });
  } catch { /* offline: keep what we have; proState applies the grace window */ }
  return proState(ledger);
}

export async function deactivatePro(ledger, { fetch = globalThis.fetch, config = PRO_CONFIG } = {}) {
  const d = load(ledger);
  if (d?.instance_id) {
    try { await call(fetch, config, 'deactivate', { license_key: d.key, instance_id: d.instance_id }); } catch { /* free the seat later */ }
  }
  clear(ledger);
  ledger.track('pro_deactivated');
  return proState(ledger);
}
