// Pro: free to use, paid to rely on (docs/CONTRACTS.md §4).
//
// A key bought at checkout is activated once against the provider's public License API (no
// secret of ours involved), checked against our store and product, and the result is kept
// in pro.json (0600). Every gate after that is a local, offline check. We re-check at most
// every 30 days, and keep working through 60 days without a successful check, so a flight
// or a flaky connection never locks anyone out. Cancelling never touches data.

import { existsSync, readFileSync, writeFileSync, rmSync, renameSync } from 'node:fs';
import { join } from 'node:path';
import { hostname } from 'node:os';
import { LedgerError } from './ledger.js';
import { PRO_CONFIG } from './pro-config.js';

const DAY = 86400000;
const RECHECK_DAYS = 30;
const GRACE_DAYS = 60;

export const PRO_FEATURES = {
  tax_pack: 'The tax pack',
  accounting_export: 'Accounting export (YNAB, Lunch Money)',
  search: 'Search with running totals',
  alerts: 'Unusual-spend alerts',
  history: 'Per-agent history',
  audit: 'The audit trail',
  oversight: 'Oversight: follow-up on missing refunds, failed or late sources and unchecked months, with a briefing',
};

function file(ledger) {
  return ledger.dataDir ? join(ledger.dataDir, 'pro.json') : null;
}
function load(ledger) {
  const f = file(ledger);
  if (!f) return ledger.memoryPro ?? null;
  if (!existsSync(f)) return null;
  try { return JSON.parse(readFileSync(f, 'utf8')); } catch { return null; }
}
function save(ledger, data) {
  const f = file(ledger);
  if (!f) { ledger.memoryPro = data; return; }
  const tmp = `${f}.${process.pid}.tmp`;
  writeFileSync(tmp, `${JSON.stringify(data, null, 2)}\n`, { mode: 0o600 });
  renameSync(tmp, f);
}
function clear(ledger) {
  const f = file(ledger);
  if (!f) { ledger.memoryPro = null; return; }
  rmSync(f, { force: true });
}

/** { pro, seats, status } from what's on this computer. No network, ever. */
export function proState(ledger) {
  if (ledger.proOverride) return { pro: true, seats: ledger.proOverride.seats ?? 1, status: 'demo' };
  const d = load(ledger);
  if (!d) return { pro: false, seats: 1, status: 'free' };
  const fresh = ledger.now() - new Date(d.checked_at) <= GRACE_DAYS * DAY;
  const pro = d.status === 'active' && fresh;
  return { pro, seats: pro ? d.seats : 1, computers: pro ? d.computers ?? d.seats : 1, status: d.status === 'active' && !fresh ? 'needs_check' : d.status };
}

/** Throw a 402 the UI can show as-is when a free user reaches a Pro feature. */
export function requirePro(ledger, feature, { seats = 1 } = {}) {
  const s = proState(ledger);
  if (s.pro && s.seats >= seats) return s;
  ledger.track('pro_gate_hit', { feature });
  const what = PRO_FEATURES[feature] ?? 'This';
  const msg = seats > 1 && s.pro
    ? `${what} comes with Pro for ${seats} or more seats.`
    : `${what} is part of Twinslip Pro. Your data and everything free keep working either way.`;
  throw new LedgerError(msg, 402);
}

/** Outbound calls give up after this long, so a stuck network never holds anything open. */
export const FETCH_TIMEOUT_MS = 15_000;

async function call(fetch, config, action, params) {
  const res = await fetch(`${config.api}/${action}`, {
    signal: AbortSignal.timeout(config.timeoutMs ?? FETCH_TIMEOUT_MS),
    method: 'POST',
    headers: { Accept: 'application/json', 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams(params).toString(),
  });
  const body = await res.json().catch(() => ({}));
  return { ok: res.ok, body };
}

/** A seat is one person on up to computersPerSeat computers: the key's activation limit, divided back into people. */
function seatsFrom(limit, config, prior = null) {
  const computers = Number(limit) > 0 ? Number(limit) : prior?.computers ?? prior?.seats ?? 1;
  const per = Math.max(1, Number(config.computersPerSeat) || 1);
  return { seats: Math.max(1, Math.floor(computers / per)), computers };
}

function friendly(error, config = {}) {
  const e = String(error ?? '').toLowerCase();
  if (e.includes('activation limit')) {
    const per = Math.max(1, Number(config.computersPerSeat) || 1);
    return `Every computer on this key is in use${per > 1 ? `: each seat is one person on up to ${per} computers` : ''}. On another computer, choose Settings → Pro → Remove Pro from this computer, or add seats.`;
  }
  if (e.includes('not found') || e.includes('invalid')) return "We didn't recognise that key. Check it against the email from checkout.";
  if (e.includes('expired') || e.includes('disabled')) return 'That key is no longer active. Renew Pro to turn it back on.';
  return `Activation didn't work: ${error || 'unknown error'}.`;
}

function ours(meta, config) {
  return meta && Number(meta.store_id) === Number(config.storeId)
    && (config.productIds.length === 0 || config.productIds.map(Number).includes(Number(meta.product_id)));
}

export async function activatePro(ledger, key, { fetch = globalThis.fetch, config = PRO_CONFIG, instanceName = hostname() } = {}) {
  const k = String(key ?? '').trim();
  if (!k) throw new LedgerError('Paste the Pro key from your checkout email.');
  if (!config.storeId) throw new LedgerError("Pro isn't on sale yet. Everything free keeps working.");
  let r;
  try {
    r = await call(fetch, config, 'activate', { license_key: k, instance_name: `Twinslip on ${instanceName}`.slice(0, 100) });
  } catch {
    throw new LedgerError("Couldn't reach the checkout service to activate. Check your connection and try again.", 503);
  }
  if (!r.ok || !r.body.activated) throw new LedgerError(friendly(r.body.error, config), 400);
  if (!ours(r.body.meta, config)) throw new LedgerError("That isn't a Twinslip Pro key.", 400);
  const nowIso = ledger.now().toISOString();
  save(ledger, {
    v: 1,
    key: k, // our own product key, needed to re-check and to deactivate; never sent anywhere else
    instance_id: r.body.instance?.id ?? null,
    status: r.body.license_key?.status ?? 'active',
    ...seatsFrom(r.body.license_key?.activation_limit, config),
    store_id: r.body.meta.store_id,
    product_id: r.body.meta.product_id,
    activated_at: nowIso,
    checked_at: nowIso,
  });
  const s = proState(ledger);
  ledger.track('pro_activated', { seats: s.seats });
  return s;
}

/** Re-check at most every 30 days. Offline is fine within the grace window. */
export async function revalidatePro(ledger, { fetch = globalThis.fetch, config = PRO_CONFIG } = {}) {
  const d = load(ledger);
  if (!d) return proState(ledger);
  if (ledger.now() - new Date(d.checked_at) < RECHECK_DAYS * DAY) return proState(ledger);
  try {
    const r = await call(fetch, config, 'validate', { license_key: d.key, ...(d.instance_id ? { instance_id: d.instance_id } : {}) });
    if (!ours(r.body.meta, config)) return proState(ledger);
    save(ledger, {
      ...d,
      status: r.body.valid ? 'active' : (r.body.license_key?.status ?? 'invalid'),
      ...seatsFrom(r.body.license_key?.activation_limit, config, d),
      checked_at: ledger.now().toISOString(),
    });
  } catch { /* offline: keep what we have; proState applies the grace window */ }
  return proState(ledger);
}

export async function deactivatePro(ledger, { fetch = globalThis.fetch, config = PRO_CONFIG } = {}) {
  const d = load(ledger);
  if (d?.instance_id) {
    try { await call(fetch, config, 'deactivate', { license_key: d.key, instance_id: d.instance_id }); } catch { /* free the seat later */ }
  }
  clear(ledger);
  ledger.track('pro_deactivated');
  return proState(ledger);
}
