// Recurring charges agents started: API plans, SaaS seats, domains. Detected from confirmed
// purchases only, per agent and merchant, so "who signed us up for this?" always has an
// answer. Awareness only: cancelling stays with the user and the vendor.

import { addDays, addMonths } from './dates.js';

const DAY = 86400000;
const CADENCES = [
  { name: 'weekly', min: 5, max: 9, grace: 4, perMonth: 52 / 12 },
  { name: 'monthly', min: 25, max: 36, grace: 10, perMonth: 1 },
  { name: 'yearly', min: 350, max: 380, grace: 30, perMonth: 1 / 12 },
];

const daysBetween = (a, b) => Math.round((Date.parse(b) - Date.parse(a)) / DAY);

function sameDayLater(date, months) {
  const [y, m, d] = date.split('-').map(Number);
  const target = addMonths(`${y}-${String(m).padStart(2, '0')}`, months);
  const [ty, tm] = target.split('-').map(Number);
  const last = new Date(Date.UTC(ty, tm, 0)).getUTCDate();
  return `${target}-${String(Math.min(d, last)).padStart(2, '0')}`;
}

function nextCharge(last, cadence) {
  if (cadence === 'weekly') return addDays(last, 7);
  return sameDayLater(last, cadence === 'monthly' ? 1 : 12);
}

/**
 * rows: confirmed purchases { agent, group, merchant, amount_cents, currency, occurred_on }
 * where `group` is the merchant identity reconciliation uses. Returns
 * { subscriptions: [...], monthly_total: [{ currency, cents }] }.
 */
export function findSubscriptions(rows, today) {
  const groups = new Map();
  for (const r of rows) {
    if (r.amount_cents <= 0) continue; // refunds don't renew
    const k = `${r.agent_id}|${r.group}|${r.currency}`;
    (groups.get(k) ?? groups.set(k, []).get(k)).push(r);
  }
  const subscriptions = [];
  for (const charges of groups.values()) {
    charges.sort((a, b) => a.occurred_on.localeCompare(b.occurred_on));
    const latest = charges[charges.length - 1];
    // The current price, and every earlier charge close to it (prices drift a little).
    const tolerance = Math.max(50, Math.round(latest.amount_cents * 0.1));
    const run = [latest];
    for (let i = charges.length - 2; i >= 0 && Math.abs(charges[i].amount_cents - latest.amount_cents) <= tolerance; i--) run.unshift(charges[i]);
    if (run.length < 2) continue;
    // Every gap must fit one schedule: a typical gap alone lets random top-ups through.
    const gaps = run.slice(1).map((r, i) => daysBetween(run[i].occurred_on, r.occurred_on));
    const cadence = CADENCES.find((c) => gaps.every((g) => g >= c.min && g <= c.max));
    if (!cadence) continue;
    const nextOn = nextCharge(latest.occurred_on, cadence.name);
    const status = today > addDays(nextOn, cadence.grace) ? 'lapsed' : 'active';
    subscriptions.push({
      merchant: latest.merchant,
      agent_id: latest.agent_id,
      agent: latest.agent,
      cadence: cadence.name,
      amount_cents: latest.amount_cents,
      currency: latest.currency,
      monthly_cents: Math.round(latest.amount_cents * cadence.perMonth),
      next_on: nextOn,
      last_on: latest.occurred_on,
      since: run[0].occurred_on,
      charges: run.length,
      status,
    });
  }
  subscriptions.sort((a, b) => (a.status === b.status ? a.next_on.localeCompare(b.next_on) : a.status === 'active' ? -1 : 1));
  const totals = new Map();
  for (const s of subscriptions.filter((x) => x.status === 'active')) totals.set(s.currency, (totals.get(s.currency) ?? 0) + s.monthly_cents);
  return {
    subscriptions,
    monthly_total: [...totals].map(([currency, cents]) => ({ currency, cents })).sort((a, b) => b.cents - a.cents),
  };
}
