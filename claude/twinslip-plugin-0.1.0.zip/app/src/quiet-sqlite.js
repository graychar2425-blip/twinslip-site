// node:sqlite prints an ExperimentalWarning on Node 22. It's noise for end users; drop
// exactly that warning and leave every other warning alone.
const original = process.emitWarning;
process.emitWarning = function (warning, ...args) {
  const text = typeof warning === 'string' ? warning : warning?.message ?? '';
  const type = typeof args[0] === 'string' ? args[0] : args[0]?.type ?? warning?.name;
  if (type === 'ExperimentalWarning' && /SQLite/i.test(text)) return;
  return original.call(this, warning, ...args);
};
