// The phone-to-Mac bridge (docs/CONTRACTS.md §2). iPhone Shortcuts appends one capture
// event per line to capture.jsonl in an iCloud Drive folder; iCloud syncs it here; we read
// only what's new (byte offset kept in the ledger), and only whole lines. We also write
// summary.json back into the same folder for the iPhone's glance view.

import { existsSync, statSync, openSync, readSync, closeSync, writeFileSync, renameSync } from 'node:fs';
import { join } from 'node:path';
import { getMeta, setMeta } from './db.js';
import { captureEvents, CAPTURE_SOURCES } from './capture.js';
import { headline } from './totals.js';
import { redact } from './redact.js';

export const CAPTURE_FILE = 'capture.jsonl';
/** Read at most this much of the capture file per tick; a longer single line is skipped. */
export const CAPTURE_CHUNK = 1024 * 1024;
export const SUMMARY_FILE = 'summary.json';

/** Our folder inside Shortcuts' own iCloud folder: iCloud Drive › Shortcuts › Twinslip on the iPhone. */
export const SYNC_FOLDER = 'Twinslip';
/** Its name before Agent Ledger became Twinslip. iPhones set up before then still write there. */
export const OLD_SYNC_FOLDER = 'Agent Ledger';
const shortcutsFolder = (home) => join(home, 'Library', 'Mobile Documents', 'iCloud~is~workflow~my~workflows', 'Documents');

/** Shortcuts' own iCloud folder on a Mac, our part of it. */
export function defaultSyncDir(home) {
  return join(shortcutsFolder(home), SYNC_FOLDER);
}

/** The old folder: read whenever it's there, and kept current, so old shortcuts keep working. */
export function oldSyncDir(home) {
  return join(shortcutsFolder(home), OLD_SYNC_FOLDER);
}

/** Capture every complete new line. Returns { captured, results, errors }. Never throws for bad lines. */
export function readCaptureFile(ledger, dir) {
  const path = join(dir, CAPTURE_FILE);
  const none = { captured: 0, results: [], errors: [] };
  if (!existsSync(path)) return none;
  const offKey = `capture_offset:${path}`;
  const lineKey = `capture_lines:${path}`;
  const skipKey = `capture_skipping:${path}`; // '1' while passing through a line over 1 MB
  const size = statSync(path).size;
  let offset = Number(getMeta(ledger.db, offKey) ?? 0);
  let lineNo = Number(getMeta(ledger.db, lineKey) ?? 0);
  let skipping = getMeta(ledger.db, skipKey) === '1';
  if (size < offset) { offset = 0; lineNo = 0; skipping = false; setMeta(ledger.db, skipKey, '0'); } // replaced by a shorter copy: re-read; refs dedupe
  if (size === offset) return none;

  // Never more than 1 MB per tick.
  const buf = Buffer.alloc(Math.min(size - offset, CAPTURE_CHUNK));
  const fd = openSync(path, 'r');
  try { readSync(fd, buf, 0, buf.length, offset); } finally { closeSync(fd); }
  const results = [];
  const errors = [];
  const at = (o) => ({ offKey, lineKey, skipKey, offset: o, lineNo, results, errors });

  if (skipping) {
    // Passing through a line over 1 MB, one chunk a tick, until its newline.
    const nl = buf.indexOf(0x0a);
    if (nl < 0) return finish(ledger, { ...at(offset + buf.length), skipping: true });
    lineNo++;
    errors.push(`line ${lineNo}: longer than 1 MB, skipped`);
    return finish(ledger, { ...at(offset + nl + 1), lineNo, skipping: false });
  }
  const end = buf.lastIndexOf(0x0a);
  if (end < 0 && buf.length === CAPTURE_CHUNK) {
    // A whole chunk without a newline: no event is that big. Skip the line over the next ticks.
    return finish(ledger, { ...at(offset + buf.length), skipping: true });
  }
  if (end < 0) return none; // only a half-written line so far: wait for the rest

  for (const raw of buf.subarray(0, end + 1).toString('utf8').split('\n').slice(0, -1)) {
    lineNo++;
    const text = raw.trim();
    if (!text) continue;
    try {
      results.push(...captureEvents(ledger, [JSON.parse(text)]));
    } catch (err) {
      errors.push(`line ${lineNo}: ${err instanceof SyntaxError ? 'not valid JSON' : err.message}`);
    }
  }
  return finish(ledger, { ...at(offset + end + 1), lineNo });
}

/** Remember how far we read, and show any unreadable lines on the iPhone source. */
function finish(ledger, { offKey, lineKey, skipKey, offset, lineNo, results, errors, skipping = false }) {
  setMeta(ledger.db, offKey, offset);
  setMeta(ledger.db, lineKey, lineNo);
  setMeta(ledger.db, skipKey, skipping ? '1' : '0');
  if (errors.length) {
    const sourceId = ledger.ensureSource('phone', CAPTURE_SOURCES.phone);
    const nowIso = ledger.now().toISOString();
    ledger.db.prepare('UPDATE sources SET last_attempt_at = ?, last_error = ? WHERE id = ?')
      .run(nowIso, redact(`${errors.length} line${errors.length === 1 ? '' : 's'} in ${CAPTURE_FILE} couldn't be read (${errors[0]})`), sourceId);
  }
  return { captured: results.length, results, errors };
}

/** The glance numbers for the phone. Same currency for both buckets: the agents' main one. */
export function summary(ledger) {
  const all = headline(ledger);
  const h = all.this_month;
  const main = h.by_currency[0];
  const currency = main?.currency ?? h.mine[0]?.currency ?? 'USD';
  const pct = (row) => (row && row.cents > 0 ? Math.max(0, Math.min(100, Math.round((row.verified_cents / row.cents) * 100))) : 0);
  const lastRow = all.last_month.by_currency.find((r) => r.currency === currency);
  // The agents behind the amount shown: same currency, and money actually spent (not refunded).
  const agentsIn = (month) => new Set(ledger.monthSpend(month).filter((r) => r.currency === currency && r.cents > 0).map((r) => r.agent)).size;
  const firstPhone = ledger.db.prepare(`SELECT min(p.created_at) AS at FROM purchases p JOIN sources s ON s.id = p.source_id WHERE s.kind = 'phone'`).get().at;
  return {
    v: 1,
    updated_at: ledger.now().toISOString(),
    month: h.month,
    currency,
    agents_cents: main?.cents ?? 0,
    mine_cents: h.mine.find((m) => m.currency === currency)?.cents ?? 0,
    verified_pct: pct(main),
    agent_count: agentsIn(h.month),
    inbox: ledger.counts().candidate,
    first_event_at: firstPhone ?? null,
    // For the phone's share card: "My agents cost me $X last month."
    last_month: {
      month: all.last_month.month,
      currency,
      agents_cents: lastRow?.cents ?? 0,
      verified_pct: pct(lastRow),
      agent_count: agentsIn(all.last_month.month),
    },
  };
}

/** Write summary.json atomically (temp file + rename), so the phone never reads half a file. */
export function writeSummary(ledger, dir) {
  if (!existsSync(dir)) return null;
  const s = summary(ledger);
  const tmp = join(dir, `.${SUMMARY_FILE}.${process.pid}.tmp`);
  writeFileSync(tmp, `${JSON.stringify(s, null, 2)}\n`);
  renameSync(tmp, join(dir, SUMMARY_FILE));
  return s;
}
