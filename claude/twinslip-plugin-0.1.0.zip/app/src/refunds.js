// Expected refunds (docs/PRODUCT.md §6). Someone expects money back: an amount, a merchant, a
// due date. The expectation is never spending and never changes a total. Refund lines (negative
// purchases) that arrive are linked to it, each line to at most one expectation:
//   - lines with independent proof (verified_at: bank CSV, iPhone, webhook, an attached receipt)
//     resolve it once they cover the amount;
//   - a refund line the user typed in is their own word, the same as marking it received;
//   - lines only an agent supplied (its own refund report, a receipt or alert it found) cover it
//     as evidence, never resolution: an agent can't close its own follow-up;
//   - only lines from the expectation's window count: from the purchase it refunds, or 60 days
//     before it was noted, so an old refund in an imported statement can't settle a new one;
//   - only the user resolves or dismisses by hand.

import { LedgerError, sameMerchant, checkReportedAmount, MAX_REPORTED_CENTS } from './ledger.js';
import { merchantKey } from './merchants.js';
import { redact } from './redact.js';
import { addDays, isIsoDate, toLocalDate } from './dates.js';
import { formatCents } from './money.js';
import { tx } from './db.js';

const OPEN = ['open', 'evidence'];
const tolerance = (cents) => Math.max(1, Math.round(cents / 100)); // within 1%, as reconciliation matches

/** Record an expected refund. by: 'user' or 'agent' (with agentId). Returns the row; { duplicate } for an agent retry. */
export function expectRefund(ledger, { purchaseId = null, merchant, amountCents, currency, dueOn, note = '' }, { by, agentId = null, reference = null } = {}) {
  if (by !== 'user' && by !== 'agent') throw new LedgerError('by must be user or agent.');
  const p = purchaseId ? ledger.getPurchase(purchaseId) : null;
  const name = redact(String(merchant ?? p?.merchant ?? '')).trim().slice(0, 80);
  if (!name) throw new LedgerError('merchant is required.');
  const cents = amountCents ?? (p ? Math.abs(p.amount_cents) : null);
  if (!Number.isSafeInteger(cents) || cents <= 0) throw new LedgerError('amount must be a positive number like "84.00".');
  if (cents > MAX_REPORTED_CENTS) checkReportedAmount(cents);
  const cur = String(currency ?? p?.currency ?? 'USD');
  if (!/^[A-Z]{3}$/.test(cur)) throw new LedgerError('currency must be a 3-letter code like USD.');
  const today = toLocalDate(ledger.now());
  if (!isIsoDate(dueOn)) throw new LedgerError('due date must be a real date like 2026-10-25.');
  if (dueOn < addDays(today, -400) || dueOn > addDays(today, 400)) throw new LedgerError('due date must be within 400 days of today.');
  const ref = reference ? redact(String(reference).trim()).slice(0, 120) : null;
  const nowIso = ledger.now().toISOString();

  return tx(ledger.db, () => {
    if (by === 'agent') {
      ledger.requireAgent(agentId);
      if (ref) {
        const prior = ledger.db.prepare('SELECT id FROM expected_refunds WHERE reported_by_agent_id = ? AND reference = ?').get(Number(agentId), ref);
        if (prior) return { ...getRefund(ledger, prior.id), duplicate: true };
      }
      ledger.checkAgentLimit(agentId); // one hourly limit across every tool an agent writes with
    }
    const { lastInsertRowid } = ledger.db.prepare(`INSERT INTO expected_refunds
      (purchase_id, merchant, merchant_key, amount_cents, currency, due_on, note, created_by, reported_by_agent_id, reference, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(p?.id ?? null, name, merchantKey(name, null), cents, cur, dueOn,
      redact(String(note ?? '')).slice(0, 200), by, by === 'agent' ? Number(agentId) : null, ref, nowIso);
    const id = Number(lastInsertRowid);
    ledger.audit('refund', p?.id ?? null, `${by === 'agent' ? 'an agent' : 'you'} expect ${formatCents(cents, cur)} back from ${name} by ${dueOn}`);
    linkExisting(ledger, id, windowStart(ledger, ledger.db.prepare('SELECT * FROM expected_refunds WHERE id = ?').get(id)));
    return { ...getRefund(ledger, id), duplicate: false };
  });
}

/** A refund line was stored or gained evidence: link it to the expectation it answers, or recheck the one it answers. */
export function matchRefund(ledger, purchaseId) {
  let p = ledger.getPurchase(purchaseId);
  if (p.status === 'merged') p = ledger.getPurchase(p.merged_into);
  if (p.amount_cents >= 0) return null;
  const linked = ledger.db.prepare('SELECT expected_refund_id FROM refund_links WHERE purchase_id = ?').get(p.id);
  if (linked) return recheck(ledger, linked.expected_refund_id);
  const c = Math.abs(p.amount_cents);
  // A proven line is measured against what is proven so far: an agent's earlier claim of the same
  // refund must not leave the bank's line with nothing to answer.
  const proof = isProof(ledger, p);
  const open = ledger.db.prepare(`SELECT * FROM expected_refunds WHERE status IN ('open', 'evidence') AND currency = ?`).all(p.currency)
    .filter((e) => sameMerchant(e.merchant_key, p.merchant_key) && p.occurred_on >= windowStart(ledger, e))
    .map((e) => { const cov = covered(ledger, e.id); return { e, left: e.amount_cents - (proof ? cov.proven : cov.all) }; });
  // The closest full match first, then the oldest due date; else a partial refund toward the oldest.
  const full = open.filter((x) => Math.abs(x.left - c) <= tolerance(x.e.amount_cents))
    .sort((a, b) => Math.abs(a.left - c) - Math.abs(b.left - c) || a.e.due_on.localeCompare(b.e.due_on) || a.e.id - b.e.id);
  const partial = open.filter((x) => c < x.left - tolerance(x.e.amount_cents)).sort((a, b) => a.e.due_on.localeCompare(b.e.due_on) || a.e.id - b.e.id);
  const pick = full[0] ?? partial[0];
  if (!pick) return null;
  ledger.db.prepare('INSERT INTO refund_links (expected_refund_id, purchase_id, cents, at) VALUES (?, ?, ?, ?)')
    .run(pick.e.id, p.id, c, ledger.now().toISOString());
  return recheck(ledger, pick.e.id);
}

/** The earliest date a refund line may have to answer this expectation. */
function windowStart(ledger, e) {
  const bought = e.purchase_id ? ledger.db.prepare('SELECT occurred_on FROM purchases WHERE id = ?').get(e.purchase_id)?.occurred_on : null;
  return bought ?? addDays(e.created_at.slice(0, 10), -60);
}

/** Proof that a refund line happened: independent evidence (verified_at), or the user's own entry. */
function isProof(ledger, p) {
  return Boolean(p.verified_at) || ledger.db.prepare('SELECT kind FROM sources WHERE id = ?').get(p.source_id)?.kind === 'manual';
}

/** An expectation was just recorded: refund lines already in the ledger may answer it. */
function linkExisting(ledger, id, since) {
  const e = ledger.db.prepare('SELECT * FROM expected_refunds WHERE id = ?').get(id);
  const lines = ledger.db.prepare(`SELECT id, amount_cents, merchant_key, verified_at, source_id FROM purchases
    WHERE status != 'merged' AND amount_cents < 0 AND currency = ? AND occurred_on >= ?
      AND id NOT IN (SELECT purchase_id FROM refund_links) ORDER BY occurred_on, id`).all(e.currency, since)
    .filter((l) => sameMerchant(l.merchant_key, e.merchant_key))
    .map((l) => ({ ...l, proof: isProof(ledger, l) }))
    .sort((a, b) => Number(b.proof) - Number(a.proof)); // proof first, so an agent's claim can't use up the amount
  for (const l of lines) {
    const cov = covered(ledger, id);
    const left = e.amount_cents - (l.proof ? cov.proven : cov.all);
    const c = Math.abs(l.amount_cents);
    if (left <= tolerance(e.amount_cents) || c > left + tolerance(e.amount_cents)) continue;
    ledger.db.prepare('INSERT INTO refund_links (expected_refund_id, purchase_id, cents, at) VALUES (?, ?, ?, ?)')
      .run(id, l.id, c, ledger.now().toISOString());
  }
  recheck(ledger, id);
}

/** Cents covered by linked lines: all of them, and those with independent proof. */
function covered(ledger, id) {
  const r = ledger.db.prepare(`SELECT COALESCE(sum(l.cents), 0) AS all_cents,
      COALESCE(sum(CASE WHEN p.verified_at IS NOT NULL OR s.kind = 'manual' THEN l.cents ELSE 0 END), 0) AS proven
    FROM refund_links l JOIN purchases p ON p.id = l.purchase_id JOIN sources s ON s.id = p.source_id WHERE l.expected_refund_id = ?`).get(id);
  return { all: r.all_cents, proven: r.proven };
}

/** Set an open expectation's status from its linked lines. The user's own resolve or dismiss stands. */
function recheck(ledger, id) {
  const e = ledger.db.prepare('SELECT * FROM expected_refunds WHERE id = ?').get(id);
  if (!OPEN.includes(e.status)) return getRefund(ledger, id);
  const { all, proven } = covered(ledger, id);
  const enough = (x) => x >= e.amount_cents - tolerance(e.amount_cents);
  const status = enough(proven) ? 'resolved' : enough(all) ? 'evidence' : 'open';
  if (status !== e.status) {
    ledger.db.prepare('UPDATE expected_refunds SET status = ?, resolved_at = ? WHERE id = ?')
      .run(status, status === 'resolved' ? ledger.now().toISOString() : null, id);
    ledger.audit('refund', e.purchase_id, status === 'resolved'
      ? `refund of ${formatCents(e.amount_cents, e.currency)} from ${e.merchant} arrived (seen by your bank or another independent source, or added by you)`
      : `an agent says the refund from ${e.merchant} arrived; waiting for your bank or your tap`);
  }
  return getRefund(ledger, id);
}

export function getRefund(ledger, id) {
  const e = ledger.db.prepare(`SELECT r.*, a.name AS agent FROM expected_refunds r LEFT JOIN agents a ON a.id = r.reported_by_agent_id WHERE r.id = ?`).get(Number(id));
  if (!e) throw new LedgerError('No such expected refund.', 404);
  const links = ledger.db.prepare(`SELECT l.purchase_id, l.cents, p.occurred_on, (p.verified_at IS NOT NULL OR s.kind = 'manual') AS independent
    FROM refund_links l JOIN purchases p ON p.id = l.purchase_id JOIN sources s ON s.id = p.source_id WHERE l.expected_refund_id = ? ORDER BY l.id`).all(e.id)
    .map((l) => ({ ...l, independent: Boolean(l.independent) }));
  const { all, proven } = covered(ledger, e.id);
  return { ...e, refunded_cents: proven, claimed_cents: all, links };
}

/** Every expected refund, open first, then by due date. */
export function listRefunds(ledger) {
  return ledger.db.prepare(`SELECT id FROM expected_refunds
    ORDER BY CASE WHEN status IN ('open', 'evidence') THEN 0 ELSE 1 END, due_on, id`).all().map((r) => getRefund(ledger, r.id));
}

function close(ledger, id, status, note) {
  const e = getRefund(ledger, id);
  if (!OPEN.includes(e.status)) throw new LedgerError(`That expected refund is already ${e.status}.`, 409);
  const what = status === 'resolved' ? 'you marked the refund as received' : 'you stopped expecting this refund';
  tx(ledger.db, () => {
    const nowIso = ledger.now().toISOString();
    ledger.db.prepare('UPDATE expected_refunds SET status = ?, resolved_at = ? WHERE id = ?').run(status, nowIso, e.id);
    // Its follow-up closes with it, in the user's words, so nothing still says it's owed.
    for (const x of ledger.db.prepare("SELECT id FROM exceptions WHERE subject = ? AND status = 'open'").all(`refund:${e.id}`)) {
      ledger.db.prepare('UPDATE exceptions SET status = ?, resolved_at = ?, updated_at = ? WHERE id = ?').run(status, nowIso, nowIso, x.id);
      ledger.db.prepare("INSERT INTO exception_events (exception_id, at, actor, action, note) VALUES (?, ?, 'user', ?, ?)")
        .run(x.id, nowIso, status, redact(String(note ?? '')).slice(0, 200));
    }
    ledger.audit('refund', e.purchase_id, `${what}: ${formatCents(e.amount_cents, e.currency)} from ${e.merchant}${note ? ` (${redact(String(note)).slice(0, 200)})` : ''}`);
  });
  return getRefund(ledger, e.id);
}

/** Only the user: the refund came some other way (a store credit, cash). */
export function resolveRefund(ledger, id, { note = '' } = {}) {
  return close(ledger, id, 'resolved', note);
}

/** Only the user: stop expecting it. */
export function dismissRefund(ledger, id, { note = '' } = {}) {
  return close(ledger, id, 'dismissed', note);
}
