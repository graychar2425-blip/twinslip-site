// Unusual-spend alerts (Pro): a watcher, not a record. Compares this month with each
// agent's own recent habits and says so in a sentence. Never blocks anything.

import { addMonths, monthKey, toLocalDate } from './dates.js';
import { formatCents } from './money.js';

const MIN_CENTS = 1000; // under $10 isn't worth interrupting anyone for

/** [{ kind, agent, merchant, cents, usual_cents, currency, message }] for the current month. */
export function unusualSpend(ledger) {
  const month = monthKey(toLocalDate(ledger.now()));
  const from = `${addMonths(month, -3)}-01`;
  const rows = ledger.db.prepare(`
    SELECT a.name AS agent, p.merchant, p.merchant_key, p.currency, p.amount_cents, substr(p.occurred_on, 1, 7) AS month
    FROM purchases p JOIN agents a ON a.id = p.agent_id
    WHERE p.status = 'confirmed' AND p.occurred_on >= ? AND p.occurred_on < ?`).all(from, `${addMonths(month, 1)}-01`);
  const groups = new Map();
  for (const r of rows) {
    const k = `${r.agent}|${r.merchant_key.split(' ')[0]}|${r.currency}`;
    const g = groups.get(k) ?? { agent: r.agent, merchant: r.merchant, currency: r.currency, now: 0, before: [0, 0, 0], biggest: 0, past: [] };
    if (r.month === month) {
      g.now += r.amount_cents;
      g.biggest = Math.max(g.biggest, r.amount_cents);
      g.merchant = r.merchant;
    } else {
      const back = [-3, -2, -1].findIndex((d) => addMonths(month, d) === r.month);
      if (back >= 0) g.before[back] += r.amount_cents;
      g.past.push(r.amount_cents);
    }
    groups.set(k, g);
  }
  const out = [];
  for (const g of groups.values()) {
    if (g.now < MIN_CENTS) continue;
    const usual = Math.round(g.before.reduce((a, b) => a + b, 0) / 3);
    const f = (c) => formatCents(c, g.currency);
    if (g.past.length === 0 && g.now >= 5000) {
      out.push({ kind: 'new_merchant', agent: g.agent, merchant: g.merchant, cents: g.now, usual_cents: 0, currency: g.currency,
        message: `${g.agent} spent ${f(g.now)} at ${g.merchant} this month, a merchant it hasn't used before.` });
    } else if (usual > 0 && g.now >= 3 * usual && g.now - usual >= 2000) {
      out.push({ kind: 'spike', agent: g.agent, merchant: g.merchant, cents: g.now, usual_cents: usual, currency: g.currency,
        message: `${g.agent} spent ${f(g.now)} at ${g.merchant} this month, ${Math.round(g.now / usual)}× its usual ${f(usual)}.` });
    }
  }
  return out.sort((a, b) => b.cents - a.cents);
}
