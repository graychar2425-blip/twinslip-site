// Paying twice: the same service on a schedule from more than one payer.
//
// Each agent that needs a browser, a model or a host signs up on its own, so a household or a
// small team ends up paying for the same plan two or three times, and nobody sees it because
// every vendor bill looks normal on its own. The same happens between you and an agent: you
// already pay for Notion, and your agent started its own seat. This finds both from what is
// already in the ledger. Awareness only: which seat to cancel is the user's call.

import { findSubscriptions } from './subscriptions.js';
import { merchantKey } from './merchants.js';
import { sameMerchant, firstToken } from './ledger.js';
import { addDays, toLocalDate } from './dates.js';
import { formatCents } from './money.js';

const YOU = 'You';

/**
 * [{ merchant, kind: 'agents' | 'you_and_agent', payers: [{ who, cadence, monthly_cents, currency, since }],
 *    combined_monthly: [{ currency, cents }], text }], biggest first.
 */
export function findOverlaps(ledger) {
  const today = toLocalDate(ledger.now());
  const agentSubs = ledger.subscriptions().subscriptions.filter((s) => s.status === 'active')
    .map((s) => ({ ...s, who: s.agent }));
  // Your own recurring charges: the Mine bucket, exactly as the Mine view defines it.
  const mineRows = ledger.minePurchases({ from: addDays(today, -400), to: addDays(today, 1) })
    .map((p) => ({ ...p, agent_id: 0, agent: YOU, group: firstToken(p.merchant_key) }));
  const mineSubs = findSubscriptions(mineRows, today).subscriptions.filter((s) => s.status === 'active')
    .map((s) => ({ ...s, who: YOU }));

  const clusters = [];
  for (const s of [...agentSubs, ...mineSubs]) {
    const key = merchantKey(s.merchant);
    const c = clusters.find((x) => sameMerchant(x.key, key));
    if (c) c.subs.push(s); else clusters.push({ key, merchant: s.merchant, subs: [s] });
  }

  const out = [];
  for (const c of clusters) {
    const payers = [...new Set(c.subs.map((s) => s.who))];
    if (payers.length < 2) continue;
    const agentsIn = payers.filter((p) => p !== YOU);
    if (!agentsIn.length) continue;
    const kind = payers.includes(YOU) ? 'you_and_agent' : 'agents';
    const combined = new Map();
    for (const s of c.subs) combined.set(s.currency, (combined.get(s.currency) ?? 0) + s.monthly_cents);
    const combinedList = [...combined].map(([currency, cents]) => ({ currency, cents })).sort((a, b) => b.cents - a.cents);
    const list = (xs) => (xs.length <= 2 ? xs.join(' and ') : `${xs.slice(0, -1).join(', ')} and ${xs.at(-1)}`);
    const total = combinedList.map((t) => formatCents(t.cents, t.currency)).join(' + ');
    const text = kind === 'you_and_agent'
      ? `You pay ${c.merchant} yourself, and ${list(agentsIn)} ${agentsIn.length === 1 ? 'pays' : 'pay'} for it too: about ${total} a month together.`
      : `${list(agentsIn)} each pay ${c.merchant} on a schedule: about ${total} a month together.`;
    out.push({
      merchant: c.merchant,
      kind,
      payers: c.subs.map((s) => ({ who: s.who, cadence: s.cadence, monthly_cents: s.monthly_cents, amount_cents: s.amount_cents, currency: s.currency, since: s.since })),
      combined_monthly: combinedList,
      text,
    });
  }
  return out.sort((a, b) => (b.combined_monthly[0]?.cents ?? 0) - (a.combined_monthly[0]?.cents ?? 0));
}
