// Dates are stored as local calendar dates, 'YYYY-MM-DD'. A purchase belongs to the day
// the user would say it happened on, in their own timezone.

const pad = (n) => String(n).padStart(2, '0');

export function toLocalDate(d) {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

export function epochToLocalDate(seconds) {
  return toLocalDate(new Date(seconds * 1000));
}

export function isIsoDate(s) {
  if (typeof s !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const [y, m, d] = s.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  return dt.getUTCFullYear() === y && dt.getUTCMonth() === m - 1 && dt.getUTCDate() === d;
}

function utc(s) {
  const [y, m, d] = s.split('-').map(Number);
  return new Date(Date.UTC(y, m - 1, d));
}

function fmtUtc(dt) {
  return `${dt.getUTCFullYear()}-${pad(dt.getUTCMonth() + 1)}-${pad(dt.getUTCDate())}`;
}

export function addDays(s, n) {
  const dt = utc(s);
  dt.setUTCDate(dt.getUTCDate() + n);
  return fmtUtc(dt);
}

/** Monday of the week containing the date. Weeks run Monday–Sunday. */
export function weekStart(s) {
  const dt = utc(s);
  const offset = (dt.getUTCDay() + 6) % 7;
  dt.setUTCDate(dt.getUTCDate() - offset);
  return fmtUtc(dt);
}

export function monthKey(s) {
  return s.slice(0, 7);
}

export function addMonths(month, n) {
  const [y, m] = month.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1 + n, 1));
  return `${dt.getUTCFullYear()}-${pad(dt.getUTCMonth() + 1)}`;
}

/** ISO-8601 week label, e.g. '2026-W40'. Used only in the beta report. */
export function isoWeekLabel(s) {
  const dt = utc(s);
  const day = (dt.getUTCDay() + 6) % 7;
  dt.setUTCDate(dt.getUTCDate() - day + 3); // Thursday of this week decides the year
  const year = dt.getUTCFullYear();
  const jan4 = new Date(Date.UTC(year, 0, 4));
  const week = 1 + Math.round(((dt - jan4) / 86400000 - 3 + ((jan4.getUTCDay() + 6) % 7)) / 7);
  return `${year}-W${pad(week)}`;
}

/**
 * Parse a date as it appears in a bank CSV export.
 * order: 'MDY' (US default) or 'DMY' for slash/dot dates. ISO dates ignore order.
 */
export function parseFlexibleDate(raw, order = 'MDY') {
  if (typeof raw !== 'string') return null;
  const s = raw.trim();
  let m = /^(\d{4})[-/](\d{1,2})[-/](\d{1,2})(?:[T ].*)?$/.exec(s);
  if (m) {
    const out = `${m[1]}-${pad(Number(m[2]))}-${pad(Number(m[3]))}`;
    return isIsoDate(out) ? out : null;
  }
  m = /^(\d{1,2})[/.-](\d{1,2})[/.-](\d{2}|\d{4})(?:\s.*)?$/.exec(s);
  if (m) {
    let [a, b] = [Number(m[1]), Number(m[2])];
    let y = Number(m[3]);
    if (m[3].length === 2) y += 2000;
    const [month, day] = order === 'DMY' ? [b, a] : [a, b];
    const out = `${y}-${pad(month)}-${pad(day)}`;
    return isIsoDate(out) ? out : null;
  }
  return null;
}

/** Decide MDY vs DMY from a column of slash dates: any first part > 12 means DMY. */
export function detectDateOrder(values) {
  for (const v of values) {
    const m = /^(\d{1,2})[/.-](\d{1,2})[/.-]\d{2,4}/.exec(String(v).trim());
    if (m && Number(m[1]) > 12) return 'DMY';
  }
  return 'MDY';
}
