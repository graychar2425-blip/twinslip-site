// The optional background job and notifications (docs/PRODUCT.md §6), macOS only.
// launchd runs `twinslip oversee` every hour and at login. When the Mac sleeps through a
// run, launchd runs it on wake, so nothing scheduled is silently lost; whatever wasn't watched
// is recorded as a gap by oversee(). The plist holds paths only: no key, token or password.

import { spawnSync } from 'node:child_process';
import { existsSync, mkdirSync, readFileSync, realpathSync, rmSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { homedir, userInfo } from 'node:os';

// Named before Agent Ledger became Twinslip, and kept: a job turned on back then must still be
// the one that status finds and "off" removes. Nobody sees the label.
export const LAUNCH_LABEL = 'dev.agentledger.oversee';

const xmlEscape = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

export function launchAgentPlist({ nodePath, binPath, dataDir, intervalSec = 3600 }) {
  const args = [nodePath, binPath, 'oversee', '--trigger', 'launchd', '--data-dir', dataDir];
  return `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>${LAUNCH_LABEL}</string>
  <key>ProgramArguments</key>
  <array>
${args.map((a) => `    <string>${xmlEscape(a)}</string>`).join('\n')}
  </array>
  <key>StartInterval</key>
  <integer>${intervalSec}</integer>
  <key>RunAtLoad</key>
  <true/>
  <key>ProcessType</key>
  <string>Background</string>
  <key>StandardErrorPath</key>
  <string>${xmlEscape(`${dataDir}/oversee.log`)}</string>
</dict>
</plist>
`;
}

/**
 * Whether an installed job is really running: "on" alone isn't enough (a Node update can move
 * the path the job starts). running: a launchd run within 2 hours; stalled: none since.
 */
export function scheduleHealth(status, lastLaunchdRunAt, now = new Date()) {
  if (!status.installed) return { state: 'off' };
  if (status.loaded === false) return { state: 'stalled', last_run_at: lastLaunchdRunAt ?? null };
  const fresh = lastLaunchdRunAt && now - new Date(lastLaunchdRunAt) <= 2 * 3600e3;
  return { state: fresh ? 'running' : 'stalled', last_run_at: lastLaunchdRunAt ?? null };
}

/**
 * The Node the job starts. Homebrew's versioned Cellar path disappears on `brew upgrade`, so
 * prefer a link that survives it and points at this same Node: <prefix>/bin/node, else the
 * formula's <prefix>/opt/<formula>/bin/node. Anything else stays as it is.
 */
export function stableNodePath(execPath, { exists = existsSync, realpath = realpathSync } = {}) {
  const m = /^(.*)\/Cellar\/([^/]+)\/[^/]+\/bin\/node$/.exec(execPath);
  if (!m) return execPath;
  const [, prefix, formula] = m;
  const same = (p) => { try { return exists(p) && realpath(p) === realpath(execPath); } catch { return false; } };
  for (const p of [`${prefix}/bin/node`, `${prefix}/opt/${formula}/bin/node`]) if (same(p)) return p;
  return execPath;
}

const plistPath = (home) => join(home, 'Library', 'LaunchAgents', `${LAUNCH_LABEL}.plist`);

/** launchctl's answer when there was nothing to unload: fine. Anything else may leave it running. */
const notLoaded = (r) => /no such process|could not find service|not find/i.test(`${r.stderr ?? ''}${r.stdout ?? ''}`) || r.status === 3 || r.status === 113;
const unloaded = (r) => !r.error && (r.status === 0 || notLoaded(r));

/** Installed (the plist is there) and loaded (launchd has it), each said separately. */
export function scheduleStatus({ home = homedir(), platform = process.platform, run = spawnSync, uid = userInfo().uid } = {}) {
  const installed = platform === 'darwin' && existsSync(plistPath(home));
  let loaded = false;
  if (installed) {
    const r = run('launchctl', ['print', `gui/${uid}/${LAUNCH_LABEL}`], { encoding: 'utf8' });
    loaded = !r.error && r.status === 0;
  }
  return { supported: platform === 'darwin', installed, loaded, file: plistPath(home) };
}

/** Write the plist and load it. On failure, nothing is left half-installed. Returns { ok, reason?, file }. */
export function installSchedule({ home = homedir(), run = spawnSync, platform = process.platform, uid = userInfo().uid, ...opts }) {
  if (platform !== 'darwin') return { ok: false, reason: 'Background checks use macOS launchd; on other systems, keep Twinslip open or run `twinslip oversee` from your own scheduler.' };
  const file = plistPath(home);
  mkdirSync(join(home, 'Library', 'LaunchAgents'), { recursive: true });
  const previous = existsSync(file) ? readFileSync(file, 'utf8') : null; // put back if the new one fails
  if (existsSync(file)) { // replace an older one, only if it really unloaded
    const out = run('launchctl', ['bootout', `gui/${uid}/${LAUNCH_LABEL}`], { encoding: 'utf8' });
    if (!unloaded(out)) return { ok: false, reason: String(out.stderr || out.error?.message || `launchctl exited ${out.status}`).trim(), file };
  }
  writeFileSync(file, launchAgentPlist(opts), { mode: 0o644 });
  const r = run('launchctl', ['bootstrap', `gui/${uid}`, file], { encoding: 'utf8' });
  if (r.error || r.status !== 0) {
    rmSync(file, { force: true });
    if (previous !== null) { // the job that was working before, back as it was
      writeFileSync(file, previous, { mode: 0o644 });
      run('launchctl', ['bootstrap', `gui/${uid}`, file], { encoding: 'utf8' });
    }
    return { ok: false, reason: String(r.stderr || r.error?.message || `launchctl exited ${r.status}`).trim(), file };
  }
  return { ok: true, file };
}

export function removeSchedule({ home = homedir(), run = spawnSync, platform = process.platform, uid = userInfo().uid } = {}) {
  if (platform !== 'darwin') return { ok: false, reason: 'There is no background job outside macOS.' };
  const file = plistPath(home);
  const r = run('launchctl', ['bootout', `gui/${uid}/${LAUNCH_LABEL}`], { encoding: 'utf8' });
  // If it didn't unload, keep the plist so the status stays true: it may still be running.
  if (!unloaded(r)) return { ok: false, reason: String(r.stderr || r.error?.message || `launchctl exited ${r.status}`).trim(), file };
  rmSync(file, { force: true });
  return { ok: true, file };
}

const asString = (s) => `"${String(s).replace(/\\/g, '\\\\').replace(/"/g, '\\"')}"`;

/** A macOS notification. It only informs; it never acts. Silent elsewhere. */
export function notifyMac(title, body, { run = spawnSync, platform = process.platform } = {}) {
  if (platform !== 'darwin') return false;
  const r = run('osascript', ['-e', `display notification ${asString(String(body).slice(0, 240))} with title ${asString(String(title).slice(0, 120))}`], { encoding: 'utf8' });
  return Boolean(r) && !r.error && r.status === 0; // false: not shown, so oversight tries again
}

/** One plain line for the CLI: never says a job is working when it isn't. */
export function scheduleSummary(status, health) {
  if (!status.supported) return 'Background checks use macOS launchd; not available here.';
  if (!status.installed) return 'Background checks are off. Turn them on with: twinslip schedule on';
  if (status.loaded === false) return "Background checks are set up but macOS isn't running them. Turn them off and on again: twinslip schedule off, then on.";
  if (health.state !== 'running') return `Background checks are on but haven't run since ${health.last_run_at ?? 'they were set up'}. Turn them off and on again (a Node update can move them).`;
  return `Background checks are on: hourly and at login (last ran ${health.last_run_at}).`;
}
