// Export the agent bucket as import-ready files: a full CSV for spreadsheets and
// accountants, and the CSV layouts YNAB and Lunch Money import. Files only, on purpose:
// syncing into those apps would mean holding the user's API tokens.
//
// Only confirmed purchases are exported. Personal spending never leaves through here.

import { LedgerError } from './ledger.js';
import { addDays, isIsoDate } from './dates.js';

export const EXPORT_FORMATS = ['csv', 'ynab', 'lunchmoney'];

// Provenance only. Whether a purchase is verified is verified_at alone (docs/design/TRUST-PLAN.md).
const SEEN_BY = { agent: 'agent', email: 'receipt found', alert: 'bank alert found', simplefin: 'bank', csv: 'bank', phone: 'iPhone', webhook: 'webhook', manual: 'added by hand', link: 'Stripe Link', lnget: 'paid through lnget' };

/**
 * One CSV field. Text a spreadsheet would run as a formula (= + - @, tab, CR) gets a leading
 * apostrophe: merchant names come from banks and agents, never trust them to be inert.
 */
export function csvField(v) {
  if (v === null || v === undefined) return '';
  if (typeof v === 'number') return String(v);
  let s = String(v);
  if (/^[=+\-@\t\r]/.test(s)) s = `'${s}`;
  return /[",\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

const decimal = (cents) => (cents / 100).toFixed(2);
const row = (fields) => fields.map((f) => (f && f.raw !== undefined ? f.raw : csvField(f))).join(',');
const num = (s) => ({ raw: s }); // already-formatted amounts: never apostrophe-prefixed

/**
 * Returns { filename, csv, rows, skipped } for confirmed purchases with from <= date < to.
 * YNAB and Lunch Money files hold one currency (default USD); `skipped` counts the rest.
 */
export function exportPurchases(ledger, { format = 'csv', from, to, currency = 'USD' } = {}) {
  if (!EXPORT_FORMATS.includes(format)) throw new LedgerError(`format must be one of: ${EXPORT_FORMATS.join(', ')}.`);
  if (!isIsoDate(from)) throw new LedgerError('from must be a date like 2026-10-01.');
  if (!isIsoDate(to)) throw new LedgerError('to must be a date like 2026-11-01.');
  if (from >= to) throw new LedgerError('from must be before to.');
  if (!/^[A-Z]{3}$/.test(currency)) throw new LedgerError('currency must be a 3-letter code like USD.');

  const all = ledger.confirmedPurchases({ from, to }).reverse(); // oldest first, like a statement
  const skipped = {};
  const picked = format === 'csv' ? all : all.filter((p) => {
    if (p.currency === currency) return true;
    skipped[p.currency] = (skipped[p.currency] ?? 0) + 1;
    return false;
  });
  const verified = (p) => Boolean(p.verified_at);
  const memo = (p) => `Agent: ${p.agent_name}${p.job ? ` · Job: ${p.job}` : ''}${verified(p) ? ' · verified' : ''} · Twinslip`;

  let lines;
  if (format === 'csv') {
    // Job is last, so a spreadsheet that reads the earlier columns by position keeps working.
    lines = [row(['Date', 'Merchant', 'Amount', 'Currency', 'Agent', 'Payment method', 'Verified', 'Seen by', 'Receipts', 'Ledger ID', 'Job'])];
    for (const p of picked) {
      const seen = [...new Set([p.source_kind, ...(p.also_seen_by ? p.also_seen_by.split(',') : [])].map((k) => SEEN_BY[k] ?? k))];
      lines.push(row([p.occurred_on, p.merchant, num(decimal(p.amount_cents)), p.currency, p.agent_name, p.payment_method ?? '',
        verified(p) ? 'yes' : 'no', seen.join(', '), p.receipt_count, p.id, p.job ?? '']));
    }
  } else if (format === 'ynab') {
    lines = [row(['Date', 'Payee', 'Memo', 'Outflow', 'Inflow'])];
    for (const p of picked) {
      const out = p.amount_cents >= 0;
      lines.push(row([p.occurred_on, p.merchant, memo(p), num(out ? decimal(p.amount_cents) : ''), num(out ? '' : decimal(-p.amount_cents))]));
    }
  } else {
    lines = [row(['date', 'payee', 'amount', 'notes', 'tags'])];
    for (const p of picked) {
      lines.push(row([p.occurred_on, p.merchant, num(decimal(p.amount_cents)), memo(p), `Twinslip,Agent: ${p.agent_name}`]));
    }
  }
  ledger.track('exported', { format, rows: picked.length });
  const last = addDays(to, -1);
  return {
    filename: `twinslip${format === 'csv' ? '' : `-${format}`}-${from}_to_${last}.csv`,
    csv: `${lines.join('\r\n')}\r\n`,
    rows: picked.length,
    skipped,
  };
}
