// Free text from agents, capture and bank lines can carry things that must never be stored:
// card numbers, keys, tokens. Strip them before anything reaches the database.

/** Card numbers: 13–19 digits (spaces, dots, slashes or dashes between) that pass the Luhn check. */
const CARDISH = /\b\d(?:[ ./-]?\d){12,18}\b/g;
function luhn(digits) {
  let sum = 0;
  for (let i = 0; i < digits.length; i++) {
    let d = Number(digits[digits.length - 1 - i]);
    if (i % 2) { d *= 2; if (d > 9) d -= 9; }
    sum += d;
  }
  return sum % 10 === 0;
}

const SECRETISH = [
  /\b(?:sk|pk|rk)[-_](?:live|test|proj|ant)?[-_]?[A-Za-z0-9_-]{12,}/g, // Stripe, OpenAI, Anthropic keys
  /\bxox[abpr]-[A-Za-z0-9-]{10,}/g,                             // Slack
  /\bgh[pousr]_[A-Za-z0-9]{20,}/g,                              // GitHub
  /\bgithub_pat_[A-Za-z0-9_]{20,}/g,
  /\bglpat-[A-Za-z0-9_-]{20,}/g,                                // GitLab
  /\bAKIA[0-9A-Z]{16}\b/g,                                      // AWS access key id
  /\bAIza[0-9A-Za-z_-]{30,}/g,                                  // Google
  /\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{4,}\.[A-Za-z0-9_-]{4,}/g, // JWT
  /\bnpm_[A-Za-z0-9]{30,}/g,
  /\bhf_[A-Za-z0-9]{20,}/g,                                     // Hugging Face
  /\bwhsec_[A-Za-z0-9+/=]{16,}/g,                               // webhook signing secrets
  /\bBearer\s+[A-Za-z0-9._~+/=-]{16,}/gi,
];

/** Strip card numbers and keys. Normal text is unchanged, and redacting twice changes nothing. */
export function redact(text) {
  // Fullwidth digits (０-９) read as digits, so they can't sneak a card number past.
  let s = String(text ?? '').replace(/[０-９]/g, (d) => String.fromCharCode(d.charCodeAt(0) - 0xFEE0));
  // An order number of the same length that fails the check is left alone.
  s = s.replace(CARDISH, (m) => (luhn(m.replace(/\D/g, '')) ? '[redacted]' : m));
  for (const re of SECRETISH) s = s.replace(re, '[redacted]');
  return s;
}
