// The beta report: the only way usage data leaves the machine, and only when the user
// copies it and sends it themselves. Counts, rates, durations and one coarse spend
// bucket. No merchant names, no exact amounts, no agent names, no descriptions.
// Definitions live in docs/METRICS.md — keep them in sync.

import { getMeta } from './db.js';
import { proState } from './pro.js';
import { addDays, addMonths, isoWeekLabel, monthKey, toLocalDate, weekStart } from './dates.js';

export const REPORT_VERSION = 1;
const SPEND_BUCKETS = [[0, '0'], [1, '<$20'], [2000, '$20–100'], [10000, '$100–500'], [50000, '$500–2,000'], [200000, '$2,000+']];

function bucketSpend(cents) {
  let label = SPEND_BUCKETS[0][1];
  for (const [min, l] of SPEND_BUCKETS) if (cents >= min) label = l;
  return label;
}

/** SQL: did a source of one of `kinds` see purchase `p`, as its own source or a merged copy? */
const WITNESS = (p, kinds) => `EXISTS (SELECT 1 FROM purchases w JOIN sources ws ON ws.id = w.source_id
  WHERE (w.id = ${p}.id OR w.merged_into = ${p}.id) AND ws.kind IN ${kinds})`;

const hoursBetween = (a, b) => Math.round(((new Date(b) - new Date(a)) / 3600000) * 10) / 10;

function median(xs) {
  if (!xs.length) return null;
  const s = [...xs].sort((a, b) => a - b);
  const mid = Math.floor(s.length / 2);
  return s.length % 2 ? s[mid] : Math.round(((s[mid - 1] + s[mid]) / 2) * 10) / 10;
}

export function betaReport(ledger, { appVersion = '0.0.0' } = {}) {
  const db = ledger.db;
  const now = ledger.now();
  const installedAt = getMeta(db, 'installed_at');
  const events = db.prepare('SELECT at, name, props FROM events ORDER BY id').all()
    .map((e) => ({ ...e, props: JSON.parse(e.props) }));
  const first = (pred) => events.find(pred)?.at ?? null;

  // Activation: a capture source is connected AND the user has tapped "yes" on at least
  // one agent purchase. That is the moment the product has answered its question once.
  // With agents reporting their own purchases, the first agent report that counts is that
  // moment too: the first positive purchase in Agents with an agent report anywhere in its
  // evidence, at the later of the report and the moment it counted. A refund or a claim still
  // waiting for the user doesn't count until it does; read from the purchases, never the log.
  const firstSource = first((e) => e.name === 'source_connected');
  const firstYes = first((e) => e.name === 'attribution' && e.props.via === 'tap' && e.props.result !== 'no');
  const firstAgentReport = db.prepare(`
    SELECT min(max(COALESCE(p.attributed_at, p.created_at),
               (SELECT min(w.created_at) FROM purchases w JOIN sources ws ON ws.id = w.source_id
                 WHERE (w.id = p.id OR w.merged_into = p.id) AND ws.kind = 'agent'))) AS at
    FROM purchases p WHERE p.status = 'confirmed' AND p.amount_cents > 0
      AND EXISTS (SELECT 1 FROM purchases w JOIN sources ws ON ws.id = w.source_id
                  WHERE (w.id = p.id OR w.merged_into = p.id) AND ws.kind = 'agent')`).get().at ?? null;
  const byTap = firstSource && firstYes ? (firstSource > firstYes ? firstSource : firstYes) : null;
  const activatedAt = [byTap, firstAgentReport].filter(Boolean).sort()[0] ?? null;

  // Weekly activity, Monday-start weeks since install.
  const today = toLocalDate(now);
  const installDay = toLocalDate(new Date(installedAt));
  const ACTIONS = new Set(['attribution', 'pulled_in', 'manual_added', 'receipt_added', 'csv_imported']);
  const weeks = [];
  for (let w = weekStart(installDay); w <= today; w = addDays(w, 7)) {
    const end = addDays(w, 7);
    const inWeek = events.filter((e) => {
      const d = toLocalDate(new Date(e.at));
      return d >= w && d < end;
    });
    weeks.push({
      week: isoWeekLabel(w),
      opened: inWeek.some((e) => e.name === 'ui_view'),
      acted: inWeek.some((e) => ACTIONS.has(e.name)),
      days_opened: new Set(inWeek.filter((e) => e.name === 'ui_view').map((e) => toLocalDate(new Date(e.at)))).size,
    });
  }

  // Confirm loop: of what we put in the inbox, how much got sorted, how fast, and how
  // often were we right that it was agent spend.
  const surfaced = db.prepare(`SELECT status, attributed_by, surfaced_at, attributed_at FROM purchases
    WHERE surfaced_at IS NOT NULL`).all();
  const resolved = surfaced.filter((p) => p.status !== 'candidate');
  const yes = resolved.filter((p) => p.status === 'confirmed');
  const within7d = resolved.filter((p) => hoursBetween(p.surfaced_at, p.attributed_at) <= 168);
  const taps = events.filter((e) => e.name === 'attribution' && e.props.via === 'tap');
  const rate = (a, b) => (b ? Math.round((a / b) * 1000) / 1000 : null);

  // Coarse spend signal for the last full month.
  const thisMonth = monthKey(today);
  const lastMonth = addMonths(thisMonth, -1);
  const usd = db.prepare(`SELECT coalesce(sum(amount_cents), 0) AS c FROM purchases
    WHERE status = 'confirmed' AND currency = 'USD' AND occurred_on >= ? AND occurred_on < ?`)
    .get(`${lastMonth}-01`, `${thisMonth}-01`).c;

  const sources = db.prepare('SELECT id, kind, last_success_at FROM sources').all().map((s) => ({
    kind: s.kind,
    hours_since_last_success: s.last_success_at ? hoursBetween(s.last_success_at, now.toISOString()) : null,
  }));
  const count = (name, pred = () => true) => events.filter((e) => e.name === name && pred(e)).length;

  return {
    report_version: REPORT_VERSION,
    app_version: appVersion,
    install_id: getMeta(db, 'install_id'),
    generated_at: now.toISOString(),
    days_since_install: Math.floor(hoursBetween(installedAt, now.toISOString()) / 24),
    activation: {
      activated: Boolean(activatedAt),
      hours_install_to_source: firstSource ? hoursBetween(installedAt, firstSource) : null,
      hours_install_to_activation: activatedAt ? hoursBetween(installedAt, activatedAt) : null,
      hours_install_to_first_agent_purchase: firstAgentReport ? hoursBetween(installedAt, firstAgentReport) : null,
    },
    weekly: {
      weeks,
      weeks_opened: weeks.filter((w) => w.opened).length,
      weeks_acted: weeks.filter((w) => w.acted).length,
      weeks_total: weeks.length,
    },
    confirm: {
      surfaced: surfaced.length,
      resolved: resolved.length,
      still_waiting: surfaced.length - resolved.length,
      resolution_rate: rate(resolved.length, surfaced.length),
      resolved_within_7d_rate: rate(within7d.length, surfaced.length),
      yes_rate: rate(yes.length, resolved.length),
      taps_yes: taps.filter((e) => e.props.result === 'yes').length,
      taps_reassign: taps.filter((e) => e.props.result === 'reassign').length,
      taps_no: taps.filter((e) => e.props.result === 'no').length,
      // Inbox burden: decisions the user had to make. A batch confirm is one tap.
      inbox_decisions: taps.length + count('inbox_batch'),
      inbox_decisions_per_week: Math.round(((taps.length + count('inbox_batch')) / Math.max(1, weeks.length)) * 10) / 10,
      batch_confirmed: events.filter((e) => e.name === 'inbox_batch').reduce((s, e) => s + (e.props.n ?? 0), 0),
      median_hours_to_resolve: median(resolved.map((p) => hoursBetween(p.surfaced_at, p.attributed_at))),
      auto_attributed_by_rule: db.prepare("SELECT count(*) AS n FROM purchases WHERE attributed_by = 'rule' AND status = 'confirmed'").get().n,
      rules: db.prepare('SELECT count(*) AS n FROM rules').get().n,
      pulled_in: count('pulled_in'),
      manual_added: count('manual_added'),
      undone: count('attribution_undone'),
    },
    capture: {
      sources,
      // Where counted purchases came from first, and how often a second source confirmed them.
      // Match and miss follow the whole evidence graph (a purchase plus its merged copies), so
      // the order the witnesses arrived in never changes the answer.
      counted_by_first_source: Object.fromEntries(db.prepare(`
        SELECT CASE WHEN s.kind IN ('simplefin', 'csv') THEN 'bank' ELSE s.kind END AS k, count(*) AS n
        FROM purchases p JOIN sources s ON s.id = p.source_id WHERE p.status = 'confirmed' GROUP BY k`).all().map((r) => [r.k, r.n])),
      agent_reports: count('agent_reported'),
      agent_reports_verified_rate: (() => {
        const r = db.prepare(`SELECT count(*) AS n, count(c.verified_at) AS v FROM purchases p JOIN sources s ON s.id = p.source_id
          JOIN purchases c ON c.id = COALESCE(p.merged_into, p.id) WHERE s.kind = 'agent'`).get();
        return rate(r.v, r.n);
      })(),
      bank_charges_agents_missed: db.prepare(`SELECT count(*) AS n FROM purchases p
        WHERE p.status = 'confirmed' AND ${WITNESS('p', "('simplefin', 'csv')")} AND NOT ${WITNESS('p', "('agent')")}
          AND EXISTS (SELECT 1 FROM sources a WHERE a.kind = 'agent')`).get().n,
      // THE TWO NUMBERS (the moat, quantified). Match rate is agent_reports_verified_rate above.
      // Miss rate: of every purchase that ended up in the agent bucket, the share no agent
      // reported (another source caught it and the user or a rule put it there).
      agent_miss_rate: (() => {
        const r = db.prepare(`SELECT count(*) AS n, sum(CASE WHEN ${WITNESS('p', "('agent')")} THEN 0 ELSE 1 END) AS missed
          FROM purchases p WHERE p.status = 'confirmed' AND EXISTS (SELECT 1 FROM sources a WHERE a.kind = 'agent')`).get();
        return rate(r.missed ?? 0, r.n);
      })(),
      captured_by_source: Object.fromEntries(['phone', 'alert', 'webhook'].map((k) => [k, count('captured', (e) => e.props.source === k)])),
      // Sweeps an agent finished (docs/design/AGENT-SETUP-PLAN.md), counts only.
      receipt_sweeps: db.prepare("SELECT count(*) AS n FROM sweeps WHERE kind = 'receipts'").get().n,
      bank_alert_sweeps: db.prepare("SELECT count(*) AS n FROM sweeps WHERE kind = 'bank_alerts'").get().n,
      mcp_connections: count('mcp_connected'),
      syncs_ok: count('sync_completed'),
      syncs_failed: count('sync_failed'),
      csv_imports: count('csv_imported'),
      receipts: db.prepare('SELECT count(*) AS n FROM receipts').get().n,
    },
    usage: {
      agents: db.prepare('SELECT count(*) AS n FROM agents').get().n,
      confirmed_purchases: db.prepare("SELECT count(*) AS n FROM purchases WHERE status = 'confirmed'").get().n,
      last_full_month: lastMonth,
      last_full_month_usd_spend_bucket: bucketSpend(usd),
      share_cards: count('share_card'),
      pro: proState(ledger).pro,
    },
  };
}
