import { createHash } from 'node:crypto';
import { mkdirSync, writeFileSync, existsSync } from 'node:fs';
import { join } from 'node:path';
import { LedgerError } from './ledger.js';

// Receipts are copies of files the user chose, kept next to the ledger. They are
// served back only as downloads or sandboxed inline previews (see server.js).

export const MAX_RECEIPT_BYTES = 10 * 1024 * 1024;

export const RECEIPT_TYPES = {
  'application/pdf': '.pdf',
  'image/png': '.png',
  'image/jpeg': '.jpg',
  'image/webp': '.webp',
  'image/gif': '.gif',
  'text/plain': '.txt',
  'message/rfc822': '.eml',
  'text/html': '.html',
};

export function receiptsDir(dataDir) {
  return join(dataDir, 'receipts');
}

export function addReceipt(ledger, purchaseId, { filename, mime, bytes }) {
  if (!ledger.dataDir) throw new LedgerError('Receipts need a data directory.', 500);
  const p = ledger.getPurchase(purchaseId);
  if (!(bytes instanceof Uint8Array) || bytes.length === 0) throw new LedgerError('Empty file.');
  if (bytes.length > MAX_RECEIPT_BYTES) throw new LedgerError('Receipts are limited to 10 MB.', 413);
  const type = String(mime ?? '').split(';')[0].trim().toLowerCase();
  const ext = RECEIPT_TYPES[type];
  if (!ext) throw new LedgerError('Receipts can be PDF, image, text, .eml or HTML files.', 415);
  const sha256 = createHash('sha256').update(bytes).digest('hex');
  const dir = receiptsDir(ledger.dataDir);
  mkdirSync(dir, { recursive: true, mode: 0o700 });
  const storedName = `${sha256}${ext}`;
  const path = join(dir, storedName);
  if (!existsSync(path)) writeFileSync(path, bytes, { mode: 0o600 });
  const cleanName = String(filename ?? 'receipt').replace(/[^\w.\- ()]+/g, '_').slice(0, 120) || 'receipt';
  ledger.db.prepare(`INSERT OR IGNORE INTO receipts (purchase_id, filename, stored_name, mime, bytes, sha256, added_at)
    VALUES (?, ?, ?, ?, ?, ?, ?)`).run(p.id, cleanName, storedName, type, bytes.length, sha256, ledger.now().toISOString());
  ledger.attachedReceipt(p.id); // a file the user chose: proof the agent didn't supply
  ledger.track('receipt_added');
  return listReceipts(ledger, p.id);
}

export function listReceipts(ledger, purchaseId) {
  return ledger.db.prepare('SELECT id, filename, mime, bytes, added_at FROM receipts WHERE purchase_id = ? ORDER BY id')
    .all(Number(purchaseId));
}

export function getReceipt(ledger, id) {
  const r = ledger.db.prepare('SELECT * FROM receipts WHERE id = ?').get(Number(id));
  if (!r) throw new LedgerError('No such receipt.', 404);
  return { ...r, path: join(receiptsDir(ledger.dataDir), r.stored_name) };
}
