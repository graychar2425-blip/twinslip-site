// The tax pack (Pro): one ZIP an accountant can take as-is. A summary PDF, a CSV where
// every row says how it was verified, and the receipt files themselves. Records, not advice.

import { readFileSync, existsSync } from 'node:fs';
import { csvField } from './export.js';
import { makePdf } from './pdf.js';
import { zip } from './zip.js';
import { listReceipts, getReceipt } from './receipts.js';
import { formatCents } from './money.js';
import { toLocalDate } from './dates.js';
import { LedgerError } from './ledger.js';

// Provenance only. Whether a purchase is verified is verified_at alone (docs/design/TRUST-PLAN.md).
const SEEN_BY = { agent: 'agent report', email: 'receipt an agent found', simplefin: 'bank', csv: 'bank', manual: 'added by hand', phone: 'iPhone', alert: 'bank alert an agent found', webhook: 'webhook' };
const safe = (s) => String(s).replace(/[^A-Za-z0-9._-]+/g, '-').replace(/-+/g, '-').slice(0, 60);

export function buildTaxPack(ledger, { year }) {
  const y = Number(year);
  if (!Number.isInteger(y) || y < 2000 || y > 2100) throw new LedgerError('year must look like 2026.');
  const from = `${y}-01-01`;
  const to = `${y + 1}-01-01`;
  const purchases = ledger.confirmedPurchases({ from, to }).reverse();
  const verified = (p) => Boolean(p.verified_at);

  // CSV with provenance, and the receipt files it points to.
  const files = [];
  const rows = [['Date', 'Merchant', 'Amount', 'Currency', 'Agent', 'Payment method', 'Verified', 'Seen by', 'Receipt files', 'Ledger ID']];
  for (const p of purchases) {
    const names = [];
    if (ledger.dataDir) {
      for (const r of listReceipts(ledger, p.id)) {
        const full = getReceipt(ledger, r.id);
        if (!existsSync(full.path)) continue;
        const name = `receipts/${p.occurred_on}_${safe(p.merchant)}_${p.id}_${safe(r.filename)}`;
        files.push({ name, data: readFileSync(full.path) });
        names.push(name);
      }
    }
    const seen = [...new Set([p.source_kind, ...(p.also_seen_by ? p.also_seen_by.split(',') : [])].map((k) => SEEN_BY[k] ?? k))];
    rows.push([p.occurred_on, p.merchant, { raw: (p.amount_cents / 100).toFixed(2) }, p.currency, p.agent_name, p.payment_method ?? '',
      verified(p) ? 'yes' : 'no', seen.join(', '), names.join('; '), p.id]);
  }
  const csv = `${rows.map((r) => r.map((f) => (f && f.raw !== undefined ? f.raw : csvField(f))).join(',')).join('\r\n')}\r\n`;

  // Summary numbers, per currency (never added across currencies).
  const by = (keyFn) => {
    const m = new Map();
    for (const p of purchases) {
      const k = `${keyFn(p)}|${p.currency}`;
      const t = m.get(k) ?? { label: keyFn(p), currency: p.currency, cents: 0, n: 0, verified: 0 };
      t.cents += p.amount_cents; t.n++; if (verified(p)) t.verified++;
      m.set(k, t);
    }
    return [...m.values()].sort((a, b) => b.cents - a.cents);
  };
  const totals = by(() => 'All agent spending');
  // Paying with crypto is itself a disposal in the US (IRS Notice 2014-21) and many other
  // countries, so the accountant needs to know which rows were paid that way.
  const crypto = purchases.filter((p) => p.payment_method === 'crypto').length;
  const lines = [
    { text: `Twinslip tax pack ${y}`, size: 20, bold: true },
    { text: `Agent purchases from ${from} to ${y}-12-31. Prepared on ${toLocalDate(ledger.now())}.`, gap: 4 },
    { text: 'These are records of what your AI agents spent, with the evidence for each. They are not tax advice;' },
    { text: 'your accountant decides how each expense is treated.' },
    { text: 'Totals', size: 13, bold: true, gap: 10 },
    ...(totals.length ? totals.map((t) => ({ text: `${t.n} purchases, ${t.verified} independently verified (${Math.round((t.verified / t.n) * 100)}%)`, right: formatCents(t.cents, t.currency) })) : [{ text: 'No agent purchases this year.' }]),
    { text: 'By agent', size: 13, bold: true, gap: 10 },
    ...by((p) => p.agent_name).map((t) => ({ text: `${t.label} (${t.n})`, right: formatCents(t.cents, t.currency) })),
    { text: 'By merchant', size: 13, bold: true, gap: 10 },
    ...by((p) => p.merchant).slice(0, 40).map((t) => ({ text: `${t.label} (${t.n})`, right: formatCents(t.cents, t.currency) })),
    { text: 'By month', size: 13, bold: true, gap: 10 },
    ...by((p) => p.occurred_on.slice(0, 7)).sort((a, b) => a.label.localeCompare(b.label)).map((t) => ({ text: t.label, right: formatCents(t.cents, t.currency) })),
    ...(crypto ? [
      { text: 'Paid in crypto', size: 13, bold: true, gap: 10 },
      { text: `${crypto} ${crypto === 1 ? 'purchase was' : 'purchases were'} paid in crypto (the CSV's payment method says "crypto").` },
      { text: 'In the US and many other countries, paying with crypto counts as disposing of it, so each' },
      { text: 'payment can mean a gain or loss to report. Your accountant will need what you first paid for' },
      { text: 'that crypto, which this ledger does not track.' },
    ] : []),
    { text: 'What is in this pack', size: 13, bold: true, gap: 10 },
    { text: `agent-purchases-${y}.csv: every purchase, its agent, how it was paid, and what verified it.` },
    { text: `receipts/: ${files.length} receipt file${files.length === 1 ? '' : 's'}, named by date, merchant and ledger ID.` },
    { text: '"Verified" means something the agent did not supply saw the charge: a bank line, the iPhone,' },
    { text: 'or a receipt file attached by hand. Receipts an agent found are listed as evidence.' },
    { text: 'Keep this pack with your records for as long as your tax authority requires (often 3 to 7 years).' },
  ];
  const pdf = makePdf(lines, { title: `Twinslip tax pack ${y}`, footer: `Twinslip tax pack ${y}` });
  const readme = [
    `Twinslip tax pack ${y}`,
    '',
    `summary-${y}.pdf          Totals by agent, merchant and month.`,
    `agent-purchases-${y}.csv  One row per purchase, with what verified it and its receipt files.`,
    'receipts/                 The receipt files, named by date, merchant and ledger ID.',
    '',
    'Records, not tax advice. Made on your own computer; nothing was uploaded.',
    '',
  ].join('\n');
  const buffer = zip([
    { name: 'README.txt', data: readme },
    { name: `summary-${y}.pdf`, data: pdf },
    { name: `agent-purchases-${y}.csv`, data: csv },
    ...files,
  ], { now: ledger.now() });
  ledger.track('taxpack_built', { year: y });
  return { filename: `Twinslip-tax-pack-${y}.zip`, buffer, purchases: purchases.length, receipts: files.length };
}
