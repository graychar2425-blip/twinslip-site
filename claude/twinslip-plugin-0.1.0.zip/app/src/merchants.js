// Candidate detection. A bank feed is mostly personal spending; the inbox must only ask
// about charges that plausibly came from an agent. This list is a starting heuristic —
// the user's own confirmations ("always" rules, and merchants they've confirmed before)
// quickly matter more than anything here.
//
// Patterns run against the uppercased bank description + payee. Word boundaries matter:
// \bAWS\b must not match "LAWSON", and "CLAUDE" alone would match "CLAUDE'S DINER".

export const KNOWN_AGENT_MERCHANTS = [
  // Model providers
  { name: 'OpenAI', patterns: [/\bOPENAI\b/, /\bCHATGPT\b/] },
  { name: 'Anthropic', patterns: [/\bANTHROPIC\b/, /\bCLAUDE\.AI\b/] },
  { name: 'Google Gemini', patterns: [/\bGEMINI API\b/, /\bGOOGLE \*?(?:AI STUDIO|GEMINI)\b/] },
  { name: 'Mistral', patterns: [/\bMISTRAL AI\b/, /\bMISTRAL\.AI\b/] },
  { name: 'Cohere', patterns: [/\bCOHERE\b/] },
  { name: 'xAI', patterns: [/\bX\.AI\b/, /\bXAI\b/] },
  { name: 'Perplexity', patterns: [/\bPERPLEXITY\b/] },
  // Inference platforms and routers
  { name: 'OpenRouter', patterns: [/\bOPENROUTER\b/] },
  { name: 'Replicate', patterns: [/\bREPLICATE\b/] },
  { name: 'Together AI', patterns: [/\bTOGETHER\.?AI\b/, /\bTOGETHER COMPUTER\b/] },
  { name: 'Groq', patterns: [/\bGROQ\b/] },
  { name: 'Fireworks AI', patterns: [/\bFIREWORKS\.?AI\b/] },
  { name: 'Hugging Face', patterns: [/\bHUGGING ?FACE\b/, /\bHUGGINGFACE\b/] },
  { name: 'Modal', patterns: [/\bMODAL LABS\b/, /\bMODAL\.COM\b/] },
  { name: 'RunPod', patterns: [/\bRUNPOD\b/] },
  // Agent tools: browsing, search, scraping, voice
  { name: 'Browserbase', patterns: [/\bBROWSERBASE\b/] },
  { name: 'Exa', patterns: [/\bEXA\.AI\b/, /\bEXA LABS\b/] },
  { name: 'Tavily', patterns: [/\bTAVILY\b/] },
  { name: 'Firecrawl', patterns: [/\bFIRECRAWL\b/] },
  { name: 'Apify', patterns: [/\bAPIFY\b/] },
  { name: 'SerpApi', patterns: [/\bSERPAPI\b/] },
  { name: 'ElevenLabs', patterns: [/\bELEVEN ?LABS\b/] },
  { name: 'Deepgram', patterns: [/\bDEEPGRAM\b/] },
  { name: 'AssemblyAI', patterns: [/\bASSEMBLY ?AI\b/] },
  { name: 'Twilio', patterns: [/\bTWILIO\b/] },
  // Coding agents and agent platforms
  { name: 'Cursor', patterns: [/\bCURSOR\b.*\bAI\b/, /\bANYSPHERE\b/, /\bCURSOR\.COM\b/] },
  { name: 'GitHub', patterns: [/\bGITHUB\b/] },
  { name: 'Replit', patterns: [/\bREPLIT\b/] },
  { name: 'Lovable', patterns: [/\bLOVABLE\b/] },
  { name: 'Cognition (Devin)', patterns: [/\bCOGNITION AI\b/, /\bDEVIN\.AI\b/] },
  { name: 'Manus', patterns: [/\bMANUS\.?AI\b/, /\bMANUS IM\b/] },
  { name: 'Zapier', patterns: [/\bZAPIER\b/] },
  { name: 'n8n', patterns: [/\bN8N\b/] },
  { name: 'Make', patterns: [/\bMAKE\.COM\b/, /\bCELONIS\b.*\bMAKE\b/] },
  // Infra agents commonly run on
  { name: 'Vercel', patterns: [/\bVERCEL\b/] },
  { name: 'Cloudflare', patterns: [/\bCLOUDFLARE\b/] },
  { name: 'AWS', patterns: [/\bAWS\b/, /\bAMAZON WEB SERVICES\b/] },
  { name: 'Google Cloud', patterns: [/\bGOOGLE \*?CLOUD\b/, /\bGOOGLE CLOUD\b/] },
  { name: 'Microsoft Azure', patterns: [/\bMICROSOFT \*?AZURE\b/, /\bAZURE\b/] },
  { name: 'DigitalOcean', patterns: [/\bDIGITALOCEAN\b/] },
  { name: 'Pinecone', patterns: [/\bPINECONE\b/] },
  { name: 'Supabase', patterns: [/\bSUPABASE\b/] },
];

export function detectKnownMerchant(text) {
  const upper = String(text ?? '').toUpperCase();
  for (const m of KNOWN_AGENT_MERCHANTS) {
    if (m.patterns.some((p) => p.test(upper))) return m.name;
  }
  return null;
}

// Card processors prefix the real merchant: "PAYPAL *OPENAI", "SQ *COFFEE", "TST* CAFE".
const PROCESSOR_PREFIX = /^(?:PAYPAL|PP|SQ|TST|SP|DD|GOOGLE|APPLE\.COM\/BILL|APL\*)\s*\*\s*/;
const BANK_NOISE = [
  /^(?:POS|ACH|DEBIT|CREDIT)\s+(?:PURCHASE|DEBIT|CARD)?\s*/,
  /^(?:CHECKCARD|CHECK CARD)\s+\d{4}\s*/,
  /^PURCHASE AUTHORIZED ON \d{2}\/\d{2}\s*/,
  /^DEBIT CARD PURCHASE\s*-?\s*/,
  /^RECURRING PAYMENT\s*-?\s*/,
];

/**
 * A stable key for "the same merchant", used for rules and learned candidates.
 * Known merchants collapse to their canonical name; everything else is the description
 * with processor prefixes, reference numbers and locations stripped.
 */
export function merchantKey(description, payee) {
  const known = detectKnownMerchant(`${payee ?? ''} ${description ?? ''}`);
  if (known) return known.toUpperCase();
  let s = String(payee || description || '').toUpperCase().trim();
  for (const re of BANK_NOISE) s = s.replace(re, '');
  s = s.replace(PROCESSOR_PREFIX, '');
  const tokens = s
    .replace(/[^A-Z0-9&.' ]+/g, ' ')
    .split(/\s+/)
    .filter((t) => t && !/\d/.test(t) && !/^[A-Z]{2}$/.test(t)); // drop refs and state codes
  return tokens.slice(0, 3).join(' ').replace(/\.$/, '') || s.slice(0, 32) || 'UNKNOWN';
}

function titleCase(s) {
  return s.toLowerCase().replace(/\b([a-z])/g, (c) => c.toUpperCase());
}

export function displayMerchant(description, payee) {
  const known = detectKnownMerchant(`${payee ?? ''} ${description ?? ''}`);
  if (known) return known;
  if (payee && String(payee).trim()) return String(payee).trim().slice(0, 80);
  const key = merchantKey(description, null);
  return titleCase(key).slice(0, 80);
}
