// The first five minutes, as a checklist that ticks itself. Each step is read from what
// actually happened (an agent connected, a purchase arrived), never from a button the
// user pressed, so a tick always means that link works.

import { getMeta } from './db.js';

export function onboarding(ledger) {
  const db = ledger.db;
  const any = (sql) => Boolean(db.prepare(sql).get());
  const steps = [
    // The one step everyone needs, with or without an agent: something is in the ledger.
    { id: 'first_expense', optional: false, done: any("SELECT 1 FROM purchases WHERE status != 'merged' LIMIT 1") },
    // An agent is optional: a person tracking only their own spending is finished without one.
    { id: 'agent', optional: true, done: any('SELECT 1 FROM agents LIMIT 1') },
    { id: 'connected', optional: true, done: any("SELECT 1 FROM sources WHERE kind = 'agent' AND last_attempt_at IS NOT NULL LIMIT 1") || any('SELECT 1 FROM capture_checks LIMIT 1') },
    {
      id: 'first_purchase',
      optional: true,
      done: any(`SELECT 1 FROM purchases p JOIN sources s ON s.id = p.source_id
                 WHERE s.kind = 'agent' AND p.status IN ('confirmed', 'merged') LIMIT 1`),
    },
    // Optional; the ledger works without them. The email sweeps (receipts and bank alerts your
    // agent finds) are evidence that catches forgotten purchases. The bank and the iPhone are what
    // earn the ✓. A finished sweep counts even when it found nothing: the agent looked.
    { id: 'receipts', optional: true, done: any("SELECT 1 FROM sources WHERE kind IN ('email', 'alert') AND last_success_at IS NOT NULL LIMIT 1") || any('SELECT 1 FROM sweeps LIMIT 1') },
    { id: 'bank', optional: true, done: any("SELECT 1 FROM sources WHERE kind IN ('simplefin', 'csv') AND last_success_at IS NOT NULL LIMIT 1") },
    { id: 'phone', optional: true, done: any("SELECT 1 FROM sources WHERE kind = 'phone' AND last_success_at IS NOT NULL LIMIT 1") },
  ];
  const done = steps.filter((s) => s.done).length;
  return {
    steps,
    done,
    total: steps.length,
    complete: steps.every((s) => s.optional || s.done), // finished: every required step done
    all_done: done === steps.length,
    dismissed: getMeta(db, 'onboarding_dismissed') === '1',
  };
}
