// The free plan's limits (docs/PRODUCT.md §2, decided by Daniel on 2026-10-23).
//
// Free covers one agent and one bank or card account: enough to prove the product end to end
// (an agent records, a statement file verifies). Pro covers every account and the agents its key
// covers: 3 per seat, plus any extra agents bought with it (src/pro.js; Daniel, 2026-10-23).
// Agents beyond what the key covers are treated exactly like agents beyond Free.
//
// Which agents are covered: places ("slots"). The first is the free agent (the one Free covers);
// Pro adds the rest. The user chooses who sits in each; an empty place fills with the next agent
// that reports, in order of first activity, and stays pinned. A place can change hands once every
// 30 days, on any plan, so rotating agents through it can't count every agent's purchases; filling
// an empty place, and swapping which covered agent is the free one, are never limited. Places a
// lapsed or smaller key no longer covers are remembered, so renewing covers the same agents.
//
// Nothing is ever lost or hidden at the limit:
//   - A purchase that would count for an agent the free plan doesn't cover is saved in full and
//     waits in the inbox (status 'candidate', match_reason 'over_free_limit', held_agent_id the
//     agent). It counts in neither bucket until it's sorted, like anything else waiting, and every
//     total that leaves it out says how much is waiting (heldSpend). Pro, or choosing that agent
//     as the free one, counts it for its agent at once.
//   - A second account's statement file is read and kept in full: its lines are listed, sorted
//     and matched like any other, so nothing is counted twice. On Free they don't verify agent
//     purchases; the free account's do. Pro lets every account verify.
//   - History and plain CSV export are never limited. A ledger that already had several agents
//     keeps every purchase it counted; only new attribution beyond the limit waits.
//
// What an "account" is: each bank or card account the user adds as a verifying source. A source
// row of kind 'csv' is one account (the user names it when importing its statement file; every
// import before accounts were named is one account), and Stripe Link's wallet ('link') is one.
// Not accounts: the iPhone, the local webhook, receipts the user attaches, bank alerts and
// receipts an agent finds, and the retired bank feed (its records keep their ✓).

import { getMeta, setMeta, tx, INDEPENDENT_SQL } from './db.js';
import { proState } from './pro.js';
import { LedgerError } from './ledger.js';
import { flagIfOutside } from './mandates.js';
import { redact } from './redact.js';

export const FREE_AGENTS = 1;
export const FREE_ACCOUNTS = 1;
/** Each source row of these kinds is one bank or card account. */
export const ACCOUNT_KINDS = ['csv', 'link'];
/** The match_reason of a purchase waiting because the free plan doesn't cover its agent. */
export const HELD = 'over_free_limit';

const FREE_AGENT_KEY = 'free_agent_id';
const SLOTS_KEY = 'pro_agent_slots'; // JSON [{ id, changed_at }]: the places after the free agent's
const FREE_ACCOUNT_KEY = 'free_account_source_id';
const APPLIED_KEY = 'plan_applied';

export const isPro = (ledger) => proState(ledger).pro;

/** How many agents the plan covers: 1 on Free; on Pro, what the key covers. */
export function agentLimit(ledger) {
  const s = proState(ledger);
  return s.pro ? Math.max(1, Number(s.agents) || 1) : FREE_AGENTS;
}

/** The plan, as the reason a purchase waits: "the free plan covers one agent" or "the Pro plan covers 3 agents". */
export function limitReason(ledger) {
  const n = agentLimit(ledger);
  return isPro(ledger) ? `the Pro plan covers ${n} agent${n === 1 ? '' : 's'}` : 'the free plan covers one agent';
}

/** "the free plan" or "the Pro plan": who doesn't cover a waiting purchase's agent. */
export const planName = (ledger) => (isPro(ledger) ? 'the Pro plan' : 'the free plan');

/**
 * The agent the free plan covers. Chosen by the user, else the first agent that reported a
 * purchase, else the first agent anything was counted for; pinned once known, so it never moves
 * on its own. With none yet, `candidate` (the agent about to be counted) becomes it.
 */
export function freeAgentId(ledger, { candidate = null } = {}) {
  const db = ledger.db;
  const exists = (id) => Boolean(id && db.prepare('SELECT 1 FROM agents WHERE id = ?').get(Number(id)));
  const pinned = Number(getMeta(db, FREE_AGENT_KEY));
  if (exists(pinned)) return pinned;
  const reported = db.prepare(`SELECT s.agent_id AS id FROM purchases p JOIN sources s ON s.id = p.source_id
    WHERE s.kind = 'agent' AND s.agent_id IS NOT NULL ORDER BY p.id LIMIT 1`).get()?.id;
  const counted = db.prepare("SELECT agent_id AS id FROM purchases WHERE status = 'confirmed' ORDER BY id LIMIT 1").get()?.id;
  const id = [reported, counted, candidate].find(exists);
  if (!id) return null;
  setMeta(db, FREE_AGENT_KEY, String(Number(id)));
  return Number(id);
}

function agentExists(ledger, id) {
  return Boolean(id && ledger.db.prepare('SELECT 1 FROM agents WHERE id = ?').get(Number(id)));
}

/** The places after the free agent's, as stored: existing agents only, each once. */
function storedSlots(ledger, first) {
  let raw = [];
  try { raw = JSON.parse(getMeta(ledger.db, SLOTS_KEY) ?? '[]'); } catch { raw = []; }
  const seen = new Set([first]);
  return (Array.isArray(raw) ? raw : []).filter((x) => {
    const id = Number(x?.id);
    if (!agentExists(ledger, id) || seen.has(id)) return false;
    seen.add(id);
    return true;
  }).map((x) => ({ id: Number(x.id), changed_at: x.changed_at ?? null }));
}
const saveSlots = (ledger, slots) => setMeta(ledger.db, SLOTS_KEY, JSON.stringify(slots));

/** Agents in the order they first did anything: reported, were counted for, or were saved waiting. */
function activityOrder(ledger) {
  return ledger.db.prepare(`SELECT id FROM (
      SELECT s.agent_id AS id, min(p.id) AS at FROM purchases p JOIN sources s ON s.id = p.source_id
        WHERE s.kind = 'agent' AND s.agent_id IS NOT NULL GROUP BY s.agent_id
      UNION ALL SELECT agent_id, min(id) FROM purchases WHERE status = 'confirmed' AND agent_id IS NOT NULL GROUP BY agent_id
      UNION ALL SELECT held_agent_id, min(id) FROM purchases WHERE held_agent_id IS NOT NULL GROUP BY held_agent_id
    ) GROUP BY id ORDER BY min(at)`).all().map((r) => Number(r.id));
}

/**
 * The agents the plan covers right now, in place order (the free agent first). Empty places fill
 * with agents in order of first activity, then `candidate` (the agent about to be counted), and are
 * pinned, so nobody moves on their own.
 */
export function coveredAgentIds(ledger, { candidate = null } = {}) {
  const limit = agentLimit(ledger);
  const first = freeAgentId(ledger, { candidate });
  if (!first) return [];
  if (limit <= 1) return [first];
  const slots = storedSlots(ledger, first);
  const before = slots.length;
  if (slots.length < limit - 1) {
    for (const id of [...activityOrder(ledger), candidate === null ? null : Number(candidate)]) {
      if (slots.length >= limit - 1) break;
      if (!agentExists(ledger, id) || id === first || slots.some((x) => x.id === id)) continue;
      slots.push({ id, changed_at: null });
    }
  }
  if (slots.length !== before) saveSlots(ledger, slots);
  return [first, ...slots.slice(0, limit - 1).map((x) => x.id)];
}

/** Every agent fits in the plan (only ever said with Pro: Free's one agent is chosen, never assumed). */
function everyAgentFits(ledger) {
  return isPro(ledger) && ledger.db.prepare('SELECT count(*) AS n FROM agents').get().n <= agentLimit(ledger);
}

/** Can a purchase count for this agent right now? For the agents the plan covers: Free's one, or the key's. */
export function coversAgent(ledger, agentId) {
  if (agentId === null || agentId === undefined) return true;
  if (everyAgentFits(ledger)) return true;
  return coveredAgentIds(ledger, { candidate: Number(agentId) }).includes(Number(agentId));
}

/** Every bank or card account, oldest first: [{ id, kind, label, created_at, last_success_at, lines }]. */
export function accounts(ledger) {
  return ledger.db.prepare(`
    SELECT s.id, s.kind, s.label, s.created_at, s.last_success_at,
           (SELECT count(*) FROM purchases p WHERE p.source_id = s.id) AS lines
    FROM sources s WHERE s.kind IN (${ACCOUNT_KINDS.map((k) => `'${k}'`).join(', ')}) ORDER BY s.id`).all();
}

/** The account the free plan lets verify: the one the user chose, else the first one added. */
export function freeAccountId(ledger) {
  const all = accounts(ledger);
  const chosen = Number(getMeta(ledger.db, FREE_ACCOUNT_KEY));
  return all.find((a) => a.id === chosen)?.id ?? all[0]?.id ?? null;
}

/** Source ids whose lines don't verify right now: on Free, every account but the free one. */
export function unverifyingSources(ledger) {
  if (isPro(ledger)) return [];
  const free = freeAccountId(ledger);
  return accounts(ledger).map((a) => a.id).filter((id) => id !== free);
}

/** A name for an account, as the user typed it: no card or account numbers (a last 4 is fine). */
export function cleanAccountName(raw) {
  const name = redact(String(raw ?? '')).replace(/\d{5,}/g, '…').replace(/\s+/g, ' ').trim().slice(0, 60);
  if (!name) throw new LedgerError('Name the account this file is from, like "Chase checking". No account numbers.');
  return name;
}

/**
 * The statement source for a named account: found by name (any letter case), or added. Every
 * CSV import from before accounts were named belongs to the first one.
 */
export function accountSource(ledger, name) {
  const clean = cleanAccountName(name);
  const row = ledger.db.prepare("SELECT id FROM sources WHERE kind = 'csv' AND label = ? COLLATE NOCASE").get(clean);
  if (row) return row.id;
  const { lastInsertRowid } = ledger.db.prepare("INSERT INTO sources (kind, label, created_at) VALUES ('csv', ?, ?)")
    .run(clean, ledger.now().toISOString());
  ledger.track('account_added', { n: accounts(ledger).length });
  return Number(lastInsertRowid);
}

/** Waiting purchases from agents the free plan doesn't cover, per currency: [{ currency, cents, n }]. */
export function heldSpend(ledger, from = null, to = null) {
  const where = ["status = 'candidate'", 'match_reason = ?'];
  const args = [HELD];
  if (from) { where.push('occurred_on >= ?'); args.push(from); }
  if (to) { where.push('occurred_on < ?'); args.push(to); }
  return ledger.db.prepare(`SELECT currency, sum(amount_cents) AS cents, count(*) AS n FROM purchases
    WHERE ${where.join(' AND ')} GROUP BY currency ORDER BY cents DESC`).all(...args).map((r) => ({ ...r }));
}

/** How a held purchase would have counted, from where it came from. */
function origin(p) {
  if (p.source_kind === 'agent') return { by: 'agent', reason: String(p.external_id).startsWith('stream:') ? 'agent_usage' : 'agent_reported' };
  if (p.source_kind === 'manual') return { by: 'user', reason: 'manual' };
  return { by: 'rule', reason: 'rule' };
}

/**
 * Count every waiting purchase whose agent the plan now covers, exactly as it would have counted
 * at once: an agent's own report for that agent, a rule's match by the rule. Returns how many.
 */
export function releaseHeld(ledger) {
  const rows = ledger.db.prepare(`SELECT p.id, p.held_agent_id, p.external_id, s.kind AS source_kind FROM purchases p
    JOIN sources s ON s.id = p.source_id WHERE p.status = 'candidate' AND p.match_reason = ? AND p.held_agent_id IS NOT NULL
    ORDER BY p.id`).all(HELD);
  const nowIso = ledger.now().toISOString();
  const pro = isPro(ledger);
  let released = 0;
  for (const p of rows) {
    if (!coversAgent(ledger, p.held_agent_id)) continue;
    const { by, reason } = origin(p);
    ledger.db.prepare(`UPDATE purchases SET status = 'confirmed', agent_id = ?, attributed_by = ?, attributed_at = ?, match_reason = ?
      WHERE id = ? AND status = 'candidate'`).run(p.held_agent_id, by, nowIso, reason, p.id);
    ledger.audit('plan', p.id, pro ? 'counted for its agent: the Pro plan covers it' : 'counted for its agent: now the free plan\'s agent');
    if (by === 'agent') flagIfOutside(ledger, ledger.getPurchase(p.id), { stream: reason === 'agent_usage' });
    released++;
  }
  if (released) ledger.track('plan_released', { n: released, pro: pro ? 1 : 0 });
  return released;
}

/** Recompute every ✓ for the accounts that verify right now. */
export function reverifyAll(ledger) {
  ledger.db.prepare(`UPDATE purchases SET verified_at = CASE WHEN ${INDEPENDENT_SQL('purchases.id', unverifyingSources(ledger))}
    THEN COALESCE(verified_at, ?) ELSE NULL END WHERE status != 'merged'`).run(ledger.now().toISOString());
}

/**
 * Bring the ledger in line with the plan after it changed (Pro switched on or off, another free
 * agent or account chosen): count what now may count, and recompute the ✓. Cheap when nothing
 * changed, so any reader can call it.
 */
export function applyPlan(ledger) {
  const pro = isPro(ledger);
  const covered = everyAgentFits(ledger) ? 'all' : coveredAgentIds(ledger);
  const signature = JSON.stringify({ pro, agents: covered, account: pro ? null : freeAccountId(ledger), accounts: accounts(ledger).length });
  if (getMeta(ledger.db, APPLIED_KEY) === signature) return { changed: false, released: 0 };
  let released = 0;
  tx(ledger.db, () => {
    released = releaseHeld(ledger);
    reverifyAll(ledger);
    setMeta(ledger.db, APPLIED_KEY, signature);
  });
  return { changed: true, released };
}

/** A covered place (an agent's, or on Free the account's) can change once every this many days, so
 * switching back and forth can't count every agent's purchases. Filling an empty place is never limited;
 * on Pro, accounts never are (every account verifies). */
export const SWITCH_DAYS = 30;
const DAY = 86_400_000;

function checkSwitch(ledger, stamp, what, more) {
  const last = Date.parse(stamp ?? '');
  const now = ledger.now().getTime();
  if (Number.isFinite(last) && now - last < SWITCH_DAYS * DAY) {
    const next = new Date(last + SWITCH_DAYS * DAY).toISOString().slice(0, 10);
    throw new LedgerError(`The ${what} a plan covers can change once every ${SWITCH_DAYS} days. The next change is possible on ${next}; ${more}.`, 409);
  }
}
const moreAgents = (ledger) => (isPro(ledger) ? 'adding an agent to Pro covers one more' : 'Pro covers more');

function allowSwitch(ledger, key, stampKey, nextId, what) {
  const current = Number(getMeta(ledger.db, key));
  if (isPro(ledger) || !current || current === Number(nextId)) return;
  checkSwitch(ledger, getMeta(ledger.db, stampKey), what, 'Pro covers them all');
}

/**
 * The user chooses an agent the plan covers. On Free it takes the one place; on Pro it fills an
 * empty place, or takes the place of `replace` (a covered agent). Its waiting purchases count at once;
 * what the agent it replaces already counted stays counted.
 */
export function chooseCoveredAgent(ledger, agentId, { replace = null } = {}) {
  const a = ledger.requireAgent(agentId);
  const covered = coveredAgentIds(ledger);
  const limit = agentLimit(ledger);
  const nowIso = ledger.now().toISOString();
  if (!covered.includes(a.id)) {
    if (!covered.length) setMeta(ledger.db, FREE_AGENT_KEY, String(a.id));
    else if (covered.length < limit) saveSlots(ledger, [...storedSlots(ledger, covered[0]).filter((x) => x.id !== a.id), { id: a.id, changed_at: null }]);
    else {
      const out = replace === null || replace === undefined ? (limit === 1 ? covered[0] : null) : Number(replace);
      if (!out) throw new LedgerError(`Every place on your plan is taken (${limit} agents). Say which covered agent ${a.name} replaces.`);
      if (!covered.includes(out)) throw new LedgerError('That agent isn\'t one the plan covers.');
      if (out === covered[0]) {
        checkSwitch(ledger, getMeta(ledger.db, 'free_agent_changed_at'), 'agent', moreAgents(ledger));
        setMeta(ledger.db, FREE_AGENT_KEY, String(a.id));
        setMeta(ledger.db, 'free_agent_changed_at', nowIso);
      } else {
        const slots = storedSlots(ledger, covered[0]).filter((x) => x.id !== a.id);
        const i = slots.findIndex((x) => x.id === out);
        checkSwitch(ledger, slots[i].changed_at, 'agent', moreAgents(ledger));
        slots[i] = { id: a.id, changed_at: nowIso };
        saveSlots(ledger, slots);
      }
    }
  }
  ledger.track('covered_agent_chosen', { pro: isPro(ledger) ? 1 : 0 });
  return { ...applyPlan(ledger), plan: planView(ledger) };
}

/**
 * The user chooses the agent the free plan covers. On Free that takes the one place (once every 30
 * days); on Pro, a covered agent swaps places with the free one (coverage doesn't change, so it's
 * never limited), and an uncovered one takes the free agent's place.
 */
export function chooseFreeAgent(ledger, agentId) {
  const a = ledger.requireAgent(agentId);
  const covered = coveredAgentIds(ledger);
  const i = covered.indexOf(a.id);
  if (isPro(ledger) && i > 0) {
    const slots = storedSlots(ledger, covered[0]);
    const k = slots.findIndex((x) => x.id === a.id);
    slots[k] = { ...slots[k], id: covered[0] };
    setMeta(ledger.db, FREE_AGENT_KEY, String(a.id));
    saveSlots(ledger, slots);
    ledger.track('free_agent_chosen');
    return { ...applyPlan(ledger), plan: planView(ledger) };
  }
  if (i === 0) return { ...applyPlan(ledger), plan: planView(ledger) };
  const r = chooseCoveredAgent(ledger, a.id, { replace: covered[0] ?? null });
  ledger.track('free_agent_chosen');
  return r;
}

/** The user chooses the account whose lines verify on the free plan. */
export function chooseFreeAccount(ledger, sourceId) {
  const a = accounts(ledger).find((x) => x.id === Number(sourceId));
  if (!a) throw new LedgerError('No such bank or card account.', 404);
  allowSwitch(ledger, FREE_ACCOUNT_KEY, 'free_account_changed_at', a.id, 'bank or card account');
  if (Number(getMeta(ledger.db, FREE_ACCOUNT_KEY)) !== a.id) setMeta(ledger.db, 'free_account_changed_at', ledger.now().toISOString());
  setMeta(ledger.db, FREE_ACCOUNT_KEY, String(a.id));
  ledger.track('free_account_chosen');
  return { ...applyPlan(ledger), plan: planView(ledger) };
}

/** What the plan covers, for the page, get_setup and setup. */
export function planView(ledger) {
  const state = proState(ledger);
  const pro = state.pro;
  const covered = coveredAgentIds(ledger);
  const all = everyAgentFits(ledger);
  const freeAgent = covered[0] ?? null;
  const freeAccount = freeAccountId(ledger);
  const agents = ledger.listAgents().map((a) => ({ id: a.id, name: a.name, free: a.id === freeAgent, covered: all || covered.includes(a.id) }));
  return {
    pro,
    status: state.status,
    // Pro limits agents only (3 per seat plus extras); Free limits agents and accounts.
    limits: pro ? { agents: agentLimit(ledger), accounts: null } : { agents: FREE_AGENTS, accounts: FREE_ACCOUNTS },
    // Fair cancel (src/pro.js): a lapsed key keeps Pro in versions released on or before it was paid through.
    kept: state.status === 'kept' ? { paid_through: state.paid_through, release_date: state.release_date } : null,
    free_agent: agents.find((a) => a.free) ? { id: freeAgent, name: agents.find((a) => a.free).name } : null,
    free_account: freeAccount ? { id: freeAccount, label: accounts(ledger).find((a) => a.id === freeAccount).label } : null,
    agents,
    accounts: accounts(ledger).map((a) => ({ ...a, free: a.id === freeAccount, verifies: pro || a.id === freeAccount })),
    held: heldSpend(ledger),
  };
}

/** One plain line for an agent or the CLI: which agents the plan covers, and how to choose. */
export function planSentence(ledger, { you = null } = {}) {
  const v = planView(ledger);
  if (v.pro) {
    const n = v.limits.agents;
    const over = v.agents.some((a) => !a.covered);
    const names = v.agents.filter((a) => a.covered).map((a) => `${a.name}${you && a.id === you ? ' (you)' : ''}`);
    return `Plan: Pro, covering ${n} agent${n === 1 ? '' : 's'} (${over ? names.join(', ') : 'every agent so far'}) and every bank or card account.` +
      (over ? " The user chooses which agents, or adds one, in Twinslip: Menu → Settings → Agents. Other agents' purchases are saved and wait in the inbox for the user." : '');
  }
  const which = v.free_agent ? `${v.free_agent.name}${you && v.free_agent.id === you ? ' (you)' : ''}` : 'the first agent that reports a purchase';
  return `Plan: Free, covering one agent (${which}) and one bank or card account${v.free_account ? ` (${v.free_account.label})` : ''}. ` +
    "The user chooses which agent in Twinslip: Menu → Settings → Agents. Other agents' purchases are saved and wait in the inbox for the user.";
}
