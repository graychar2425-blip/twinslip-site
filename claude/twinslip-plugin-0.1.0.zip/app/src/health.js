// Source health and coverage (docs/PRODUCT.md §6). Free, always: the ledger never hides that
// it is stale or incomplete. Four separate facts per source:
//   last_check_at     the last time looking at the source worked (even if it found nothing)
//   last_purchase_at  the last purchase it delivered
//   failed / overdue  a check that went wrong, or one that is late
//   unknown           what can't be known: Twinslip can't see whether an agent app is
//                     running, so it never invents a heartbeat or calls a quiet agent broken.

import { getMeta } from './db.js';
import { addDays, addMonths, toLocalDate } from './dates.js';

/** Days after which a bank CSV import or an email sweep counts as overdue. */
export const OVERDUE_DAYS = 35;
/** Days without a purchase after which a working source is described as quiet. */
export const QUIET_DAYS = 14;

const DAY = 86400e3;
const short = (iso) => new Date(`${String(iso).slice(0, 10)}T12:00:00Z`).toLocaleDateString('en-US', { month: 'short', day: 'numeric', timeZone: 'UTC' });
const olderThan = (iso, days, now) => !iso || now - new Date(iso) > days * DAY;
const latest = (...xs) => xs.filter(Boolean).sort().pop() ?? null;

/** [{ source_id, kind, label, last_check_at, last_success_at, last_purchase_at, state, detail }] */
export function sourceHealth(ledger, now = ledger.now()) {
  const db = ledger.db;
  const lastPurchase = db.prepare('SELECT max(created_at) AS at FROM purchases WHERE source_id = ?');
  const agentName = db.prepare('SELECT name FROM agents WHERE id = ?');
  const out = [];
  for (const s of ledger.listSources()) {
    if (s.kind === 'manual') continue;
    const purchaseAt = lastPurchase.get(s.id).at ?? null;
    // For an agent app, its last connection: the only check there is (it says nothing about now).
    const checkedAt = s.kind === 'agent' ? latest(s.last_attempt_at) : latest(getMeta(db, `checked_at:${s.id}`), s.last_success_at);
    // Two kinds of trouble: the check itself failed (cleared by the next good check), or lines
    // it delivered were refused (cleared by the next successful capture, so the reason stays).
    let checkError = null;
    try { checkError = JSON.parse(getMeta(db, `check_error:${s.id}`) ?? 'null'); } catch { /* unreadable: ignore */ }
    const refused = s.kind !== 'agent' && Boolean(s.last_error) && !((s.last_success_at ?? '') > (s.last_attempt_at ?? ''));
    const failed = Boolean(checkError) || refused;
    const error = checkError?.message ?? (refused ? s.last_error : null);
    const failedAt = checkError?.at ?? (refused ? s.last_attempt_at : null);
    const base = { source_id: s.id, kind: s.kind, label: s.label, last_check_at: checkedAt, last_success_at: s.last_success_at, last_purchase_at: purchaseAt };
    let state;
    let detail;
    if (s.kind === 'simplefin') {
      state = 'retired';
      detail = 'Bank feed (retired): its records stay; nothing new syncs.';
    } else if (s.kind === 'agent') {
      const name = agentName.get(s.agent_id)?.name ?? s.label;
      const connected = latest(s.last_attempt_at);
      state = 'unknown';
      detail = `Twinslip can't tell whether ${name} is running. ${connected ? `It last connected ${short(connected)}` : 'It has never connected'}; ${s.last_success_at ? `last purchase reported ${short(s.last_success_at)}` : 'no purchases reported yet'}.`;
    } else if (failed) {
      state = 'failed';
      detail = checkError ? `The last check failed: ${checkError.message}` : `Some of what it sent couldn't be recorded: ${s.last_error}`;
    } else if (!checkedAt) {
      state = 'never';
      detail = s.kind === 'csv' ? 'No bank CSV imported yet.' : 'Not checked yet.';
    } else if (s.kind === 'csv') {
      const through = db.prepare('SELECT max(occurred_on) AS d FROM purchases WHERE source_id = ?').get(s.id).d;
      state = olderThan(checkedAt, OVERDUE_DAYS, now) ? 'overdue' : 'ok';
      detail = `Last import ${short(checkedAt)}; bank lines cover up to ${through ? short(through) : 'nothing yet'}.${state === 'overdue' ? ' Import a newer statement to check recent purchases.' : ''}`;
    } else {
      state = olderThan(purchaseAt, QUIET_DAYS, now) ? 'quiet' : 'ok';
      detail = state === 'quiet'
        ? `Checked ${short(checkedAt)}: working, no new purchases since ${purchaseAt ? short(purchaseAt) : 'it started'}.`
        : `Checked ${short(checkedAt)}; last purchase ${short(purchaseAt)}.`;
    }
    out.push({ ...base, state, detail, ...(failed && state === 'failed' ? { error, failed_at: failedAt } : {}) });
  }
  // Email sweeps are run by an agent when the user asks; shown once any agent exists.
  if (db.prepare('SELECT 1 FROM agents LIMIT 1').get()) {
    for (const [kind, sweep, label] of [['email_sweep', 'receipts', 'Receipt sweep'], ['alert_sweep', 'bank_alerts', 'Bank alert sweep']]) {
      const last = db.prepare('SELECT finished_at, found FROM sweeps WHERE kind = ? ORDER BY id DESC LIMIT 1').get(sweep);
      const state = !last ? 'never' : olderThan(last.finished_at, OVERDUE_DAYS, now) ? 'overdue' : 'ok';
      out.push({
        source_id: null, kind, label, last_check_at: last?.finished_at ?? null, last_success_at: last?.finished_at ?? null, last_purchase_at: null, state,
        detail: !last ? 'Never run. Your agent runs it when you ask, if it can read your email.'
          : `Last run ${short(last.finished_at)} (${last.found} found).${state === 'overdue' ? ' Ask your agent to run it again.' : ''}`,
      });
    }
  }
  return out;
}

/** Days without a bank line that still count as covered (weekends, quiet days, posting lag). */
export const COVER_SLACK_DAYS = 4;

/** Stretches of days the bank has shown: each import's span, plus dense runs of bank lines. */
function bankSpans(db) {
  const spans = db.prepare('SELECT from_date AS f, to_date AS t FROM bank_imports').all().map((x) => ({ f: x.f, t: x.t }));
  const days = db.prepare(`SELECT DISTINCT p.occurred_on AS d FROM purchases p JOIN sources s ON s.id = p.source_id
    WHERE s.kind IN ('csv', 'simplefin') ORDER BY 1`).all().map((x) => x.d);
  for (const d of days) spans.push({ f: d, t: d }); // single days; merged below when close together
  spans.sort((x, y) => x.f.localeCompare(y.f) || x.t.localeCompare(y.t));
  const merged = [];
  for (const sp of spans) {
    const cur = merged.at(-1);
    if (cur && sp.f <= addDays(cur.t, COVER_SLACK_DAYS)) { if (sp.t > cur.t) cur.t = sp.t; } else merged.push({ ...sp });
  }
  return merged;
}

/**
 * What a month's records can and can't claim. bank_complete only when the bank's spans reach
 * from the month's first days to its last (or today) without a hole; complete only when, as
 * well, nothing failed, is overdue or has never run, and no agent can pay outside the bank.
 */
export function coverage(ledger, month, now = ledger.now()) {
  const db = ledger.db;
  const today = toLocalDate(now);
  const start = `${month}-01`;
  const monthEnd = addDays(`${addMonths(month, 1)}-01`, -1);
  const until = monthEnd < today ? monthEnd : today;
  const spans = bankSpans(db);
  const covering = spans.find((sp) => sp.f <= addDays(start, COVER_SLACK_DAYS - 1) && sp.t >= start) ?? null;
  const later = spans.find((sp) => sp.f > addDays(start, COVER_SLACK_DAYS - 1) && sp.f <= until) ?? null;
  const bankThrough = covering?.t ?? null;
  const health = sourceHealth(ledger, now);
  const problems = health.filter((h) => h.state === 'failed' || h.state === 'overdue' || (h.state === 'never' && h.source_id !== null));
  const agents = health.some((h) => h.kind === 'agent');
  const unknown = [];
  if (!spans.length) unknown.push('Nothing from your bank yet: import its CSV file to check purchases against it.');
  else if (!covering) unknown.push(`Your bank's lines don't cover the start of ${monthLabel(month)}: import a statement that begins by ${short(start)}.`);
  else if (bankThrough < until) unknown.push(`Your bank's lines stop on ${short(bankThrough)}${later ? ` and pick up again on ${short(later.f)}` : ''}: purchases after that aren't checked yet.`);
  if (agents) unknown.push('Payments your agents make outside your bank (prepaid credits, crypto, other cards) are only what they report.');
  for (const p of problems) unknown.push(`${p.label}: ${p.detail}`);
  const bankComplete = Boolean(covering) && bankThrough >= until;
  return {
    month, bank_through: bankThrough, bank_complete: bankComplete,
    complete: bankComplete && problems.length === 0 && !agents,
    unknown,
  };
}

const monthLabel = (m) => new Date(`${m}-15T12:00:00Z`).toLocaleDateString('en-US', { month: 'long', timeZone: 'UTC' });
