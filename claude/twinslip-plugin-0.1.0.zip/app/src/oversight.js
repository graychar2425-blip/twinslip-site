// Oversight (Pro; docs/PRODUCT.md §6). One idempotent run, oversee(), looks at what can go
// wrong and keeps a list of exceptions: what needs the user, with the evidence, what is still
// uncertain, a suggested next step, and the history of each. Nothing here acts on the world:
// no merchant is contacted, nothing is cancelled or disputed, no money moves. A notification
// only informs.
//
// Runs come from the local server (on start, hourly, after a sleep), `twinslip oversee`,
// or an optional launchd job. Time when nothing ran is recorded as a gap and never presented
// as watched.

import { LedgerError } from './ledger.js';
import { tx } from './db.js';
import { proState } from './pro.js';
import { sourceHealth, coverage } from './health.js';
import { listRefunds } from './refunds.js';
import { addDays, addMonths, monthKey, toLocalDate } from './dates.js';
import { formatCents } from './money.js';

/** A run more than this long after the last one leaves a recorded gap. */
export const GAP_MS = 2 * 3600e3;
/** A gap this long becomes an exception the user sees (shorter ones show in the briefing). */
export const GAP_EXCEPTION_MS = 72 * 3600e3;

const short = (iso) => new Date(`${String(iso).slice(0, 10)}T12:00:00Z`).toLocaleDateString('en-US', { month: 'short', day: 'numeric', timeZone: 'UTC' });
const monthName = (month) => new Date(`${month}-15T12:00:00Z`).toLocaleDateString('en-US', { month: 'long', timeZone: 'UTC' });
const SYSTEM_KINDS = ['missing_refund', 'refund_unconfirmed', 'source_failed', 'source_overdue', 'coverage_gap']; // cleared by the system when the condition goes

/** What needs attention right now: [{ kind, subject, severity, title, evidence, uncertain, next_action }] */
function conditions(ledger, now) {
  const today = toLocalDate(now);
  const out = [];
  for (const r of listRefunds(ledger)) {
    const owed = formatCents(r.amount_cents - r.refunded_cents, r.currency);
    const evidence = { expected_refund_id: r.id, merchant: r.merchant, amount_cents: r.amount_cents, currency: r.currency,
      due_on: r.due_on, refunded_cents: r.refunded_cents, claimed_cents: r.claimed_cents, refund_lines: r.links.map((l) => l.purchase_id) };
    if (r.status === 'open' && r.due_on < today) {
      out.push({
        kind: 'missing_refund', subject: `refund:${r.id}`, severity: 'urgent', evidence,
        title: `${r.merchant} still owes you ${owed} (due ${short(r.due_on)})`,
        uncertain: `The refund may have come another way (store credit, another card), or your bank's latest lines may not reach it yet.${r.refunded_cents ? ` ${formatCents(r.refunded_cents, r.currency)} has arrived so far.` : ''}`,
        next_action: `Check with ${r.merchant}, or import a newer bank statement. If it came another way, mark it received in Refunds you expect.`,
      });
    } else if (r.status === 'evidence' && r.due_on < today) {
      // Overdue, and only an agent says it arrived: still urgent. An agent's word never quiets it.
      out.push({
        kind: 'missing_refund', subject: `refund:${r.id}`, severity: 'urgent', evidence,
        title: `An agent says ${r.merchant} refunded ${formatCents(r.claimed_cents, r.currency)}, but your bank hasn't shown it (due ${short(r.due_on)})`,
        uncertain: "Only an agent's report says the refund arrived, and it's past due. It may not have arrived at all, or your bank's latest lines may not reach it yet.",
        next_action: `Import a newer bank statement to confirm it, or check with ${r.merchant}. If you've seen it, mark it received in Refunds you expect.`,
      });
    } else if (r.status === 'evidence') {
      out.push({
        kind: 'refund_unconfirmed', subject: `refund:${r.id}`, severity: 'normal', evidence,
        title: `An agent says ${r.merchant} refunded ${formatCents(r.claimed_cents, r.currency)}; your bank hasn't shown it`,
        uncertain: "Only an agent's report says the refund arrived. Twinslip settles it when your bank shows it or you say so.",
        next_action: "Import your bank's CSV to confirm it, or mark it received in Refunds you expect if you've seen it.",
      });
    }
  }
  for (const h of sourceHealth(ledger, now)) {
    const subject = `source:${h.source_id ?? h.kind}`;
    const evidence = { source_id: h.source_id, kind: h.kind, label: h.label, last_check_at: h.last_check_at, state: h.state,
      ...(h.error ? { error: h.error, failed_at: h.failed_at } : {}) };
    if (h.state === 'failed') {
      out.push({ kind: 'source_failed', subject, severity: 'urgent', evidence, title: `${h.label}: the last check failed`,
        uncertain: `${h.detail} Purchases it would have seen since then may be missing from your totals.`,
        next_action: h.kind === 'phone' ? 'Open the Twinslip iPhone app and follow its steps, and check that iCloud Drive is on.' : 'Open Settings to see the source, and fix what the message says.' });
    } else if (h.state === 'overdue') {
      out.push({ kind: 'source_overdue', subject, severity: 'normal', evidence, title: `${h.label} is overdue`,
        uncertain: `${h.detail} Purchases since then aren't checked against it.`,
        next_action: h.kind === 'csv' ? "Download a newer CSV from your bank's website and import it in Settings."
          : 'Ask your agent to run it again ("Set up Twinslip" lists it), if it can read your email.' });
    }
  }
  // Last month, plus every earlier month still open: a new month never quietly drops one.
  const lastMonth = addMonths(monthKey(today), -1);
  const months = new Set(ledger.db.prepare("SELECT subject FROM exceptions WHERE kind = 'coverage_gap' AND status = 'open'").all().map((x) => x.subject.slice('coverage:'.length)));
  if (ledger.db.prepare("SELECT 1 FROM purchases WHERE status != 'merged' AND substr(occurred_on, 1, 7) = ? LIMIT 1").get(lastMonth)) months.add(lastMonth);
  for (const month of [...months].sort()) {
    const cov = coverage(ledger, month, now);
    if (cov.bank_complete) continue;
    out.push({ kind: 'coverage_gap', subject: `coverage:${month}`, severity: 'normal',
      evidence: { month, bank_through: cov.bank_through },
      title: `${monthName(month)} isn't fully checked against your bank`,
      uncertain: cov.unknown.filter((u) => !/outside your bank/.test(u)).join(' '),
      next_action: `Import your bank's CSV covering ${monthName(month)} through its last day (${short(addDays(`${addMonths(month, 1)}-01`, -1))}).` });
  }
  return out;
}

/** Why a system exception cleared, in words. */
function clearedBecause(ledger, e) {
  const ev = JSON.parse(e.evidence);
  if (e.kind === 'missing_refund' || e.kind === 'refund_unconfirmed') {
    const r = listRefunds(ledger).find((x) => x.id === ev.expected_refund_id);
    if (r?.status === 'resolved') return r.links.some((l) => l.independent) ? 'the refund arrived (seen by your bank or another independent source, or added by you)' : 'you marked it received';
    if (r?.status === 'dismissed') return 'you stopped expecting this refund';
    if (r && r.due_on < toLocalDate(ledger.now())) return 'it is past due now, so it is followed up as an urgent item';
    return "the refund's details changed; it is followed up under its current state";
  }
  if (e.kind === 'source_failed') return 'a later check worked';
  if (e.kind === 'source_overdue') return 'it was checked again';
  if (e.kind === 'coverage_gap') return "your bank's lines now cover the month";
  return 'the condition went away';
}

/**
 * One oversight run. Idempotent: running it again with nothing new changes nothing and sends
 * nothing. Returns { opened, updated, resolved, gap: { from, to } | null }.
 */
export function oversee(ledger, { now = ledger.now(), trigger = 'cli', notify = () => {}, pro = proState(ledger).pro } = {}) {
  const nowIso = now.toISOString();
  const db = ledger.db;
  const toNotify = [];
  const result = tx(db, () => {
    const prev = db.prepare('SELECT COALESCE(finished_at, started_at) AS at FROM monitor_runs ORDER BY id DESC LIMIT 1').get()?.at ?? null;
    const gap = prev && now - new Date(prev) > GAP_MS ? { from: prev, to: nowIso } : null;
    const runId = Number(db.prepare('INSERT INTO monitor_runs (started_at, trigger, gap_from, gap_to) VALUES (?, ?, ?, ?)')
      .run(nowIso, trigger, gap?.from ?? null, gap?.to ?? null).lastInsertRowid);
    const event = db.prepare('INSERT INTO exception_events (exception_id, at, actor, action, note) VALUES (?, ?, ?, ?, ?)');
    const counts = { opened: 0, updated: 0, resolved: 0 };

    const found = conditions(ledger, now);
    if (gap && now - new Date(gap.from) >= GAP_EXCEPTION_MS) {
      // One item for long gaps; each new one extends it (and reopens it if you had closed it).
      let prior = null;
      try { prior = JSON.parse(db.prepare("SELECT evidence FROM exceptions WHERE kind = 'monitoring_gap' AND subject = 'monitoring'").get()?.evidence ?? 'null'); } catch { /* start over */ }
      const hoursNow = Math.round((now - new Date(gap.from)) / 3600e3);
      const ev = { first_from: prior?.first_from ?? gap.from, from: gap.from, to: gap.to, count: (prior?.count ?? 0) + 1, max_hours: Math.max(prior?.max_hours ?? 0, hoursNow) };
      found.push({ kind: 'monitoring_gap', subject: 'monitoring', severity: 'normal', evidence: ev,
        title: `Nothing was watching from ${short(gap.from)} to ${short(gap.to)}${ev.count > 1 ? ` (${ev.count} long gaps since ${short(ev.first_from)})` : ''}`,
        uncertain: 'Purchases that arrived then were recorded, but no checks ran: overdue refunds and failed sources weren\'t flagged until now.',
        next_action: 'Keep Twinslip open, or turn on background checks in Settings so they run hourly even when the page is closed.' });
    }
    const seen = new Set();
    for (const c of found) {
      seen.add(`${c.kind}|${c.subject}`);
      const evidence = JSON.stringify(c.evidence);
      const row = db.prepare('SELECT * FROM exceptions WHERE kind = ? AND subject = ?').get(c.kind, c.subject);
      if (!row) {
        const id = Number(db.prepare(`INSERT INTO exceptions (kind, subject, severity, status, title, evidence, uncertain, next_action, opened_at, updated_at)
          VALUES (?, ?, ?, 'open', ?, ?, ?, ?, ?, ?)`).run(c.kind, c.subject, c.severity, c.title, evidence, c.uncertain, c.next_action, nowIso, nowIso).lastInsertRowid);
        event.run(id, nowIso, 'system', 'opened', '');
        counts.opened++;
        continue;
      }
      const changed = row.evidence !== evidence || row.title !== c.title || row.uncertain !== c.uncertain || row.next_action !== c.next_action || row.severity !== c.severity;
      if (row.status === 'open') {
        if (!changed) continue;
        db.prepare('UPDATE exceptions SET title = ?, evidence = ?, uncertain = ?, next_action = ?, severity = ?, updated_at = ? WHERE id = ?')
          .run(c.title, evidence, c.uncertain, c.next_action, c.severity, nowIso, row.id);
        event.run(row.id, nowIso, 'system', 'updated', '');
        counts.updated++;
        continue;
      }
      // Closed. The system's own clearing reopens when the condition is back; the user's decision
      // stands until the facts change.
      const lastActor = db.prepare('SELECT actor FROM exception_events WHERE exception_id = ? ORDER BY id DESC LIMIT 1').get(row.id)?.actor;
      if (lastActor === 'user' && !changed) continue;
      db.prepare(`UPDATE exceptions SET status = 'open', title = ?, evidence = ?, uncertain = ?, next_action = ?, severity = ?, updated_at = ?,
        resolved_at = NULL, notified_at = NULL WHERE id = ?`).run(c.title, evidence, c.uncertain, c.next_action, c.severity, nowIso, row.id);
      event.run(row.id, nowIso, 'system', 'reopened', lastActor === 'user' ? 'the facts changed since you closed it' : '');
      counts.opened++;
    }
    for (const row of db.prepare("SELECT * FROM exceptions WHERE status = 'open'").all()) {
      if (!SYSTEM_KINDS.includes(row.kind) || seen.has(`${row.kind}|${row.subject}`)) continue;
      db.prepare("UPDATE exceptions SET status = 'resolved', resolved_at = ?, updated_at = ? WHERE id = ?").run(nowIso, nowIso, row.id);
      event.run(row.id, nowIso, 'system', 'cleared', clearedBecause(ledger, row));
      counts.resolved++;
    }
    if (pro) {
      for (const row of db.prepare("SELECT * FROM exceptions WHERE status = 'open' AND severity = 'urgent' AND notified_at IS NULL").all()) {
        db.prepare('UPDATE exceptions SET notified_at = ? WHERE id = ?').run(nowIso, row.id);
        toNotify.push(row);
      }
    }
    db.prepare('UPDATE monitor_runs SET finished_at = ? WHERE id = ?').run(nowIso, runId);
    return { ...counts, gap };
  });
  // After the commit (the claim above stops two runs sending the same one). A notification
  // that fails is unclaimed, so the next run tries again; the item is open in the app either way.
  for (const row of toNotify) {
    let sent = false;
    try { sent = notify(row.title, row.next_action) !== false; } catch { sent = false; }
    if (!sent) db.prepare('UPDATE exceptions SET notified_at = NULL WHERE id = ? AND notified_at = ?').run(row.id, nowIso);
  }
  return result;
}

/** Every exception with its evidence and history: open ones first, urgent first. */
export function listExceptions(ledger) {
  const events = ledger.db.prepare('SELECT at, actor, action, note FROM exception_events WHERE exception_id = ? ORDER BY id');
  return ledger.db.prepare(`SELECT * FROM exceptions ORDER BY CASE status WHEN 'open' THEN 0 ELSE 1 END,
    CASE severity WHEN 'urgent' THEN 0 ELSE 1 END, opened_at DESC, id DESC`).all()
    .map((e) => ({ ...e, evidence: JSON.parse(e.evidence), history: events.all(e.id) }));
}

function closeException(ledger, id, status, note) {
  const e = ledger.db.prepare('SELECT * FROM exceptions WHERE id = ?').get(Number(id));
  if (!e) throw new LedgerError('No such item.', 404);
  if (e.status !== 'open') throw new LedgerError(`That item is already ${e.status}.`, 409);
  const nowIso = ledger.now().toISOString();
  tx(ledger.db, () => {
    ledger.db.prepare('UPDATE exceptions SET status = ?, resolved_at = ?, updated_at = ? WHERE id = ?').run(status, nowIso, nowIso, e.id);
    ledger.db.prepare("INSERT INTO exception_events (exception_id, at, actor, action, note) VALUES (?, ?, 'user', ?, ?)")
      .run(e.id, nowIso, status, String(note ?? '').slice(0, 200));
  });
  return listExceptions(ledger).find((x) => x.id === e.id);
}

/** Only the user: it's handled. */
export function resolveException(ledger, id, { note = '' } = {}) {
  return closeException(ledger, id, 'resolved', note);
}

/** Only the user: not worth following. It stays closed until the facts change. */
export function dismissException(ledger, id, { note = '' } = {}) {
  return closeException(ledger, id, 'dismissed', note);
}

/**
 * The briefing for a month: what was checked, what is unknown, what needs the user. It says
 * "Everything checked" only when coverage supports it, nothing is open, and nothing went unwatched.
 */
export function briefing(ledger, { month = monthKey(toLocalDate(ledger.now())), now = ledger.now() } = {}) {
  const cov = coverage(ledger, month, now);
  const health = sourceHealth(ledger, now);
  const checked = health.filter((h) => h.state === 'ok' || h.state === 'quiet').map((h) => ({
    label: h.label,
    through: h.kind === 'csv' ? `bank lines up to ${cov.bank_through ? short(cov.bank_through) : 'nothing yet'}` : `checked ${short(h.last_check_at)}`,
  }));
  const start = `${month}-01`;
  const end = `${addMonths(month, 1)}-01`;
  const gaps = ledger.db.prepare('SELECT gap_from, gap_to FROM monitor_runs WHERE gap_from IS NOT NULL AND gap_from < ? AND gap_to > ? ORDER BY id').all(end, start);
  // Gaps in one line. Checks look at the ledger's state, so each run after a wake catches up on
  // what happened; only a long gap (72 hours or more) means something may have waited too long.
  const hours = (g) => (new Date(g.gap_to) - new Date(g.gap_from)) / 3600e3;
  const longGaps = gaps.filter((g) => hours(g) * 3600e3 >= GAP_EXCEPTION_MS);
  const gapLine = !gaps.length ? [] : gaps.length === 1
    ? [`Twinslip wasn't running (or the Mac was asleep) from ${short(gaps[0].gap_from)} to ${short(gaps[0].gap_to)}; checks caught up when it woke.`]
    : [`Twinslip wasn't running (or the Mac was asleep) ${gaps.length} times this month, the longest for ${Math.round(Math.max(...gaps.map(hours)))} hours; checks caught up each time.`];
  const unknown = [...cov.unknown,
    ...health.filter((h) => h.state === 'never' && h.kind !== 'csv').map((h) => `${h.label}: ${h.detail}`),
    ...gapLine];
  const exceptions = listExceptions(ledger).filter((e) => e.status === 'open');
  const name = monthName(month);
  const n = exceptions.length;
  const everything = cov.complete && n === 0 && longGaps.length === 0;
  const headline = everything ? `Everything checked for ${name}: nothing needs you.`
    : `${n === 0 ? 'Nothing needs you right now' : `${n} thing${n === 1 ? ' needs' : 's need'} you`} for ${name}. Not everything could be checked: see what's unknown below.`;
  return { month, headline, checked, unknown, exceptions, complete: everything };
}
