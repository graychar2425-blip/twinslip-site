// Twinslip UI. Vanilla JS, no build. Every string from the bank or the user goes
// into the DOM via textContent — never innerHTML.

const TOKEN = document.querySelector('meta[name="ledger-token"]').content;
const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => [...document.querySelectorAll(sel)];

const ui = {
  state: null,
  period: 'month',
  month: null, // 'YYYY-MM' shown in the purchases card
  inboxOpen: false,
  inbox: [],
  focus: 0, // keyboard cursor in the inbox
  rollDelay: 0, // ms the totals wait before rolling (after a sort, the row leaves first)
  sortNames: false, // inbox rows carry view-transition names while a sort plays
};

// Home is the number, one line per agent, and recent purchases. Everything else is a
// view behind Menu, addressed by the URL hash so Back works.
const VIEWS = { taxpack: '#taxpack-card', audit: '#audit-card', privacy: '#privacy-card', totals: '#totals-card', purchases: '#purchases-card', subscriptions: '#subscriptions-card', jobs: '#jobs-card', refunds: '#refunds-card', attention: '#attention-card', export: '#export-card', missing: '#missing-card', settings: '#settings-card' };
const HOME = ['#hero', '#agents-card', '#recent-card']; // #setup-card shows itself until setup is done
const RECENT = 8;
const SEARCH_LIMIT = 200;
const currentView = () => (location.hash.slice(1) in VIEWS ? location.hash.slice(1) : 'home');

// ── helpers ──────────────────────────────────────────────────────────────────

async function api(method, path, body, headers = {}) {
  const opts = { method, headers: { 'X-Ledger-Token': TOKEN, ...headers } };
  if (body instanceof Blob) opts.body = body;
  else if (body !== undefined) {
    opts.body = JSON.stringify(body);
    opts.headers['Content-Type'] = 'application/json';
  }
  const res = await fetch(path, opts);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw Object.assign(new Error(data.error || `Request failed (${res.status})`), { status: res.status });
  return data;
}

function h(tag, attrs = {}, ...children) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (v === undefined || v === null || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
    else if (k === 'text') el.textContent = v;
    else if (k === 'style') el.style.cssText = v; // CSSOM, allowed under style-src 'self'
    else el.setAttribute(k, v === true ? '' : v);
  }
  for (const c of children.flat()) {
    if (c === null || c === undefined || c === false) continue;
    el.append(c instanceof Node ? c : document.createTextNode(String(c)));
  }
  return el;
}

function money(cents, currency = 'USD') {
  try {
    return new Intl.NumberFormat(undefined, { style: 'currency', currency }).format(cents / 100);
  } catch {
    return `${(cents / 100).toFixed(2)} ${currency}`;
  }
}

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const MONTHS_LONG = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
function shortDate(iso) {
  const [, m, d] = iso.split('-').map(Number);
  return `${MONTHS[m - 1]} ${d}`;
}
function monthName(ym, long = true) {
  const [y, m] = ym.split('-').map(Number);
  const name = (long ? MONTHS_LONG : MONTHS)[m - 1];
  return y === new Date().getFullYear() ? name : `${name} ${y}`;
}
function addMonths(ym, n) {
  const [y, m] = ym.split('-').map(Number);
  const d = new Date(Date.UTC(y, m - 1 + n, 1));
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}`;
}
function ago(iso) {
  if (!iso) return 'never';
  const mins = Math.round((Date.now() - new Date(iso)) / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins} min ago`;
  const hrs = Math.round(mins / 60);
  if (hrs < 48) return `${hrs}h ago`;
  return `${Math.round(hrs / 24)} days ago`;
}
function today() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

let toastTimer = null;
function toast(message, actions = [], { error = false, ms = 6000 } = {}) {
  const t = $('#toast');
  t.replaceChildren(h('span', { text: message }), ...actions.map(([label, fn]) =>
    h('button', { onclick: async () => { hideToast(); await fn(); } }, label)));
  t.classList.toggle('error', error);
  t.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(hideToast, ms);
}
function hideToast() { $('#toast').hidden = true; }

async function guard(fn) {
  try {
    await fn();
  } catch (err) {
    if (err.status === 402) toast(err.message, [['See Pro', () => goPro()]], { ms: 9000 });
    else toast(err.message, [], { error: true, ms: 9000 });
  }
}
function goPro() {
  location.hash = '#settings';
  setTimeout(() => $('#pro-settings')?.scrollIntoView({ block: 'start' }), 50);
}
const isPro = () => Boolean(ui.state?.pro?.pro);
// Per-agent Pro (src/plan.js): agents beyond what the key covers wait like agents beyond Free, and
// the one way to count them is to add an agent on the website's Pro page.
const addAgentUrl = () => `${ui.state?.site_url ?? 'https://twinslip.example'}/pro#agents`;
const planName = () => (isPro() ? 'your Pro plan' : 'the free plan');
/** The one upgrade action for purchases that wait: "Count it with Pro" on Free, "Add an agent" on Pro. */
function upgradeAction(label, ariaLabel, cls = '') {
  if (!isPro()) return h('button', { type: 'button', class: cls, onclick: () => goPro(), 'aria-label': ariaLabel }, label);
  return h('a', { class: cls === 'link' ? 'ghost-link' : 'file-btn', href: addAgentUrl(), target: '_blank', rel: 'noopener noreferrer', 'aria-label': ariaLabel }, 'Add an agent');
}

const COLORS = ['var(--bar)', 'var(--bar-2)', 'var(--bar-3)', 'var(--bar-4)'];

/** The state marks (docs/DESIGN.md): an original slip, and for verified its carbon copy lined
 *  up behind it; dashed when it's waiting for you. Shape differs, so color is never the only cue. */
function slip(kind) {
  const NS = 'http://www.w3.org/2000/svg';
  const el = (tag, attrs) => { const e = document.createElementNS(NS, tag); for (const [k, v] of Object.entries(attrs)) e.setAttribute(k, v); return e; };
  const svg = el('svg', { viewBox: '0 0 16 16', class: 'slip', 'aria-hidden': 'true', focusable: 'false' });
  if (kind === 'ok') svg.append(el('rect', { class: 'copy', x: '4.5', y: '4.5', width: '10', height: '10.5', rx: '1.5' }));
  svg.append(el('rect', { class: 'orig', x: '1', y: '1', width: '10', height: '10.5', rx: '1.5' }));
  return svg;
}

/** The inbox's "done" mark: a filed stack of slips, each with its copy behind it. */
function filedStack() {
  const NS = 'http://www.w3.org/2000/svg';
  const el = (tag, attrs) => { const e = document.createElementNS(NS, tag); for (const [k, v] of Object.entries(attrs)) e.setAttribute(k, v); return e; };
  const svg = el('svg', { viewBox: '0 0 40 40', class: 'slip stack', 'aria-hidden': 'true', focusable: 'false' });
  for (const [x, y] of [[4, 14], [9, 9], [14, 4]]) {
    svg.append(el('rect', { class: 'copy', x: String(x + 3), y: String(y + 3), width: '20', height: '21', rx: '2' }));
    svg.append(el('rect', { class: 'orig filed', x: String(x), y: String(y), width: '20', height: '21', rx: '2' }));
  }
  return svg;
}

// ── Motion (docs/DESIGN.md "Motion") ────────────────────────────────────────
// Four moments, each answering something real: a purchase gets its carbon copy (the match),
// a total changes (the roll), you sort the inbox (the row leaves, the gap closes). With Reduce
// Motion on, each shows its end state at once.
const calm = () => matchMedia('(prefers-reduced-motion: reduce)').matches;
const EASE = 'cubic-bezier(0.16, 1, 0.3, 1)';
const ROLL = { ms: 600, stagger: 40, lag: 120 };

/** The odometer's plan: line `to` up with `from` from the right (amounts grow on the left), and
 *  give each digit that changed the digits it rolls through ('' = nothing there before) and its
 *  turn, counted right to left. Keep in step with site/main.js (test/motion.test.js). */
function rollPlan(from, to) {
  const value = (s) => Number(s.replace(/\D/g, '') || 0);
  const up = value(to) >= value(from);
  const a = [...from];
  const b = [...to];
  const shift = a.length - b.length;
  const cols = b.map((ch, i) => ({ ch, was: a[i + shift] ?? '', path: null, turn: 0 }));
  let turn = 0;
  for (let i = cols.length - 1; i >= 0; i--) {
    const c = cols[i];
    if (!/^\d$/.test(c.ch) || c.was === c.ch) continue;
    c.turn = turn++;
    if (!/^\d$/.test(c.was)) { c.path = ['', c.ch]; continue; }
    const [f, t] = [Number(c.was), Number(c.ch)];
    const steps = up ? (t - f + 10) % 10 : (f - t + 10) % 10;
    c.path = Array.from({ length: steps + 1 }, (_, k) => String((f + (up ? k : -k) + 10) % 10));
  }
  return { up, cols: cols.map(({ ch, path, turn: n }) => ({ ch, path, turn: n })) };
}

/** Show `text` in `el`, rolling the digits that changed. The first value is set as is (nothing
 *  rolls on page load). While it rolls, screen readers get the real text and the digit columns
 *  are hidden from them; at rest the element holds plain text again. Where the figure has a
 *  carbon copy (a text-shadow), the copy rolls as its own layer, a beat behind. */
const rolled = new WeakMap();
/** Roll only between two plain amounts: ASCII digits, the same sign, one currency. Anything else
 *  (crossing zero, other numeral systems, "A + B" in two currencies) is shown without rolling. */
function canRoll(from, to) {
  const plain = /^[^0-9\-\u2212+]*[0-9][0-9.,\s\u00a0\u202f']*[^0-9\-\u2212+]*$/;
  const negative = (x) => /[-\u2212]/.test(x);
  const clean = (x) => x.replace(/[-\u2212]/g, '');
  return plain.test(clean(from)) && plain.test(clean(to)) && negative(from) === negative(to) && !/\p{Nd}/u.test(from.replace(/[0-9]/g, '') + to.replace(/[0-9]/g, ''));
}

/** Where the cents start in one plain amount ("$109.12" → 4), for a figure that draws them
 *  smaller (data-cents; POLISH-RESEARCH #3, as Mercury does). -1 for anything else: no
 *  decimals, or two currencies joined with " + ". */
const CENTS = /^(.*\d)([.,]\d{2})(\D*)$/;
function centsAt(el, text) {
  if (!el.hasAttribute('data-cents') || text.includes('+')) return -1;
  const m = text.match(CENTS);
  return m ? m[1].length : -1;
}

/** The figure at rest: plain text, or with its cents drawn smaller while screen readers still
 *  read the whole value ("$109.12"). */
function setText(el, text) {
  const at = centsAt(el, text);
  if (at < 0) { el.textContent = text; return; }
  el.replaceChildren(h('span', { class: 'sr', text }),
    h('span', { 'aria-hidden': 'true' }, text.slice(0, at), h('span', { class: 'cents' }, text.slice(at, at + 3)), text.slice(at + 3)));
}

function rollText(el, text, { delay = 0 } = {}) {
  const last = rolled.get(el);
  if (last?.text === text) return;
  for (const a of last?.anims ?? []) a.cancel();
  const now = { text, anims: [] };
  rolled.set(el, now);
  if (!last || calm() || !el.animate || el.closest('[hidden]') || !canRoll(last.text, text)) { setText(el, text); return; }
  const { up, cols } = rollPlan(last.text, text);
  const copy = getComputedStyle(el).textShadow !== 'none';
  const at = centsAt(el, text);
  const face = h('span', { 'aria-hidden': 'true' });
  const cents = at >= 0 ? h('span', { class: 'cents' }) : null;
  const rolling = [];
  cols.forEach((c, i) => {
    if (cents && i === at) face.append(cents);
    const into = cents && i >= at && i < at + 3 ? cents : face;
    if (!c.path) { into.append(c.ch); return; }
    const strip = (cls) => h('span', { class: cls }, ...(up ? c.path : [...c.path].reverse()).map((d) => h('span', {}, d || ' ')));
    const layers = copy ? [strip('roll-strip copy'), strip('roll-strip')] : [strip('roll-strip')];
    const col = h('span', { class: 'roll-col' }, h('span', { class: 'roll-sizer' }, c.ch), ...layers);
    into.append(col);
    rolling.push({ c, col, layers });
  });
  el.replaceChildren(h('span', { class: 'sr', text }), face);
  // Measured in place, so the smaller cents roll by their own line height.
  for (const { c, col, layers } of rolling) {
    const css = getComputedStyle(col);
    const lh = parseFloat(css.lineHeight) || parseFloat(css.fontSize) * 1.2;
    const travel = (c.path.length - 1) * lh;
    layers.forEach((layer, k) => {
      const lagging = copy && k === 0;
      const ends = [`translateY(${up ? 0 : -travel}px)`, `translateY(${up ? -travel : 0}px)`];
      now.anims.push(layer.animate(ends.map((transform) => ({ transform })), {
        duration: ROLL.ms, easing: EASE, fill: 'both', delay: delay + c.turn * ROLL.stagger + (lagging ? ROLL.lag : 0),
      }));
    });
  }
  Promise.all(now.anims.map((a) => a.finished))
    .then(() => { if (rolled.get(el) === now) setText(el, text); })
    .catch(() => { /* cancelled by a newer value, which has taken over */ });
}

/** The state each purchase was last shown in, so the match moment plays only when a purchase
 *  you have already seen goes from unverified to verified: never on page load, never for a row
 *  that arrives verified. */
function stateMemory() {
  const seen = new Map(); // purchase id → was it verified when last shown
  return (id, verified) => {
    const was = seen.get(id);
    // Never downgrade: a stale, older response can't make a verified purchase play again.
    seen.set(id, Boolean(verified || was));
    return was === false && Boolean(verified);
  };
}
const justMatched = stateMemory();

/** The match: the copy slip slides into register under the original, then "verified" is written. */
function playMatch(mark) {
  if (calm() || !mark.animate) return;
  mark.querySelector('.copy').animate([{ transform: 'translate(6px, 6px)', opacity: 0 }, { transform: 'none', opacity: 1 }],
    { duration: 520, easing: EASE, delay: 150, fill: 'backwards' });
  mark.querySelector('.word').animate([{ clipPath: 'inset(0 100% 0 0)' }, { clipPath: 'inset(0 0 0 0)' }],
    { duration: 280, easing: 'ease-out', delay: 560, fill: 'backwards' });
}

const agentColor = (agentId) => {
  const i = ui.state.agents.findIndex((a) => a.id === agentId);
  return COLORS[(i < 0 ? 0 : i) % COLORS.length];
};

// ── load + render ────────────────────────────────────────────────────────────

// Refreshes can overlap (live updates, actions, undo). Each takes a number; whatever a slower,
// older one fetched is dropped instead of drawn over a newer screen.
let refreshGen = 0;
const stale = (gen) => gen !== refreshGen;

async function refresh() {
  const gen = ++refreshGen;
  const hadFirstPurchase = ui.state?.onboarding.steps.find((x) => x.id === 'first_purchase')?.done;
  const fresh = await api('GET', '/api/state');
  if (stale(gen)) return;
  ui.state = fresh;
  // The moment that proves the whole loop works: say so.
  if (hadFirstPurchase === false && ui.state.onboarding.steps.find((x) => x.id === 'first_purchase')?.done) {
    toast('🎉 Your agent just recorded its first purchase. Twinslip is working.', [], { ms: 10000 });
  }
  const s = ui.state;
  // Open on the month that has something to show: this month, or last month early on.
  ui.month ??= s.headline.this_month.by_currency.length ? s.headline.this_month.month : s.headline.last_month.month;
  const hasAgents = s.agents.length > 0;
  // Ready once something real is feeding the ledger: an agent app that actually connected (not
  // just started), or a bank CSV, receipts or phone. A bank CSV alone is enough for Mine.
  const hasSources = s.sources.some((x) => x.kind !== 'manual' && (x.kind !== 'agent' || x.last_attempt_at));

  // Or the person started with their own spending: one expense is enough. No agent needed.
  const ready = hasSources || Boolean(s.onboarding.steps.find((x) => x.id === 'first_expense')?.done);
  // Settings stay reachable during step 2 so a user can add agents before connecting.
  let view = currentView();
  if (!ready && !(hasAgents && view === 'settings')) view = 'home';
  $('#onboard-agent').hidden = ready || view !== 'home';
  $('#onboard-human').hidden = ready || view !== 'home';
  $('#menu').hidden = !ready && !hasAgents;
  for (const a of $$('#menu a[data-needs="ready"]')) a.hidden = !ready;
  for (const id of HOME) $(id).hidden = !ready || view !== 'home';
  for (const [name, id] of Object.entries(VIEWS)) $(id).hidden = view !== name;
  $('#back').hidden = view === 'home';

  renderSync();
  renderHandoff();
  for (const el of $$('.setup-cmd')) el.textContent = (s.setup_command ?? 'twinslip setup --agent').replace(/ --agent$/, '');
  const agentSources = s.sources.filter((x) => x.kind === 'agent');
  for (const el of $$('.agent-wait')) {
    const live = agentSources.find((x) => x.last_attempt_at);
    el.textContent = live ? `${live.label} is connected.` : 'This page moves on by itself when your agent connects.';
    el.classList.toggle('ok', Boolean(live));
  }
  if (!ready && !hasAgents) return;
  renderSettings();
  if (!ready) return;
  renderHero();
  renderSetup(view === 'home');
  renderHealthBanner(view === 'home');
  renderUpdate(view === 'home');
  await renderAttentionBanner(view === 'home');
  if (view === 'home') await Promise.all([renderInbox(gen), renderRecent(gen)]);
  else { $('#needs-banner').hidden = true; $('#inbox-card').hidden = true; }
  if (view === 'totals') await renderTotals();
  if (view === 'purchases') await renderPurchases(gen);
  if (view === 'subscriptions') await renderSubscriptions();
  if (view === 'jobs' || view === 'home' || view === 'settings') await renderAhead(view);
  else $('#ahead-card').hidden = true;
  if (view === 'refunds') await renderRefunds();
  if (view === 'attention') await renderAttention();
  if (view === 'taxpack') renderTaxpack();
  if (view === 'audit') await renderAudit();
  if (view === 'settings') await Promise.all([renderCapture(), renderSchedule()]);
  if (view === 'home') await renderProAlerts();
  else $('#pro-alerts').hidden = true;
}

// The handoff (docs/design/AGENT-SETUP-PLAN.md): setup is the agent's job. The person's one
// instruction is a sentence to say to it.
const HANDOFF = 'Set up Twinslip';
function copyHandoff() {
  guard(async () => { await navigator.clipboard.writeText(HANDOFF); toast('Copied. Paste it into your agent app.'); });
}
/** "Say this to your agent", with a Copy button. */
function handoffLine() {
  return h('div', { class: 'handoff' }, h('p', { class: 'say', text: HANDOFF }), h('button', { type: 'button', onclick: copyHandoff }, 'Copy'));
}
/** The agent apps setup connected: ready to open, or already connected. */
function renderHandoff() {
  const hosts = (ui.state.setup_hosts ?? []).filter((x) => x.status !== 'not-installed');
  $('#handoff-hosts').replaceChildren(...hosts.map((x) => h('li', {},
    h('div', { class: 'who' }, h('div', { class: 'm', text: x.name }),
      h('div', { class: 'd' }, x.connected ? `Connected as "${x.agent}"` : x.configured ? `Ready: open ${x.name} and say it` : `Couldn't connect. ${x.fix ?? ''}`)),
    x.connected ? h('span', { class: 'state ok' }, slip('ok'), 'connected') : null)));
  $('#handoff-hosts').hidden = hosts.length === 0;
  // No agent app found or connected: say so plainly, and point to doing it yourself.
  const any = hosts.some((x) => x.configured);
  $('#handoff-intro').textContent = any
    ? 'Twinslip is connected to your agent apps. Open one and say this. Your agent does the rest and tells you if anything is left for you.'
    : "No agent app was found on this computer yet. Install one, such as Claude, ChatGPT, Codex, Cursor, VS Code, Gemini CLI or Zed, and start Twinslip again; it connects itself. Then say this to your agent. Or do it yourself below.";
}

/** Setup checklist: ticks itself from what actually happened. Help text only for what's left. */
function renderSetup(onHome) {
  const o = ui.state.onboarding;
  const name = ui.state.agents[0]?.name ?? 'your agent';
  const card = $('#setup-card');
  card.hidden = !onHome || o.all_done || o.dismissed;
  if (card.hidden) return;
  // Finished once the one required step is done; the rest are extras, and it says so.
  $('#setup-count').textContent = o.complete ? `done · ${o.total - o.done} optional left` : `${o.done} of ${o.total} done`;
  const agentDoes = () => h('span', { class: 'who-does' }, 'Your agent can do this.');
  const youDo = () => h('span', { class: 'who-does you' }, 'Only you can do this.');
  const STEP = {
    first_expense: {
      todo: 'Add or import your first expense',
      done: 'Your ledger has its first expense',
      help: () => [youDo(), 'Add one below, ', h('a', { href: '#settings' }, "import your bank's CSV file"), ', or let your agent report its next purchase. No agent is needed to track your own spending.'],
    },
    agent: { todo: 'An agent app connects', done: `Your agent: ${name}`, help: () => [agentDoes(), 'Open your agent app and say:', handoffLine()] },
    connected: {
      todo: 'Connect your agent',
      done: `${name} is connected`,
      // Said once: when the step above is open too, this one just ticks along with it.
      help: () => (o.steps.find((x) => x.id === 'agent')?.done
        ? [agentDoes(), 'Open your agent app (Claude, ChatGPT, Codex, Cursor, VS Code or another one Twinslip connected) and say:', handoffLine()]
        : [h('span', { class: 'who-does' }, 'Happens by itself.'), 'Ticks when your agent app connects.']),
    },
    first_purchase: {
      todo: 'First purchase from your agent',
      done: 'First purchase recorded',
      help: () => [h('span', { class: 'who-does' }, 'Your agent does this, the next time it pays.'), `It appears here within a second. To check the connection now, ask ${name}: “How much have you spent this month?”`],
    },
    receipts: {
      todo: 'Find receipts and bank alerts in your email',
      done: 'Email searched',
      help: () => [agentDoes(), `If ${name} can read your email (using access you already gave it), say:`, handoffLine(),
        h('span', { class: 'help-note' }, "It runs when you ask; nothing sweeps on a schedule. No agent that can read your email? Import your bank's CSV or use the iPhone instead: nothing in Twinslip reads your mailbox.")],
    },
    phone: {
      todo: 'Capture from your iPhone',
      done: 'iPhone connected',
      help: () => [youDo(), 'Open the Twinslip iPhone app and follow its three steps. Purchases you make with your phone land here by themselves.'],
    },
    bank: {
      todo: 'Check purchases against your bank',
      done: 'Bank connected',
      help: () => [youDo(), "This is what puts the ✓ on what your agents report: download your bank's CSV file from its website and ", h('a', { href: '#settings' }, 'import it in Settings'), '. Twinslip never logs into your bank.'],
    },
  };
  // Only the step you're on is open (POLISH-RESEARCH #6); later ones are a click away, and
  // one you opened stays open across live refreshes.
  const next = o.steps.find((s) => !s.done);
  const opened = new Set($$('#setup-steps details[open]').map((d) => d.dataset.step));
  $('#setup-steps').replaceChildren(...o.steps.map((s) => {
    const t = STEP[s.id];
    const opt = s.optional && !s.done ? h('span', { class: 'opt' }, 'optional') : null;
    const mark = h('span', { class: 'step-mark', 'aria-hidden': 'true' }, s.done ? '✓' : '');
    const cls = s.done ? 'done' : s === next ? 'next' : '';
    if (s.done || !t.help) return h('li', { class: cls }, mark, h('div', {}, h('div', { class: 'title' }, s.done ? t.done : t.todo, opt)));
    if (s === next) return h('li', { class: cls }, mark, h('div', {}, h('div', { class: 'title' }, t.todo, opt), h('div', { class: 'help' }, ...t.help())));
    return h('li', { class: cls }, mark,
      h('details', { 'data-step': s.id, open: opened.has(s.id) },
        h('summary', { class: 'title' }, t.todo, opt, h('span', { class: 'how' }, 'How')),
        h('div', { class: 'help' }, ...t.help())));
  }));
}

async function renderProAlerts() {
  const box = $('#pro-alerts');
  if (!isPro()) { box.hidden = true; return; }
  const { alerts } = await api('GET', '/api/alerts');
  box.hidden = alerts.length === 0;
  box.replaceChildren(...alerts.map((a) => h('li', {}, a.message)));
}

function renderTaxpack() {
  const year = Number(ui.state.headline.this_month.month.slice(0, 4));
  const sel = $('#taxpack-year');
  if (!sel.options.length) sel.replaceChildren(...[year, year - 1, year - 2].map((y) => h('option', { value: y }, String(y))));
  $('#taxpack-form').hidden = !isPro();
  $('#taxpack-upsell').hidden = isPro();
  $('#taxpack-upsell').replaceChildren('The tax pack is part of Pro. ', h('a', { href: '#settings', onclick: (e) => { e.preventDefault(); goPro(); } }, 'See Pro'));
}

async function renderAudit() {
  const ok = isPro() && ui.state.pro.seats >= 2;
  $('#audit-upsell').hidden = ok;
  $('#audit-upsell').replaceChildren('The audit trail comes with Pro for 2 or more seats. ', h('a', { href: '#settings', onclick: (e) => { e.preventDefault(); goPro(); } }, 'See Pro'));
  if (!ok) { $('#audit').replaceChildren(); return; }
  const { audit } = await api('GET', '/api/audit');
  const said = { agent: 'Agents', mine: 'Mine', undo: 'Undone', rule: 'Rule' };
  $('#audit').replaceChildren(...(audit.length ? audit.map((e) => h('li', {},
    h('div', { class: 'who' },
      h('div', { class: 'm' }, `${said[e.action] ?? e.action}: ${e.merchant ?? ''}`, e.agent ? ` → ${e.agent}` : ''),
      h('div', { class: 'd', text: `${new Date(e.at).toLocaleString()}${e.detail ? ` · ${e.detail}` : ''}` })),
    e.amount_cents != null ? h('div', { class: 'amt', text: money(e.amount_cents, e.currency ?? 'USD') }) : null)) : [h('li', { class: 'muted small' }, 'Nothing sorted yet.')]));
}

const AGENT_SNIPPET = (name) => `You're connected to Twinslip, which keeps my record of what my agents spend.
Every time you complete a purchase or payment for me, of any amount and by any method (card, prepaid credits, crypto, invoice), call record_purchase right away with the merchant, the amount actually charged, the payment method, and the order or transaction id as the reference.
Before a purchase over $20, call get_budget and tell me if it would go over my budget. Before buying from a merchant you haven't used for me, call check_mandate, and ask me first if it's outside.
Report small pay-per-request payments with record_usage. Name the job each purchase is for (job), and the client if I bill the work to one (client). When you finish a job, tell me what it cost with get_job_cost.
When I ask you to bill a client, call get_unbilled and help me draft the invoice from it. Never tell me something is billed: I mark that in Twinslip.
Never include card numbers, passwords or API keys in anything you record.
You are "${name}" in my ledger.`;

async function renderCapture() {
  const info = await api('POST', '/api/capture-info', {});
  $('#capture-phone').textContent = info.sync_dir
    ? 'connected through iCloud Drive › Shortcuts › Twinslip. Set up the shortcuts in the iPhone app.'
    : 'turn on iCloud Drive and the Shortcuts app on this Mac, then reopen Twinslip.';
  $('#capture-url').textContent = info.webhook_url;
  $('#capture-key-copy').onclick = () => guard(async () => { await navigator.clipboard.writeText(info.key); toast('Capture key copied. Keep it private.'); });
  $('#agent-snippet').textContent = AGENT_SNIPPET(ui.state.agents[0]?.name ?? 'my agent');
}

// ── Share card: "My agents cost me $X last month." No merchants, no Mine. ──
const share = { size: 'social', names: false };
function shareFacts() {
  const { last_month: last, this_month: cur } = ui.state.headline;
  const useLast = (last.by_currency[0]?.cents ?? 0) > 0;
  const month = useLast ? last : cur;
  const row = month.by_currency[0];
  // Every field from the same month and currency: the agents who spent it, not this month's.
  const agents = (month.by_agent ?? []).filter((a) => a.currency === row?.currency && a.cents > 0);
  const verifiedPct = row?.cents > 0 ? Math.max(0, Math.min(100, Math.round(((row.verified_cents ?? 0) / row.cents) * 100))) : 0;
  return {
    amount: money(row?.cents ?? 0, row?.currency ?? 'USD'),
    when: useLast ? 'last month' : `so far in ${monthName(cur.month)}`,
    agentCount: agents.length,
    names: agents.map((a) => a.agent),
    verifiedPct,
  };
}
function shareText(f) {
  return `My agents cost me ${f.amount} ${f.when}. What did yours cost you? ${(ui.state.site_url ?? 'https://twinslip.example').replace(/^https?:\/\//, '')}`;
}
// Share card colors: design/tokens.json (test/design.test.js keeps them in step).
const CARD = { carbon: '#121628', rule: '#323a5c', edge: '#6b74a3', paper: '#ece7da', 'paper-2': '#a9aecb', transfer: '#9ea6ff', copy: '#464b78' };

/** The detail line, made to fit: agent names if they fit, else "N agents", then smaller type. */
function fitDetail(g, f, font, maxWidth, size, floor) {
  // Same as the iPhone card: say nothing about checking until something has been checked.
  const tail = f.verifiedPct > 0 ? ` · ${f.verifiedPct}% checked against your bank` : '';
  const count = `${f.agentCount} agent${f.agentCount === 1 ? '' : 's'}`;
  const options = share.names && f.names.length ? [f.names.join(', '), count] : [count];
  for (let px = size; px >= floor; px -= 2) {
    g.font = font(500, px);
    for (const who of options) {
      const text = `across ${who}${tail}`;
      if (g.measureText(text).width <= maxWidth) return text;
    }
  }
  g.font = font(500, floor);
  return `across ${count}`;
}

function drawShareCard() {
  const f = shareFacts();
  const c = $('#share-canvas');
  const phone = share.size === 'phone';
  const [W, H] = phone ? [1080, 1350] : [1200, 630];
  c.width = W; c.height = H;
  const g = c.getContext('2d');
  const pad = 72;
  const maxWidth = W - pad * 2;
  const font = (w, s) => `${w} ${s}px "Schibsted Grotesk", ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif`;
  const site = (ui.state.site_url ?? 'https://twinslip.example').replace(/^https?:\/\//, '');

  // Ground, with a visible edge so the card holds its shape on a light feed.
  g.fillStyle = CARD.carbon; g.fillRect(0, 0, W, H);
  g.strokeStyle = CARD.edge; g.lineWidth = 4; g.strokeRect(2, 2, W - 4, H - 4);

  // Brand: the original slip and its copy, then the name.
  g.fillStyle = CARD.transfer; g.fillRect(pad + 9, pad + 9, 30, 36);
  g.fillStyle = CARD.paper; g.fillRect(pad, pad, 30, 36);
  g.fillStyle = CARD['paper-2']; g.font = font(650, 32); g.fillText('Twinslip', pad + 58, pad + 31);

  const top = phone ? 440 : 236;
  g.fillStyle = CARD.paper; g.font = font(500, phone ? 64 : 50);
  g.fillText('My agents cost me', pad, top);
  // The total, with its carbon copy out of register behind it.
  const amountY = top + (phone ? 172 : 132);
  g.font = font(800, phone ? 156 : 124);
  g.fillStyle = CARD.copy; g.fillText(f.amount, pad + 7, amountY + 7, maxWidth);
  g.fillStyle = CARD.paper; g.fillText(f.amount, pad, amountY, maxWidth);
  g.font = font(500, phone ? 64 : 50);
  g.fillText(`${f.when}.`, pad, top + (phone ? 264 : 206));

  g.fillStyle = CARD['paper-2'];
  const detail = fitDetail(g, f, font, maxWidth, phone ? 38 : 30, phone ? 28 : 24);
  g.fillText(detail, pad, top + (phone ? 344 : 262));

  // Perforation, then the tear-off line.
  const footY = H - pad + 6;
  g.strokeStyle = CARD.rule; g.lineWidth = 2; g.setLineDash([12, 8]);
  g.beginPath(); g.moveTo(pad, footY - 52); g.lineTo(W - pad, footY - 52); g.stroke(); g.setLineDash([]);
  g.fillStyle = CARD.transfer; g.font = font(650, 30);
  g.fillText(`What did your agents cost you? → ${site}`, pad, footY, maxWidth);
}
function shareBlob() {
  return new Promise((resolve) => $('#share-canvas').toBlob(resolve, 'image/png'));
}
async function countShare(channel) {
  try { await api('POST', '/api/share-event', { channel, size: share.size }); } catch { /* counting never blocks sharing */ }
}

const CADENCE = { weekly: 'week', monthly: 'month', yearly: 'year' };

async function renderSubscriptions() {
  const { subscriptions, monthly_total: total } = await api('GET', '/api/subscriptions');
  const active = subscriptions.filter((s) => s.status === 'active');
  $('#subs-total').textContent = active.length
    ? `About ${total.map((t) => money(t.cents, t.currency)).join(' + ')} a month across ${active.length} active subscription${active.length === 1 ? '' : 's'}.`
    : 'No recurring charges yet. They show up here after an agent pays the same merchant twice on a schedule.';
  $('#subscriptions').replaceChildren(...subscriptions.map((s) => h('li', { class: s.status === 'lapsed' ? 'lapsed' : '' },
    h('div', { class: 'who' },
      h('div', { class: 'm', text: s.merchant }),
      h('div', { class: 'd' }, `${s.agent} · ${s.cadence} since ${shortDate(s.since)}`,
        s.status === 'lapsed' ? ` · looks stopped (last ${shortDate(s.last_on)})` : ` · next about ${shortDate(s.next_on)}`)),
    h('span', { class: 'agent-chip', text: s.agent }),
    h('div', { class: 'amt' }, money(s.amount_cents, s.currency), h('span', { class: 'of', text: ` / ${CADENCE[s.cadence]}` })))));
}

// Where agent spending is heading (docs/design/AHEAD.md): mandate flags and paying twice on
// Home, cost per job and pay-per-use on Jobs, each agent's mandate in Settings. All free.
const METHODS = { card: 'Card', prepaid_credits: 'Prepaid credits', crypto: 'Crypto', bank_transfer: 'Bank transfer', invoice: 'Invoice', other: 'Other' };

async function renderAhead(view) {
  const a = await api('GET', `/api/ahead?view=${view}`);
  if (view !== 'home') $('#ahead-card').hidden = true;
  if (view === 'home') renderWorthALook(a);
  if (view === 'jobs') renderJobs(a);
  if (view === 'settings') renderMandates(a);
}

function renderWorthALook(a) {
  $('#ahead-card').hidden = a.flags.length + a.overlaps.length === 0;
  const answer = (f, how) => guard(async () => {
    await api('POST', `/api/mandate-flags/${f.id}`, { how });
    toast(how === 'allowed' ? `${f.agent}'s mandate now covers this.` : 'Noted.');
    await refresh();
  });
  $('#mandate-flags').replaceChildren(...a.flags.map((f) => h('li', {},
    h('div', { class: 'who' },
      h('div', { class: 'm', text: `${f.agent} bought outside its mandate: ${f.merchant}` }),
      h('div', { class: 'd', text: `${shortDate(f.occurred_on)} · ${f.reasons.map((r) => r.text).join(' ')}` })),
    h('div', { class: 'amt', text: money(f.amount_cents, f.currency) }),
    h('div', { class: 'pick' },
      h('button', { type: 'button', class: 'ghost', onclick: () => answer(f, 'noted') }, 'Noted'),
      // Only what a tap can widen: a merchant, the one-purchase limit, a payment method. An ended
      // mandate or a different currency is the user's to edit in Settings, never restarted by a tap.
      !f.reasons.some((r) => ['merchant', 'amount', 'method'].includes(r.code)) || f.reasons.some((r) => r.code === 'expired') ? null
        : h('button', { type: 'button', onclick: () => answer(f, 'allowed') }, 'Allow next time')))));
  $('#overlaps').replaceChildren(...a.overlaps.map((o) => h('li', {},
    h('div', { class: 'who' },
      h('div', { class: 'm', text: `Paying twice: ${o.merchant}` }),
      h('div', { class: 'd', text: o.text })),
    h('div', { class: 'amt' }, o.combined_monthly.map((t) => money(t.cents, t.currency)).join(' + '), h('span', { class: 'of', text: ' / month' })))));
}

function renderJobs(a) {
  $('#jobs-empty').hidden = a.jobs.length > 0;
  $('#client-names').replaceChildren(...a.client_names.map((n) => h('option', { value: n })));
  // Every client with something to bill or a billing to undo, even one whose jobs aren't listed below.
  $('#clients-head').hidden = !a.clients.length;
  $('#jobs-head').hidden = !a.clients.length || !a.jobs.length;
  $('#clients').replaceChildren(...a.clients.map(clientRow));
  const owed = new Map(a.clients.filter((c) => c.lines).map((c) => [c.client_id, c]));
  // A live refresh never rebuilds a client form the user has open: their typing would be lost.
  if (!$('#jobs').querySelector('details[open]')) $('#jobs').replaceChildren(...a.jobs.map((j) => jobRow(j, owed.get(j.client_id))));
  $('#streams-empty').hidden = a.streams.length > 0;
  $('#streams').replaceChildren(...a.streams.map((s) => h('li', {},
    h('div', { class: 'who' },
      h('div', { class: 'm', text: s.merchant }),
      h('div', { class: 'd', text: `${s.agent} · ${shortDate(s.day)} · ${s.payments.toLocaleString()} payment${s.payments === 1 ? '' : 's'}, ${s.exact} exactly${s.job ? ` · ${s.job}` : ''}${s.purchase_id ? '' : ' · under a cent so far'}` })),
    h('div', { class: 'amt', text: s.counted }))));
}

// Billing clients (src/billing.js): each job's client, and "Bill <client> $X" for what that client
// hasn't been billed yet. Seeing it is free. On Free the button opens a preview of the statement,
// watermarked, with one line on Pro and its price; nothing else in the app asks for Pro here.
function jobRow(j, owed) {
  const input = h('input', { list: 'client-names', value: j.client ?? '', maxlength: '80', placeholder: 'Client name', 'aria-label': `Client for ${j.job}` });
  const save = (client) => guard(async () => {
    const r = await api('PUT', '/api/jobs/client', { job: j.job, client });
    toast(r.client ? `"${j.job}" is billed to ${r.client} now, later purchases too.` : `"${j.job}" has no client now.`);
    $('#jobs').querySelectorAll('details[open]').forEach((d) => { d.open = false; });
    await refresh();
  });
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); save(input.value); } });
  return h('li', {},
    h('div', { class: 'who' },
      h('div', { class: 'm', text: j.job }),
      h('div', { class: 'd', text: [
        j.client ? `for ${j.client}` : null,
        j.first_on === j.last_on ? shortDate(j.first_on) : `${shortDate(j.first_on)} – ${shortDate(j.last_on)}`,
        `${j.purchases} purchase${j.purchases === 1 ? '' : 's'} by ${j.agents.join(', ')}`,
        `paid to ${j.merchants.slice(0, 4).join(', ')}${j.merchants.length > 4 ? ` and ${j.merchants.length - 4} more` : ''}`,
        j.verified === j.purchases ? 'all checked against your bank or a receipt' : `${j.verified} of ${j.purchases} checked`,
      ].filter(Boolean).join(' · ') }),
      h('div', { class: 'row job-client' },
        owed ? h('button', { type: 'button', class: 'ghost bill', onclick: () => guard(() => openStatement(owed.client_id)) },
          `Bill ${owed.client} ${owed.billable.map((t) => money(t.cents, t.currency)).join(' + ')}`) : null,
        j.client && !owed ? h('span', { class: 'muted small', text: `Nothing to bill ${j.client} right now.` }) : null,
        j.client && !owed ? h('button', { type: 'button', class: 'link', onclick: () => guard(() => openStatement(j.client_id)) }, 'What was billed') : null,
        h('details', { class: 'inner' },
          h('summary', {}, j.client ? 'Change client' : 'Add a client'),
          h('div', { class: 'row' }, input,
            h('button', { type: 'button', onclick: () => save(input.value) }, 'Save'),
            j.client ? h('button', { type: 'button', class: 'link', onclick: () => save(null) }, 'No client') : null)))),
    h('div', { class: 'amt', text: j.totals.map((t) => money(t.cents, t.currency)).join(' + ') }));
}

function clientRow(c) {
  const due = c.billable.map((t) => money(t.cents, t.currency)).join(' + ');
  const open = () => guard(() => openStatement(c.client_id));
  return h('li', {},
    h('div', { class: 'who' },
      h('div', { class: 'm', text: c.client }),
      h('div', { class: 'd', text: c.lines
        ? [`${c.lines} line${c.lines === 1 ? '' : 's'} not billed yet`,
          c.first_on === c.last_on ? shortDate(c.first_on) : `${shortDate(c.first_on)} – ${shortDate(c.last_on)}`,
          c.markup_bp ? `${c.markup_bp / 100}% handling fee` : null,
          c.billings ? `${c.billings} marked billed before` : null].filter(Boolean).join(' · ')
        : `Nothing to bill right now · ${c.billings} marked billed` })),
    c.lines ? h('div', { class: 'amt', text: due }) : null,
    c.lines ? h('button', { type: 'button', class: 'ghost bill', 'aria-label': `Bill ${c.client} ${due}`, onclick: open }, 'Bill')
      : h('button', { type: 'button', class: 'link', onclick: open }, 'What was billed'));
}

const statement = { clientId: null, period: 'all', data: null };

/** Messages inside the open statement: a toast would sit behind the modal dialog. */
function say(message, { error = false } = {}) {
  const el = $('#statement-status');
  el.textContent = message;
  el.classList.toggle('error', error);
}
async function statementGuard(fn) {
  try {
    say('');
    await fn();
  } catch (err) {
    say(err.message, { error: true });
  }
}

async function openStatement(clientId) {
  statement.clientId = clientId;
  statement.period = 'all';
  $('#statement-invoice').value = '';
  $('#statement-settings').open = false;
  say('');
  await loadStatement();
  if (!$('#statement-dialog').open) $('#statement-dialog').showModal();
}

async function loadStatement() {
  statement.data = await api('GET', `/api/clients/${statement.clientId}/statement?period=${encodeURIComponent(statement.period)}`);
  renderStatement(statement.data);
}

function renderStatement(st) {
  const preview = st.preview;
  $('#statement-title').textContent = preview ? `Preview: the statement for ${st.client.name}` : `Bill ${st.client.name}`;
  $('#statement-watermark').hidden = !preview;
  const sel = $('#statement-period');
  const months = st.months.includes(st.period.key) || st.period.key === 'all' ? st.months : [st.period.key, ...st.months];
  sel.replaceChildren(h('option', { value: 'all' }, 'Everything not billed yet'), ...months.map((m) => h('option', { value: m }, monthName(m))));
  sel.value = st.period.key;
  $('#statement-from').textContent = st.business_name || 'Your business name';
  $('#statement-from').classList.toggle('muted', !st.business_name);
  $('#statement-meta').textContent = `For ${st.client.name} · ${st.period.label} · prepared ${st.prepared_on}`;
  $('#statement-lines').replaceChildren(...(st.lines.length ? st.lines.map((l) => h('tr', {},
    h('td', { class: 'date', text: shortDate(l.occurred_on) }),
    h('td', {},
      h('div', {}, h('span', { class: 'm', text: l.merchant }), h('span', { class: 'muted', text: ` ${l.agent}${l.job ? ` · ${l.job}` : ''}` })),
      // How the line was checked, under it: the same marks as everywhere else in the app.
      l.marked ? h('span', { class: 'state flag' }, slip('flag'), 'Agent report only')
        : ['bank', 'iphone', 'receipt', 'webhook', 'verified'].includes(l.evidence) ? h('span', { class: 'state ok' }, slip('ok'), l.evidence_label)
          : h('span', { class: 'state muted', text: l.evidence_label })),
    h('td', { class: 'num', text: money(l.cents, l.currency) }))) : [h('tr', {}, h('td', { colspan: '3', class: 'muted', text: 'Nothing to bill for this period.' }))]));
  const multi = st.totals.length > 1;
  const cur = (t) => (multi ? ` (${t.currency})` : '');
  $('#statement-totals').replaceChildren(...st.totals.flatMap((t) => [
    h('tr', {}, h('th', { scope: 'row', text: `Subtotal${cur(t)}` }), h('td', { class: 'num', text: money(t.subtotal_cents, t.currency) })),
    t.markup_cents ? h('tr', {}, h('th', { scope: 'row', text: `Handling fee (${st.client.markup_bp / 100}%)${cur(t)}` }), h('td', { class: 'num', text: money(t.markup_cents, t.currency) })) : null,
    h('tr', { class: 'total' }, h('th', { scope: 'row', text: `Total${cur(t)}` }), h('td', { class: 'num', text: money(t.total_cents, t.currency) })),
  ].filter(Boolean)));
  $('#statement-note').hidden = !st.marked;
  $('#statement-note').textContent = st.marked
    ? `${st.marked === 1 ? 'One line was' : `${st.marked} lines were`} reported by an agent with no independent proof yet: no bank line, iPhone record or receipt you attached has seen ${st.marked === 1 ? 'it' : 'them'}. The statement marks ${st.marked === 1 ? 'it' : 'them'}.`
    : '';
  $('#statement-upsell').hidden = !preview;
  if (preview) {
    $('#statement-upsell').replaceChildren(`${st.pro_line} `, h('a', { href: '#settings', onclick: (e) => { e.preventDefault(); $('#statement-dialog').close(); goPro(); } }, 'See Pro'));
  }
  $('#statement-pro').hidden = preview;
  for (const b of ['#statement-bill', '#statement-pdf', '#statement-csv', '#statement-lines-csv']) $(b).disabled = !st.lines.length;
  if (document.activeElement !== $('#statement-business')) $('#statement-business').value = st.business_name;
  if (document.activeElement !== $('#statement-fee')) $('#statement-fee').value = st.client.markup_bp ? String(st.client.markup_bp / 100) : '';
  $('#statement-billed').hidden = !st.billings.length;
  $('#statement-billings').replaceChildren(...st.billings.map((b) => h('li', {},
    h('div', { class: 'who' },
      h('div', { class: 'm', text: b.reference }),
      h('div', { class: 'd', text: `${new Date(b.billed_at).toLocaleDateString()} · ${b.lines} line${b.lines === 1 ? '' : 's'}${b.markup_bp ? ` · with the ${b.markup_bp / 100}% handling fee` : ''}` })),
    h('div', { class: 'amt', text: b.billable.map((t) => money(t.cents, t.currency)).join(' + ') }),
    h('button', { type: 'button', class: 'link', onclick: () => statementGuard(async () => {
      await api('POST', `/api/billings/${b.id}/undo`, {});
      await loadStatement();
      say(`${b.reference} is undone: its lines are unbilled again.`);
      await refresh();
    }) }, 'Undo'))));
}

async function downloadStatement(kind) {
  const q = new URLSearchParams({ period: statement.period });
  if (kind === 'invoice-lines.csv') q.set('invoice', $('#statement-invoice').value.trim());
  const res = await fetch(`/api/clients/${statement.clientId}/${kind}?${q}`, { headers: { 'X-Ledger-Token': TOKEN } });
  if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || `Download failed (${res.status})`);
  const name = /filename="([^"]+)"/.exec(res.headers.get('Content-Disposition') ?? '')?.[1] ?? 'Twinslip-statement';
  const href = URL.createObjectURL(await res.blob());
  const a = h('a', { href, download: name });
  $('#statement-dialog').append(a); a.click(); a.remove(); // inside the dialog: the page behind a modal is inert
  setTimeout(() => URL.revokeObjectURL(href), 5000);
  say(`Saved ${name}.`);
}

function renderMandates(a) {
  // A live refresh never rebuilds a form the user has open: their typing would be lost.
  if ($('#mandates').querySelector('details[open]')) return;
  const byAgent = new Map(a.mandates.map((m) => [m.agent_id, m]));
  $('#mandates').replaceChildren(...ui.state.agents.map((agent) => {
    const m = byAgent.get(agent.id);
    const merchants = h('input', { value: m ? m.merchants.join(', ') : '', placeholder: 'Any merchant', 'aria-label': `Merchants ${agent.name} may pay, separated by commas` });
    const max = h('input', { class: 'budget', inputmode: 'decimal', placeholder: 'No limit', value: m?.max_purchase_cents ? (m.max_purchase_cents / 100).toFixed(2) : '', 'aria-label': `Most ${agent.name} may spend on one purchase` });
    const until = h('input', { type: 'date', value: m?.until ?? '', 'aria-label': `Last day ${agent.name}'s mandate covers` });
    const note = h('input', { value: m?.note ?? '', maxlength: '200', placeholder: 'A note for your agent (optional)', 'aria-label': `Note in ${agent.name}'s mandate` });
    const boxes = Object.entries(METHODS).map(([k, label]) => {
      const box = h('input', { type: 'checkbox', value: k, checked: Boolean(m?.methods.includes(k)) });
      return h('label', { class: 'check' }, box, label);
    });
    return h('li', {},
      h('details', { class: 'inner mandate' },
        h('summary', {}, h('span', { class: 'm', text: agent.name }), h('span', { class: 'muted small', text: m ? m.text : 'No mandate: may buy anything.' })),
        h('label', { class: 'stack' }, h('span', { class: 'muted small' }, 'May pay (leave empty for anyone)'), merchants),
        h('div', { class: 'row' },
          h('label', { class: 'budget-field' }, h('span', { class: 'muted small' }, 'Most for one purchase'), max),
          h('label', { class: 'budget-field' }, h('span', { class: 'muted small' }, 'Until'), until)),
        h('fieldset', { class: 'methods' }, h('legend', { class: 'muted small' }, 'May pay by (none ticked: any way)'), boxes),
        h('label', { class: 'stack' }, h('span', { class: 'muted small' }, 'Note'), note),
        h('div', { class: 'row' },
          h('button', { type: 'button', onclick: () => guard(async () => {
            await api('PUT', `/api/agents/${agent.id}/mandate`, {
              merchants: merchants.value, max_purchase: max.value, until: until.value || null, note: note.value,
              currency: m?.currency ?? 'USD',
              methods: boxes.map((b) => b.querySelector('input')).filter((b) => b.checked).map((b) => b.value),
            });
            toast(`Saved ${agent.name}'s mandate.`);
            $('#mandates').querySelectorAll('details[open]').forEach((d) => { d.open = false; });
            await refresh();
          }) }, 'Save mandate'),
          m ? h('button', { type: 'button', class: 'link', onclick: () => guard(async () => {
            await api('DELETE', `/api/agents/${agent.id}/mandate`);
            toast(`${agent.name} has no mandate now.`);
            $('#mandates').querySelectorAll('details[open]').forEach((d) => { d.open = false; });
            await refresh();
          }) }, 'Remove') : null)));
  }));
}

function renderSync() {
  const status = $('#sync-status');
  const csv = ui.state.sources.find((x) => x.kind === 'csv');
  status.textContent = csv ? `CSV imported ${ago(csv.last_success_at)}` : '';
}

/** The month as a line under the hero (POLISH-RESEARCH #1): this month's running total in
 *  `paper`, last month's behind it in `copy`, its carbon copy. Decorative: the sentence under it
 *  says the same in words, so the drawing is hidden from screen readers. */
function renderTrend(trend) {
  const box = $('#hero-trend');
  box.hidden = !trend;
  if (!trend) return box.replaceChildren();
  const NS = 'http://www.w3.org/2000/svg';
  const el = (tag, attrs) => { const e = document.createElementNS(NS, tag); for (const [k, v] of Object.entries(attrs)) e.setAttribute(k, v); return e; };
  const W = 320, H = 56, PAD = 3;
  const days = Math.max(trend.days_in_month, trend.last_month.length);
  const top = Math.max(trend.this_month.at(-1) ?? 0, trend.last_month.at(-1) ?? 0, 1);
  const x = (i) => (days <= 1 ? 0 : (i / (days - 1)) * W);
  const y = (cents) => H - PAD - (cents / top) * (H - 2 * PAD);
  const points = (line) => line.map((c, i) => `${x(i).toFixed(1)},${y(c).toFixed(1)}`).join(' ');
  const svg = el('svg', { viewBox: `0 0 ${W} ${H}`, focusable: 'false' });
  if (trend.last_month.length > 1) svg.append(el('polyline', { class: 'last', points: points(trend.last_month) }));
  if (trend.this_month.length > 1) svg.append(el('polyline', { class: 'this', points: points(trend.this_month) }));
  const end = trend.this_month.length - 1;
  svg.append(el('circle', { class: 'now', cx: x(end).toFixed(1), cy: y(trend.this_month[end] ?? 0).toFixed(1), r: '3' }));
  box.replaceChildren(svg);
}

const mineAmount = h('span'); // kept between renders so your own total can roll too
function renderHero() {
  const { last_month: last, this_month: cur } = ui.state.headline;
  const sum = (rows) => (rows.length ? rows.map((r) => money(r.cents, r.currency)).join(' + ') : money(0));
  rollText($('#hero-amount'), sum(cur.by_currency), { delay: ui.rollDelay });
  renderTrend(ui.state.headline.trend);
  const pace = cur.pace.length ? ` · on pace for ${cur.pace.map((r) => money(r.cents, r.currency)).join(' + ')}` : '';
  $('#hero-sub').textContent = `so far in ${monthName(cur.month)}${pace} · ${monthName(last.month)}: ${sum(last.by_currency)}`;
  // Saved purchases from agents the free plan doesn't cover: not in the total until they're sorted
  // or Pro counts them, and always said beside it (src/plan.js).
  const held = cur.held ?? [];
  $('#hero-held').hidden = held.length === 0;
  if (held.length) {
    const n = held.reduce((a, r) => a + r.n, 0);
    $('#hero-held').replaceChildren(`Plus ${sum(held)} from agents ${planName()} doesn't cover, saved in your inbox (${n} purchase${n === 1 ? '' : 's'}). `,
      upgradeAction('Count them with Pro', isPro() ? 'Add an agent to Pro to count them' : 'Get Pro to count them', 'link'));
  }

  // The share something the agents didn't supply saw (bank, iPhone, webhook, a receipt you attached). This is the product.
  const main = cur.by_currency[0];
  const verified = $('#hero-verified');
  verified.hidden = !main || main.cents <= 0;
  if (main && main.cents > 0) {
    const pct = Math.max(0, Math.min(100, Math.round((main.verified_cents / main.cents) * 100)));
    // Only what the agents don't supply can check them: the bank, the iPhone, the local webhook, Stripe Link.
    const canVerify = ui.state.sources.some((x) => ['simplefin', 'csv', 'phone', 'webhook', 'link'].includes(x.kind) && x.last_success_at);
    verified.classList.toggle('pending', !canVerify && pct === 0);
    verified.replaceChildren(...(!canVerify && pct === 0
      ? [slip('one'), 'Not verified yet: connect your bank or iPhone to check these']
      : [slip('ok'), `${pct}% checked against your bank or iPhone`]));
    verified.title = "The rest is what agents reported that your bank or iPhone hasn't seen yet. Receipts your agent finds are kept as evidence; attach one yourself to verify a purchase.";
  }

  // Free, always: how far last month is checked against the bank, said plainly when it isn't.
  const cov = ui.state.coverage;
  const hadLastMonth = (last.by_currency ?? []).length > 0 || (last.mine ?? []).length > 0;
  $('#hero-coverage').hidden = !cov || cov.bank_complete || !hadLastMonth;
  if (cov && !cov.bank_complete && hadLastMonth) {
    $('#hero-coverage').textContent = cov.bank_through
      ? `${monthName(cov.month)} isn't fully checked against your bank: its lines stop on ${shortDate(cov.bank_through)}.`
      : `${monthName(cov.month)} isn't checked against your bank yet: import its CSV file to check it.`;
  }

  // The other bucket: what you spent yourself, kept apart.
  // Shown from $0.00, so the two buckets are there from day one and the first "Mine" has a place to go.
  const mine = cur.mine?.[0] ?? { cents: 0, currency: cur.by_currency[0]?.currency ?? 'USD' };
  $('#hero-mine').hidden = false;
  if (!$('#hero-mine').contains(mineAmount)) $('#hero-mine').replaceChildren('You spent ', mineAmount, ' yourself this month, kept separate.');
  rollText(mineAmount, money(mine.cents, mine.currency), { delay: ui.rollDelay });
  $('#share-btn').hidden = !(cur.by_currency[0]?.cents > 0 || ui.state.headline.last_month.by_currency[0]?.cents > 0);

  // Budgets: only say something at 80% and above.
  const alerts = cur.budgets.filter((b) => b.level >= 80);
  $('#budget-alerts').hidden = alerts.length === 0 || currentView() !== 'home';
  $('#budget-alerts').replaceChildren(...alerts.map((b) => h('li', { class: b.level >= 100 ? 'over' : '' },
    b.level >= 100
      ? `${b.agent} is over its ${money(b.budget_cents, b.currency)} monthly budget (${money(b.spent_cents, b.currency)}, ${b.pct}%)`
      : `${b.agent} is at ${b.pct}% of its ${money(b.budget_cents, b.currency)} monthly budget`)));

  // One line per agent, biggest spender first. With a budget the bar is spend against it;
  // without one, its share of the biggest spender.
  const budgetOf = new Map(cur.budgets.map((b) => [b.agent, b]));
  const lines = [...cur.by_agent];
  for (const b of cur.budgets) if (!lines.some((a) => a.agent === b.agent)) lines.push({ agent: b.agent, cents: 0, currency: b.currency });
  const top = Math.max(1, ...lines.map((a) => a.cents));
  $('#agents-empty').hidden = lines.length > 0;
  $('#agent-lines').replaceChildren(...lines.map((a) => {
    const color = agentColor(ui.state.agents.find((x) => x.name === a.agent)?.id);
    const b = budgetOf.get(a.agent);
    const budgeted = b && b.currency === a.currency;
    const width = budgeted ? Math.min(100, b.pct) : Math.round((a.cents / top) * 100);
    const fill = budgeted && b.level >= 100 ? 'var(--alarm)' : budgeted && b.level >= 80 ? 'var(--flag)' : color;
    return h('li', {},
      h('span', { class: 'dot', style: `background:${color}` }),
      h('span', { class: 'name', text: a.agent }),
      h('span', { class: 'share', 'aria-hidden': 'true' },
        h('span', { style: `width:${Math.max(2, width)}%;background:${fill}` })),
      h('span', { class: 'amt' }, money(a.cents, a.currency),
        budgeted ? h('span', { class: 'of', text: ` of ${money(b.budget_cents, b.currency)}` }) : null));
  }));
}

/** Why the agents' total just went up (POLISH-RESEARCH #4), in one line: what arrived, and who
 *  put it there. Only what arrived without you: your own sorting already says so in a toast.
 *  "+$25.00 · OpenRouter, reported by Muse". Empty when there's nothing to say. */
function whyMoved(arrived, fmt) {
  const by = (p) => (p.attributed_by === 'agent' ? `reported by ${p.agent_name}`
    : p.attributed_by === 'rule' ? `filed for ${p.agent_name} by your rule` : `for ${p.agent_name}`);
  const list = arrived.filter((p) => p.attributed_by !== 'user' && p.amount_cents > 0);
  if (!list.length) return '';
  const same = list.filter((p) => p.currency === list[0].currency);
  const total = fmt(same.reduce((n, p) => n + p.amount_cents, 0), list[0].currency);
  if (same.length === 1) return `+${total} · ${same[0].merchant}, ${by(same[0])}`;
  if (same.length === 2) return `+${total} · ${same[0].merchant} and ${same[1].merchant}`;
  return `+${total} · ${same[0].merchant} and ${same.length - 1} more`;
}

let seenPurchases = null; // ids already on screen; null until the first look (nothing to explain then)
let whyTimer = 0;
const WHY_MS = 7000;
function showWhy(line) {
  const el = $('#hero-why');
  clearTimeout(whyTimer);
  el.textContent = line;
  el.hidden = !line;
  if (line) whyTimer = setTimeout(() => { el.hidden = true; el.textContent = ''; }, WHY_MS);
}

async function renderRecent(gen = refreshGen) {
  const from = `${ui.state.headline.last_month.month}-01`;
  const { purchases } = await api('GET', `/api/purchases?from=${from}`);
  if (stale(gen)) return;
  const thisMonth = ui.state.headline.this_month.month;
  if (seenPurchases) {
    const line = whyMoved(purchases.filter((p) => !seenPurchases.has(p.id) && p.occurred_on.startsWith(thisMonth)), money);
    if (line) showWhy(line);
  }
  seenPurchases = new Set(purchases.map((p) => p.id));
  const recent = purchases.slice(0, RECENT);
  $('#recent-empty').hidden = recent.length > 0;
  $('#recent').replaceChildren(...recent.map((p) => {
    return h('li', {},
      h('div', { class: 'who' },
        h('div', { class: 'm', text: p.merchant }),
        h('div', { class: 'd' }, shortDate(p.occurred_on), ` · ${p.agent_name}`)),
      stateMark(p),
      h('div', { class: `amt${p.amount_cents < 0 ? ' refund' : ''}`, text: money(p.amount_cents, p.currency) }));
  }));
}

/** What an agent supplies: its reports, and the receipts and bank alerts it finds. Never proof on their own. */
const AGENT_SUPPLIED = ['agent', 'email', 'alert', 'lnget'];

/**
 * VERIFIED (✓: the bank, the iPhone, the webhook or a receipt file you attached saw it),
 * REPORTED-UNVERIFIED (flagged, never hidden), or nothing for the rest. verified_at alone decides.
 */
function stateMark(p) {
  const verified = Boolean(p.verified_at);
  // Any agent report or agent-found evidence in the purchase or its merged copies.
  const seen = [p.source_kind, ...(p.also_seen_by ? p.also_seen_by.split(',') : [])];
  const state = verified ? 'ok' : seen.some((k) => AGENT_SUPPLIED.includes(k)) ? 'flag' : null;
  // Every confirmed row is remembered, marked or not, so a bank or manual entry that a receipt
  // later verifies plays its match too.
  const matched = justMatched(p.id, verified);
  if (state === 'ok') {
    const mark = h('span', { class: 'state ok', title: 'Verified: your bank, your iPhone or a receipt you attached saw this charge' }, slip('ok'), h('span', { class: 'word' }, 'verified'));
    if (matched) playMatch(mark);
    return mark;
  }
  if (state === 'flag') return h('span', { class: 'state flag', title: 'Your agent reported this. Your bank, your iPhone or a receipt you attach will verify it.' }, slip('flag'), 'unverified');
  return null;
}

async function renderInbox(gen = refreshGen) {
  const { inbox } = await api('GET', '/api/inbox');
  if (stale(gen)) return;
  const list = $('#inbox');
  // Shown only when something is waiting: a small banner that opens the list in place.
  // Clearing it while it's open earns a moment of "done" (POLISH-RESEARCH #2); an inbox that
  // was simply empty stays out of the way.
  if (!inbox.length) { if (ui.inboxOpen) ui.inboxDone = true; ui.inboxOpen = false; }
  else ui.inboxDone = false;
  $('#needs-banner').hidden = inbox.length === 0;
  $('#needs-banner').setAttribute('aria-expanded', String(ui.inboxOpen));
  $('#needs-text').replaceChildren(h('span', { class: 'state wait' }, slip('wait')), `${inbox.length} to sort: Mine or Agents?`);
  $('#needs-banner .banner-go').textContent = ui.inboxOpen ? 'Hide' : 'Review';
  $('#inbox-card').hidden = !ui.inboxOpen && !ui.inboxDone;
  $('#inbox-card').classList.toggle('done', Boolean(ui.inboxDone));
  $('#inbox-done').hidden = !ui.inboxDone;
  if (ui.inboxDone && !$('#inbox-done-mark').firstChild) $('#inbox-done-mark').append(filedStack());
  ui.inbox = inbox;
  const sure = inbox.filter((p) => p.confidence === 'high');
  $('#sure-btn').hidden = sure.length === 0;
  $('#sure-btn').textContent = `File ${sure.length} as suggested`;
  const agents = ui.state.agents;
  ui.focus = Math.min(ui.focus, Math.max(0, inbox.length - 1));
  list.replaceChildren(...inbox.map((p, i) => {
    // Two most likely agents, best first; the reason says why, so a guess can be checked.
    const guesses = p.guesses?.length ? p.guesses : agents.slice(0, 2).map((a) => ({ agent_id: a.id, agent_name: a.name }));
    const others = agents.filter((a) => !guesses.some((g) => g.agent_id === a.id));
    const refund = p.amount_cents < 0;
    const reason = p.why ?? (p.match_reason === 'receipt' ? 'receipt your agent found in email'
      : p.match_reason === 'agent_reported' ? 'an agent says it bought this'
      : p.match_reason === 'agent_refund' ? 'an agent reported this refund'
      : p.match_reason === 'rule_suggests' ? 'your rule matches; an agent found this in email'
      : p.match_reason === 'learned' ? 'an agent bought from here before'
      : p.match_reason === 'pulled_in' ? 'you pulled this in'
      : p.match_reason === 'lnget' ? "lnget paid this: the Lightning client your agents run (in sats)"
      : p.match_reason === 'agent_requested' ? 'paid with a Link card an agent asked for' : null);
    // From an agent the free plan doesn't cover: saved in full, marked, with one plain way to count it.
    if (p.over_limit) return heldRow(p, i);
    const li = h('li', { class: i === ui.focus ? 'focus' : '', 'data-i': i, onclick: () => { ui.focus = i; markFocus(); } },
      h('div', { class: 'who' },
        h('div', { class: 'm' }, h('span', { class: 'state wait', title: 'Waiting for you: Mine or Agents?' }, slip('wait'), h('span', { class: 'sr', text: 'Waiting for you: Mine or Agents?' })), ' ', p.merchant, p.confidence === 'high' ? h('span', { class: 'sure', title: 'Sure enough to file with "File as suggested"' }, 'sure') : null),
        h('div', { class: 'd' }, shortDate(p.occurred_on), reason ? ` · ${reason}` : '', refund ? ' · refund' : '')),
      h('div', { class: `amt${refund ? ' refund' : ''}`, text: money(p.amount_cents, p.currency) }),
      h('div', { class: 'ask' },
        ...guesses.map((g, k) => h('button', {
          class: k === 0 ? '' : 'ghost',
          onclick: () => guard(() => confirm(p, g.agent_id)),
          'aria-label': `${p.merchant} was ${g.agent_name}`,
          'aria-keyshortcuts': String(k + 1),
        }, g.agent_name)),
        h('button', { class: 'no', onclick: () => guard(() => reject(p)), 'aria-label': `${p.merchant} was mine, not an agent`, 'aria-keyshortcuts': 'N' }, 'Mine'),
        others.length ? h('select', {
          'aria-label': 'It was a different agent',
          onchange: (e) => { if (e.target.value) guard(() => confirm(p, Number(e.target.value))); },
        }, h('option', { value: '' }, 'Another agent…'), ...others.map((a) => h('option', { value: a.id }, a.name))) : null));
    if (ui.sortNames) li.style.setProperty('view-transition-name', `inbox-row-${p.id}`);
    return li;
  }));
}

/** An inbox row saved from an agent the free plan doesn't cover (src/plan.js). Never lost, never
 *  counted for the wrong agent: Pro counts it for its agent, or the user says it was theirs. */
function heldRow(p, i) {
  const agent = p.held_agent_name ?? 'an agent';
  const li = h('li', { class: `held${i === ui.focus ? ' focus' : ''}`, 'data-i': i, onclick: () => { ui.focus = i; markFocus(); } },
    h('div', { class: 'who' },
      h('div', { class: 'm' }, h('span', { class: 'state wait', title: 'Saved, waiting for you' }, slip('wait'), h('span', { class: 'sr', text: 'Saved, waiting for you' })), ' ', p.merchant,
        isPro() ? h('span', { class: 'pro-tag', title: `Your Pro plan covers ${(p.covered_agent_names ?? []).join(', ') || 'other agents'}` }, 'Not covered')
          : h('span', { class: 'pro-tag', title: `The free plan covers one agent${p.free_agent_name ? `: ${p.free_agent_name}` : ''}` }, 'Not on Free')),
      h('div', { class: 'd' }, shortDate(p.occurred_on), isPro()
        ? ` · from ${agent}, an agent your Pro plan doesn't cover yet. Saved in full; it counts for ${agent} once you add an agent or choose ${agent} in Settings.`
        : ` · from ${agent}, an agent the free plan doesn't cover. Saved in full; it counts for ${agent} with Pro.`)),
    h('div', { class: `amt${p.amount_cents < 0 ? ' refund' : ''}`, text: money(p.amount_cents, p.currency) }),
    h('div', { class: 'ask' },
      upgradeAction('Count it with Pro', isPro() ? `Add an agent to Pro to count ${p.merchant} for ${agent}` : `Get Pro to count ${p.merchant} for ${agent}`),
      h('button', { class: 'no', onclick: () => guard(() => reject(p)), 'aria-label': `${p.merchant} was mine, not an agent`, 'aria-keyshortcuts': 'N' }, 'Mine')));
  if (ui.sortNames) li.style.setProperty('view-transition-name', `inbox-row-${p.id}`);
  return li;
}

function markFocus() {
  for (const li of $$('#inbox > li')) li.classList.toggle('focus', Number(li.dataset.i) === ui.focus);
  $(`#inbox > li[data-i="${ui.focus}"]`)?.scrollIntoView({ block: 'nearest' });
}

async function confirmSure() {
  const { confirmed } = await api('POST', '/api/inbox/confirm-sure', {});
  await refresh();
  const name = (id) => ui.state.agents.find((a) => a.id === id)?.name ?? 'agent';
  toast(`Confirmed ${confirmed.length}: ${confirmed.map((c) => `${c.merchant} → ${name(c.agent_id)}`).join(', ')}.`, [
    ['Undo', () => guard(async () => {
      for (const c of confirmed) await api('POST', `/api/purchases/${c.id}/undo`, {});
      await refresh();
    })],
  ], { ms: 9000 });
}

/** Sorting the inbox: the row leaves toward where it went (the agents' total, or your own line),
 *  and the rows under it close the gap, as a same-document view transition. The panel keeps its
 *  height while they do, then shrinks; the totals roll once the row has gone. Without view
 *  transitions, or with Reduce Motion on, the list simply updates. */
let sortRun = 0;
let lastSortAt = -Infinity;
const QUICK_SORT_MS = 1200; // sorting in a run (1, 2, N, ...) skips the slide: frequent actions animate less
async function sortAway(p, toward) {
  const rows = $$('#inbox > li');
  const row = rows.find((li) => ui.inbox[li.dataset.i]?.id === p.id);
  const card = $('#inbox-card');
  const isQuick = performance.now() - lastSortAt < QUICK_SORT_MS;
  lastSortAt = performance.now();
  if (isQuick || calm() || !document.startViewTransition || !row || card.hidden) return refresh();
  const run = ++sortRun;
  const dest = [toward, '#hero-amount'].map((s) => $(s)).find((el) => el && !el.closest('[hidden]'));
  const from = row.getBoundingClientRect();
  const to = dest?.getBoundingClientRect() ?? { left: from.left, top: from.top - 1, width: from.width, height: 0 };
  const dx = to.left + to.width / 2 - (from.left + from.width / 2);
  const dy = to.top + to.height / 2 - (from.top + from.height / 2);
  const len = Math.hypot(dx, dy) || 1;
  const root = document.documentElement.style;
  root.setProperty('--sort-x', `${Math.round((dx / len) * 40)}px`);
  root.setProperty('--sort-y', `${Math.round((dy / len) * 40)}px`);
  row.style.setProperty('view-transition-name', 'inbox-sorted');
  for (const li of rows) if (li !== row) li.style.setProperty('view-transition-name', `inbox-row-${ui.inbox[li.dataset.i].id}`);
  const held = card.offsetHeight;
  ui.sortNames = true;
  ui.rollDelay = 220;
  const t = document.startViewTransition(async () => {
    await refresh();
    if (!card.hidden) card.style.setProperty('min-height', `${held}px`);
  });
  t.ready.catch(() => {});
  t.finished.catch(() => {}).then(() => {
    if (run !== sortRun) return; // a newer sort has taken over
    ui.sortNames = false;
    for (const li of $$('#inbox > li')) li.style.removeProperty('view-transition-name');
    card.style.removeProperty('min-height');
    root.removeProperty('--sort-x');
    root.removeProperty('--sort-y');
    const natural = card.offsetHeight;
    if (!card.hidden && natural < held && !calm()) card.animate([{ height: `${held}px` }, { height: `${natural}px` }], { duration: 220, easing: EASE });
  });
  try { await t.updateCallbackDone; } finally { ui.rollDelay = 0; }
}

const zero = () => (ui.state.counts.candidate === 0 ? ' Inbox zero ✓' : '');

async function confirm(p, agentId) {
  const r = await api('POST', `/api/purchases/${p.id}/confirm`, { agentId });
  const name = ui.state.agents.find((a) => a.id === agentId)?.name ?? 'agent';
  await sortAway(p, '#hero-amount');
  toast(`${p.merchant} → ${name}.${zero()}`, [
    [`Always for ${p.merchant}`, () => guard(async () => {
      const rule = await api('POST', '/api/rules', { purchaseId: r.id });
      await refresh();
      toast(`${p.merchant} will go to ${name} automatically${rule.retroactive ? ` (${rule.retroactive} more sorted)` : ''}.`);
    })],
    ['Undo', () => guard(async () => { await api('POST', `/api/purchases/${p.id}/undo`, {}); await refresh(); })],
  ]);
}

async function reject(p) {
  const r = await api('POST', `/api/purchases/${p.id}/reject`, {});
  await sortAway(p, '#hero-mine');
  toast(`${p.merchant} → Mine.${zero()}`, [
    [`Never ask about ${p.merchant}`, () => guard(async () => {
      const rule = await api('POST', '/api/rules', { purchaseId: r.id });
      await refresh();
      toast(`Won't ask about ${p.merchant} again${rule.retroactive ? ` (${rule.retroactive} more cleared)` : ''}.`);
    })],
    ['Undo', () => guard(async () => { await api('POST', `/api/purchases/${p.id}/undo`, {}); await refresh(); })],
  ]);
}

async function renderTotals() {
  const count = ui.period === 'week' ? 8 : 6;
  const t = await api('GET', `/api/totals?period=${ui.period}&count=${count}`);
  const table = $('#totals');
  $('#totals-empty').hidden = t.series.length > 0;
  table.hidden = t.series.length === 0;
  if (!t.series.length) return table.replaceChildren();
  const label = (b) => (t.period === 'week' ? shortDate(b.from) : monthName(b.key, false));
  const cell = (cents, currency) => h('td', { class: cents ? '' : 'zero', text: cents ? money(cents, currency) : '—' });
  const head = h('thead', {}, h('tr', {},
    h('th', { scope: 'col' }, 'Agent'),
    ...t.buckets.map((b) => h('th', { scope: 'col', title: b.label }, label(b))),
    h('th', { scope: 'col' }, 'Total')));
  const body = h('tbody', {}, ...t.series.map((s) => h('tr', {},
    h('th', { scope: 'row' }, h('span', { class: 'dot', style: `background:${agentColor(s.agent_id)}` }), s.agent_name,
      s.currency !== 'USD' ? ` (${s.currency})` : ''),
    ...s.values.map((v) => cell(v, s.currency)),
    cell(s.total, s.currency))));
  const foot = h('tfoot', {}, ...Object.entries(t.totals).map(([cur, vals]) => h('tr', {},
    h('td', {}, Object.keys(t.totals).length > 1 ? `All agents (${cur})` : 'All agents'),
    ...vals.map((v) => cell(v, cur)),
    cell(vals.reduce((a, b) => a + b, 0), cur))));
  const mineRow = t.mine?.some((m) => m.length) ? h('tr', { class: 'mine-row' },
    h('th', { scope: 'row' }, 'Mine (you)'),
    ...t.mine.map((m) => cell(m[0]?.cents ?? 0, m[0]?.currency ?? 'USD')),
    cell(t.mine.reduce((a, m) => a + (m[0]?.cents ?? 0), 0), 'USD')) : null;
  if (mineRow) foot.append(mineRow);
  table.replaceChildren(head, body, foot);
  $('#totals-pro').hidden = !t.per_agent_is_pro;
}

// Month, bucket and search changes each start a new purchases view; only the newest may draw.
let purchasesGen = 0;
async function renderPurchases(gen = refreshGen) {
  const mine = ++purchasesGen;
  const old = () => stale(gen) || mine !== purchasesGen;
  const bucket = ui.bucket ?? 'agents';
  for (const b of $$('#bucket-seg button')) b.setAttribute('aria-selected', String(b.dataset.bucket === bucket));
  $('#search-form').hidden = bucket === 'mine';
  if (bucket === 'mine') return renderMine(old);
  const q = $('#search-q').value.trim();
  if (q && !isPro()) {
    $('.month-nav').hidden = false;
    $('#search-total').hidden = false;
    $('#search-total').replaceChildren('Search with running totals is part of Pro. ', h('a', { href: '#settings', onclick: (e) => { e.preventDefault(); goPro(); } }, 'See Pro'));
    return;
  }
  $('.month-nav').hidden = Boolean(q);
  $('#search-total').hidden = !q;
  let purchases;
  if (q) {
    // Search spans all time unless the query says otherwise; the running total is the point.
    const r = await api('GET', `/api/search?q=${encodeURIComponent(q)}`);
    if (old()) return;
    purchases = r.purchases.slice(0, SEARCH_LIMIT);
    const n = r.purchases.length;
    $('#search-total').textContent = !n ? 'Nothing matches.'
      : r.totals.map((t) => `${money(t.cents, t.currency)} across ${t.count} purchase${t.count === 1 ? '' : 's'} · ${t.verified_count} ✓ verified`).join('  ·  ') +
        (n > SEARCH_LIMIT ? `  (showing the newest ${SEARCH_LIMIT})` : '');
    $('#purchases-empty').hidden = true;
  } else {
    const from = `${ui.month}-01`;
    const to = `${addMonths(ui.month, 1)}-01`;
    $('#month-label').textContent = monthName(ui.month);
    $('#month-next').disabled = ui.month >= ui.state.headline.this_month.month;
    ({ purchases } = await api('GET', `/api/purchases?from=${from}&to=${to}`));
    if (old()) return;
    $('#purchases-empty').hidden = purchases.length > 0;
  }
  $('#purchases').replaceChildren(...purchases.map(purchaseRow));
}

async function renderMine(old = () => false) {
  $('.month-nav').hidden = false;
  $('#search-total').hidden = true;
  const from = `${ui.month}-01`;
  const to = `${addMonths(ui.month, 1)}-01`;
  $('#month-label').textContent = monthName(ui.month);
  $('#month-next').disabled = ui.month >= ui.state.headline.this_month.month;
  const { purchases } = await api('GET', `/api/mine?from=${from}&to=${to}`);
  if (old()) return;
  $('#purchases-empty').hidden = purchases.length > 0;
  $('#purchases-empty').textContent = purchases.length ? '' : 'Nothing of yours recorded this month. Your iPhone, bank alerts or a CSV fill this in.';
  $('#purchases').replaceChildren(...purchases.map((p) => h('li', {},
    h('div', { class: 'who' },
      h('div', { class: 'm', text: p.merchant }),
      // A Mine line an agent found in email says so, so a made-up one stands out.
      h('div', { class: 'd' }, shortDate(p.occurred_on), ` · ${p.found_by ? `bank alert ${p.found_by} found in email` : SOURCE_NAME[p.source_kind] ?? p.source_kind}`)),
    h('div', { class: 'amt', text: money(p.amount_cents, p.currency) }),
    h('button', {
      class: 'link',
      onclick: () => guard(async () => { await api('POST', `/api/purchases/${p.id}/pull-in`, {}); await refresh(); toast(`${p.merchant} moved to sort: Mine or Agents?`); }),
    }, 'An agent bought this'))));
}
const SOURCE_NAME = { phone: 'iPhone', alert: 'bank alert', simplefin: 'bank', csv: 'CSV', email: 'receipt', manual: 'added by hand', webhook: 'this computer', link: 'Stripe Link', lnget: 'lnget' };

function purchaseRow(p) {
  const receipts = h('span', { class: 'receipts' });
  if (p.receipt_count) {
    receipts.append(h('button', {
      class: 'link',
      onclick: () => guard(async () => {
        const { receipts: rs } = await api('GET', `/api/purchases/${p.id}/receipts`);
        receipts.replaceChildren(...rs.map((r) => h('a', { href: `/api/receipts/${r.id}`, target: '_blank', rel: 'noopener' }, r.filename)));
      }),
    }, `${p.receipt_count} receipt${p.receipt_count > 1 ? 's' : ''}`));
  }
  const fileInput = h('input', {
    type: 'file', accept: '.pdf,.png,.jpg,.jpeg,.webp,.gif,.txt,.eml,.html',
    onchange: (e) => guard(async () => {
      const f = e.target.files[0];
      if (!f) return;
      await api('POST', `/api/purchases/${p.id}/receipts`, f, {
        'Content-Type': f.type || (f.name.endsWith('.eml') ? 'message/rfc822' : 'application/octet-stream'),
        'X-Filename': encodeURIComponent(f.name),
      });
      toast('Receipt attached.');
      await renderPurchases();
    }),
  });
  return h('li', {},
    h('div', { class: 'who' },
      h('div', { class: 'm', text: p.merchant }),
      h('div', { class: 'd' }, shortDate(p.occurred_on),
        p.payment_method ? ` · ${p.payment_method.replace('_', ' ')}` : '',
        p.attributed_by === 'rule' ? ' · sorted by rule' : '', ' ', ...evidence(p))),
    h('span', { class: 'agent-chip', text: p.agent_name }),
    stateMark(p),
    h('div', { class: `amt${p.amount_cents < 0 ? ' refund' : ''}`, text: money(p.amount_cents, p.currency) }),
    receipts,
    h('label', { class: 'file-btn ghost', style: 'min-height:30px;padding:2px 10px;margin:0;font-size:13px' }, fileInput, 'Attach receipt'),
    p.amount_cents > 0 ? h('button', { class: 'link', onclick: () => expectRefundFor(p) }, 'Expect a refund') : null,
    h('button', {
      class: 'link',
      onclick: () => guard(async () => { await api('POST', `/api/purchases/${p.id}/undo`, {}); await refresh(); toast('Moved back to “Needs a look”.'); }),
    }, 'Undo'));
}

/** Which sources saw this charge. Only independent ones (bank, iPhone, webhook, Stripe Link, a receipt you attached) carry the ✓. */
function evidence(p) {
  const label = { agent: 'reported by agent', email: 'receipt found', alert: 'bank alert found', simplefin: 'bank', csv: 'bank',
    phone: 'iPhone', webhook: 'webhook', manual: 'added by hand', link: 'Stripe Link', lnget: 'paid through lnget' };
  const independent = ['simplefin', 'csv', 'phone', 'webhook', 'link'];
  const seen = [p.source_kind, ...(p.also_seen_by ? p.also_seen_by.split(',') : [])];
  const chips = new Map();
  for (const k of seen) chips.set(label[k] ?? k, (chips.get(label[k] ?? k) ?? false) || independent.includes(k));
  if (p.receipt_count > 0) chips.set('receipt attached', true);
  return [...chips].map(([n, ok]) => h('span', { class: `ev${ok ? ' ok' : ''}`, title: ok ? 'Independent proof of this charge' : AGENT_SUPPLIED.some((k) => label[k] === n) ? 'Supplied by your agent: kept as evidence, not proof' : '' },
    ok ? `✓ ${n}` : n));
}

/** Refunds you expect: waiting, an agent's word only, received, or no longer expected. */
const REFUND_STATE = {
  open: 'waiting',
  evidence: "an agent says it arrived; waiting for your bank or your tap",
  resolved: 'received',
  dismissed: 'no longer expected',
};
async function renderRefunds() {
  const { refunds } = await api('GET', '/api/refunds');
  $('#refunds-empty').hidden = refunds.length > 0;
  const todayIso = today();
  $('#refunds').replaceChildren(...refunds.map((r) => {
    const live = r.status === 'open' || r.status === 'evidence';
    const overdue = live && r.due_on < todayIso;
    const part = live && r.refunded_cents > 0 ? ` · ${money(r.refunded_cents, r.currency)} of ${money(r.amount_cents, r.currency)} back` : '';
    const close = (action, done) => guard(async () => {
      await api('POST', `/api/refunds/${r.id}/${action}`, {});
      await renderRefunds();
      toast(done);
    });
    return h('li', { class: overdue ? 'lapsed' : '' },
      h('div', { class: 'who' },
        h('div', { class: 'm', text: r.merchant }),
        h('div', { class: 'd' }, `${overdue ? 'overdue since' : live ? 'expected by' : 'was due'} ${shortDate(r.due_on)} · ${REFUND_STATE[r.status]}${part}`,
          r.created_by === 'agent' ? ` · noted by ${r.agent ?? 'an agent'}` : '', r.note ? ` · ${r.note}` : '')),
      h('div', { class: 'amt', text: money(r.amount_cents, r.currency) }),
      live ? h('button', { class: 'link', onclick: () => close('resolve', 'Marked as received.') }, 'Mark received') : null,
      live ? h('button', { class: 'link', onclick: () => close('dismiss', 'No longer expected.') }, 'Stop expecting') : null);
  }));
}

/** From a purchase row: start an expected refund for it. */
function expectRefundFor(p) {
  $('#refund-merchant').value = p.merchant;
  $('#refund-amount').value = (Math.abs(p.amount_cents) / 100).toFixed(2);
  $('#refund-purchase').value = String(p.id);
  location.hash = '#refunds';
  $('#refund-due').focus();
}

/** Pro: how many things need the user, on the home page. */
async function renderAttentionBanner(onHome) {
  const banner = $('#attention-banner');
  if (!onHome || !isPro()) { banner.hidden = true; return; }
  const { exceptions } = await api('GET', '/api/exceptions');
  const open = exceptions.filter((e) => e.status === 'open');
  banner.hidden = open.length === 0;
  if (banner.hidden) return;
  const urgent = open.filter((e) => e.severity === 'urgent').length;
  banner.replaceChildren(h('span', {}, `${open.length} thing${open.length === 1 ? ' needs' : 's need'} you${urgent ? ` (${urgent} urgent)` : ''}: ${open[0].title}`),
    h('span', { class: 'banner-go' }, 'See'));
}

const EXCEPTION_DONE = { resolved: 'handled', dismissed: 'dismissed' };
async function renderAttention() {
  const pro = isPro();
  $('#attention-upsell').hidden = pro;
  $('#attention-body').hidden = !pro;
  $('#attention-upsell').replaceChildren('Follow-up on missing refunds, failed or late sources and unchecked months, with a briefing, is part of Pro. Whether a source failed or is late is always shown for free, on the home page and in Settings. ',
    h('a', { href: '#settings', onclick: (e) => { e.preventDefault(); goPro(); } }, 'See Pro'));
  if (!pro) return;
  const [b, { exceptions }] = await Promise.all([api('GET', '/api/briefing'), api('GET', '/api/exceptions')]);
  $('#briefing-headline').textContent = b.headline;
  $('#briefing-checked').replaceChildren(...(b.checked.length ? b.checked.map((c) => h('li', {}, h('div', { class: 'who' }, h('div', { class: 'm', text: c.label }), h('div', { class: 'd', text: c.through }))))
    : [h('li', { class: 'muted small' }, 'Nothing has been checked yet.')]));
  $('#briefing-unknown').replaceChildren(...(b.unknown.length ? b.unknown.map((u) => h('li', { class: 'small' }, u)) : [h('li', { class: 'muted small' }, 'Nothing unknown.')]));
  $('#exceptions').replaceChildren(...(exceptions.length ? exceptions.map((e) => {
    const close = (action, done) => guard(async () => { await api('POST', `/api/exceptions/${e.id}/${action}`, {}); await renderAttention(); toast(done); });
    const live = e.status === 'open';
    return h('li', { class: `exception${e.severity === 'urgent' && live ? ' urgent' : ''}${live ? '' : ' closed'}` },
      h('div', { class: 'who' },
        h('div', { class: 'm', text: e.title }),
        h('div', { class: 'd' }, live ? (e.severity === 'urgent' ? 'urgent' : 'open') : EXCEPTION_DONE[e.status] ?? e.status),
        live ? h('p', { class: 'small' }, h('strong', {}, 'Not certain: '), e.uncertain) : null,
        live ? h('p', { class: 'small' }, h('strong', {}, 'Next: '), e.next_action) : null,
        h('details', { class: 'inner' }, h('summary', {}, 'History and evidence'),
          h('ul', { class: 'small' }, ...e.history.map((x) => h('li', {}, `${new Date(x.at).toLocaleString()} · ${x.actor === 'user' ? 'you' : 'Twinslip'} ${x.action}${x.note ? `: ${x.note}` : ''}`))),
          h('pre', { class: 'small evidence', text: JSON.stringify(e.evidence, null, 2) }))),
      live ? h('button', { class: 'link', onclick: () => close('resolve', 'Marked as handled.') }, 'Handled') : null,
      live ? h('button', { class: 'link', onclick: () => close('dismiss', 'Dismissed. It comes back only if something changes.') }, 'Dismiss') : null);
  }) : [h('li', { class: 'muted small' }, 'Nothing needs you.')]));
}

/** Pro: background checks through macOS launchd, hourly and at login, even with the page closed. */
async function renderSchedule() {
  const s = await api('GET', '/api/schedule');
  $('#schedule-row').hidden = !s.supported || !isPro();
  if ($('#schedule-row').hidden) return;
  $('#schedule-status').textContent = !s.installed ? 'Background checks: off. Checks run while Twinslip is open.'
    : s.state === 'running' ? `Background checks: on (hourly and at login; last ran ${ago(s.last_run_at)}).`
    : `Background checks are on but haven't run${s.last_run_at ? ` since ${ago(s.last_run_at)}` : ' yet'}. A Node update can move them: turn them off and on again.`;
  $('#schedule-status').classList.toggle('warn', s.installed && s.state !== 'running');
  $('#schedule-btn').textContent = s.installed ? 'Turn off' : 'Turn on';
  $('#schedule-btn').onclick = () => guard(async () => {
    await api('POST', '/api/schedule', { on: !s.installed });
    await renderSchedule();
    toast(s.installed ? 'Background checks are off.' : 'Background checks are on.');
  });
}

/** What can't be trusted right now: a failed or overdue source. Never behind Pro. */
function renderHealthBanner(onHome) {
  // A configured source that never ran counts too (an email sweep nobody asked for doesn't).
  const bad = (ui.state.health ?? []).filter((x) => x.state === 'failed' || x.state === 'overdue' || (x.state === 'never' && x.source_id !== null));
  const banner = $('#health-banner');
  banner.hidden = !onHome || bad.length === 0;
  if (banner.hidden) return;
  const first = bad[0];
  banner.replaceChildren(h('span', {}, `${first.label}: ${first.detail}`),
    bad.length > 1 ? h('span', { class: 'muted' }, ` (and ${bad.length - 1} more)`) : '', h('span', { class: 'banner-go' }, 'Sources'));
}

const HEALTH_WORD = { ok: 'working', quiet: 'quiet', failed: 'check failed', overdue: 'overdue', never: 'not checked yet', unknown: "can't tell", retired: 'retired' };

function sourceLine(x) {
  const hl = (ui.state.health ?? []).find((y) => y.source_id === x.id);
  if (hl) return `${HEALTH_WORD[hl.state]} · ${hl.detail}`;
  if (x.kind === 'agent') {
    if (!x.last_attempt_at) return 'Agent · set up, not connected yet';
    return `Agent · connected ${ago(x.last_attempt_at)} · ${x.last_success_at ? `last purchase reported ${ago(x.last_success_at)}` : 'no purchases reported yet'}`;
  }
  if (x.kind === 'email') return `Receipts your agent found · last ${ago(x.last_success_at)}`;
  if (x.kind === 'simplefin') return 'Bank feed (retired) · its records stay, with their ✓ · nothing new syncs';
  return `Last ${x.kind === 'csv' ? 'import' : 'sync'}: ${ago(x.last_success_at)}`;
}

/** On Pro with more agents than the key covers: which are covered, and a way to choose (src/plan.js). */
function proPlanBit(plan, a) {
  if (!plan?.pro || !plan.agents.some((x) => !x.covered)) return null;
  const mine = plan.agents.find((x) => x.id === a.id);
  if (mine?.covered) return h('span', { class: 'pro-tag', title: 'Your Pro plan covers this agent' }, 'Covered');
  const covered = plan.agents.filter((x) => x.covered);
  return h('select', {
    'aria-label': `Cover ${a.name} instead of another agent`,
    onchange: (e) => {
      const out = Number(e.target.value);
      if (!out) return;
      guard(async () => {
        const r = await api('PUT', '/api/plan', { coverAgentId: a.id, replaceAgentId: out });
        await refresh();
        toast(`Pro now covers ${a.name}.${r.released ? ` ${r.released} saved purchase${r.released === 1 ? '' : 's'} now count${r.released === 1 ? 's' : ''} for it.` : ''} What other agents already counted stays.`);
      });
    },
  }, h('option', { value: '' }, 'Cover instead of…'), ...covered.map((x) => h('option', { value: x.id }, x.name)));
}

function renderSettings() {
  const s = ui.state;
  const pro = s.pro ?? { pro: false, seats: 1, status: 'free' };
  $('#pro-status').textContent = pro.status === 'demo' ? `Demo: showing Pro for ${pro.seats} seats.`
    // Fair cancel (src/pro.js): a lapsed key keeps Pro in versions released before it lapsed.
    : pro.status === 'kept' ? `Your Pro key ran out on ${pro.paid_through}. This version of Twinslip came out before then, so Pro keeps working in it; newer versions run as Free until you renew. Your data is never touched.`
    : pro.pro ? `Pro is on: ${pro.seats} seat${pro.seats === 1 ? '' : 's'} (each one person, on up to ${Math.max(1, Math.round((pro.computers ?? pro.seats) / pro.seats))} computers), covering ${pro.agents} agents.`
      : pro.status === 'needs_check' ? "Pro couldn't be checked for a while. Connect to the internet once to keep it on."
        : pro.status === 'free' ? 'You are on the free plan. Everything you see here keeps working.'
          : `Your Pro key is ${pro.status}. Everything free keeps working.`;
  // What the free plan covers, in one line (src/plan.js).
  const plan = s.plan;
  $('#plan-line').textContent = !plan ? '' : plan.pro
    ? `Pro covers ${plan.limits.agents} agents and every bank or card account. ${plan.agents.some((a) => !a.covered) ? 'Choose which agents in the list above, or add an agent; other agents\' purchases are saved in your inbox.' : 'Each extra agent is $3 a month or $29 a year.'}`
    : `Free covers 1 agent (${plan.free_agent?.name ?? 'the first one that reports'}) and 1 bank or card account (${plan.free_account?.label ?? 'the first one you import'}), with unlimited purchases, all your history and plain CSV export. Pro covers 3 agents and every account.`;
  $('#pro-add-agent').hidden = !plan?.pro || pro.status === 'demo';
  $('#pro-add-agent').href = addAgentUrl();
  $('#pro-form').hidden = pro.pro && pro.status !== 'kept'; // a kept (lapsed) key can be renewed or replaced
  $('#pro-deactivate').hidden = !pro.pro || pro.status === 'demo';
  $('#pro-buy').hidden = pro.pro && pro.status !== 'kept';
  $('#pro-buy').href = `${s.site_url ?? 'https://twinslip.example'}/pro`;
  $('#agents').replaceChildren(...s.agents.map((a) => {
    const input = h('input', { value: a.name, maxlength: '60', 'aria-label': `Rename ${a.name}` });
    const budget = h('input', {
      class: 'budget', inputmode: 'decimal', placeholder: 'No budget', 'aria-label': `Monthly budget for ${a.name}`,
      value: a.monthly_budget_cents ? (a.monthly_budget_cents / 100).toFixed(2) : '',
    });
    // On Free: which agent the plan covers, and a way to choose another (its saved purchases then count).
    const onFree = s.plan && !s.plan.pro;
    const free = onFree && s.plan.free_agent?.id === a.id;
    const planBit = !onFree ? proPlanBit(s.plan, a) : free ? h('span', { class: 'pro-tag', title: 'The free plan covers this agent' }, 'On Free')
      : h('button', {
        type: 'button', class: 'link',
        onclick: () => guard(async () => {
          const r = await api('PUT', '/api/plan', { freeAgentId: a.id });
          await refresh();
          toast(`Free now covers ${a.name}.${r.released ? ` ${r.released} saved purchase${r.released === 1 ? '' : 's'} now count${r.released === 1 ? 's' : ''} for it.` : ''} What other agents already counted stays.`);
        }),
      }, 'Use on Free');
    return h('li', {}, input, planBit, h('label', { class: 'budget-field' }, h('span', { class: 'muted small' }, 'Monthly budget'), budget), h('button', {
      class: 'ghost',
      onclick: () => guard(async () => {
        const renamed = input.value.trim() !== a.name;
        await api('PATCH', `/api/agents/${a.id}`, { ...(renamed ? { name: input.value } : {}), budget: budget.value });

        await refresh();
        // Agent apps identify the agent by name in their config line.
        toast('Saved.'); // a rename never needs setup again: apps keep reaching the same agent
      }),
    }, 'Save'));
  }));
  const account = (x) => (s.plan?.accounts ?? []).find((a) => a.id === x.id);
  $('#sources').replaceChildren(...s.sources.filter((x) => x.kind !== 'manual').map((x) => h('li', {},
    h('div', { class: 'who' },
      h('div', { class: 'm', text: x.label }),
      h('div', { class: 'd', text: sourceLine(x) }),
      // A bank or card account: whether its lines check agent purchases on this plan.
      account(x) ? h('div', { class: 'd', text: account(x).verifies ? 'Checks agent purchases.'
        : "Kept and listed in full. The free plan checks agent purchases against one account; with Pro this one checks them too." }) : null,
      account(x) && !account(x).verifies ? h('button', {
        type: 'button', class: 'link',
        onclick: () => guard(async () => {
          await api('PUT', '/api/plan', { freeAccountId: x.id });
          await refresh();
          toast(`Free now checks agent purchases against ${x.label}.`);
        }),
      }, 'Use on Free') : null,
      x.last_error && x.kind !== 'simplefin' ? h('div', { class: 'd warn', text: x.last_error }) : null),
    // Removing the old saved access is the user's choice; it never touches a record.
    x.kind === 'simplefin' ? h('button', {
      class: 'link',
      onclick: () => guard(async () => {
        if (!window.confirm('Remove the saved bank-feed access from this computer? Your bank-feed records stay.')) return;
        const r = await api('DELETE', '/api/simplefin/access');
        toast(r.removed ? 'Saved bank-feed access removed. Your records stay.' : 'No saved bank-feed access was left.');
      }),
    }, 'Remove saved access') : null)));
  // Email sweeps aren't sources of their own; their health is listed beside them.
  for (const sw of (s.health ?? []).filter((x) => x.source_id === null)) {
    $('#sources').append(h('li', {}, h('div', { class: 'who' }, h('div', { class: 'm', text: sw.label }),
      h('div', { class: `d${sw.state === 'overdue' ? ' warn' : ''}`, text: `${HEALTH_WORD[sw.state]} · ${sw.detail}` }))));
  }
  if (!s.sources.some((x) => x.kind !== 'manual')) $('#sources').replaceChildren(h('li', { class: 'muted' }, 'Nothing connected yet.'));
  // Email sweeps your agent finished: the evidence behind the receipts and bank steps.
  const lastSweep = (kind) => (s.sweeps ?? []).find((x) => x.kind === kind);
  const sweepText = [['receipts', 'Receipt sweep'], ['bank_alerts', 'Bank alert sweep']]
    .map(([kind, label]) => { const x = lastSweep(kind); return x ? `${label}: last finished ${shortDate(x.finished_at.slice(0, 10))}, ${x.found} recorded.` : null; })
    .filter(Boolean).join(' ');
  $('#sweeps-line').hidden = !sweepText;
  $('#sweeps-line').textContent = sweepText;
  $('#rules').replaceChildren(...(s.rules.length ? s.rules.map((r) => h('li', {},
    h('div', { class: 'who' }, r.action === 'attribute' ? `Always: ${r.merchant_key} → ${r.agent_name}` : `Never ask: ${r.merchant_key}`),
    h('button', {
      class: 'link',
      onclick: () => guard(async () => { await api('DELETE', `/api/rules/${r.id}`); await refresh(); }),
    }, 'Remove'))) : [h('li', { class: 'muted small' }, 'No rules yet.')]));
  const sel = $('#manual-agent');
  const prev = sel.value;
  sel.replaceChildren(h('option', { value: '' }, 'Mine'), ...s.agents.map((a) => h('option', { value: a.id }, `${a.name} (agent)`)));
  if (prev) sel.value = prev;
}

// ── Updates (src/updates.js) ─────────────────────────────────────────────────
// Settings says what the daily check found; home gets one quiet line. The user downloads and installs.

function renderUpdate(onHome) {
  const u = ui.state.update;
  const avail = u?.available ?? null;
  const line = $('#update-line');
  line.hidden = !onHome || !avail;
  if (avail) line.replaceChildren(`Update available: Twinslip ${avail.version}. `, h('a', { href: '#settings' }, 'See Settings'));
  if (!u) { $('#update-settings').hidden = true; return; }
  $('#update-status').textContent = avail ? `Update available: ${avail.version} (released ${shortDate(avail.released)}). You have ${u.current}.`
    : !u.ready ? `You have version ${u.current}. This build can't check for updates yet.`
    : !u.on ? (u.off_by === 'env' ? 'Update checks are off (TWINSLIP_UPDATE_CHECKS is set to off).' : 'Update checks are off.')
      : u.checked_at ? `You have the latest version, ${u.current}. Last checked ${ago(u.checked_at)}.`
        : `You have version ${u.current}. Not checked yet.`;
  const notes = $('#update-notes');
  notes.hidden = !avail;
  if (avail) {
    notes.replaceChildren(...[...avail.notes.split('\n').filter((x) => x.trim()).map((x) => h('p', { text: x })),
      avail.node_ok ? null : h('p', { class: 'warn', text: `This version needs Node ${avail.min_node} or newer; the read-me inside says how to update it.` }),
      h('p', { text: `SHA-256 of the download: ${avail.sha256}`, style: 'overflow-wrap: anywhere' })].filter(Boolean));
  }
  const dl = $('#update-download');
  dl.hidden = !avail;
  if (avail) { dl.href = avail.download; dl.textContent = `Download ${avail.version}`; }
  const check = $('#update-check');
  check.hidden = !u.on || !u.ready;
  check.onclick = () => guard(async () => {
    check.disabled = true;
    try {
      const r = await api('POST', '/api/updates/check', {});
      await refresh();
      toast(r.available ? `Update available: ${r.available.version}.` : "You have the latest version.");
    } finally { check.disabled = false; }
  });
  const on = $('#update-on');
  on.checked = u.on;
  on.disabled = u.off_by === 'env';
  on.onchange = () => guard(async () => { await api('PUT', '/api/updates', { on: on.checked }); await refresh(); });
}

// ── CSV import ───────────────────────────────────────────────────────────────

async function startCsv(file) {
  if (!file) return;
  const csv = await file.text();
  let preview = await api('POST', '/api/import/csv/preview', { csv });
  const dlg = $('#csv-dialog');
  const show = () => {
    $('#csv-summary').textContent =
      `${preview.rows} transactions${preview.from ? ` from ${preview.from} to ${preview.to}` : ''}. ` +
      `${preview.likelyAgentRows} look like agent purchases — you'll confirm each one. ` +
      (preview.skipped ? `${preview.skipped} rows couldn't be read and will be skipped.` : '');
    $('#csv-sign').hidden = !('amount' in preview.mapping); // debit/credit columns need no guess
    for (const r of $$('#csv-sign input')) r.checked = r.value === preview.spendSign;
    $('#csv-sample').replaceChildren(...preview.sample.map((t) => h('tr', {},
      h('td', { text: t.date }), h('td', { text: t.description }),
      h('td', { text: `${t.amount_cents >= 0 ? 'spent ' : 'refund/credit '}${money(Math.abs(t.amount_cents))}` }))));
  };
  show();
  // Which bank or card account the file is from: each one is an account (src/plan.js).
  const accounts = ui.state.plan?.accounts?.filter((a) => a.kind === 'csv') ?? [];
  const field = $('#csv-account');
  $('#csv-accounts').replaceChildren(...accounts.map((a) => h('option', { value: a.label })));
  field.value = accounts[0]?.label ?? '';
  const note = () => {
    const name = field.value.trim().toLowerCase();
    const isNew = name && !accounts.some((a) => a.label.toLowerCase() === name);
    const freeAcct = ui.state.plan?.free_account?.label;
    const limited = isNew && ui.state.plan && !ui.state.plan.pro && (ui.state.plan.accounts ?? []).length >= 1;
    $('#csv-account-note').hidden = !limited;
    $('#csv-account-note').textContent = limited
      ? `A new account. The free plan checks agent purchases against one account${freeAcct ? ` (${freeAcct})` : ''}: this file is still imported and listed in full, and with Pro it checks them too.` : '';
  };
  field.oninput = note;
  note();
  for (const r of $$('#csv-sign input')) {
    r.onchange = () => guard(async () => {
      preview = await api('POST', '/api/import/csv/preview', { csv, spendSign: r.value });
      show();
    });
  }
  dlg.returnValue = '';
  dlg.showModal();
  dlg.onclose = () => guard(async () => {
    if (dlg.returnValue !== 'import') return;
    const r = await api('POST', '/api/import/csv', { csv, spendSign: preview.spendSign, account: $('#csv-account').value.trim() || 'My bank' });
    await refresh();
    toast(importReport(r));
  });
}

/** What a bank import found, in one line (POLISH-RESEARCH #11): what's new, what it checked,
 *  what's left for you. "3 new bank lines · 2 checked an agent's report · 1 to sort." */
function importReport(r) {
  const n = (count, one, many = `${one}s`) => `${count} ${count === 1 ? one : many}`;
  const lines = r.inserted + r.merged;
  const parts = [lines ? n(lines, 'new bank line') : 'No new bank lines'];
  if (r.checked) parts.push(`${r.checked} checked ${r.checked === 1 ? "an agent's report" : "agents' reports"}`);
  if (r.candidates) parts.push(`${r.candidates} to sort`);
  if (r.auto) parts.push(`${r.auto} sorted by your rules`);
  if (r.duplicates) parts.push(`${r.duplicates} already here`);
  const limit = r.verifies === false ? ` ${r.account}'s lines are kept and listed; with Pro they check agent purchases too.` : '';
  return `${parts.join(' · ')}.${limit}`;
}

// ── wiring ───────────────────────────────────────────────────────────────────

$('#sure-btn').addEventListener('click', () => guard(confirmSure));

for (const b of $$('#bucket-seg button')) {
  b.addEventListener('click', () => guard(async () => { ui.bucket = b.dataset.bucket; await renderPurchases(); }));
}
for (const a of $$('[data-go="pro"]')) a.addEventListener('click', (e) => { e.preventDefault(); goPro(); });

$('#share-btn').addEventListener('click', async () => {
  // The card is drawn in the app's face; wait for it so the PNG never falls back to another font.
  try { await Promise.all([document.fonts.load('800 120px "Schibsted Grotesk"'), document.fonts.load('500 50px "Schibsted Grotesk"')]); } catch { /* draw with the fallback */ }
  drawShareCard();
  $('#share-dialog').showModal();
});
for (const b of $$('#share-size button')) {
  b.addEventListener('click', () => {
    share.size = b.dataset.size;
    for (const x of $$('#share-size button')) x.setAttribute('aria-selected', String(x === b));
    drawShareCard();
  });
}
$('#share-names').addEventListener('change', (e) => { share.names = e.target.checked; drawShareCard(); });
$('#share-copy').addEventListener('click', () => guard(async () => {
  await navigator.clipboard.writeText(shareText(shareFacts()));
  await countShare('copy');
  toast('Copied.');
}));
$('#share-download').addEventListener('click', () => guard(async () => {
  const href = URL.createObjectURL(await shareBlob());
  const a = h('a', { href, download: `my-agents-${ui.state.headline.this_month.month}.png` });
  document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(href), 5000);
  await countShare('download');
}));
$('#share-go').addEventListener('click', () => guard(async () => {
  const file = new File([await shareBlob()], 'my-agents.png', { type: 'image/png' });
  const data = { files: [file], text: shareText(shareFacts()) };
  if (navigator.canShare?.(data)) {
    try { await navigator.share(data); await countShare('share_sheet'); } catch { /* the user closed the sheet */ }
  } else {
    $('#share-download').click();
    toast('Saved the image. Post it anywhere with the copied text.');
    await navigator.clipboard.writeText(data.text).catch(() => {});
  }
}));

$('#pro-form').addEventListener('submit', (e) => {
  e.preventDefault();
  guard(async () => {
    const s = await api('POST', '/api/pro/activate', { key: $('#pro-key').value });
    $('#pro-key').value = '';
    await refresh();
    toast(`Pro is on: ${s.seats} seat${s.seats === 1 ? '' : 's'}. Thank you.`);
  });
});
$('#pro-deactivate').addEventListener('click', () => guard(async () => {
  await api('POST', '/api/pro/deactivate', {});
  await refresh();
  toast('Pro removed from this computer. Your data and everything free are untouched.');
}));
$('#statement-period').addEventListener('change', (e) => statementGuard(async () => { statement.period = e.target.value; await loadStatement(); }));
$('#statement-pdf').addEventListener('click', () => statementGuard(() => downloadStatement('statement.pdf')));
$('#statement-csv').addEventListener('click', () => statementGuard(() => downloadStatement('statement.csv')));
$('#statement-lines-csv').addEventListener('click', () => statementGuard(() => downloadStatement('invoice-lines.csv')));
$('#statement-bill').addEventListener('click', () => statementGuard(async () => {
  const st = statement.data;
  const reference = $('#statement-invoice').value.trim();
  if (!reference) { $('#statement-invoice').focus(); throw new Error('Type the invoice number these lines were billed on.'); }
  // Exactly the lines and amounts on screen: anything that changed since is refused, never billed blind.
  const r = await api('POST', `/api/clients/${st.client.id}/bill`, { reference, period: st.period.key, lines: st.lines.map((l) => ({ id: l.id, cents: l.cents })) });
  $('#statement-invoice').value = '';
  await loadStatement();
  say(`Marked ${r.lines} line${r.lines === 1 ? '' : 's'} billed on ${r.reference}. You can undo it below.`);
  await refresh();
}));
$('#statement-save').addEventListener('click', () => statementGuard(async () => {
  await api('PUT', '/api/business', { name: $('#statement-business').value });
  await api('PATCH', `/api/clients/${statement.clientId}`, { markup: $('#statement-fee').value });
  await loadStatement();
  say('Saved.');
  await refresh();
}));
// Enter in a field acts on it; it never submits the dialog's form (which would close it).
for (const [field, button] of [['#statement-invoice', '#statement-bill'], ['#statement-business', '#statement-save'], ['#statement-fee', '#statement-save']]) {
  $(field).addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); $(button).click(); } });
}

$('#taxpack-form').addEventListener('submit', (e) => {
  e.preventDefault();
  guard(async () => {
    const year = $('#taxpack-year').value;
    const res = await fetch(`/api/taxpack?year=${year}`, { headers: { 'X-Ledger-Token': TOKEN } });
    if (!res.ok) throw Object.assign(new Error((await res.json().catch(() => ({}))).error || `Tax pack failed (${res.status})`), { status: res.status });
    const href = URL.createObjectURL(await res.blob());
    const a = h('a', { href, download: `Twinslip-tax-pack-${year}.zip` });
    document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(href), 5000);
    toast(`Saved your ${year} tax pack.`);
  });
});
$('#agent-snippet-copy').addEventListener('click', () => guard(async () => {
  await navigator.clipboard.writeText($('#agent-snippet').textContent);
  toast('Copied. Paste it into your agent app’s custom instructions.');
}));
$('#setup-hide').addEventListener('click', () => guard(async () => {
  await api('POST', '/api/onboarding/dismiss', {});
  await refresh();
  toast('Hidden. Everything it showed is still in Settings.');
}));

/** [from, to) for the export period picker, from the ledger's own idea of "this month". */
function exportRange(period) {
  const cur = ui.state.headline.this_month.month;
  const year = Number(cur.slice(0, 4));
  if (period === 'last_month') return [`${addMonths(cur, -1)}-01`, `${cur}-01`];
  if (period === 'this_year') return [`${year}-01-01`, `${addMonths(cur, 1)}-01`];
  if (period === 'last_year') return [`${year - 1}-01-01`, `${year}-01-01`];
  if (period === 'all') return ['2000-01-01', `${addMonths(cur, 1)}-01`];
  return [`${cur}-01`, `${addMonths(cur, 1)}-01`];
}

$('#export-form').addEventListener('submit', (e) => {
  e.preventDefault();
  guard(async () => {
    const format = new FormData(e.target).get('format');
    const [from, to] = exportRange($('#export-period').value);
    const res = await fetch(`/api/export?${new URLSearchParams({ format, from, to })}`, { headers: { 'X-Ledger-Token': TOKEN } });
    if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || `Export failed (${res.status})`);
    const name = /filename="([^"]+)"/.exec(res.headers.get('Content-Disposition') ?? '')?.[1] ?? 'twinslip.csv';
    const rows = Number(res.headers.get('X-Export-Rows') ?? 0);
    const skipped = Object.entries(JSON.parse(res.headers.get('X-Export-Skipped') || '{}'));
    const href = URL.createObjectURL(new Blob([await res.text()], { type: 'text/csv' }));
    const a = h('a', { href, download: name });
    document.body.append(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(href), 5000);
    toast(`Saved ${name}: ${rows} purchase${rows === 1 ? '' : 's'}.` +
      (skipped.length ? ` Left out ${skipped.map(([c, n]) => `${n} in ${c}`).join(', ')}: ${format === 'ynab' ? 'YNAB' : 'Lunch Money'} files hold one currency.` : ''), [], { ms: 9000 });
  });
});

// Inbox keys: J/K or arrows move, 1/2 pick the first/second guess, N not an agent.
document.addEventListener('keydown', (e) => {
  if (!ui.inboxOpen || $('#inbox-card').hidden || e.metaKey || e.ctrlKey || e.altKey) return;
  if (e.target.closest('input, select, textarea, dialog')) return;
  const p = ui.inbox[ui.focus];
  const key = e.key.toLowerCase();
  if (key === 'j' || key === 'arrowdown') ui.focus = Math.min(ui.focus + 1, ui.inbox.length - 1);
  else if (key === 'k' || key === 'arrowup') ui.focus = Math.max(ui.focus - 1, 0);
  else if (p && !p.over_limit && (key === '1' || key === '2') && p.guesses?.[Number(key) - 1]) guard(() => confirm(p, p.guesses[Number(key) - 1].agent_id));
  else if (p && key === 'n') guard(() => reject(p));
  else return;
  e.preventDefault();
  markFocus();
});

$('#needs-banner').addEventListener('click', () => guard(async () => {
  ui.inboxOpen = !ui.inboxOpen;
  await renderInbox();
}));
$('#inbox-done-close').addEventListener('click', () => guard(async () => {
  ui.inboxDone = false;
  await renderInbox();
}));
const menu = $('#menu');
addEventListener('hashchange', () => {
  menu.open = false;
  for (const d of ['#share-dialog', '#statement-dialog']) if ($(d).open) $(d).close();
  scrollTo(0, 0);
  guard(refresh);
});
document.addEventListener('click', (e) => { if (menu.open && !menu.contains(e.target)) menu.open = false; });
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && menu.open) { menu.open = false; menu.querySelector('summary').focus(); }
});

$('#first-agent-form').addEventListener('submit', (e) => {
  e.preventDefault();
  guard(async () => { await api('POST', '/api/agents', { name: $('#first-agent-name').value }); await refresh(); });
});
$('#agent-form').addEventListener('submit', (e) => {
  e.preventDefault();
  guard(async () => {
    await api('POST', '/api/agents', { name: $('#agent-name').value });
    $('#agent-name').value = '';
    await refresh();
  });
});
for (const input of $$('.csv-input')) {
  input.addEventListener('change', (e) => guard(async () => { await startCsv(e.target.files[0]); e.target.value = ''; }));
}
for (const b of $$('.seg button')) {
  b.addEventListener('click', () => guard(async () => {
    ui.period = b.dataset.period;
    for (const x of $$('.seg button')) x.setAttribute('aria-selected', String(x === b));
    await renderTotals();
  }));
}
let searchTimer = null;
$('#search-q').addEventListener('input', () => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(() => guard(renderPurchases), 250);
});
$('#search-form').addEventListener('submit', (e) => { e.preventDefault(); guard(renderPurchases); });
$('#month-prev').addEventListener('click', () => guard(async () => { ui.month = addMonths(ui.month, -1); await renderPurchases(); }));
$('#month-next').addEventListener('click', () => guard(async () => { ui.month = addMonths(ui.month, 1); await renderPurchases(); }));
$('#activity-form').addEventListener('submit', (e) => {
  e.preventDefault();
  guard(async () => {
    const { activity } = await api('GET', `/api/activity?q=${encodeURIComponent($('#activity-q').value)}`);
    $('#activity').replaceChildren(...(activity.length ? activity.map((p) => h('li', {},
      h('div', { class: 'who' }, h('div', { class: 'm', text: p.merchant }), h('div', { class: 'd', text: shortDate(p.occurred_on) })),
      h('div', { class: 'amt', text: money(p.amount_cents, p.currency) }),
      h('button', {
        class: 'ghost',
        onclick: () => guard(async () => { await api('POST', `/api/purchases/${p.id}/pull-in`, {}); await refresh(); toast(`${p.merchant} moved to “Needs a look”.`); $('#activity-form').requestSubmit(); }),
      }, 'Pull in'))) : [h('li', { class: 'muted small' }, 'No matching bank activity.')]));
  });
});
$('#manual-date').value = today();
$('#refund-form').addEventListener('submit', (e) => {
  e.preventDefault();
  guard(async () => {
    await api('POST', '/api/refunds', {
      merchant: $('#refund-merchant').value, amount: $('#refund-amount').value, dueOn: $('#refund-due').value,
      note: $('#refund-note').value, purchaseId: $('#refund-purchase').value ? Number($('#refund-purchase').value) : null,
    });
    for (const f of ['#refund-merchant', '#refund-amount', '#refund-note', '#refund-purchase']) $(f).value = '';
    await renderRefunds();
    toast("Noted. It won't change any total; your bank's refund line will settle it.");
  });
});
$('#first-expense-date').value = today();
$('#first-expense-form').addEventListener('submit', (e) => {
  e.preventDefault();
  guard(async () => {
    await api('POST', '/api/purchases', { date: $('#first-expense-date').value, amount: $('#first-expense-amount').value, merchant: $('#first-expense-merchant').value, agentId: null });
    $('#first-expense-amount').value = '';
    $('#first-expense-merchant').value = '';
    await refresh();
    toast('Added to Mine.');
  });
});
$('#manual-form').addEventListener('submit', (e) => {
  e.preventDefault();
  guard(async () => {
    await api('POST', '/api/purchases', {
      date: $('#manual-date').value,
      amount: $('#manual-amount').value,
      merchant: $('#manual-merchant').value,
      agentId: $('#manual-agent').value ? Number($('#manual-agent').value) : null,
    });
    $('#manual-amount').value = '';
    $('#manual-merchant').value = '';
    await refresh();
    toast($('#manual-agent').value ? 'Added.' : 'Added to Mine.');
  });
});
$('#report-btn').addEventListener('click', () => guard(async () => {
  const r = await api('GET', '/api/report');
  $('#report').textContent = JSON.stringify(r, null, 2);
  $('#report-wrap').hidden = false;
}));
// Feedback without a server: copy the counts-only report, then open the tester's own email
// app with a short message. They pick the recipient and see everything before sending.
$('#feedback-btn').addEventListener('click', () => guard(async () => {
  const r = await api('GET', '/api/report');
  let copied = true;
  try { await navigator.clipboard.writeText(JSON.stringify(r, null, 2)); } catch { copied = false; }
  const body = [
    'What worked, what annoyed you, what you expected to happen:',
    '', '', '',
    copied ? 'Beta report (counts only, no merchants, amounts or names). It is on your clipboard: paste it below this line.'
      : 'Beta report: open Settings > Show beta report in Twinslip, copy it, and paste it below this line.',
    '',
  ].join('\n');
  location.href = `mailto:?subject=${encodeURIComponent('Twinslip beta feedback')}&body=${encodeURIComponent(body)}`;
  toast(copied ? 'Opening your email. Your beta report is on the clipboard: paste it in.' : 'Opening your email.', [], { ms: 9000 });
}));
$('#report-copy').addEventListener('click', () => guard(async () => {
  await navigator.clipboard.writeText($('#report').textContent);
  toast('Copied. Paste it wherever you send beta feedback.');
}));

for (const b of $$('.copy-cmd')) {
  b.addEventListener('click', () => guard(async () => {
    await navigator.clipboard.writeText(b.parentElement.querySelector('code').textContent);
    toast('Copied. Paste it into a terminal.');
  }));
}

// Live: the server pushes "change" whenever an agent (or a sync) writes to the ledger.
let liveTimer = null;
function connectLive() {
  const es = new EventSource('/api/live');
  es.onopen = () => { $('#live').hidden = false; };
  es.onerror = () => { $('#live').hidden = true; };
  es.addEventListener('change', () => {
    clearTimeout(liveTimer);
    liveTimer = setTimeout(() => guard(refresh), 250);
  });
}

guard(refresh);
connectLive();

for (const b of $$('.handoff-copy')) b.addEventListener('click', copyHandoff);
